# Snapshot do Renum Backend Legado

## Visão Geral

Este diretório contém um snapshot limpo do `renum-backend` extraído do repositório legado `renum-suna-core`. O conteúdo foi importado usando `git archive` para preservar apenas os arquivos sem histórico de commits.

## Estrutura Importada

### Diretório Principal: `renum-backend/`

#### Aplicação (`app/`)
- **API Routes** (`api/routes/`): 18 endpoints incluindo teams, executions, auth, webhooks, websocket
- **Services** (`services/`): 40+ serviços incluindo orchestrator, suna client, notification service
- **Models** (`models/`): Schemas Pydantic para teams, auth, agents, websocket
- **Core** (`core/`): Configurações, logging, auth utilities
- **Database** (`db/`): Configuração Supabase
- **Middleware** (`middleware/`): Auth, logging, security middlewares

#### Documentação (`docs/`)
- Architecture, Development, Installation, Usage guides

#### Scripts (`scripts/`)
- 30+ scripts para setup, migration, testing, deployment
- SQL schemas para Supabase
- Integration verification scripts

#### Testes (`tests/`)
- 50+ arquivos de teste cobrindo API, services, integration
- Testes de performance, security, deployment

## Tecnologias Identificadas

### Framework & Core
- **FastAPI** 0.115.12 - Framework web principal
- **Uvicorn** 0.27.1 - ASGI server
- **Pydantic** - Validação e serialização de dados

### Banco de Dados & Auth
- **Supabase** 2.17.0 - PostgreSQL + Auth + Real-time
- **JWT** 2.10.1 - Autenticação baseada em tokens

### Integrações
- **httpx** 0.28.0 - Cliente HTTP para Suna Backend
- **websockets** 13.1 - Comunicação em tempo real
- **Redis** 5.0.0 - Cache e sessões

### Observabilidade
- **structlog** 25.4.0 - Logging estruturado
- **prometheus-client** 0.21.1 - Métricas

## Funcionalidades Principais

### 1. **Gerenciamento de Teams**
- CRUD completo de equipes de agentes
- Suporte a workflows: sequential, parallel, conditional, pipeline
- Configuração de papéis e permissões

### 2. **Execução de Workflows**
- Orquestração de execução de agentes
- Monitoramento em tempo real via WebSocket
- Sistema de logs e métricas detalhadas

### 3. **Integração Suna Backend**
- Cliente robusto para comunicação com Suna API
- Proxy transparente para endpoints Suna
- Tratamento de erros e retry policies

### 4. **Sistema de Notificações**
- Notificações em tempo real via WebSocket
- Sistema de canais e salas
- Persistência de notificações

### 5. **Autenticação & Segurança**
- Integração com Supabase Auth
- Middleware de autenticação JWT
- Rate limiting e security headers

## Endpoints Críticos Identificados

### Core API
- `POST/GET/PUT/DELETE /teams` - Gerenciamento de equipes
- `POST /teams/{id}/execute` - Execução de workflows
- `GET /executions/{id}` - Status de execução
- `WS /ws` - WebSocket para tempo real

### Integrações
- `GET /agents` - Proxy para Suna (listar agentes)
- `POST /agents/{id}/execute` - Proxy para Suna (executar agente)
- `POST /webhooks/{integration_id}` - Receber webhooks

### Auth & Admin
- `POST /auth/login` - Autenticação
- `GET /health` - Health checks
- `GET /notifications` - Sistema de notificações

## Configurações Críticas

### Suna Backend Integration
```
SUNA_API_URL=http://157.180.39.41:8000/api
SUNA_WS_URL=ws://157.180.39.41:8000/ws
```

### Supabase Configuration
- URL, anon key, service key necessários
- RLS policies implementadas
- Schemas customizados para teams, executions, notifications

## Qualidade do Código

### Pontos Fortes
- ✅ Arquitetura bem estruturada com separação de responsabilidades
- ✅ Testes abrangentes (50+ arquivos de teste)
- ✅ Documentação detalhada
- ✅ Logging estruturado
- ✅ Error handling robusto
- ✅ Configuração via environment variables

### Áreas de Melhoria
- 🔄 Muitos arquivos de configuração duplicados
- 🔄 Alguns serviços muito acoplados
- 🔄 Falta de type hints em alguns módulos
- 🔄 Configuração de deployment complexa

## Estratégia de Migração

### Alta Prioridade (Migrar primeiro)
1. **Core API** - teams.py, team_executions.py, auth.py
2. **Suna Integration** - suna_api_client.py → infra/suna/
3. **Database** - supabase_service.py → infra/supabase/
4. **Schemas** - team_models.py → schemas/

### Média Prioridade
1. **WebSocket** - websocket_manager.py → infra/websocket/
2. **Notifications** - notification_service.py
3. **Webhooks** - webhook_service.py

### Baixa Prioridade (Avaliar necessidade)
1. **RAG System** - rag/ directory
2. **Billing** - billing_manager.py
3. **Advanced Security** - security middlewares

## Dependências Externas

### Críticas
- **Suna Backend** (157.180.39.41:8000) - Sistema de agentes
- **Supabase** - Banco de dados e autenticação

### Opcionais
- **Redis** - Cache e sessões (pode ser substituído)
- **Prometheus** - Métricas (pode ser removido inicialmente)

## Próximos Passos

1. **Análise detalhada** dos endpoints mais críticos
2. **Mapeamento de dependências** entre módulos
3. **Identificação de breaking changes** necessários
4. **Plano de migração incremental** por funcionalidade
5. **Setup de ambiente** de desenvolvimento

## Notas Importantes

- ⚠️ **Não fazer push** deste conteúdo para o repositório remoto
- ⚠️ **Manter apenas localmente** para análise e migração
- ⚠️ **Remover após migração** completa aprovada
- ✅ **Usar apenas como referência** para nova implementação

---

**Data do Snapshot**: 15/08/2025  
**Fonte**: https://github.com/rcarraroia/renum-suna-core.git  
**Branch**: main  
**Commit**: HEAD (último commit disponível)