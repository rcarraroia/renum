# Renum Backend

Backend para a Plataforma Renum Suna, incluindo o sistema de Equipes de Agentes.

## Visão Geral

O Renum Backend é responsável por gerenciar equipes de agentes de IA, permitindo que usuários criem, configurem e executem equipes coordenadas para resolver tarefas complexas que requerem múltiplas especialidades.

## Status do Projeto

✅ **Sistema implementado com sucesso!** Todos os componentes principais estão funcionais.

### Documentação Completa
- [Resumo da Implementação](./IMPLEMENTATION_SUMMARY.md)
- [Instruções de Execução](./EXECUTION_INSTRUCTIONS.md)
- [Documentação da API](./API_DOCUMENTATION.md)
- [Conclusão](./CONCLUSAO.md)

## Funcionalidades Principais

- ✅ Criação e gerenciamento de equipes de agentes
- ✅ Execução com múltiplas estratégias (sequencial, paralelo, condicional, pipeline)
- ✅ Monitoramento em tempo real
- ✅ Contexto compartilhado entre agentes
- ✅ Sistema de mensagens
- ✅ Gerenciamento seguro de API keys
- ✅ Integração com Suna Core

## Início Rápido

### Docker (Recomendado)
```bash
git clone https://github.com/renum/renum-backend.git
cd renum-backend
cp .env.example .env
# Configure suas variáveis de ambiente
docker-compose up -d
```

### Instalação Local
```bash
git clone https://github.com/renum/renum-backend.git
cd renum-backend
python -m venv venv
source venv/bin/activate  # Linux/Mac
pip install -r requirements.txt
cp .env.example .env
# Configure suas variáveis de ambiente
python scripts/apply_team_tables.py
python scripts/run_server.py
```

## Documentação Detalhada

- 📖 [Instalação Completa](./docs/INSTALLATION.md)
- 🚀 [Guia de Uso](./docs/USAGE.md)
- 🛠️ [Desenvolvimento](./docs/DEVELOPMENT.md)

## API

- **URL**: `http://localhost:9000/api/v1`
- **Docs**: `http://localhost:9000/docs`

## Licença

Proprietary - Todos os direitos reservados.