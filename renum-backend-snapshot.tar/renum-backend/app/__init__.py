"""
Pacote principal do Backend Renum.

Este pacote contém os módulos do Backend Renum.
"""