"""
Pacote de API do Backend Renum.

Este pacote contém os módulos da API do Backend Renum.
"""