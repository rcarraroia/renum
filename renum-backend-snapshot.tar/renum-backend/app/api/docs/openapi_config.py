"""
Configuração OpenAPI/Swagger para documentação da API.

Este módulo configura a documentação automática da API com exemplos,
descrições detalhadas e informações de autenticação.
"""

from fastapi import FastAPI
from fastapi.openapi.utils import get_openapi
from typing import Dict, Any


def custom_openapi(app: FastAPI) -> Dict[str, Any]:
    """
    Gera documentação OpenAPI customizada.
    
    Args:
        app: Instância da aplicação FastAPI
        
    Returns:
        Dict: Schema OpenAPI customizado
    """
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title="Suna Webhook Integrations API",
        version="1.0.0",
        description="""
# Suna Webhook Integrations API

API completa para gerenciamento de integrações webhook com agentes Suna.

## Visão Geral

Esta API permite que sistemas externos se integrem com agentes Suna através de webhooks,
fornecendo funcionalidades para:

- **Criação e gerenciamento de integrações**
- **Execução de agentes via webhook**
- **Monitoramento e analytics**
- **Rate limiting e segurança**
- **Múltiplos canais de integração**

## Autenticação

A API utiliza autenticação Bearer Token para webhooks:

```
Authorization: Bearer whk_your_webhook_token_here
```

Para endpoints de gerenciamento, utilize autenticação de usuário padrão.

## Rate Limiting

Todos os endpoints de webhook possuem rate limiting configurável por integração.
Headers de resposta informam o status atual:

- `X-RateLimit-Limit`: Limite de requisições por minuto
- `X-RateLimit-Remaining`: Requisições restantes
- `X-RateLimit-Reset`: Timestamp de reset do limite

## Canais Suportados

- **WhatsApp**: Integração com WhatsApp Business API
- **Telegram**: Bot do Telegram
- **Zapier**: Automação via Zapier
- **n8n**: Workflows n8n
- **Make**: Cenários Make (Integromat)
- **Custom**: Integrações personalizadas

## Códigos de Status

- `200`: Sucesso
- `400`: Payload inválido ou erro de validação
- `401`: Token não fornecido
- `403`: Token inválido ou não autorizado
- `429`: Rate limit excedido
- `500`: Erro interno do servidor

## Exemplos de Uso

### Webhook WhatsApp
```bash
curl -X POST "https://api.suna.com/webhook/agent-id/whatsapp" \\
  -H "Authorization: Bearer whk_your_token" \\
  -H "Content-Type: application/json" \\
  -d '{
    "message": "Olá, como você está?",
    "phone": "+5511999999999",
    "message_type": "text"
  }'
```

### Webhook Zapier
```bash
curl -X POST "https://api.suna.com/webhook/agent-id/zapier" \\
  -H "Authorization: Bearer whk_your_token" \\
  -H "Content-Type: application/json" \\
  -d '{
    "trigger_event": "new_contact",
    "data": {
      "name": "João Silva",
      "email": "joao@example.com"
    }
  }'
```
        """,
        routes=app.routes,
    )
    
    # Adicionar informações de segurança
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
            "description": "Token de webhook no formato: whk_..."
        },
        "UserAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
            "description": "Token de autenticação de usuário"
        }
    }
    
    # Adicionar informações do servidor
    openapi_schema["servers"] = [
        {
            "url": "https://api.suna.com",
            "description": "Servidor de produção"
        },
        {
            "url": "https://staging-api.suna.com",
            "description": "Servidor de staging"
        },
        {
            "url": "http://localhost:8000",
            "description": "Servidor de desenvolvimento"
        }
    ]
    
    # Adicionar informações de contato
    openapi_schema["info"]["contact"] = {
        "name": "Suporte Suna",
        "url": "https://suna.com/support",
        "email": "support@suna.com"
    }
    
    openapi_schema["info"]["license"] = {
        "name": "MIT",
        "url": "https://opensource.org/licenses/MIT"
    }
    
    # Adicionar tags para organização
    openapi_schema["tags"] = [
        {
            "name": "webhooks",
            "description": "Endpoints de webhook para execução de agentes"
        },
        {
            "name": "integrations",
            "description": "Gerenciamento de integrações"
        },
        {
            "name": "monitoring",
            "description": "Monitoramento e analytics"
        },
        {
            "name": "health",
            "description": "Health checks e status do sistema"
        },
        {
            "name": "security",
            "description": "Segurança e monitoramento de ameaças"
        }
    ]
    
    # Adicionar exemplos para schemas comuns
    if "components" not in openapi_schema:
        openapi_schema["components"] = {}
    
    if "examples" not in openapi_schema["components"]:
        openapi_schema["components"]["examples"] = {}
    
    # Exemplos de payloads por canal
    openapi_schema["components"]["examples"].update({
        "WhatsAppPayloadExample": {
            "summary": "Exemplo de payload WhatsApp",
            "description": "Payload típico para integração WhatsApp",
            "value": {
                "message": "Olá! Preciso de ajuda com meu pedido.",
                "phone": "+5511999999999",
                "message_type": "text",
                "timestamp": "2024-01-15T10:30:00Z"
            }
        },
        "TelegramPayloadExample": {
            "summary": "Exemplo de payload Telegram",
            "description": "Payload típico para bot Telegram",
            "value": {
                "message": "Como posso verificar meu saldo?",
                "chat_id": 123456789,
                "user_id": 987654321,
                "username": "usuario_exemplo"
            }
        },
        "ZapierPayloadExample": {
            "summary": "Exemplo de payload Zapier",
            "description": "Payload típico de automação Zapier",
            "value": {
                "trigger_event": "new_contact",
                "data": {
                    "name": "Maria Santos",
                    "email": "maria@empresa.com",
                    "company": "Empresa XYZ",
                    "phone": "+5511888888888"
                },
                "zap_id": "zap_12345",
                "user_email": "usuario@zapier.com"
            }
        },
        "N8nPayloadExample": {
            "summary": "Exemplo de payload n8n",
            "description": "Payload típico de workflow n8n",
            "value": {
                "workflow_id": "workflow_abc123",
                "execution_id": "exec_def456",
                "data": {
                    "customer_id": "cust_789",
                    "action": "purchase_completed",
                    "amount": 299.99,
                    "currency": "BRL"
                },
                "node_name": "webhook_trigger"
            }
        },
        "MakePayloadExample": {
            "summary": "Exemplo de payload Make",
            "description": "Payload típico de cenário Make",
            "value": {
                "scenario_id": "scenario_xyz789",
                "execution_id": "exec_abc123",
                "data": {
                    "lead_id": "lead_456",
                    "source": "website_form",
                    "score": 85,
                    "tags": ["hot_lead", "enterprise"]
                },
                "module_name": "webhook_receiver"
            }
        },
        "SuccessResponseExample": {
            "summary": "Resposta de sucesso",
            "description": "Exemplo de resposta bem-sucedida do webhook",
            "value": {
                "success": True,
                "data": {
                    "response": "Olá! Recebi sua mensagem. Como posso ajudar você hoje?",
                    "agent_id": "agent_123",
                    "execution_id": "exec_456"
                },
                "execution_time_ms": 250
            }
        },
        "ErrorResponseExample": {
            "summary": "Resposta de erro",
            "description": "Exemplo de resposta de erro",
            "value": {
                "success": False,
                "error": "Token inválido ou agente não autorizado",
                "code": "INVALID_TOKEN",
                "details": {
                    "agent_id": "agent_123",
                    "timestamp": "2024-01-15T10:30:00Z"
                }
            }
        }
    })
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema


def setup_api_docs(app: FastAPI):
    """
    Configura documentação da API.
    
    Args:
        app: Instância da aplicação FastAPI
    """
    
    # Configurar OpenAPI customizado
    app.openapi = lambda: custom_openapi(app)
    
    # Configurar metadados da aplicação
    app.title = "Suna Webhook Integrations API"
    app.description = "API para integrações webhook com agentes Suna"
    app.version = "1.0.0"
    
    # Configurar URLs de documentação
    app.docs_url = "/docs"
    app.redoc_url = "/redoc"
    app.openapi_url = "/openapi.json"