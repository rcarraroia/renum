"""
Exceções específicas para webhooks de integrações.

Este módulo define exceções customizadas para diferentes tipos de erro
que podem ocorrer durante o processamento de webhooks.
"""

from typing import Optional, Dict, Any


class WebhookException(Exception):
    """Exceção base para erros de webhook."""
    
    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        status_code: int = 400,
        details: Optional[Dict[str, Any]] = None
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.status_code = status_code
        self.details = details or {}


class WebhookAuthenticationError(WebhookException):
    """Erro de autenticação de webhook."""
    
    def __init__(
        self,
        message: str = "Token de autenticação requerido",
        error_code: str = "AUTHENTICATION_REQUIRED",
        details: Optional[Dict[str, Any]] = None
    ):
        super().__init__(
            message=message,
            error_code=error_code,
            status_code=401,
            details=details
        )


class WebhookAuthorizationError(WebhookException):
    """Erro de autorização de webhook."""
    
    def __init__(
        self,
        message: str = "Token inválido ou agente não autorizado",
        error_code: str = "AUTHORIZATION_FAILED",
        details: Optional[Dict[str, Any]] = None
    ):
        super().__init__(
            message=message,
            error_code=error_code,
            status_code=403,
            details=details
        )


class WebhookRateLimitError(WebhookException):
    """Erro de rate limiting de webhook."""
    
    def __init__(
        self,
        message: str = "Rate limit excedido",
        error_code: str = "RATE_LIMIT_EXCEEDED",
        retry_after: int = 60,
        details: Optional[Dict[str, Any]] = None
    ):
        details = details or {}
        details["retry_after"] = retry_after
        
        super().__init__(
            message=message,
            error_code=error_code,
            status_code=429,
            details=details
        )


class WebhookValidationError(WebhookException):
    """Erro de validação de payload de webhook."""
    
    def __init__(
        self,
        message: str = "Payload inválido",
        error_code: str = "VALIDATION_ERROR",
        field: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        details = details or {}
        if field:
            details["field"] = field
        
        super().__init__(
            message=message,
            error_code=error_code,
            status_code=400,
            details=details
        )


class WebhookAgentError(WebhookException):
    """Erro relacionado ao agente."""
    
    def __init__(
        self,
        message: str = "Erro no agente",
        error_code: str = "AGENT_ERROR",
        agent_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        details = details or {}
        if agent_id:
            details["agent_id"] = agent_id
        
        super().__init__(
            message=message,
            error_code=error_code,
            status_code=422,
            details=details
        )


class WebhookExecutionError(WebhookException):
    """Erro durante a execução do agente."""
    
    def __init__(
        self,
        message: str = "Erro na execução do agente",
        error_code: str = "EXECUTION_ERROR",
        execution_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        details = details or {}
        if execution_id:
            details["execution_id"] = execution_id
        
        super().__init__(
            message=message,
            error_code=error_code,
            status_code=500,
            details=details
        )


class WebhookTimeoutError(WebhookException):
    """Erro de timeout na execução."""
    
    def __init__(
        self,
        message: str = "Timeout na execução do agente",
        error_code: str = "EXECUTION_TIMEOUT",
        timeout_seconds: Optional[int] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        details = details or {}
        if timeout_seconds:
            details["timeout_seconds"] = timeout_seconds
        
        super().__init__(
            message=message,
            error_code=error_code,
            status_code=504,
            details=details
        )


class WebhookServiceUnavailableError(WebhookException):
    """Erro de serviço indisponível."""
    
    def __init__(
        self,
        message: str = "Serviço temporariamente indisponível",
        error_code: str = "SERVICE_UNAVAILABLE",
        retry_after: int = 300,
        details: Optional[Dict[str, Any]] = None
    ):
        details = details or {}
        details["retry_after"] = retry_after
        
        super().__init__(
            message=message,
            error_code=error_code,
            status_code=503,
            details=details
        )


class WebhookInternalError(WebhookException):
    """Erro interno do servidor."""
    
    def __init__(
        self,
        message: str = "Erro interno do servidor",
        error_code: str = "INTERNAL_ERROR",
        details: Optional[Dict[str, Any]] = None
    ):
        super().__init__(
            message=message,
            error_code=error_code,
            status_code=500,
            details=details
        )