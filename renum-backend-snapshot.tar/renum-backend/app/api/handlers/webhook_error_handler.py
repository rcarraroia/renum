"""
Handler de erros para webhooks de integrações.

Este módulo implementa o tratamento centralizado de erros para webhooks,
incluindo logging, métricas e formatação de respostas.
"""

import logging
import time
import traceback
from typing import Dict, Any, Optional, Tuple
from uuid import UUID

from fastapi import Request
from fastapi.responses import JSONResponse

from app.api.exceptions.webhook_exceptions import (
    WebhookException,
    WebhookAuthenticationError,
    WebhookAuthorizationError,
    WebhookRateLimitError,
    WebhookValidationError,
    WebhookAgentError,
    WebhookExecutionError,
    WebhookTimeoutError,
    WebhookServiceUnavailableError,
    WebhookInternalError
)
from app.api.schemas.webhooks import WebhookErrorResponse

# Configurar logger
logger = logging.getLogger(__name__)


class WebhookErrorHandler:
    """Handler centralizado para erros de webhook."""
    
    def __init__(self):
        """Inicializa o handler de erros."""
        self.error_metrics = {}
    
    def log_error(
        self,
        error: Exception,
        request: Request,
        agent_id: Optional[UUID] = None,
        integration_id: Optional[UUID] = None,
        execution_time_ms: Optional[int] = None
    ):
        """
        Registra um erro no log com contexto completo.
        
        Args:
            error: Exceção ocorrida
            request: Requisição FastAPI
            agent_id: ID do agente (se disponível)
            integration_id: ID da integração (se disponível)
            execution_time_ms: Tempo de execução até o erro
        """
        # Obter informações da requisição
        client_ip = self._get_client_ip(request)
        user_agent = request.headers.get("User-Agent", "")
        
        # Preparar contexto do erro
        error_context = {
            "error_type": type(error).__name__,
            "error_message": str(error),
            "agent_id": str(agent_id) if agent_id else None,
            "integration_id": str(integration_id) if integration_id else None,
            "client_ip": client_ip,
            "user_agent": user_agent,
            "execution_time_ms": execution_time_ms,
            "timestamp": time.time()
        }
        
        # Log baseado no tipo de erro
        if isinstance(error, (WebhookAuthenticationError, WebhookAuthorizationError)):
            logger.warning(f"Erro de autenticação/autorização: {error_context}")
        elif isinstance(error, WebhookRateLimitError):
            logger.warning(f"Rate limit excedido: {error_context}")
        elif isinstance(error, WebhookValidationError):
            logger.info(f"Erro de validação: {error_context}")
        elif isinstance(error, (WebhookExecutionError, WebhookTimeoutError)):
            logger.error(f"Erro de execução: {error_context}", exc_info=True)
        elif isinstance(error, WebhookServiceUnavailableError):
            logger.error(f"Serviço indisponível: {error_context}")
        else:
            logger.error(f"Erro não categorizado: {error_context}", exc_info=True)
        
        # Atualizar métricas de erro
        self._update_error_metrics(error)
    
    def _get_client_ip(self, request: Request) -> str:
        """Obtém o IP do cliente considerando proxies."""
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        
        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip
        
        return request.client.host if request.client else "unknown"
    
    def _update_error_metrics(self, error: Exception):
        """Atualiza métricas de erro."""
        error_type = type(error).__name__
        
        if error_type not in self.error_metrics:
            self.error_metrics[error_type] = {
                "count": 0,
                "last_occurrence": None
            }
        
        self.error_metrics[error_type]["count"] += 1
        self.error_metrics[error_type]["last_occurrence"] = time.time()
    
    def handle_webhook_exception(
        self,
        error: WebhookException,
        request: Request,
        agent_id: Optional[UUID] = None,
        integration_id: Optional[UUID] = None,
        execution_time_ms: Optional[int] = None
    ) -> JSONResponse:
        """
        Trata exceções específicas de webhook.
        
        Args:
            error: Exceção de webhook
            request: Requisição FastAPI
            agent_id: ID do agente
            integration_id: ID da integração
            execution_time_ms: Tempo de execução
            
        Returns:
            JSONResponse: Resposta de erro formatada
        """
        # Log do erro
        self.log_error(error, request, agent_id, integration_id, execution_time_ms)
        
        # Preparar detalhes do erro
        details = error.details.copy()
        details.update({
            "agent_id": str(agent_id) if agent_id else None,
            "timestamp": time.time()
        })
        
        if execution_time_ms:
            details["execution_time_ms"] = execution_time_ms
        
        # Criar resposta de erro
        error_response = WebhookErrorResponse(
            error=error.message,
            code=error.error_code,
            details=details
        )
        
        # Preparar headers adicionais
        headers = {}
        
        # Headers específicos para rate limiting
        if isinstance(error, WebhookRateLimitError):
            headers["Retry-After"] = str(error.details.get("retry_after", 60))
            headers["X-RateLimit-Reset"] = str(int(time.time()) + error.details.get("retry_after", 60))
        
        # Headers para serviço indisponível
        elif isinstance(error, WebhookServiceUnavailableError):
            headers["Retry-After"] = str(error.details.get("retry_after", 300))
        
        return JSONResponse(
            status_code=error.status_code,
            content=error_response.dict(),
            headers=headers
        )
    
    def handle_generic_exception(
        self,
        error: Exception,
        request: Request,
        agent_id: Optional[UUID] = None,
        integration_id: Optional[UUID] = None,
        execution_time_ms: Optional[int] = None
    ) -> JSONResponse:
        """
        Trata exceções genéricas convertendo-as em WebhookInternalError.
        
        Args:
            error: Exceção genérica
            request: Requisição FastAPI
            agent_id: ID do agente
            integration_id: ID da integração
            execution_time_ms: Tempo de execução
            
        Returns:
            JSONResponse: Resposta de erro formatada
        """
        # Converter para WebhookInternalError
        internal_error = WebhookInternalError(
            message="Erro interno do servidor",
            details={
                "original_error": str(error),
                "error_type": type(error).__name__
            }
        )
        
        return self.handle_webhook_exception(
            internal_error,
            request,
            agent_id,
            integration_id,
            execution_time_ms
        )
    
    def classify_error(self, error: Exception) -> WebhookException:
        """
        Classifica uma exceção genérica em uma exceção específica de webhook.
        
        Args:
            error: Exceção a ser classificada
            
        Returns:
            WebhookException: Exceção classificada
        """
        error_message = str(error).lower()
        
        # Classificar por mensagem de erro
        if "token" in error_message and ("inválido" in error_message or "invalid" in error_message):
            return WebhookAuthorizationError(
                message=str(error),
                details={"original_error": str(error)}
            )
        
        elif "rate limit" in error_message or "too many requests" in error_message:
            return WebhookRateLimitError(
                message=str(error),
                details={"original_error": str(error)}
            )
        
        elif "timeout" in error_message or "timed out" in error_message:
            return WebhookTimeoutError(
                message=str(error),
                details={"original_error": str(error)}
            )
        
        elif "agente" in error_message and ("não encontrado" in error_message or "not found" in error_message):
            return WebhookAgentError(
                message=str(error),
                error_code="AGENT_NOT_FOUND",
                details={"original_error": str(error)}
            )
        
        elif "agente" in error_message and ("inativo" in error_message or "inactive" in error_message):
            return WebhookAgentError(
                message=str(error),
                error_code="AGENT_INACTIVE",
                details={"original_error": str(error)}
            )
        
        elif "connection" in error_message or "conexão" in error_message:
            return WebhookServiceUnavailableError(
                message="Serviço temporariamente indisponível",
                details={"original_error": str(error)}
            )
        
        elif "validation" in error_message or "validação" in error_message:
            return WebhookValidationError(
                message=str(error),
                details={"original_error": str(error)}
            )
        
        # Classificar por tipo de exceção
        elif isinstance(error, ValueError):
            return WebhookValidationError(
                message=str(error),
                details={"original_error": str(error)}
            )
        
        elif isinstance(error, PermissionError):
            return WebhookAuthorizationError(
                message=str(error),
                details={"original_error": str(error)}
            )
        
        elif isinstance(error, TimeoutError):
            return WebhookTimeoutError(
                message=str(error),
                details={"original_error": str(error)}
            )
        
        # Fallback para erro interno
        else:
            return WebhookInternalError(
                message="Erro interno do servidor",
                details={
                    "original_error": str(error),
                    "error_type": type(error).__name__
                }
            )
    
    def get_error_metrics(self) -> Dict[str, Any]:
        """
        Obtém métricas de erro.
        
        Returns:
            Dict: Métricas de erro
        """
        return {
            "error_counts": self.error_metrics,
            "total_errors": sum(metric["count"] for metric in self.error_metrics.values()),
            "last_updated": time.time()
        }
    
    def reset_error_metrics(self):
        """Reseta as métricas de erro."""
        self.error_metrics = {}


# Instância global do handler
webhook_error_handler = WebhookErrorHandler()


def handle_webhook_error(
    error: Exception,
    request: Request,
    agent_id: Optional[UUID] = None,
    integration_id: Optional[UUID] = None,
    execution_time_ms: Optional[int] = None
) -> JSONResponse:
    """
    Função utilitária para tratar erros de webhook.
    
    Args:
        error: Exceção ocorrida
        request: Requisição FastAPI
        agent_id: ID do agente
        integration_id: ID da integração
        execution_time_ms: Tempo de execução
        
    Returns:
        JSONResponse: Resposta de erro formatada
    """
    if isinstance(error, WebhookException):
        return webhook_error_handler.handle_webhook_exception(
            error, request, agent_id, integration_id, execution_time_ms
        )
    else:
        # Classificar e tratar erro genérico
        classified_error = webhook_error_handler.classify_error(error)
        return webhook_error_handler.handle_webhook_exception(
            classified_error, request, agent_id, integration_id, execution_time_ms
        )