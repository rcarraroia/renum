"""
Middleware avançado de segurança com headers, CORS e proteções adicionais.

Este módulo implementa proteções avançadas incluindo CSP, HSTS,
detecção de ataques, CORS configurável e monitoramento de segurança.
"""

import time
import json
import hashlib
import ipaddress
from typing import Callable, Dict, Any, Optional, List, Set
from urllib.parse import urlparse

from fastapi import Request, Response, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.cors import CORSMiddleware
from starlette.types import ASGIApp

from app.core.config import settings
from app.services.advanced_rate_limiting import get_advanced_rate_limiter, ThreatLevel


class AdvancedSecurityMiddleware(BaseHTTPMiddleware):
    """Middleware avançado de segurança."""
    
    def __init__(
        self,
        app: ASGIApp,
        enable_csp: bool = True,
        enable_hsts: bool = True,
        enable_attack_detection: bool = True,
        allowed_origins: List[str] = None,
        blocked_countries: List[str] = None,
        max_request_size: int = 10 * 1024 * 1024,  # 10MB
        enable_honeypot: bool = True
    ):
        """
        Inicializa o middleware de segurança avançado.
        
        Args:
            app: Aplicação ASGI
            enable_csp: Habilitar Content Security Policy
            enable_hsts: Habilitar HTTP Strict Transport Security
            enable_attack_detection: Habilitar detecção de ataques
            allowed_origins: Origens permitidas para CORS
            blocked_countries: Países bloqueados (códigos ISO)
            max_request_size: Tamanho máximo de requisição
            enable_honeypot: Habilitar honeypots para detectar bots
        """
        super().__init__(app)
        self.enable_csp = enable_csp
        self.enable_hsts = enable_hsts
        self.enable_attack_detection = enable_attack_detection
        self.allowed_origins = allowed_origins or []
        self.blocked_countries = set(blocked_countries or [])
        self.max_request_size = max_request_size
        self.enable_honeypot = enable_honeypot
        
        # Cache para otimização
        self._ip_cache: Dict[str, Dict[str, Any]] = {}
        self._cache_ttl = 300  # 5 minutos
        
        # Padrões de ataque conhecidos
        self.attack_patterns = {
            "sql_injection": [
                r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION)\b)",
                r"(--|#|/\*|\*/)",
                r"(\b(OR|AND)\s+\d+\s*=\s*\d+)"
            ],
            "xss": [
                r"<script[^>]*>.*?</script>",
                r"javascript:",
                r"on\w+\s*=",
                r"<iframe[^>]*>.*?</iframe>"
            ],
            "path_traversal": [
                r"\.\.\/",
                r"\.\.\\",
                r"\/etc\/passwd",
                r"\/proc\/"
            ],
            "command_injection": [
                r"[;&|`$(){}[\]\\]",
                r"\b(cat|ls|pwd|whoami|id|uname|ps|netstat|ifconfig|ping|wget|curl|nc|telnet|ssh|ftp)\b"
            ]
        }
        
        # User-Agents suspeitos
        self.suspicious_user_agents = {
            "bots": ["bot", "crawler", "spider", "scraper"],
            "tools": ["curl", "wget", "python-requests", "postman"],
            "scanners": ["sqlmap", "nmap", "nikto", "burp", "acunetix", "nessus"],
            "empty": ["", "-", "null", "none"]
        }
        
        # Honeypot endpoints
        self.honeypot_paths = {
            "/admin", "/wp-admin", "/phpmyadmin", "/administrator",
            "/.env", "/config.php", "/database.sql", "/backup.zip",
            "/robots.txt", "/sitemap.xml", "/.well-known/security.txt"
        }
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """
        Processa requisição com verificações de segurança avançadas.
        
        Args:
            request: Requisição HTTP
            call_next: Próximo middleware/handler
            
        Returns:
            Response: Resposta HTTP
        """
        start_time = time.time()
        client_ip = self._get_client_ip(request)
        
        try:
            # 1. Verificações básicas de segurança
            basic_check = await self._perform_basic_security_checks(request, client_ip)
            if basic_check:
                return basic_check
            
            # 2. Verificar honeypots
            if self.enable_honeypot and self._is_honeypot_request(request):
                await self._log_honeypot_hit(request, client_ip)
                return self._create_honeypot_response()
            
            # 3. Verificar geolocalização (se configurado)
            geo_check = await self._check_geolocation(client_ip)
            if geo_check:
                return geo_check
            
            # 4. Detecção de ataques
            if self.enable_attack_detection:
                attack_check = await self._detect_attacks(request, client_ip)
                if attack_check:
                    return attack_check
            
            # 5. Verificar rate limiting avançado
            rate_limit_check = await self._check_advanced_rate_limiting(request, client_ip)
            if rate_limit_check:
                return rate_limit_check
            
            # 6. Processar requisição
            response = await call_next(request)
            
            # 7. Adicionar headers de segurança
            self._add_security_headers(response, request)
            
            # 8. Log de segurança
            await self._log_security_metrics(request, response, client_ip, start_time)
            
            return response
            
        except Exception as e:
            # Log erro de segurança
            await self._log_security_error(request, client_ip, str(e))
            
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={
                    "error": "Internal security error",
                    "code": "SECURITY_ERROR"
                }
            )
    
    async def _perform_basic_security_checks(
        self,
        request: Request,
        client_ip: str
    ) -> Optional[JSONResponse]:
        """Realiza verificações básicas de segurança."""
        
        # 1. Verificar tamanho da requisição
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                size = int(content_length)
                if size > self.max_request_size:
                    await self._log_security_event(
                        "oversized_request",
                        client_ip,
                        {"size": size, "max_allowed": self.max_request_size}
                    )
                    return JSONResponse(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        content={
                            "error": "Request too large",
                            "code": "REQUEST_TOO_LARGE",
                            "max_size": self.max_request_size
                        }
                    )
            except ValueError:
                pass
        
        # 2. Verificar método HTTP
        if request.method not in ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"]:
            await self._log_security_event(
                "invalid_http_method",
                client_ip,
                {"method": request.method}
            )
            return JSONResponse(
                status_code=status.HTTP_405_METHOD_NOT_ALLOWED,
                content={
                    "error": "Method not allowed",
                    "code": "METHOD_NOT_ALLOWED"
                }
            )
        
        # 3. Verificar headers maliciosos
        malicious_headers = self._check_malicious_headers(request.headers)
        if malicious_headers:
            await self._log_security_event(
                "malicious_headers",
                client_ip,
                {"headers": malicious_headers}
            )
            return JSONResponse(
                status_code=status.HTTP_400_BAD_REQUEST,
                content={
                    "error": "Malicious headers detected",
                    "code": "MALICIOUS_HEADERS"
                }
            )
        
        # 4. Verificar User-Agent suspeito
        user_agent = request.headers.get("user-agent", "")
        if self._is_suspicious_user_agent(user_agent):
            await self._log_security_event(
                "suspicious_user_agent",
                client_ip,
                {"user_agent": user_agent}
            )
            # Não bloquear, apenas logar para análise
        
        return None
    
    def _is_honeypot_request(self, request: Request) -> bool:
        """Verifica se é uma requisição para honeypot."""
        path = request.url.path.lower()
        return any(honeypot in path for honeypot in self.honeypot_paths)
    
    async def _log_honeypot_hit(self, request: Request, client_ip: str):
        """Registra acesso a honeypot."""
        await self._log_security_event(
            "honeypot_hit",
            client_ip,
            {
                "path": request.url.path,
                "user_agent": request.headers.get("user-agent", ""),
                "referer": request.headers.get("referer", "")
            }
        )
    
    def _create_honeypot_response(self) -> JSONResponse:
        """Cria resposta falsa para honeypot."""
        # Resposta que parece legítima mas é falsa
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "status": "success",
                "message": "Resource found",
                "data": []
            }
        )
    
    async def _check_geolocation(self, client_ip: str) -> Optional[JSONResponse]:
        """Verifica geolocalização do IP."""
        if not self.blocked_countries:
            return None
        
        # Verificar cache
        cache_key = f"geo_{client_ip}"
        if cache_key in self._ip_cache:
            cache_entry = self._ip_cache[cache_key]
            if time.time() - cache_entry["timestamp"] < self._cache_ttl:
                if cache_entry["blocked"]:
                    return JSONResponse(
                        status_code=status.HTTP_403_FORBIDDEN,
                        content={
                            "error": "Access denied from your location",
                            "code": "GEO_BLOCKED"
                        }
                    )
                return None
        
        # Verificar geolocalização (implementação simplificada)
        country_code = await self._get_country_code(client_ip)
        blocked = country_code in self.blocked_countries
        
        # Atualizar cache
        self._ip_cache[cache_key] = {
            "blocked": blocked,
            "country": country_code,
            "timestamp": time.time()
        }
        
        if blocked:
            await self._log_security_event(
                "geo_blocked",
                client_ip,
                {"country": country_code}
            )
            return JSONResponse(
                status_code=status.HTTP_403_FORBIDDEN,
                content={
                    "error": "Access denied from your location",
                    "code": "GEO_BLOCKED"
                }
            )
        
        return None
    
    async def _detect_attacks(self, request: Request, client_ip: str) -> Optional[JSONResponse]:
        """Detecta padrões de ataque."""
        detected_attacks = []
        
        # Verificar URL
        url_attacks = self._scan_for_attacks(str(request.url))
        detected_attacks.extend(url_attacks)
        
        # Verificar headers
        for header_name, header_value in request.headers.items():
            header_attacks = self._scan_for_attacks(f"{header_name}: {header_value}")
            detected_attacks.extend(header_attacks)
        
        # Verificar query parameters
        for param, value in request.query_params.items():
            param_attacks = self._scan_for_attacks(f"{param}={value}")
            detected_attacks.extend(param_attacks)
        
        # Verificar body (se aplicável)
        if request.method in ["POST", "PUT", "PATCH"]:
            try:
                body = await request.body()
                if body:
                    body_str = body.decode('utf-8', errors='ignore')
                    body_attacks = self._scan_for_attacks(body_str)
                    detected_attacks.extend(body_attacks)
                    
                    # Recriar request com body
                    async def receive():
                        return {"type": "http.request", "body": body}
                    request._receive = receive
            except Exception:
                pass
        
        if detected_attacks:
            await self._log_security_event(
                "attack_detected",
                client_ip,
                {
                    "attacks": list(set(detected_attacks)),
                    "url": str(request.url),
                    "method": request.method
                }
            )
            
            return JSONResponse(
                status_code=status.HTTP_400_BAD_REQUEST,
                content={
                    "error": "Malicious request detected",
                    "code": "ATTACK_DETECTED"
                }
            )
        
        return None
    
    def _scan_for_attacks(self, text: str) -> List[str]:
        """Escaneia texto em busca de padrões de ataque."""
        import re
        
        detected = []
        text_lower = text.lower()
        
        for attack_type, patterns in self.attack_patterns.items():
            for pattern in patterns:
                if re.search(pattern, text_lower, re.IGNORECASE):
                    detected.append(attack_type)
                    break
        
        return detected
    
    async def _check_advanced_rate_limiting(
        self,
        request: Request,
        client_ip: str
    ) -> Optional[JSONResponse]:
        """Verifica rate limiting avançado."""
        # Implementar integração com AdvancedRateLimiter se necessário
        # Por enquanto, retorna None (sem limitação)
        return None
    
    def _check_malicious_headers(self, headers: Dict[str, str]) -> List[str]:
        """Verifica headers maliciosos."""
        malicious = []
        
        for header_name, header_value in headers.items():
            header_lower = header_name.lower()
            value_lower = header_value.lower()
            
            # Headers suspeitos
            if header_lower in ["x-forwarded-host", "x-original-url", "x-rewrite-url"]:
                if not self._is_valid_header_value(header_value):
                    malicious.append(header_name)
            
            # Valores suspeitos
            if any(pattern in value_lower for pattern in ["<script", "javascript:", "data:text/html"]):
                malicious.append(header_name)
            
            # Headers muito longos
            if len(header_value) > 8192:  # 8KB
                malicious.append(header_name)
        
        return malicious
    
    def _is_valid_header_value(self, value: str) -> bool:
        """Valida valor de header."""
        # Verificar caracteres de controle
        if any(ord(c) < 32 and c not in ['\t', '\n', '\r'] for c in value):
            return False
        
        # Verificar encoding suspeito
        try:
            value.encode('ascii')
        except UnicodeEncodeError:
            # Permitir Unicode, mas verificar se não é malicioso
            pass
        
        return True
    
    def _is_suspicious_user_agent(self, user_agent: str) -> bool:
        """Verifica se User-Agent é suspeito."""
        if not user_agent:
            return True
        
        user_agent_lower = user_agent.lower()
        
        for category, patterns in self.suspicious_user_agents.items():
            if any(pattern in user_agent_lower for pattern in patterns):
                return True
        
        return False
    
    def _get_client_ip(self, request: Request) -> str:
        """Obtém IP real do cliente."""
        # Verificar headers de proxy em ordem de prioridade
        forwarded_headers = [
            "cf-connecting-ip",  # Cloudflare
            "x-real-ip",
            "x-forwarded-for",
            "x-client-ip",
            "x-cluster-client-ip"
        ]
        
        for header in forwarded_headers:
            if header in request.headers:
                ip = request.headers[header].split(",")[0].strip()
                if self._is_valid_ip(ip):
                    return ip
        
        # Fallback para IP direto
        return request.client.host if request.client else "unknown"
    
    def _is_valid_ip(self, ip_str: str) -> bool:
        """Valida formato de IP."""
        try:
            ipaddress.ip_address(ip_str.strip())
            return True
        except ValueError:
            return False
    
    async def _get_country_code(self, ip_address: str) -> str:
        """Obtém código do país para um IP (implementação simplificada)."""
        # Em produção, usar serviço de geolocalização como MaxMind
        # Por enquanto, retorna código genérico
        return "XX"
    
    def _add_security_headers(self, response: Response, request: Request):
        """Adiciona headers de segurança à resposta."""
        
        # Headers básicos de segurança
        security_headers = {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Referrer-Policy": "strict-origin-when-cross-origin",
            "X-Permitted-Cross-Domain-Policies": "none",
            "X-Download-Options": "noopen",
            "X-DNS-Prefetch-Control": "off"
        }
        
        # HSTS (apenas para HTTPS)
        if self.enable_hsts and request.url.scheme == "https":
            security_headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains; preload"
        
        # Content Security Policy
        if self.enable_csp:
            csp_policy = self._build_csp_policy(request)
            security_headers["Content-Security-Policy"] = csp_policy
        
        # Aplicar headers
        for header, value in security_headers.items():
            response.headers[header] = value
        
        # Headers customizados
        response.headers["X-Security-Middleware"] = "AdvancedSecurity/1.0"
        response.headers["X-Request-ID"] = self._generate_request_id(request)
    
    def _build_csp_policy(self, request: Request) -> str:
        """Constrói política de Content Security Policy."""
        # Política restritiva para webhooks
        if request.url.path.startswith("/webhook/"):
            return "default-src 'none'; frame-ancestors 'none';"
        
        # Política padrão para API
        return (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: https:; "
            "font-src 'self'; "
            "connect-src 'self'; "
            "frame-ancestors 'none'; "
            "base-uri 'self'; "
            "form-action 'self';"
        )
    
    def _generate_request_id(self, request: Request) -> str:
        """Gera ID único para a requisição."""
        request_data = f"{request.client.host}:{request.method}:{request.url.path}:{time.time()}"
        return hashlib.sha256(request_data.encode()).hexdigest()[:16]
    
    async def _log_security_event(
        self,
        event_type: str,
        client_ip: str,
        details: Dict[str, Any]
    ):
        """Registra evento de segurança."""
        event_data = {
            "event_type": event_type,
            "client_ip": client_ip,
            "timestamp": time.time(),
            "details": details
        }
        
        # Em produção, enviar para sistema de logging/SIEM
        print(f"SECURITY EVENT: {json.dumps(event_data)}")
    
    async def _log_security_metrics(
        self,
        request: Request,
        response: Response,
        client_ip: str,
        start_time: float
    ):
        """Registra métricas de segurança."""
        processing_time = time.time() - start_time
        
        metrics = {
            "client_ip": client_ip,
            "method": request.method,
            "path": request.url.path,
            "status_code": response.status_code,
            "processing_time": processing_time,
            "user_agent": request.headers.get("user-agent", ""),
            "timestamp": time.time()
        }
        
        # Em produção, enviar para sistema de métricas
        # print(f"SECURITY METRICS: {json.dumps(metrics)}")
    
    async def _log_security_error(self, request: Request, client_ip: str, error: str):
        """Registra erro de segurança."""
        error_data = {
            "error": error,
            "client_ip": client_ip,
            "method": request.method,
            "path": request.url.path,
            "timestamp": time.time()
        }
        
        print(f"SECURITY ERROR: {json.dumps(error_data)}")


class CORSSecurityMiddleware(CORSMiddleware):
    """Middleware CORS com verificações de segurança adicionais."""
    
    def __init__(
        self,
        app: ASGIApp,
        allow_origins: List[str] = None,
        allow_methods: List[str] = None,
        allow_headers: List[str] = None,
        allow_credentials: bool = False,
        expose_headers: List[str] = None,
        max_age: int = 600,
        allow_origin_regex: str = None,
        enable_origin_validation: bool = True
    ):
        """
        Inicializa middleware CORS com segurança.
        
        Args:
            app: Aplicação ASGI
            allow_origins: Origens permitidas
            allow_methods: Métodos permitidos
            allow_headers: Headers permitidos
            allow_credentials: Permitir credenciais
            expose_headers: Headers expostos
            max_age: Tempo de cache preflight
            allow_origin_regex: Regex para origens permitidas
            enable_origin_validation: Habilitar validação de origem
        """
        
        # Configurações seguras por padrão
        safe_origins = allow_origins or []
        safe_methods = allow_methods or ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
        safe_headers = allow_headers or [
            "Accept",
            "Accept-Language",
            "Content-Language",
            "Content-Type",
            "Authorization"
        ]
        
        super().__init__(
            app=app,
            allow_origins=safe_origins,
            allow_methods=safe_methods,
            allow_headers=safe_headers,
            allow_credentials=allow_credentials,
            expose_headers=expose_headers or [],
            max_age=max_age,
            allow_origin_regex=allow_origin_regex
        )
        
        self.enable_origin_validation = enable_origin_validation
        self.trusted_origins = set(safe_origins)
    
    def is_allowed_origin(self, origin: str) -> bool:
        """
        Verifica se origem é permitida com validações adicionais.
        
        Args:
            origin: Origem a verificar
            
        Returns:
            bool: True se permitida
        """
        # Verificação básica do CORS
        if not super().is_allowed_origin(origin):
            return False
        
        if not self.enable_origin_validation:
            return True
        
        # Validações adicionais de segurança
        try:
            parsed = urlparse(origin)
            
            # Verificar esquema
            if parsed.scheme not in ["https", "http"]:
                return False
            
            # Verificar se não é IP privado (em produção)
            if parsed.hostname:
                try:
                    ip = ipaddress.ip_address(parsed.hostname)
                    if ip.is_private and parsed.scheme == "http":
                        # Permitir HTTP apenas para desenvolvimento local
                        return parsed.hostname in ["localhost", "127.0.0.1"]
                except ValueError:
                    # Não é IP, continuar verificação
                    pass
            
            # Verificar domínios suspeitos
            if self._is_suspicious_domain(parsed.hostname):
                return False
            
            return True
            
        except Exception:
            return False
    
    def _is_suspicious_domain(self, hostname: str) -> bool:
        """Verifica se domínio é suspeito."""
        if not hostname:
            return True
        
        # Domínios suspeitos
        suspicious_patterns = [
            "bit.ly", "tinyurl.com", "t.co",  # Encurtadores
            "ngrok.io", "localtunnel.me",     # Túneis
            ".tk", ".ml", ".ga", ".cf"        # TLDs gratuitos suspeitos
        ]
        
        hostname_lower = hostname.lower()
        return any(pattern in hostname_lower for pattern in suspicious_patterns)


def configure_advanced_security(
    app: ASGIApp,
    enable_cors: bool = True,
    cors_origins: List[str] = None,
    blocked_countries: List[str] = None,
    enable_honeypot: bool = True
) -> ASGIApp:
    """
    Configura middleware de segurança avançado.
    
    Args:
        app: Aplicação ASGI
        enable_cors: Habilitar CORS
        cors_origins: Origens permitidas para CORS
        blocked_countries: Países bloqueados
        enable_honeypot: Habilitar honeypots
        
    Returns:
        ASGIApp: Aplicação com middleware configurado
    """
    
    # Middleware de segurança avançado
    app = AdvancedSecurityMiddleware(
        app,
        enable_csp=True,
        enable_hsts=True,
        enable_attack_detection=True,
        allowed_origins=cors_origins or [],
        blocked_countries=blocked_countries or [],
        enable_honeypot=enable_honeypot
    )
    
    # Middleware CORS seguro
    if enable_cors:
        app = CORSSecurityMiddleware(
            app,
            allow_origins=cors_origins or ["https://localhost:3000"],
            allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            allow_headers=[
                "Accept",
                "Accept-Language", 
                "Content-Language",
                "Content-Type",
                "Authorization",
                "X-Requested-With"
            ],
            allow_credentials=False,
            max_age=600,
            enable_origin_validation=True
        )
    
    return app