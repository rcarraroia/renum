"""
Middleware para validação de entrada de dados em webhooks.

Este módulo contém middleware para validar tamanho de payload, content-type,
rate limiting e outras validações de segurança antes do processamento.
"""

import json
import time
from typing import Callable, Dict, Any, Optional
from fastapi import Request, Response, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from app.api.validators.security_validator import security_validator
from app.core.config import settings


class PayloadValidationMiddleware(BaseHTTPMiddleware):
    """Middleware para validação de payload de webhooks."""
    
    def __init__(
        self,
        app: ASGIApp,
        max_payload_size: int = 1024 * 1024,  # 1MB
        allowed_content_types: list = None,
        enable_security_validation: bool = True
    ):
        """
        Inicializa o middleware.
        
        Args:
            app: Aplicação ASGI
            max_payload_size: Tamanho máximo do payload em bytes
            allowed_content_types: Tipos de conteúdo permitidos
            enable_security_validation: Se deve aplicar validação de segurança
        """
        super().__init__(app)
        self.max_payload_size = max_payload_size
        self.allowed_content_types = allowed_content_types or [
            "application/json",
            "application/x-www-form-urlencoded",
            "text/plain"
        ]
        self.enable_security_validation = enable_security_validation
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """
        Processa a requisição aplicando validações.
        
        Args:
            request: Requisição HTTP
            call_next: Próximo middleware/handler
            
        Returns:
            Resposta HTTP
        """
        # Aplicar validações apenas para endpoints de webhook
        if not request.url.path.startswith("/webhook/"):
            return await call_next(request)
        
        # Validar método HTTP
        if request.method not in ["POST", "PUT", "PATCH"]:
            return await call_next(request)
        
        try:
            # Validar Content-Type
            content_type = request.headers.get("content-type", "").split(";")[0].strip()
            if content_type not in self.allowed_content_types:
                return JSONResponse(
                    status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                    content={
                        "success": False,
                        "error": f"Content-Type não suportado: {content_type}",
                        "code": "UNSUPPORTED_CONTENT_TYPE",
                        "allowed_types": self.allowed_content_types
                    }
                )
            
            # Validar tamanho do payload
            content_length = request.headers.get("content-length")
            if content_length:
                try:
                    size = int(content_length)
                    if size > self.max_payload_size:
                        return JSONResponse(
                            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                            content={
                                "success": False,
                                "error": f"Payload muito grande: {size} bytes (máximo: {self.max_payload_size})",
                                "code": "PAYLOAD_TOO_LARGE",
                                "max_size": self.max_payload_size
                            }
                        )
                except ValueError:
                    return JSONResponse(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        content={
                            "success": False,
                            "error": "Content-Length inválido",
                            "code": "INVALID_CONTENT_LENGTH"
                        }
                    )
            
            # Ler e validar o corpo da requisição
            body = await request.body()
            
            # Validar tamanho real do corpo
            if len(body) > self.max_payload_size:
                return JSONResponse(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    content={
                        "success": False,
                        "error": f"Payload muito grande: {len(body)} bytes (máximo: {self.max_payload_size})",
                        "code": "PAYLOAD_TOO_LARGE",
                        "max_size": self.max_payload_size
                    }
                )
            
            # Validar JSON se aplicável
            if content_type == "application/json" and body:
                try:
                    payload_data = json.loads(body.decode('utf-8'))
                    
                    # Aplicar validação de segurança se habilitada
                    if self.enable_security_validation:
                        validation_result = security_validator.validate_dict(payload_data, "request_payload")
                        if not validation_result["valid"]:
                            return JSONResponse(
                                status_code=status.HTTP_400_BAD_REQUEST,
                                content={
                                    "success": False,
                                    "error": "Payload contém dados suspeitos ou inválidos",
                                    "code": "SECURITY_VALIDATION_FAILED",
                                    "issues": validation_result["issues"]
                                }
                            )
                    
                    # Adicionar dados validados ao request state
                    request.state.validated_payload = payload_data
                    
                except json.JSONDecodeError as e:
                    return JSONResponse(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        content={
                            "success": False,
                            "error": f"JSON inválido: {str(e)}",
                            "code": "INVALID_JSON"
                        }
                    )
                except UnicodeDecodeError:
                    return JSONResponse(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        content={
                            "success": False,
                            "error": "Encoding inválido, esperado UTF-8",
                            "code": "INVALID_ENCODING"
                        }
                    )
            
            # Validar headers suspeitos
            suspicious_headers = self._check_suspicious_headers(request.headers)
            if suspicious_headers:
                return JSONResponse(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    content={
                        "success": False,
                        "error": "Headers suspeitos detectados",
                        "code": "SUSPICIOUS_HEADERS",
                        "details": suspicious_headers
                    }
                )
            
            # Criar nova requisição com corpo validado
            async def receive():
                return {"type": "http.request", "body": body}
            
            request._receive = receive
            
            # Adicionar headers de segurança à resposta
            response = await call_next(request)
            
            # Adicionar headers de segurança
            security_headers = security_validator.get_security_headers()
            for header, value in security_headers.items():
                response.headers[header] = value
            
            return response
            
        except Exception as e:
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={
                    "success": False,
                    "error": "Erro interno na validação do payload",
                    "code": "VALIDATION_ERROR",
                    "details": str(e) if settings.DEBUG else None
                }
            )
    
    def _check_suspicious_headers(self, headers: Dict[str, str]) -> Optional[Dict[str, str]]:
        """
        Verifica headers suspeitos na requisição.
        
        Args:
            headers: Headers da requisição
            
        Returns:
            Dict com headers suspeitos encontrados ou None
        """
        suspicious = {}
        
        # Headers que podem indicar ataques
        dangerous_headers = [
            "x-forwarded-for",
            "x-real-ip",
            "x-originating-ip",
            "x-remote-ip",
            "x-client-ip"
        ]
        
        for header_name, header_value in headers.items():
            header_lower = header_name.lower()
            
            # Verificar injeção em headers
            if any(pattern in header_value.lower() for pattern in ["<script", "javascript:", "data:text/html"]):
                suspicious[header_name] = "Possível XSS em header"
            
            # Verificar headers de IP suspeitos
            if header_lower in dangerous_headers:
                # Validar formato de IP
                if not self._is_valid_ip(header_value):
                    suspicious[header_name] = "Formato de IP inválido"
            
            # Verificar User-Agent suspeito
            if header_lower == "user-agent":
                if len(header_value) > 500:
                    suspicious[header_name] = "User-Agent muito longo"
                elif any(pattern in header_value.lower() for pattern in ["<script", "javascript:", "sqlmap", "nmap"]):
                    suspicious[header_name] = "User-Agent suspeito"
        
        return suspicious if suspicious else None
    
    def _is_valid_ip(self, ip_str: str) -> bool:
        """
        Valida se uma string é um IP válido.
        
        Args:
            ip_str: String do IP
            
        Returns:
            True se for um IP válido
        """
        import ipaddress
        try:
            ipaddress.ip_address(ip_str.strip())
            return True
        except ValueError:
            return False


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware para rate limiting de webhooks."""
    
    def __init__(
        self,
        app: ASGIApp,
        default_rate_limit: int = 60,  # requests per minute
        rate_limit_window: int = 60,   # window in seconds
        enable_ip_based_limiting: bool = True
    ):
        """
        Inicializa o middleware de rate limiting.
        
        Args:
            app: Aplicação ASGI
            default_rate_limit: Limite padrão de requisições por minuto
            rate_limit_window: Janela de tempo em segundos
            enable_ip_based_limiting: Se deve aplicar limite por IP
        """
        super().__init__(app)
        self.default_rate_limit = default_rate_limit
        self.rate_limit_window = rate_limit_window
        self.enable_ip_based_limiting = enable_ip_based_limiting
        self.request_counts: Dict[str, Dict[str, Any]] = {}
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """
        Processa a requisição aplicando rate limiting.
        
        Args:
            request: Requisição HTTP
            call_next: Próximo middleware/handler
            
        Returns:
            Resposta HTTP
        """
        # Aplicar rate limiting apenas para endpoints de webhook
        if not request.url.path.startswith("/webhook/"):
            return await call_next(request)
        
        # Determinar chave para rate limiting
        if self.enable_ip_based_limiting:
            client_ip = self._get_client_ip(request)
            rate_limit_key = f"ip:{client_ip}"
        else:
            # Usar token ou integration_id se disponível
            rate_limit_key = "global"
        
        current_time = time.time()
        
        # Limpar contadores antigos
        self._cleanup_old_counts(current_time)
        
        # Verificar rate limit
        if rate_limit_key in self.request_counts:
            count_data = self.request_counts[rate_limit_key]
            
            # Verificar se está dentro da janela de tempo
            if current_time - count_data["window_start"] < self.rate_limit_window:
                if count_data["count"] >= self.default_rate_limit:
                    # Rate limit excedido
                    reset_time = int(count_data["window_start"] + self.rate_limit_window)
                    
                    return JSONResponse(
                        status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                        content={
                            "success": False,
                            "error": "Rate limit excedido",
                            "code": "RATE_LIMIT_EXCEEDED",
                            "limit": self.default_rate_limit,
                            "window_seconds": self.rate_limit_window,
                            "reset_time": reset_time
                        },
                        headers={
                            "X-RateLimit-Limit": str(self.default_rate_limit),
                            "X-RateLimit-Remaining": "0",
                            "X-RateLimit-Reset": str(reset_time),
                            "Retry-After": str(reset_time - int(current_time))
                        }
                    )
                else:
                    # Incrementar contador
                    count_data["count"] += 1
            else:
                # Nova janela de tempo
                self.request_counts[rate_limit_key] = {
                    "count": 1,
                    "window_start": current_time
                }
        else:
            # Primeira requisição para esta chave
            self.request_counts[rate_limit_key] = {
                "count": 1,
                "window_start": current_time
            }
        
        # Processar requisição
        response = await call_next(request)
        
        # Adicionar headers de rate limit
        count_data = self.request_counts.get(rate_limit_key, {"count": 0, "window_start": current_time})
        remaining = max(0, self.default_rate_limit - count_data["count"])
        reset_time = int(count_data["window_start"] + self.rate_limit_window)
        
        response.headers["X-RateLimit-Limit"] = str(self.default_rate_limit)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Reset"] = str(reset_time)
        
        return response
    
    def _get_client_ip(self, request: Request) -> str:
        """
        Obtém o IP do cliente considerando proxies.
        
        Args:
            request: Requisição HTTP
            
        Returns:
            IP do cliente
        """
        # Verificar headers de proxy em ordem de prioridade
        forwarded_headers = [
            "x-forwarded-for",
            "x-real-ip",
            "x-client-ip",
            "cf-connecting-ip"  # Cloudflare
        ]
        
        for header in forwarded_headers:
            if header in request.headers:
                ip = request.headers[header].split(",")[0].strip()
                if self._is_valid_ip(ip):
                    return ip
        
        # Fallback para IP direto
        return request.client.host if request.client else "unknown"
    
    def _is_valid_ip(self, ip_str: str) -> bool:
        """
        Valida se uma string é um IP válido.
        
        Args:
            ip_str: String do IP
            
        Returns:
            True se for um IP válido
        """
        import ipaddress
        try:
            ipaddress.ip_address(ip_str.strip())
            return True
        except ValueError:
            return False
    
    def _cleanup_old_counts(self, current_time: float):
        """
        Remove contadores antigos para economizar memória.
        
        Args:
            current_time: Timestamp atual
        """
        keys_to_remove = []
        
        for key, count_data in self.request_counts.items():
            if current_time - count_data["window_start"] > self.rate_limit_window * 2:
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del self.request_counts[key]


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Middleware para adicionar headers de segurança."""
    
    def __init__(self, app: ASGIApp, custom_headers: Dict[str, str] = None):
        """
        Inicializa o middleware.
        
        Args:
            app: Aplicação ASGI
            custom_headers: Headers customizados adicionais
        """
        super().__init__(app)
        self.custom_headers = custom_headers or {}
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """
        Adiciona headers de segurança à resposta.
        
        Args:
            request: Requisição HTTP
            call_next: Próximo middleware/handler
            
        Returns:
            Resposta HTTP com headers de segurança
        """
        response = await call_next(request)
        
        # Headers de segurança padrão
        security_headers = {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Referrer-Policy": "strict-origin-when-cross-origin",
            "X-Permitted-Cross-Domain-Policies": "none"
        }
        
        # Adicionar headers customizados
        security_headers.update(self.custom_headers)
        
        # Aplicar headers à resposta
        for header, value in security_headers.items():
            response.headers[header] = value
        
        return response