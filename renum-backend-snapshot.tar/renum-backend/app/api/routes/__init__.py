"""
Pacote de rotas da API.

Este pacote contém os módulos de rotas da API do Backend Renum.
"""

from app.api.routes import teams, team_executions