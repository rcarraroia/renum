"""
Endpoints de health check e monitoramento do sistema.

Este módulo implementa endpoints para verificação de saúde dos componentes
do sistema, incluindo banco de dados, Redis, Suna Core e métricas gerais.
"""

import time
import asyncio
import psutil
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, text

from app.models.integrations import Integration, WebhookCall
from app.core.database import get_async_session
from app.core.dependencies import get_redis_client
from app.services.webhook_service import WebhookService
from app.services.integration_service import IntegrationService


# Criar router
router = APIRouter(tags=["health-monitoring"], prefix="/health")


@router.get(
    "/",
    summary="Health check geral",
    description="Verifica saúde geral do sistema com informações básicas."
)
async def health_check() -> JSONResponse:
    """
    Health check básico do sistema.
    
    Returns:
        JSONResponse: Status de saúde básico
    """
    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content={
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "service": "webhook-integrations",
            "version": "1.0.0",
            "uptime_seconds": time.time() - getattr(health_check, '_start_time', time.time())
        }
    )


# Armazenar tempo de início
health_check._start_time = time.time()


@router.get(
    "/detailed",
    summary="Health check detalhado",
    description="Verifica saúde detalhada de todos os componentes do sistema."
)
async def detailed_health_check(
    session: AsyncSession = Depends(get_async_session),
    redis_client = Depends(get_redis_client)
) -> JSONResponse:
    """
    Health check detalhado de todos os componentes.
    
    Args:
        session: Sessão do banco de dados
        redis_client: Cliente Redis
        
    Returns:
        JSONResponse: Status detalhado de saúde
    """
    health_status = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "service": "webhook-integrations",
        "version": "1.0.0",
        "components": {},
        "metrics": {},
        "system": {}
    }
    
    # 1. Verificar banco de dados
    try:
        start_time = time.time()
        
        # Teste de conectividade
        await session.execute(text("SELECT 1"))
        
        # Contar integrações ativas
        integration_count = await session.execute(
            select(func.count(Integration.id)).where(Integration.is_active == True)
        )
        active_integrations = integration_count.scalar()
        
        # Contar webhook calls nas últimas 24h
        yesterday = datetime.utcnow() - timedelta(hours=24)
        calls_count = await session.execute(
            select(func.count(WebhookCall.id)).where(
                WebhookCall.created_at >= yesterday
            )
        )
        recent_calls = calls_count.scalar()
        
        db_response_time = (time.time() - start_time) * 1000  # ms
        
        health_status["components"]["database"] = {
            "status": "healthy",
            "response_time_ms": round(db_response_time, 2),
            "active_integrations": active_integrations,
            "recent_calls_24h": recent_calls
        }
        
    except Exception as e:
        health_status["status"] = "degraded"
        health_status["components"]["database"] = {
            "status": "unhealthy",
            "error": str(e)
        }
    
    # 2. Verificar Redis
    try:
        start_time = time.time()
        
        # Teste de conectividade
        await redis_client.ping()
        
        # Informações do Redis
        redis_info = await redis_client.info()
        redis_memory = redis_info.get("used_memory_human", "unknown")
        redis_connections = redis_info.get("connected_clients", 0)
        
        redis_response_time = (time.time() - start_time) * 1000  # ms
        
        health_status["components"]["redis"] = {
            "status": "healthy",
            "response_time_ms": round(redis_response_time, 2),
            "memory_usage": redis_memory,
            "connected_clients": redis_connections
        }
        
    except Exception as e:
        health_status["status"] = "degraded"
        health_status["components"]["redis"] = {
            "status": "unhealthy",
            "error": str(e)
        }
    
    # 3. Verificar Suna Core (simulado)
    try:
        start_time = time.time()
        
        # Em produção, faria uma chamada real ao Suna Core
        # Por enquanto, simular verificação
        await asyncio.sleep(0.01)  # Simular latência
        
        suna_response_time = (time.time() - start_time) * 1000  # ms
        
        health_status["components"]["suna_core"] = {
            "status": "healthy",
            "response_time_ms": round(suna_response_time, 2),
            "endpoint": "http://suna-core:8000/health"
        }
        
    except Exception as e:
        health_status["status"] = "degraded"
        health_status["components"]["suna_core"] = {
            "status": "unhealthy",
            "error": str(e)
        }
    
    # 4. Métricas do sistema
    try:
        # CPU e memória
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory_info = psutil.virtual_memory()
        disk_info = psutil.disk_usage('/')
        
        health_status["system"] = {
            "cpu_percent": round(cpu_percent, 1),
            "memory_percent": round(memory_info.percent, 1),
            "memory_used_mb": round(memory_info.used / 1024 / 1024, 1),
            "disk_percent": round(disk_info.percent, 1),
            "disk_free_gb": round(disk_info.free / 1024 / 1024 / 1024, 1)
        }
        
        # Verificar se recursos estão críticos
        if cpu_percent > 90 or memory_info.percent > 90 or disk_info.percent > 90:
            health_status["status"] = "degraded"
            
    except Exception as e:
        health_status["system"] = {"error": str(e)}
    
    # 5. Métricas de aplicação
    try:
        # Calcular métricas das últimas 24h
        yesterday = datetime.utcnow() - timedelta(hours=24)
        
        # Total de calls
        total_calls = await session.execute(
            select(func.count(WebhookCall.id)).where(
                WebhookCall.created_at >= yesterday
            )
        )
        
        # Calls com sucesso
        success_calls = await session.execute(
            select(func.count(WebhookCall.id)).where(
                WebhookCall.created_at >= yesterday,
                WebhookCall.status_code == 200
            )
        )
        
        # Tempo médio de execução
        avg_time = await session.execute(
            select(func.avg(WebhookCall.execution_time_ms)).where(
                WebhookCall.created_at >= yesterday,
                WebhookCall.execution_time_ms.isnot(None)
            )
        )
        
        total = total_calls.scalar() or 0
        success = success_calls.scalar() or 0
        avg_execution_time = avg_time.scalar() or 0
        
        success_rate = (success / total * 100) if total > 0 else 100
        error_rate = 100 - success_rate
        
        health_status["metrics"] = {
            "total_calls_24h": total,
            "success_calls_24h": success,
            "success_rate_percent": round(success_rate, 2),
            "error_rate_percent": round(error_rate, 2),
            "avg_execution_time_ms": round(avg_execution_time, 2)
        }
        
        # Verificar se métricas estão críticas
        if error_rate > 10:  # Mais de 10% de erro
            health_status["status"] = "degraded"
            
    except Exception as e:
        health_status["metrics"] = {"error": str(e)}
    
    # Determinar status final
    unhealthy_components = [
        name for name, component in health_status["components"].items()
        if component.get("status") == "unhealthy"
    ]
    
    if unhealthy_components:
        health_status["status"] = "unhealthy"
        health_status["unhealthy_components"] = unhealthy_components
    
    # Código de status HTTP baseado na saúde
    status_code = {
        "healthy": status.HTTP_200_OK,
        "degraded": status.HTTP_200_OK,  # Ainda funcional
        "unhealthy": status.HTTP_503_SERVICE_UNAVAILABLE
    }.get(health_status["status"], status.HTTP_200_OK)
    
    return JSONResponse(
        status_code=status_code,
        content=health_status
    )


@router.get(
    "/readiness",
    summary="Readiness check",
    description="Verifica se o sistema está pronto para receber tráfego."
)
async def readiness_check(
    session: AsyncSession = Depends(get_async_session),
    redis_client = Depends(get_redis_client)
) -> JSONResponse:
    """
    Verifica se o sistema está pronto para receber tráfego.
    
    Args:
        session: Sessão do banco de dados
        redis_client: Cliente Redis
        
    Returns:
        JSONResponse: Status de prontidão
    """
    readiness_status = {
        "ready": True,
        "timestamp": datetime.utcnow().isoformat(),
        "checks": {}
    }
    
    # Verificar componentes essenciais
    essential_checks = [
        ("database", lambda: session.execute(text("SELECT 1"))),
        ("redis", lambda: redis_client.ping())
    ]
    
    for check_name, check_func in essential_checks:
        try:
            start_time = time.time()
            await check_func()
            response_time = (time.time() - start_time) * 1000
            
            readiness_status["checks"][check_name] = {
                "ready": True,
                "response_time_ms": round(response_time, 2)
            }
            
        except Exception as e:
            readiness_status["ready"] = False
            readiness_status["checks"][check_name] = {
                "ready": False,
                "error": str(e)
            }
    
    status_code = status.HTTP_200_OK if readiness_status["ready"] else status.HTTP_503_SERVICE_UNAVAILABLE
    
    return JSONResponse(
        status_code=status_code,
        content=readiness_status
    )


@router.get(
    "/liveness",
    summary="Liveness check",
    description="Verifica se o sistema está vivo e responsivo."
)
async def liveness_check() -> JSONResponse:
    """
    Verifica se o sistema está vivo (não travado).
    
    Returns:
        JSONResponse: Status de vida
    """
    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content={
            "alive": True,
            "timestamp": datetime.utcnow().isoformat(),
            "pid": psutil.Process().pid,
            "uptime_seconds": time.time() - getattr(health_check, '_start_time', time.time())
        }
    )


@router.get(
    "/metrics",
    summary="Métricas do sistema",
    description="Retorna métricas detalhadas do sistema para monitoramento."
)
async def system_metrics(
    period_hours: int = Query(24, ge=1, le=168, description="Período em horas"),
    session: AsyncSession = Depends(get_async_session),
    redis_client = Depends(get_redis_client)
) -> JSONResponse:
    """
    Retorna métricas detalhadas do sistema.
    
    Args:
        period_hours: Período em horas para análise
        session: Sessão do banco de dados
        redis_client: Cliente Redis
        
    Returns:
        JSONResponse: Métricas do sistema
    """
    try:
        start_time = datetime.utcnow() - timedelta(hours=period_hours)
        
        # Métricas de webhook calls
        total_calls = await session.execute(
            select(func.count(WebhookCall.id)).where(
                WebhookCall.created_at >= start_time
            )
        )
        
        success_calls = await session.execute(
            select(func.count(WebhookCall.id)).where(
                WebhookCall.created_at >= start_time,
                WebhookCall.status_code == 200
            )
        )
        
        error_calls = await session.execute(
            select(func.count(WebhookCall.id)).where(
                WebhookCall.created_at >= start_time,
                WebhookCall.status_code != 200
            )
        )
        
        # Métricas de tempo de execução
        avg_execution_time = await session.execute(
            select(func.avg(WebhookCall.execution_time_ms)).where(
                WebhookCall.created_at >= start_time,
                WebhookCall.execution_time_ms.isnot(None)
            )
        )
        
        max_execution_time = await session.execute(
            select(func.max(WebhookCall.execution_time_ms)).where(
                WebhookCall.created_at >= start_time,
                WebhookCall.execution_time_ms.isnot(None)
            )
        )
        
        min_execution_time = await session.execute(
            select(func.min(WebhookCall.execution_time_ms)).where(
                WebhookCall.created_at >= start_time,
                WebhookCall.execution_time_ms.isnot(None)
            )
        )
        
        # Métricas por status code
        status_codes = await session.execute(
            select(
                WebhookCall.status_code,
                func.count(WebhookCall.id).label('count')
            ).where(
                WebhookCall.created_at >= start_time
            ).group_by(WebhookCall.status_code)
        )
        
        # Métricas por integração
        integration_metrics = await session.execute(
            select(
                Integration.name,
                Integration.channel,
                func.count(WebhookCall.id).label('call_count'),
                func.avg(WebhookCall.execution_time_ms).label('avg_time')
            ).join(
                WebhookCall, Integration.id == WebhookCall.integration_id
            ).where(
                WebhookCall.created_at >= start_time
            ).group_by(Integration.id, Integration.name, Integration.channel)
        )
        
        # Compilar métricas
        total = total_calls.scalar() or 0
        success = success_calls.scalar() or 0
        errors = error_calls.scalar() or 0
        
        metrics = {
            "period": {
                "hours": period_hours,
                "start_time": start_time.isoformat(),
                "end_time": datetime.utcnow().isoformat()
            },
            "webhook_calls": {
                "total": total,
                "success": success,
                "errors": errors,
                "success_rate": round((success / total * 100) if total > 0 else 100, 2),
                "error_rate": round((errors / total * 100) if total > 0 else 0, 2)
            },
            "execution_time": {
                "avg_ms": round(avg_execution_time.scalar() or 0, 2),
                "max_ms": max_execution_time.scalar() or 0,
                "min_ms": min_execution_time.scalar() or 0
            },
            "status_codes": {
                str(row.status_code): row.count
                for row in status_codes.fetchall()
            },
            "integrations": [
                {
                    "name": row.name,
                    "channel": row.channel,
                    "call_count": row.call_count,
                    "avg_execution_time_ms": round(row.avg_time or 0, 2)
                }
                for row in integration_metrics.fetchall()
            ]
        }
        
        # Métricas do sistema
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory_info = psutil.virtual_memory()
        
        metrics["system"] = {
            "cpu_percent": round(cpu_percent, 1),
            "memory_percent": round(memory_info.percent, 1),
            "memory_used_mb": round(memory_info.used / 1024 / 1024, 1),
            "memory_available_mb": round(memory_info.available / 1024 / 1024, 1)
        }
        
        # Métricas do Redis
        try:
            redis_info = await redis_client.info()
            metrics["redis"] = {
                "used_memory_mb": round(redis_info.get("used_memory", 0) / 1024 / 1024, 1),
                "connected_clients": redis_info.get("connected_clients", 0),
                "total_commands_processed": redis_info.get("total_commands_processed", 0),
                "keyspace_hits": redis_info.get("keyspace_hits", 0),
                "keyspace_misses": redis_info.get("keyspace_misses", 0)
            }
        except Exception:
            metrics["redis"] = {"error": "Unable to fetch Redis metrics"}
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "timestamp": datetime.utcnow().isoformat(),
                "metrics": metrics
            }
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao obter métricas: {str(e)}"
        )


@router.get(
    "/alerts",
    summary="Status de alertas",
    description="Verifica condições de alerta do sistema."
)
async def alert_status(
    session: AsyncSession = Depends(get_async_session),
    redis_client = Depends(get_redis_client)
) -> JSONResponse:
    """
    Verifica condições de alerta do sistema.
    
    Args:
        session: Sessão do banco de dados
        redis_client: Cliente Redis
        
    Returns:
        JSONResponse: Status de alertas
    """
    alerts = []
    alert_level = "ok"  # ok, warning, critical
    
    try:
        # 1. Verificar taxa de erro nas últimas 24h
        yesterday = datetime.utcnow() - timedelta(hours=24)
        
        total_calls = await session.execute(
            select(func.count(WebhookCall.id)).where(
                WebhookCall.created_at >= yesterday
            )
        )
        
        error_calls = await session.execute(
            select(func.count(WebhookCall.id)).where(
                WebhookCall.created_at >= yesterday,
                WebhookCall.status_code != 200
            )
        )
        
        total = total_calls.scalar() or 0
        errors = error_calls.scalar() or 0
        error_rate = (errors / total * 100) if total > 0 else 0
        
        if error_rate > 20:  # Mais de 20% de erro
            alerts.append({
                "type": "high_error_rate",
                "level": "critical",
                "message": f"Taxa de erro muito alta: {error_rate:.1f}%",
                "value": error_rate,
                "threshold": 20
            })
            alert_level = "critical"
        elif error_rate > 10:  # Mais de 10% de erro
            alerts.append({
                "type": "elevated_error_rate",
                "level": "warning",
                "message": f"Taxa de erro elevada: {error_rate:.1f}%",
                "value": error_rate,
                "threshold": 10
            })
            if alert_level == "ok":
                alert_level = "warning"
        
        # 2. Verificar tempo de resposta médio
        last_hour = datetime.utcnow() - timedelta(hours=1)
        
        avg_response_time = await session.execute(
            select(func.avg(WebhookCall.execution_time_ms)).where(
                WebhookCall.created_at >= last_hour,
                WebhookCall.execution_time_ms.isnot(None)
            )
        )
        
        avg_time = avg_response_time.scalar() or 0
        
        if avg_time > 5000:  # Mais de 5 segundos
            alerts.append({
                "type": "slow_response_time",
                "level": "critical",
                "message": f"Tempo de resposta muito lento: {avg_time:.0f}ms",
                "value": avg_time,
                "threshold": 5000
            })
            alert_level = "critical"
        elif avg_time > 2000:  # Mais de 2 segundos
            alerts.append({
                "type": "elevated_response_time",
                "level": "warning",
                "message": f"Tempo de resposta elevado: {avg_time:.0f}ms",
                "value": avg_time,
                "threshold": 2000
            })
            if alert_level == "ok":
                alert_level = "warning"
        
        # 3. Verificar recursos do sistema
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory_info = psutil.virtual_memory()
        
        if cpu_percent > 90:
            alerts.append({
                "type": "high_cpu_usage",
                "level": "critical",
                "message": f"Uso de CPU muito alto: {cpu_percent:.1f}%",
                "value": cpu_percent,
                "threshold": 90
            })
            alert_level = "critical"
        elif cpu_percent > 80:
            alerts.append({
                "type": "elevated_cpu_usage",
                "level": "warning",
                "message": f"Uso de CPU elevado: {cpu_percent:.1f}%",
                "value": cpu_percent,
                "threshold": 80
            })
            if alert_level == "ok":
                alert_level = "warning"
        
        if memory_info.percent > 90:
            alerts.append({
                "type": "high_memory_usage",
                "level": "critical",
                "message": f"Uso de memória muito alto: {memory_info.percent:.1f}%",
                "value": memory_info.percent,
                "threshold": 90
            })
            alert_level = "critical"
        elif memory_info.percent > 80:
            alerts.append({
                "type": "elevated_memory_usage",
                "level": "warning",
                "message": f"Uso de memória elevado: {memory_info.percent:.1f}%",
                "value": memory_info.percent,
                "threshold": 80
            })
            if alert_level == "ok":
                alert_level = "warning"
        
        # 4. Verificar conectividade Redis
        try:
            await redis_client.ping()
        except Exception as e:
            alerts.append({
                "type": "redis_connection_failed",
                "level": "critical",
                "message": f"Falha na conexão com Redis: {str(e)}",
                "error": str(e)
            })
            alert_level = "critical"
        
        # 5. Verificar integrações inativas
        inactive_integrations = await session.execute(
            select(func.count(Integration.id)).where(
                Integration.is_active == False
            )
        )
        
        inactive_count = inactive_integrations.scalar() or 0
        total_integrations = await session.execute(
            select(func.count(Integration.id))
        )
        
        total_int = total_integrations.scalar() or 0
        inactive_rate = (inactive_count / total_int * 100) if total_int > 0 else 0
        
        if inactive_rate > 50:  # Mais de 50% inativas
            alerts.append({
                "type": "many_inactive_integrations",
                "level": "warning",
                "message": f"Muitas integrações inativas: {inactive_count}/{total_int} ({inactive_rate:.1f}%)",
                "value": inactive_rate,
                "threshold": 50
            })
            if alert_level == "ok":
                alert_level = "warning"
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "timestamp": datetime.utcnow().isoformat(),
                "alert_level": alert_level,
                "alerts": alerts,
                "alert_count": len(alerts),
                "summary": {
                    "critical_alerts": len([a for a in alerts if a.get("level") == "critical"]),
                    "warning_alerts": len([a for a in alerts if a.get("level") == "warning"])
                }
            }
        )
        
    except Exception as e:
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "timestamp": datetime.utcnow().isoformat(),
                "alert_level": "critical",
                "alerts": [{
                    "type": "monitoring_system_error",
                    "level": "critical",
                    "message": f"Erro no sistema de monitoramento: {str(e)}",
                    "error": str(e)
                }],
                "alert_count": 1
            }
        )


@router.get(
    "/dependencies",
    summary="Status de dependências",
    description="Verifica status de todas as dependências externas."
)
async def dependencies_status(
    session: AsyncSession = Depends(get_async_session),
    redis_client = Depends(get_redis_client)
) -> JSONResponse:
    """
    Verifica status de todas as dependências externas.
    
    Args:
        session: Sessão do banco de dados
        redis_client: Cliente Redis
        
    Returns:
        JSONResponse: Status das dependências
    """
    dependencies = {}
    overall_status = "healthy"
    
    # 1. Banco de dados
    try:
        start_time = time.time()
        await session.execute(text("SELECT 1"))
        response_time = (time.time() - start_time) * 1000
        
        dependencies["database"] = {
            "status": "healthy",
            "response_time_ms": round(response_time, 2),
            "type": "postgresql",
            "critical": True
        }
    except Exception as e:
        dependencies["database"] = {
            "status": "unhealthy",
            "error": str(e),
            "type": "postgresql",
            "critical": True
        }
        overall_status = "unhealthy"
    
    # 2. Redis
    try:
        start_time = time.time()
        await redis_client.ping()
        response_time = (time.time() - start_time) * 1000
        
        dependencies["redis"] = {
            "status": "healthy",
            "response_time_ms": round(response_time, 2),
            "type": "redis",
            "critical": True
        }
    except Exception as e:
        dependencies["redis"] = {
            "status": "unhealthy",
            "error": str(e),
            "type": "redis",
            "critical": True
        }
        overall_status = "unhealthy"
    
    # 3. Suna Core (simulado)
    try:
        start_time = time.time()
        # Em produção, faria chamada real
        await asyncio.sleep(0.01)
        response_time = (time.time() - start_time) * 1000
        
        dependencies["suna_core"] = {
            "status": "healthy",
            "response_time_ms": round(response_time, 2),
            "type": "http_api",
            "critical": True,
            "endpoint": "http://suna-core:8000/health"
        }
    except Exception as e:
        dependencies["suna_core"] = {
            "status": "unhealthy",
            "error": str(e),
            "type": "http_api",
            "critical": True
        }
        overall_status = "unhealthy"
    
    # Contar dependências por status
    healthy_count = len([d for d in dependencies.values() if d["status"] == "healthy"])
    unhealthy_count = len([d for d in dependencies.values() if d["status"] == "unhealthy"])
    critical_unhealthy = len([
        d for d in dependencies.values()
        if d["status"] == "unhealthy" and d.get("critical", False)
    ])
    
    return JSONResponse(
        status_code=status.HTTP_200_OK if overall_status == "healthy" else status.HTTP_503_SERVICE_UNAVAILABLE,
        content={
            "timestamp": datetime.utcnow().isoformat(),
            "overall_status": overall_status,
            "dependencies": dependencies,
            "summary": {
                "total": len(dependencies),
                "healthy": healthy_count,
                "unhealthy": unhealthy_count,
                "critical_unhealthy": critical_unhealthy
            }
        }
    )