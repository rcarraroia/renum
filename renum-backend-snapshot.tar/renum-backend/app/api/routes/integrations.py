"""
Módulo que implementa as rotas da API para gerenciamento de integrações.

Este módulo contém os endpoints CRUD para integrações de agentes,
permitindo criar, listar, atualizar e excluir integrações.
"""

import logging
from typing import Optional, List, Dict, Any
from uuid import UUID
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, Path, status
from fastapi.responses import JSONResponse

from app.api.schemas.webhooks import (
    IntegrationCreate,
    IntegrationUpdate,
    IntegrationResponse,
    IntegrationListResponse,
    PaginationParams
)
from app.models.integrations import IntegrationChannel, IntegrationStatus
from app.services.integration_service import get_integration_service
from app.api.dependencies.auth import get_current_user

# Configurar logger
logger = logging.getLogger(__name__)

# Criar router
router = APIRouter(tags=["integrations"])


@router.post(
    "/integrations",
    response_model=IntegrationResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Criar nova integração",
    description="""
    Cria uma nova integração de agente com sistema externo.
    
    ## Funcionalidades
    
    - Gera token único automaticamente
    - Configura rate limiting personalizado
    - Suporte a metadados específicos do canal
    - Validação de permissões de acesso ao agente
    
    ## Canais Suportados
    
    - `whatsapp`: Integração com WhatsApp Business
    - `zapier`: Integração com Zapier
    - `n8n`: Integração com n8n
    - `telegram`: Integração com Telegram Bot
    - `custom`: Integração customizada
    """
)
async def create_integration(
    integration_data: IntegrationCreate,
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Cria uma nova integração de agente.
    
    Args:
        integration_data: Dados da integração
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        IntegrationResponse: Integração criada
        
    Raises:
        HTTPException: Se erro na criação
    """
    try:
        # TODO: Verificar se o usuário tem acesso ao agente
        # TODO: Verificar se o agente existe e está ativo
        
        integration = await integration_service.create_integration(
            request=integration_data,
            client_id=current_user.client_id,
            created_by=current_user.id
        )
        
        logger.info(f"Integração criada: {integration.id} por usuário {current_user.id}")
        return integration
        
    except ValueError as e:
        logger.warning(f"Dados inválidos para criação de integração: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Erro ao criar integração: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.get(
    "/integrations",
    response_model=IntegrationListResponse,
    summary="Listar integrações",
    description="""
    Lista as integrações do cliente com suporte a filtros e paginação.
    
    ## Filtros Disponíveis
    
    - `agent_id`: Filtrar por agente específico
    - `channel`: Filtrar por canal de integração
    - `status`: Filtrar por status (active/inactive)
    
    ## Paginação
    
    - `page`: Número da página (padrão: 1)
    - `per_page`: Itens por página (padrão: 20, máximo: 100)
    """
)
async def list_integrations(
    agent_id: Optional[UUID] = Query(None, description="Filtrar por agente"),
    channel: Optional[IntegrationChannel] = Query(None, description="Filtrar por canal"),
    status: Optional[IntegrationStatus] = Query(None, description="Filtrar por status"),
    page: int = Query(1, ge=1, description="Número da página"),
    per_page: int = Query(20, ge=1, le=100, description="Itens por página"),
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Lista integrações do cliente.
    
    Args:
        agent_id: Filtro por agente (opcional)
        channel: Filtro por canal (opcional)
        status: Filtro por status (opcional)
        page: Número da página
        per_page: Itens por página
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        IntegrationListResponse: Lista paginada de integrações
    """
    try:
        # Calcular offset
        offset = (page - 1) * per_page
        
        # Obter integrações
        integrations = await integration_service.list_integrations(
            client_id=current_user.client_id,
            agent_id=agent_id,
            channel=channel,
            status=status,
            limit=per_page,
            offset=offset
        )
        
        # Contar total
        total = await integration_service.count_integrations(
            client_id=current_user.client_id,
            agent_id=agent_id,
            channel=channel,
            status=status
        )
        
        response = IntegrationListResponse(
            integrations=integrations,
            total=total,
            page=page,
            per_page=per_page
        )
        
        logger.info(f"Listadas {len(integrations)} integrações para usuário {current_user.id}")
        return response
        
    except Exception as e:
        logger.error(f"Erro ao listar integrações: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.get(
    "/integrations/{integration_id}",
    response_model=IntegrationResponse,
    summary="Obter integração",
    description="Obtém uma integração específica por ID."
)
async def get_integration(
    integration_id: UUID = Path(..., description="ID da integração"),
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Obtém uma integração por ID.
    
    Args:
        integration_id: ID da integração
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        IntegrationResponse: Dados da integração
        
    Raises:
        HTTPException: Se integração não encontrada
    """
    try:
        integration = await integration_service.get_integration(
            integration_id=integration_id,
            client_id=current_user.client_id
        )
        
        if not integration:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Integração não encontrada"
            )
        
        logger.info(f"Integração obtida: {integration_id} por usuário {current_user.id}")
        return integration
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter integração {integration_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.put(
    "/integrations/{integration_id}",
    response_model=IntegrationResponse,
    summary="Atualizar integração",
    description="""
    Atualiza uma integração existente.
    
    ## Campos Atualizáveis
    
    - `status`: Ativar/desativar integração
    - `rate_limit_per_minute`: Alterar limite de chamadas
    - `metadata`: Atualizar metadados específicos do canal
    
    **Nota**: O token e canal não podem ser alterados após criação.
    """
)
async def update_integration(
    integration_id: UUID = Path(..., description="ID da integração"),
    integration_data: IntegrationUpdate = ...,
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Atualiza uma integração.
    
    Args:
        integration_id: ID da integração
        integration_data: Dados de atualização
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        IntegrationResponse: Integração atualizada
        
    Raises:
        HTTPException: Se integração não encontrada ou erro na atualização
    """
    try:
        integration = await integration_service.update_integration(
            integration_id=integration_id,
            request=integration_data,
            client_id=current_user.client_id
        )
        
        if not integration:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Integração não encontrada"
            )
        
        logger.info(f"Integração atualizada: {integration_id} por usuário {current_user.id}")
        return integration
        
    except HTTPException:
        raise
    except ValueError as e:
        logger.warning(f"Dados inválidos para atualização: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Erro ao atualizar integração {integration_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.delete(
    "/integrations/{integration_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Excluir integração",
    description="""
    Exclui uma integração permanentemente.
    
    **Atenção**: Esta ação não pode ser desfeita. Todos os logs de webhook
    associados também serão removidos.
    """
)
async def delete_integration(
    integration_id: UUID = Path(..., description="ID da integração"),
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Exclui uma integração.
    
    Args:
        integration_id: ID da integração
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Raises:
        HTTPException: Se integração não encontrada
    """
    try:
        success = await integration_service.delete_integration(
            integration_id=integration_id,
            client_id=current_user.client_id
        )
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Integração não encontrada"
            )
        
        logger.info(f"Integração excluída: {integration_id} por usuário {current_user.id}")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao excluir integração {integration_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.get(
    "/agents/{agent_id}/integrations",
    response_model=List[IntegrationResponse],
    summary="Listar integrações do agente",
    description="Lista todas as integrações de um agente específico."
)
async def list_agent_integrations(
    agent_id: UUID = Path(..., description="ID do agente"),
    channel: Optional[IntegrationChannel] = Query(None, description="Filtrar por canal"),
    status: Optional[IntegrationStatus] = Query(None, description="Filtrar por status"),
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Lista integrações de um agente específico.
    
    Args:
        agent_id: ID do agente
        channel: Filtro por canal (opcional)
        status: Filtro por status (opcional)
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        List[IntegrationResponse]: Lista de integrações do agente
    """
    try:
        # TODO: Verificar se o usuário tem acesso ao agente
        
        integrations = await integration_service.list_integrations(
            client_id=current_user.client_id,
            agent_id=agent_id,
            channel=channel,
            status=status,
            limit=100  # Limite maior para agente específico
        )
        
        logger.info(f"Listadas {len(integrations)} integrações do agente {agent_id}")
        return integrations
        
    except Exception as e:
        logger.error(f"Erro ao listar integrações do agente {agent_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.get(
    "/integrations/stats/summary",
    summary="Resumo de integrações",
    description="Obtém estatísticas resumidas das integrações do cliente."
)
async def get_integrations_summary(
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Obtém resumo estatístico das integrações.
    
    Args:
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        Dict: Estatísticas das integrações
    """
    try:
        # Contar por status
        active_count = await integration_service.count_integrations(
            client_id=current_user.client_id,
            status=IntegrationStatus.ACTIVE
        )
        
        inactive_count = await integration_service.count_integrations(
            client_id=current_user.client_id,
            status=IntegrationStatus.INACTIVE
        )
        
        # Contar por canal
        channel_stats = {}
        for channel in IntegrationChannel:
            count = await integration_service.count_integrations(
                client_id=current_user.client_id,
                channel=channel
            )
            if count > 0:
                channel_stats[channel.value] = count
        
        summary = {
            "total_integrations": active_count + inactive_count,
            "active_integrations": active_count,
            "inactive_integrations": inactive_count,
            "by_channel": channel_stats,
            "timestamp": "2024-01-15T10:30:00Z"  # TODO: Usar timestamp real
        }
        
        logger.info(f"Resumo de integrações obtido para usuário {current_user.id}")
        return summary
        
    except Exception as e:
        logger.error(f"Erro ao obter resumo de integrações: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.post(
    "/integrations/{integration_id}/regenerate-token",
    response_model=IntegrationResponse,
    summary="Regenerar token de integração",
    description="""
    Regenera o token de webhook de uma integração.
    
    **Atenção**: O token anterior será invalidado imediatamente.
    Atualize todos os sistemas externos que usam esta integração.
    """
)
async def regenerate_integration_token(
    integration_id: UUID = Path(..., description="ID da integração"),
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Regenera o token de uma integração.
    
    Args:
        integration_id: ID da integração
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        IntegrationResponse: Integração com novo token
        
    Raises:
        HTTPException: Se integração não encontrada
    """
    try:
        integration = await integration_service.regenerate_token(
            integration_id=integration_id,
            client_id=current_user.client_id
        )
        
        if not integration:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Integração não encontrada"
            )
        
        logger.info(f"Token regenerado para integração {integration_id} por usuário {current_user.id}")
        return integration
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao regenerar token da integração {integration_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.post(
    "/integrations/{integration_id}/test",
    summary="Testar integração",
    description="""
    Testa uma integração enviando um payload simulado.
    
    ## Funcionalidades
    
    - Valida se a integração está ativa
    - Simula execução do agente
    - Retorna resposta formatada
    - Não consome rate limit real
    
    **Nota**: Este é um teste simulado. Para teste real,
    use o endpoint de webhook diretamente.
    """
)
async def test_integration(
    integration_id: UUID = Path(..., description="ID da integração"),
    test_data: Dict[str, Any] = ...,
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Testa uma integração.
    
    Args:
        integration_id: ID da integração
        test_data: Payload de teste
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        Dict: Resultado do teste
        
    Raises:
        HTTPException: Se integração não encontrada
    """
    try:
        result = await integration_service.test_integration(
            integration_id=integration_id,
            client_id=current_user.client_id,
            test_payload=test_data
        )
        
        if not result["success"]:
            # Determinar status code baseado no erro
            error_msg = result.get("error", "")
            if "não encontrada" in error_msg:
                status_code = status.HTTP_404_NOT_FOUND
            elif "não está ativa" in error_msg:
                status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
            else:
                status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            
            raise HTTPException(
                status_code=status_code,
                detail=result["error"]
            )
        
        logger.info(f"Integração testada: {integration_id} por usuário {current_user.id}")
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao testar integração {integration_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.get(
    "/integrations/{integration_id}/token-info",
    summary="Informações do token",
    description="""
    Obtém informações sobre o token de uma integração.
    
    **Segurança**: O token completo não é retornado, apenas
    informações sobre sua validade e formato.
    """
)
async def get_token_info(
    integration_id: UUID = Path(..., description="ID da integração"),
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Obtém informações sobre o token de uma integração.
    
    Args:
        integration_id: ID da integração
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        Dict: Informações do token
        
    Raises:
        HTTPException: Se integração não encontrada
    """
    try:
        integration = await integration_service.get_integration(
            integration_id=integration_id,
            client_id=current_user.client_id
        )
        
        if not integration:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Integração não encontrada"
            )
        
        # Informações seguras sobre o token
        token_info = {
            "integration_id": str(integration_id),
            "token_prefix": integration.webhook_token[:8] + "...",
            "token_length": len(integration.webhook_token),
            "is_valid_format": integration.webhook_token.startswith("whk_"),
            "webhook_url": integration.webhook_url,
            "status": integration.status.value,
            "created_at": integration.created_at.isoformat(),
            "updated_at": integration.updated_at.isoformat()
        }
        
        logger.info(f"Informações do token obtidas para integração {integration_id}")
        return token_info
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter informações do token da integração {integration_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.get(
    "/integrations/{integration_id}/calls",
    summary="Histórico de chamadas webhook",
    description="""
    Obtém o histórico de chamadas webhook de uma integração.
    
    ## Filtros Disponíveis
    
    - `status_code`: Filtrar por código de status HTTP
    - `start_date`: Data inicial (ISO format)
    - `end_date`: Data final (ISO format)
    - `page`: Número da página
    - `per_page`: Itens por página
    
    ## Informações Incluídas
    
    - Timestamp da chamada
    - Código de status HTTP
    - Tempo de execução
    - IP de origem
    - User-Agent
    - Mensagem de erro (se houver)
    """
)
async def get_integration_calls(
    integration_id: UUID = Path(..., description="ID da integração"),
    status_code: Optional[int] = Query(None, description="Filtrar por status code"),
    start_date: Optional[str] = Query(None, description="Data inicial (ISO format)"),
    end_date: Optional[str] = Query(None, description="Data final (ISO format)"),
    page: int = Query(1, ge=1, description="Número da página"),
    per_page: int = Query(20, ge=1, le=100, description="Itens por página"),
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Obtém histórico de chamadas webhook.
    
    Args:
        integration_id: ID da integração
        status_code: Filtro por status code (opcional)
        start_date: Data inicial (opcional)
        end_date: Data final (opcional)
        page: Número da página
        per_page: Itens por página
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        Dict: Lista paginada de chamadas webhook
    """
    try:
        # Converter datas se fornecidas
        start_dt = None
        end_dt = None
        
        if start_date:
            try:
                start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Formato de data inicial inválido. Use ISO format."
                )
        
        if end_date:
            try:
                end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Formato de data final inválido. Use ISO format."
                )
        
        # Calcular offset
        offset = (page - 1) * per_page
        
        # Obter chamadas
        calls = await integration_service.get_webhook_calls(
            integration_id=integration_id,
            client_id=current_user.client_id,
            limit=per_page,
            offset=offset,
            status_code=status_code,
            start_date=start_dt,
            end_date=end_dt
        )
        
        # TODO: Implementar contagem total para paginação correta
        total = len(calls)  # Simplificado por enquanto
        
        response = {
            "calls": calls,
            "total": total,
            "page": page,
            "per_page": per_page,
            "filters": {
                "status_code": status_code,
                "start_date": start_date,
                "end_date": end_date
            }
        }
        
        logger.info(f"Histórico de chamadas obtido para integração {integration_id}")
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter histórico de chamadas: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.get(
    "/integrations/{integration_id}/analytics",
    summary="Analytics da integração",
    description="""
    Obtém analytics detalhados de uma integração.
    
    ## Métricas Incluídas
    
    - Total de chamadas e taxa de sucesso
    - Tempo médio de execução
    - Distribuição por status code
    - Distribuição horária (últimas 24h)
    - Tipos de erro mais comuns
    - Tendências de uso
    
    ## Períodos Disponíveis
    
    - 1 hora: `period_hours=1`
    - 24 horas: `period_hours=24` (padrão)
    - 7 dias: `period_hours=168`
    - 30 dias: `period_hours=720`
    """
)
async def get_integration_analytics(
    integration_id: UUID = Path(..., description="ID da integração"),
    period_hours: int = Query(24, ge=1, le=8760, description="Período em horas"),
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Obtém analytics de uma integração.
    
    Args:
        integration_id: ID da integração
        period_hours: Período em horas
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        Dict: Analytics da integração
    """
    try:
        analytics = await integration_service.get_integration_analytics(
            integration_id=integration_id,
            client_id=current_user.client_id,
            period_hours=period_hours
        )
        
        if not analytics:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Integração não encontrada"
            )
        
        logger.info(f"Analytics obtidos para integração {integration_id}")
        return analytics
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter analytics da integração: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.get(
    "/analytics/summary",
    summary="Resumo de analytics do cliente",
    description="""
    Obtém resumo de analytics de todas as integrações do cliente.
    
    ## Informações Incluídas
    
    - Estatísticas agregadas de todas as integrações
    - Top 5 integrações por volume de chamadas
    - Distribuição por canal de integração
    - Métricas de performance geral
    - Comparação de períodos
    """
)
async def get_client_analytics_summary(
    period_hours: int = Query(24, ge=1, le=8760, description="Período em horas"),
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Obtém resumo de analytics do cliente.
    
    Args:
        period_hours: Período em horas
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        Dict: Resumo de analytics
    """
    try:
        summary = await integration_service.get_client_analytics_summary(
            client_id=current_user.client_id,
            period_hours=period_hours
        )
        
        logger.info(f"Resumo de analytics obtido para cliente {current_user.client_id}")
        return summary
        
    except Exception as e:
        logger.error(f"Erro ao obter resumo de analytics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.get(
    "/integrations/{integration_id}/health",
    summary="Status de saúde da integração",
    description="""
    Verifica o status de saúde de uma integração.
    
    ## Verificações Incluídas
    
    - Status da integração (ativa/inativa)
    - Última chamada bem-sucedida
    - Taxa de erro recente
    - Disponibilidade do agente
    - Rate limiting atual
    """
)
async def get_integration_health(
    integration_id: UUID = Path(..., description="ID da integração"),
    current_user = Depends(get_current_user),
    integration_service = Depends(get_integration_service)
):
    """
    Verifica saúde de uma integração.
    
    Args:
        integration_id: ID da integração
        current_user: Usuário autenticado
        integration_service: Serviço de integrações
        
    Returns:
        Dict: Status de saúde
    """
    try:
        # Obter integração
        integration = await integration_service.get_integration(
            integration_id=integration_id,
            client_id=current_user.client_id
        )
        
        if not integration:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Integração não encontrada"
            )
        
        # Obter estatísticas recentes (última hora)
        recent_analytics = await integration_service.get_integration_analytics(
            integration_id=integration_id,
            client_id=current_user.client_id,
            period_hours=1
        )
        
        # Determinar status de saúde
        health_status = "healthy"
        issues = []
        
        if integration.status != IntegrationStatus.ACTIVE:
            health_status = "inactive"
            issues.append("Integração está inativa")
        
        if recent_analytics.get("error_rate", 0) > 50:
            health_status = "degraded"
            issues.append(f"Taxa de erro alta: {recent_analytics['error_rate']:.1f}%")
        
        if recent_analytics.get("total_calls", 0) == 0 and integration.status == IntegrationStatus.ACTIVE:
            health_status = "warning"
            issues.append("Nenhuma chamada recente")
        
        health_info = {
            "integration_id": str(integration_id),
            "status": health_status,
            "integration_active": integration.status == IntegrationStatus.ACTIVE,
            "last_call_at": recent_analytics.get("last_call_at"),
            "recent_calls": recent_analytics.get("total_calls", 0),
            "recent_success_rate": recent_analytics.get("success_rate", 0),
            "recent_avg_time_ms": recent_analytics.get("avg_execution_time_ms"),
            "issues": issues,
            "checked_at": datetime.now().isoformat()
        }
        
        logger.info(f"Status de saúde verificado para integração {integration_id}: {health_status}")
        return health_info
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao verificar saúde da integração: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )