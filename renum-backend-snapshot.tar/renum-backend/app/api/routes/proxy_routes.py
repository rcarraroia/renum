"""
Rotas de proxy genérico para o Suna Backend.

Este módulo implementa rotas que encaminham requisições dos frontends
diretamente para o suna-backend, atuando como um proxy transparente.
"""

import logging
from typing import Dict, Any, Optional
from fastapi import APIRouter, Request, HTTPException, WebSocket, Query
from fastapi.responses import Response, StreamingResponse

from app.services.suna_proxy import suna_proxy_service
from app.api.dependencies.auth import get_current_user_optional

logger = logging.getLogger(__name__)

# Criar router para proxy genérico
router = APIRouter(
    tags=["Proxy"],
    responses={404: {"description": "Not found"}},
)

class ProxyRequest:
    """Classe auxiliar para criar requisições proxy."""
    
    def __init__(self, original_request: Request, new_path: str):
        self.method = original_request.method
        self.url = original_request.url.replace(path=new_path)
        self.headers = original_request.headers
        self.query_params = original_request.query_params
        self._body = None
        self._original_request = original_request
    
    async def body(self):
        if self._body is None:
            self._body = await self._original_request.body()
        return self._body

@router.api_route(
    "/proxy/suna/{path:path}",
    methods=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"],
    response_class=Response
)
async def proxy_to_suna(
    path: str,
    request: Request
):
    """
    Proxy genérico para encaminhar requisições ao suna-backend.
    
    Args:
        path: Caminho da requisição a ser encaminhada
        request: Requisição FastAPI original
        
    Returns:
        Resposta do suna-backend
    """
    try:
        # Reconstrói o path original removendo o prefixo /proxy/suna
        original_path = f"/{path}"
        
        # Cria uma nova requisição com o path correto
        proxy_request = ProxyRequest(request, original_path)
        
        # Obtém dados do usuário do middleware
        current_user = await get_current_user_optional(request)
        
        # Encaminha a requisição
        response = await suna_proxy_service.forward_request(
            proxy_request, 
            current_user
        )
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro no proxy genérico para {path}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Erro interno do proxy: {str(e)}"
        )

@router.api_route(
    "/proxy/suna/stream/{path:path}",
    methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    response_class=StreamingResponse
)
async def proxy_streaming_to_suna(
    path: str,
    request: Request
):
    """
    Proxy para requisições com resposta em streaming ao suna-backend.
    
    Args:
        path: Caminho da requisição a ser encaminhada
        request: Requisição FastAPI original
        
    Returns:
        Resposta em streaming do suna-backend
    """
    try:
        # Reconstrói o path original removendo o prefixo /proxy/suna/stream
        original_path = f"/{path}"
        
        # Cria uma nova requisição com o path correto
        proxy_request = ProxyRequest(request, original_path)
        
        # Obtém dados do usuário do middleware
        current_user = await get_current_user_optional(request)
        
        # Encaminha a requisição com streaming
        response = await suna_proxy_service.forward_streaming_request(
            proxy_request, 
            current_user
        )
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro no proxy streaming para {path}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Erro interno do proxy streaming: {str(e)}"
        )

@router.get("/proxy/suna/health")
async def proxy_health_check():
    """
    Verifica a saúde da conexão com o suna-backend através do proxy.
    
    Returns:
        Status da conexão com o suna-backend
    """
    try:
        health_status = await suna_proxy_service.health_check()
        return health_status
        
    except Exception as e:
        logger.error(f"Erro no health check do proxy: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Erro no health check do proxy: {str(e)}"
        )

# Rotas de proxy direto (sem prefixo /proxy/suna) para compatibilidade
@router.api_route(
    "/api/v1/{path:path}",
    methods=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"],
    response_class=Response
)
async def direct_proxy_to_suna(
    path: str,
    request: Request
):
    """
    Proxy direto para encaminhar requisições /api/v1/* ao suna-backend.
    
    Esta rota permite que os frontends façam requisições diretamente
    para /api/v1/* e sejam automaticamente encaminhadas ao suna-backend.
    
    Args:
        path: Caminho da requisição a ser encaminhada
        request: Requisição FastAPI original
        
    Returns:
        Resposta do suna-backend
    """
    try:
        # Reconstrói o path original
        original_path = f"/api/v1/{path}"
        
        # Cria uma nova requisição com o path correto
        proxy_request = ProxyRequest(request, original_path)
        
        # Obtém dados do usuário do middleware
        current_user = await get_current_user_optional(request)
        
        # Encaminha a requisição
        response = await suna_proxy_service.forward_request(
            proxy_request, 
            current_user
        )
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro no proxy direto para {path}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Erro interno do proxy direto: {str(e)}"
        )

@router.websocket("/ws/proxy/suna/{path:path}")
async def websocket_proxy_to_suna(
    websocket: WebSocket,
    path: str,
    token: Optional[str] = Query(None, description="Authentication token"),
):
    """
    Proxy WebSocket para encaminhar conexões ao suna-backend.
    
    Args:
        websocket: Conexão WebSocket do cliente
        path: Caminho do WebSocket a ser encaminhado
        token: Token de autenticação (opcional)
    """
    try:
        # Aceita a conexão WebSocket
        await websocket.accept()
        
        # Tenta obter dados do usuário se token fornecido
        user_data = None
        if token:
            try:
                # Simula a validação do token (em produção, usar validação real)
                user_data = {
                    "id": "user-from-token",
                    "email": "user@example.com",
                    "role": "user"
                }
            except Exception as e:
                logger.warning(f"Erro ao validar token WebSocket: {str(e)}")
        
        # Obtém parâmetros de query
        query_params = dict(websocket.query_params) if websocket.query_params else None
        
        # Encaminha a conexão WebSocket
        await suna_proxy_service.proxy_websocket(
            websocket,
            f"/{path}",
            query_params,
            user_data
        )
        
    except Exception as e:
        logger.error(f"Erro no proxy WebSocket para {path}: {str(e)}")
        if websocket.client_state.CONNECTED:
            await websocket.close(code=1011, reason=f"Proxy error: {str(e)}")

@router.websocket("/ws/{path:path}")
async def direct_websocket_proxy_to_suna(
    websocket: WebSocket,
    path: str,
    token: Optional[str] = Query(None, description="Authentication token"),
):
    """
    Proxy WebSocket direto para encaminhar conexões /ws/* ao suna-backend.
    
    Esta rota permite que os frontends façam conexões WebSocket diretamente
    para /ws/* e sejam automaticamente encaminhadas ao suna-backend.
    
    Args:
        websocket: Conexão WebSocket do cliente
        path: Caminho do WebSocket a ser encaminhado
        token: Token de autenticação (opcional)
    """
    try:
        # Aceita a conexão WebSocket
        await websocket.accept()
        
        # Tenta obter dados do usuário se token fornecido
        user_data = None
        if token:
            try:
                # Simula a validação do token (em produção, usar validação real)
                user_data = {
                    "id": "user-from-token",
                    "email": "user@example.com",
                    "role": "user"
                }
            except Exception as e:
                logger.warning(f"Erro ao validar token WebSocket: {str(e)}")
        
        # Obtém parâmetros de query
        query_params = dict(websocket.query_params) if websocket.query_params else None
        
        # Reconstrói o path original
        original_path = f"/ws/{path}"
        
        # Encaminha a conexão WebSocket
        await suna_proxy_service.proxy_websocket(
            websocket,
            original_path,
            query_params,
            user_data
        )
        
    except Exception as e:
        logger.error(f"Erro no proxy WebSocket direto para {path}: {str(e)}")
        if websocket.client_state.CONNECTED:
            await websocket.close(code=1011, reason=f"Proxy error: {str(e)}")