"""
Endpoints para monitoramento de segurança.

Este módulo contém endpoints para monitorar eventos de segurança,
IPs bloqueados, métricas de ameaças e relatórios de segurança.
"""

import time
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from app.services.advanced_rate_limiting import (
    get_advanced_rate_limiter,
    ThreatLevel,
    BlockReason
)
from app.core.dependencies import get_redis_client, get_current_admin_user


# Criar router
router = APIRouter(tags=["security-monitoring"], prefix="/api/v1/security")


@router.get(
    "/blocked-ips",
    summary="Listar IPs bloqueados",
    description="Retorna lista de IPs atualmente bloqueados por atividade suspeita."
)
async def get_blocked_ips(
    redis_client = Depends(get_redis_client),
    current_user = Depends(get_current_admin_user)
) -> JSONResponse:
    """
    Lista IPs atualmente bloqueados.
    
    Args:
        redis_client: Cliente Redis
        current_user: Usuário admin autenticado
        
    Returns:
        JSONResponse: Lista de IPs bloqueados
    """
    try:
        rate_limiter = get_advanced_rate_limiter(redis_client)
        blocked_ips = await rate_limiter.get_blocked_ips()
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "blocked_ips": blocked_ips,
                "total": len(blocked_ips),
                "timestamp": datetime.utcnow().isoformat()
            }
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao obter IPs bloqueados: {str(e)}"
        )


@router.delete(
    "/blocked-ips/{ip_address}",
    summary="Desbloquear IP",
    description="Remove bloqueio de um IP específico."
)
async def unblock_ip(
    ip_address: str,
    redis_client = Depends(get_redis_client),
    current_user = Depends(get_current_admin_user)
) -> JSONResponse:
    """
    Remove bloqueio de um IP.
    
    Args:
        ip_address: IP a ser desbloqueado
        redis_client: Cliente Redis
        current_user: Usuário admin autenticado
        
    Returns:
        JSONResponse: Resultado da operação
    """
    try:
        rate_limiter = get_advanced_rate_limiter(redis_client)
        success = await rate_limiter.unblock_ip(ip_address)
        
        if success:
            return JSONResponse(
                status_code=status.HTTP_200_OK,
                content={
                    "success": True,
                    "message": f"IP {ip_address} desbloqueado com sucesso",
                    "ip_address": ip_address,
                    "unblocked_by": current_user.id,
                    "timestamp": datetime.utcnow().isoformat()
                }
            )
        else:
            return JSONResponse(
                status_code=status.HTTP_404_NOT_FOUND,
                content={
                    "success": False,
                    "message": f"IP {ip_address} não estava bloqueado",
                    "ip_address": ip_address
                }
            )
            
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao desbloquear IP: {str(e)}"
        )


@router.get(
    "/events",
    summary="Listar eventos de segurança",
    description="Retorna eventos de segurança recentes com filtros opcionais."
)
async def get_security_events(
    limit: int = Query(100, ge=1, le=1000, description="Limite de eventos"),
    threat_level: Optional[ThreatLevel] = Query(None, description="Filtrar por nível de ameaça"),
    hours: int = Query(24, ge=1, le=168, description="Últimas N horas"),
    redis_client = Depends(get_redis_client),
    current_user = Depends(get_current_admin_user)
) -> JSONResponse:
    """
    Lista eventos de segurança recentes.
    
    Args:
        limit: Limite de eventos a retornar
        threat_level: Filtrar por nível de ameaça
        hours: Últimas N horas
        redis_client: Cliente Redis
        current_user: Usuário admin autenticado
        
    Returns:
        JSONResponse: Lista de eventos de segurança
    """
    try:
        rate_limiter = get_advanced_rate_limiter(redis_client)
        events = await rate_limiter.get_security_events(
            limit=limit,
            threat_level=threat_level
        )
        
        # Filtrar por tempo se necessário
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        filtered_events = []
        
        for event in events:
            event_time = datetime.fromisoformat(event["timestamp"].replace('Z', '+00:00'))
            if event_time >= cutoff_time:
                filtered_events.append(event)
        
        # Estatísticas dos eventos
        stats = {
            "total_events": len(filtered_events),
            "threat_levels": {},
            "event_types": {},
            "top_ips": {}
        }
        
        for event in filtered_events:
            # Contar por nível de ameaça
            level = event["threat_level"]
            stats["threat_levels"][level] = stats["threat_levels"].get(level, 0) + 1
            
            # Contar por tipo de evento
            event_type = event["event_type"]
            stats["event_types"][event_type] = stats["event_types"].get(event_type, 0) + 1
            
            # Contar por IP
            ip = event["ip_address"]
            stats["top_ips"][ip] = stats["top_ips"].get(ip, 0) + 1
        
        # Top 10 IPs mais ativos
        stats["top_ips"] = dict(sorted(
            stats["top_ips"].items(),
            key=lambda x: x[1],
            reverse=True
        )[:10])
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "events": filtered_events,
                "statistics": stats,
                "filters": {
                    "limit": limit,
                    "threat_level": threat_level.value if threat_level else None,
                    "hours": hours
                },
                "timestamp": datetime.utcnow().isoformat()
            }
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao obter eventos de segurança: {str(e)}"
        )


@router.get(
    "/metrics",
    summary="Métricas de segurança",
    description="Retorna métricas agregadas de segurança e ameaças."
)
async def get_security_metrics(
    hours: int = Query(24, ge=1, le=168, description="Período em horas"),
    redis_client = Depends(get_redis_client),
    current_user = Depends(get_current_admin_user)
) -> JSONResponse:
    """
    Obtém métricas agregadas de segurança.
    
    Args:
        hours: Período em horas para análise
        redis_client: Cliente Redis
        current_user: Usuário admin autenticado
        
    Returns:
        JSONResponse: Métricas de segurança
    """
    try:
        rate_limiter = get_advanced_rate_limiter(redis_client)
        
        # Obter eventos recentes
        events = await rate_limiter.get_security_events(limit=10000)
        
        # Filtrar por período
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        recent_events = []
        
        for event in events:
            event_time = datetime.fromisoformat(event["timestamp"].replace('Z', '+00:00'))
            if event_time >= cutoff_time:
                recent_events.append(event)
        
        # Obter IPs bloqueados
        blocked_ips = await rate_limiter.get_blocked_ips()
        
        # Calcular métricas
        metrics = {
            "period_hours": hours,
            "total_events": len(recent_events),
            "blocked_ips_count": len(blocked_ips),
            "threat_levels": {
                "low": 0,
                "medium": 0,
                "high": 0,
                "critical": 0
            },
            "attack_types": {
                "sql_injection": 0,
                "xss": 0,
                "command_injection": 0,
                "path_traversal": 0,
                "rate_limit_exceeded": 0,
                "suspicious_patterns": 0,
                "malicious_payload": 0,
                "brute_force": 0
            },
            "hourly_distribution": {},
            "geographic_distribution": {},
            "user_agent_analysis": {
                "bots": 0,
                "tools": 0,
                "scanners": 0,
                "legitimate": 0
            },
            "top_attacking_ips": {},
            "blocked_countries": []
        }
        
        # Processar eventos
        for event in recent_events:
            # Contar por nível de ameaça
            threat_level = event["threat_level"]
            if threat_level in metrics["threat_levels"]:
                metrics["threat_levels"][threat_level] += 1
            
            # Analisar detalhes do evento
            details = event.get("details", {})
            
            # Detectar tipos de ataque
            if "detected_patterns" in details:
                patterns = details["detected_patterns"]
                for pattern in patterns:
                    if pattern in metrics["attack_types"]:
                        metrics["attack_types"][pattern] += 1
            
            # Distribuição horária
            event_time = datetime.fromisoformat(event["timestamp"].replace('Z', '+00:00'))
            hour_key = event_time.strftime("%Y-%m-%d %H:00")
            metrics["hourly_distribution"][hour_key] = metrics["hourly_distribution"].get(hour_key, 0) + 1
            
            # Top IPs atacantes
            ip = event["ip_address"]
            metrics["top_attacking_ips"][ip] = metrics["top_attacking_ips"].get(ip, 0) + 1
            
            # Análise de User-Agent
            user_agent = details.get("user_agent", "").lower()
            if any(bot in user_agent for bot in ["bot", "crawler", "spider"]):
                metrics["user_agent_analysis"]["bots"] += 1
            elif any(tool in user_agent for tool in ["curl", "wget", "python"]):
                metrics["user_agent_analysis"]["tools"] += 1
            elif any(scanner in user_agent for scanner in ["sqlmap", "nmap", "nikto"]):
                metrics["user_agent_analysis"]["scanners"] += 1
            else:
                metrics["user_agent_analysis"]["legitimate"] += 1
        
        # Top 10 IPs atacantes
        metrics["top_attacking_ips"] = dict(sorted(
            metrics["top_attacking_ips"].items(),
            key=lambda x: x[1],
            reverse=True
        )[:10])
        
        # Análise de IPs bloqueados
        for blocked_ip in blocked_ips:
            country = blocked_ip.get("country", "Unknown")
            if country not in metrics["blocked_countries"]:
                metrics["blocked_countries"].append(country)
        
        # Calcular taxas
        total_requests = sum(metrics["attack_types"].values()) + metrics["user_agent_analysis"]["legitimate"]
        if total_requests > 0:
            metrics["attack_rate"] = (sum(metrics["attack_types"].values()) / total_requests) * 100
            metrics["block_rate"] = (len(blocked_ips) / total_requests) * 100
        else:
            metrics["attack_rate"] = 0
            metrics["block_rate"] = 0
        
        # Tendências (comparar com período anterior)
        previous_cutoff = cutoff_time - timedelta(hours=hours)
        previous_events = [
            event for event in events
            if previous_cutoff <= datetime.fromisoformat(event["timestamp"].replace('Z', '+00:00')) < cutoff_time
        ]
        
        metrics["trends"] = {
            "events_change": len(recent_events) - len(previous_events),
            "events_change_percent": (
                ((len(recent_events) - len(previous_events)) / max(len(previous_events), 1)) * 100
                if len(previous_events) > 0 else 0
            )
        }
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "metrics": metrics,
                "timestamp": datetime.utcnow().isoformat(),
                "generated_by": current_user.id
            }
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao calcular métricas de segurança: {str(e)}"
        )


@router.get(
    "/report",
    summary="Relatório de segurança",
    description="Gera relatório detalhado de segurança para um período específico."
)
async def generate_security_report(
    start_date: Optional[str] = Query(None, description="Data início (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="Data fim (YYYY-MM-DD)"),
    format: str = Query("json", regex="^(json|csv)$", description="Formato do relatório"),
    redis_client = Depends(get_redis_client),
    current_user = Depends(get_current_admin_user)
) -> JSONResponse:
    """
    Gera relatório detalhado de segurança.
    
    Args:
        start_date: Data de início do relatório
        end_date: Data de fim do relatório
        format: Formato do relatório (json ou csv)
        redis_client: Cliente Redis
        current_user: Usuário admin autenticado
        
    Returns:
        JSONResponse: Relatório de segurança
    """
    try:
        # Definir período padrão (últimos 7 dias)
        if not start_date:
            start_dt = datetime.utcnow() - timedelta(days=7)
        else:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        
        if not end_date:
            end_dt = datetime.utcnow()
        else:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
        
        rate_limiter = get_advanced_rate_limiter(redis_client)
        
        # Obter todos os eventos no período
        all_events = await rate_limiter.get_security_events(limit=50000)
        period_events = []
        
        for event in all_events:
            event_time = datetime.fromisoformat(event["timestamp"].replace('Z', '+00:00'))
            if start_dt <= event_time <= end_dt:
                period_events.append(event)
        
        # Obter IPs bloqueados
        blocked_ips = await rate_limiter.get_blocked_ips()
        
        # Gerar relatório
        report = {
            "report_info": {
                "generated_at": datetime.utcnow().isoformat(),
                "generated_by": current_user.id,
                "period": {
                    "start": start_dt.isoformat(),
                    "end": end_dt.isoformat(),
                    "days": (end_dt - start_dt).days
                },
                "format": format
            },
            "summary": {
                "total_events": len(period_events),
                "unique_ips": len(set(event["ip_address"] for event in period_events)),
                "blocked_ips": len(blocked_ips),
                "critical_events": len([e for e in period_events if e["threat_level"] == "critical"]),
                "high_threat_events": len([e for e in period_events if e["threat_level"] == "high"])
            },
            "detailed_analysis": {
                "threat_distribution": {},
                "attack_patterns": {},
                "geographic_analysis": {},
                "temporal_analysis": {},
                "top_threats": []
            },
            "recommendations": [],
            "blocked_ips_details": blocked_ips,
            "critical_events": [
                event for event in period_events
                if event["threat_level"] in ["critical", "high"]
            ][:50]  # Top 50 eventos críticos
        }
        
        # Análise detalhada
        threat_counts = {}
        attack_patterns = {}
        hourly_distribution = {}
        
        for event in period_events:
            # Distribuição de ameaças
            threat_level = event["threat_level"]
            threat_counts[threat_level] = threat_counts.get(threat_level, 0) + 1
            
            # Padrões de ataque
            details = event.get("details", {})
            if "detected_patterns" in details:
                for pattern in details["detected_patterns"]:
                    attack_patterns[pattern] = attack_patterns.get(pattern, 0) + 1
            
            # Distribuição temporal
            event_time = datetime.fromisoformat(event["timestamp"].replace('Z', '+00:00'))
            hour = event_time.hour
            hourly_distribution[hour] = hourly_distribution.get(hour, 0) + 1
        
        report["detailed_analysis"]["threat_distribution"] = threat_counts
        report["detailed_analysis"]["attack_patterns"] = attack_patterns
        report["detailed_analysis"]["temporal_analysis"] = {
            "hourly_distribution": hourly_distribution,
            "peak_hour": max(hourly_distribution.items(), key=lambda x: x[1])[0] if hourly_distribution else None
        }
        
        # Top ameaças
        ip_threat_counts = {}
        for event in period_events:
            ip = event["ip_address"]
            if ip not in ip_threat_counts:
                ip_threat_counts[ip] = {"count": 0, "threat_levels": []}
            ip_threat_counts[ip]["count"] += 1
            ip_threat_counts[ip]["threat_levels"].append(event["threat_level"])
        
        report["detailed_analysis"]["top_threats"] = sorted(
            [
                {
                    "ip_address": ip,
                    "event_count": data["count"],
                    "max_threat_level": max(data["threat_levels"], key=lambda x: ["low", "medium", "high", "critical"].index(x))
                }
                for ip, data in ip_threat_counts.items()
            ],
            key=lambda x: x["event_count"],
            reverse=True
        )[:20]
        
        # Recomendações baseadas na análise
        recommendations = []
        
        if threat_counts.get("critical", 0) > 0:
            recommendations.append({
                "priority": "high",
                "category": "threat_response",
                "message": f"Detectados {threat_counts['critical']} eventos críticos. Revisar imediatamente.",
                "action": "Investigar eventos críticos e considerar bloqueios adicionais"
            })
        
        if len(blocked_ips) > 100:
            recommendations.append({
                "priority": "medium",
                "category": "capacity",
                "message": f"Alto número de IPs bloqueados ({len(blocked_ips)}). Considerar revisão.",
                "action": "Revisar lista de IPs bloqueados e remover bloqueios desnecessários"
            })
        
        if attack_patterns.get("sql_injection", 0) > 10:
            recommendations.append({
                "priority": "high",
                "category": "vulnerability",
                "message": f"Múltiplas tentativas de SQL injection detectadas ({attack_patterns['sql_injection']}).",
                "action": "Revisar e fortalecer validação de entrada de dados"
            })
        
        report["recommendations"] = recommendations
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content=report
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao gerar relatório de segurança: {str(e)}"
        )


@router.post(
    "/whitelist-ip",
    summary="Adicionar IP à whitelist",
    description="Adiciona um IP à lista de IPs confiáveis."
)
async def whitelist_ip(
    ip_address: str,
    reason: str,
    redis_client = Depends(get_redis_client),
    current_user = Depends(get_current_admin_user)
) -> JSONResponse:
    """
    Adiciona IP à whitelist.
    
    Args:
        ip_address: IP a ser adicionado à whitelist
        reason: Razão para whitelist
        redis_client: Cliente Redis
        current_user: Usuário admin autenticado
        
    Returns:
        JSONResponse: Resultado da operação
    """
    try:
        # Validar formato do IP
        import ipaddress
        try:
            ipaddress.ip_address(ip_address)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Formato de IP inválido"
            )
        
        # Adicionar à whitelist
        whitelist_key = f"whitelist_ip:{ip_address}"
        whitelist_data = {
            "ip_address": ip_address,
            "reason": reason,
            "added_by": current_user.id,
            "added_at": datetime.utcnow().isoformat()
        }
        
        await redis_client.setex(
            whitelist_key,
            86400 * 30,  # 30 dias
            json.dumps(whitelist_data)
        )
        
        # Remover da lista de bloqueados se estiver lá
        rate_limiter = get_advanced_rate_limiter(redis_client)
        await rate_limiter.unblock_ip(ip_address)
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "success": True,
                "message": f"IP {ip_address} adicionado à whitelist",
                "ip_address": ip_address,
                "reason": reason,
                "added_by": current_user.id,
                "timestamp": datetime.utcnow().isoformat()
            }
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao adicionar IP à whitelist: {str(e)}"
        )


@router.get(
    "/health",
    summary="Status de saúde da segurança",
    description="Verifica status geral dos sistemas de segurança."
)
async def security_health_check(
    redis_client = Depends(get_redis_client)
) -> JSONResponse:
    """
    Verifica saúde dos sistemas de segurança.
    
    Args:
        redis_client: Cliente Redis
        
    Returns:
        JSONResponse: Status de saúde
    """
    try:
        health_status = {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "components": {
                "redis": "unknown",
                "rate_limiter": "unknown",
                "security_middleware": "unknown"
            },
            "metrics": {
                "active_blocks": 0,
                "recent_events": 0
            }
        }
        
        # Verificar Redis
        try:
            await redis_client.ping()
            health_status["components"]["redis"] = "healthy"
        except Exception:
            health_status["components"]["redis"] = "unhealthy"
            health_status["status"] = "degraded"
        
        # Verificar rate limiter
        try:
            rate_limiter = get_advanced_rate_limiter(redis_client)
            blocked_ips = await rate_limiter.get_blocked_ips()
            health_status["components"]["rate_limiter"] = "healthy"
            health_status["metrics"]["active_blocks"] = len(blocked_ips)
        except Exception:
            health_status["components"]["rate_limiter"] = "unhealthy"
            health_status["status"] = "degraded"
        
        # Verificar eventos recentes
        try:
            recent_events = await rate_limiter.get_security_events(limit=100)
            health_status["metrics"]["recent_events"] = len(recent_events)
        except Exception:
            pass
        
        # Middleware sempre assume como healthy se chegou até aqui
        health_status["components"]["security_middleware"] = "healthy"
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content=health_status
        )
        
    except Exception as e:
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content={
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
        )