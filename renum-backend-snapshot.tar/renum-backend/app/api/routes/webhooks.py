"""
Módulo que implementa as rotas da API para webhooks de integrações de agentes.

Este módulo contém os endpoints para receber webhooks externos e gerenciar
integrações de agentes com sistemas externos.
"""

import logging
import time
from typing import Dict, Any, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, Header, status, BackgroundTasks
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.schemas.webhooks import (
    WebhookPayload,
    WebhookResponse,
    WebhookErrorResponse,
    RateLimitHeaders,
    WhatsAppPayload,
    TelegramPayload,
    ZapierPayload,
    N8nPayload,
    MakePayload,
    CustomPayload
)
from app.api.exceptions.webhook_exceptions import (
    WebhookAuthenticationError,
    WebhookAuthorizationError,
    WebhookValidationError
)
from app.api.handlers.webhook_error_handler import handle_webhook_error
from app.api.validators.security_validator import security_validator, validate_webhook_payload
from app.services.webhook_service import get_webhook_service
from app.core.dependencies import get_redis_client
from app.db.database import get_db

# Configurar logger
logger = logging.getLogger(__name__)

# Criar router
router = APIRouter(tags=["webhooks"])


def get_client_ip(request: Request) -> str:
    """
    Obtém o IP do cliente considerando proxies.
    
    Args:
        request: Requisição FastAPI
        
    Returns:
        str: Endereço IP do cliente
    """
    # Verificar headers de proxy
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        # Pegar o primeiro IP da lista (cliente original)
        return forwarded_for.split(",")[0].strip()
    
    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip
    
    # Fallback para IP direto
    return request.client.host if request.client else "unknown"


def create_error_response(
    error_message: str,
    error_code: Optional[str] = None,
    status_code: int = 400,
    details: Optional[Dict[str, Any]] = None
) -> JSONResponse:
    """
    Cria uma resposta de erro padronizada.
    
    Args:
        error_message: Mensagem de erro
        error_code: Código do erro
        status_code: Código de status HTTP
        details: Detalhes adicionais
        
    Returns:
        JSONResponse: Resposta de erro formatada
    """
    error_response = WebhookErrorResponse(
        error=error_message,
        code=error_code,
        details=details or {}
    )
    
    return JSONResponse(
        status_code=status_code,
        content=error_response.dict()
    )


def validate_webhook_payload_comprehensive(payload_data: Dict[str, Any], request: Request) -> Dict[str, Any]:
    """
    Realiza validação abrangente do payload do webhook.
    
    Args:
        payload_data: Dados do payload
        request: Requisição HTTP
        
    Returns:
        Dict com resultado da validação
        
    Raises:
        WebhookValidationError: Se a validação falhar
    """
    # Validação de segurança básica
    security_result = validate_webhook_payload(payload_data)
    if not security_result["valid"]:
        raise WebhookValidationError(
            f"Payload contém dados suspeitos: {', '.join(security_result['issues'])}"
        )
    
    # Validar tamanho do payload
    import json
    payload_size = len(json.dumps(payload_data).encode('utf-8'))
    max_size = 1024 * 1024  # 1MB
    
    if payload_size > max_size:
        raise WebhookValidationError(
            f"Payload muito grande: {payload_size} bytes (máximo: {max_size})"
        )
    
    # Validar headers suspeitos
    user_agent = request.headers.get("user-agent", "")
    if len(user_agent) > 500:
        raise WebhookValidationError("User-Agent suspeito detectado")
    
    # Validar origem se necessário
    origin = request.headers.get("origin")
    if origin:
        url_validation = security_validator.validate_url(origin, "origin")
        if not url_validation["valid"]:
            raise WebhookValidationError(f"Origin inválida: {', '.join(url_validation['issues'])}")
    
    # Validar referer se presente
    referer = request.headers.get("referer")
    if referer:
        url_validation = security_validator.validate_url(referer, "referer")
        if not url_validation["valid"]:
            logger.warning(f"Referer suspeito detectado: {referer}")
    
    return {"valid": True, "sanitized_payload": payload_data}


def sanitize_webhook_response(response_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Sanitiza a resposta do webhook antes de enviar.
    
    Args:
        response_data: Dados da resposta
        
    Returns:
        Dados sanitizados
    """
    def sanitize_recursive(obj):
        if isinstance(obj, dict):
            return {key: sanitize_recursive(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [sanitize_recursive(item) for item in obj]
        elif isinstance(obj, str):
            return security_validator.sanitize_string(obj)
        else:
            return obj
    
    return sanitize_recursive(response_data)


# Endpoints específicos por canal com validação otimizada

@router.post(
    "/webhook/{agent_id}/whatsapp",
    response_model=WebhookResponse,
    responses={
        200: {"description": "Webhook WhatsApp processado com sucesso"},
        400: {"model": WebhookErrorResponse, "description": "Payload inválido"},
        401: {"model": WebhookErrorResponse, "description": "Token não fornecido"},
        403: {"model": WebhookErrorResponse, "description": "Token inválido ou agente não autorizado"},
        429: {"model": WebhookErrorResponse, "description": "Rate limit excedido"},
        500: {"model": WebhookErrorResponse, "description": "Erro interno do servidor"}
    },
    summary="Receber webhook do WhatsApp",
    description="Endpoint específico para webhooks do WhatsApp com validação otimizada."
)
async def whatsapp_webhook_handler(
    agent_id: UUID,
    payload: WhatsAppPayload,
    request: Request,
    authorization: Optional[str] = Header(None),
    redis_client = Depends(get_redis_client)
):
    """Processa webhook específico do WhatsApp."""
    return await process_webhook_with_validation(
        agent_id=agent_id,
        channel="whatsapp",
        payload=payload.dict(),
        request=request,
        authorization=authorization,
        redis_client=redis_client
    )


@router.post(
    "/webhook/{agent_id}/telegram",
    response_model=WebhookResponse,
    summary="Receber webhook do Telegram"
)
async def telegram_webhook_handler(
    agent_id: UUID,
    payload: TelegramPayload,
    request: Request,
    authorization: Optional[str] = Header(None),
    redis_client = Depends(get_redis_client)
):
    """Processa webhook específico do Telegram."""
    return await process_webhook_with_validation(
        agent_id=agent_id,
        channel="telegram",
        payload=payload.dict(),
        request=request,
        authorization=authorization,
        redis_client=redis_client
    )


@router.post(
    "/webhook/{agent_id}/zapier",
    response_model=WebhookResponse,
    summary="Receber webhook do Zapier"
)
async def zapier_webhook_handler(
    agent_id: UUID,
    payload: ZapierPayload,
    request: Request,
    authorization: Optional[str] = Header(None),
    redis_client = Depends(get_redis_client)
):
    """Processa webhook específico do Zapier."""
    return await process_webhook_with_validation(
        agent_id=agent_id,
        channel="zapier",
        payload=payload.dict(),
        request=request,
        authorization=authorization,
        redis_client=redis_client
    )


@router.post(
    "/webhook/{agent_id}/n8n",
    response_model=WebhookResponse,
    summary="Receber webhook do n8n"
)
async def n8n_webhook_handler(
    agent_id: UUID,
    payload: N8nPayload,
    request: Request,
    authorization: Optional[str] = Header(None),
    redis_client = Depends(get_redis_client)
):
    """Processa webhook específico do n8n."""
    return await process_webhook_with_validation(
        agent_id=agent_id,
        channel="n8n",
        payload=payload.dict(),
        request=request,
        authorization=authorization,
        redis_client=redis_client
    )


@router.post(
    "/webhook/{agent_id}/make",
    response_model=WebhookResponse,
    summary="Receber webhook do Make"
)
async def make_webhook_handler(
    agent_id: UUID,
    payload: MakePayload,
    request: Request,
    authorization: Optional[str] = Header(None),
    redis_client = Depends(get_redis_client)
):
    """Processa webhook específico do Make."""
    return await process_webhook_with_validation(
        agent_id=agent_id,
        channel="make",
        payload=payload.dict(),
        request=request,
        authorization=authorization,
        redis_client=redis_client
    )


@router.post(
    "/webhook/{agent_id}",
    response_model=WebhookResponse,
    responses={
        200: {"description": "Webhook processado com sucesso"},
        400: {"model": WebhookErrorResponse, "description": "Payload inválido"},
        401: {"model": WebhookErrorResponse, "description": "Token não fornecido"},
        403: {"model": WebhookErrorResponse, "description": "Token inválido ou agente não autorizado"},
        429: {"model": WebhookErrorResponse, "description": "Rate limit excedido"},
        500: {"model": WebhookErrorResponse, "description": "Erro interno do servidor"}
    },
    summary="Receber webhook genérico",
    description="""
    Endpoint genérico para receber webhooks de sistemas externos e executar agentes.
    
    ## Autenticação
    
    Requer token Bearer no header Authorization:
    ```
    Authorization: Bearer whk_your_webhook_token_here
    ```
    
    ## Rate Limiting
    
    - Limite configurável por integração (padrão: 60 chamadas/minuto)
    - Headers de resposta informam status do limite
    - Retorna 429 quando limite excedido
    
    ## Payload
    
    Aceita qualquer estrutura JSON válida. Campos comuns:
    - `message`: Mensagem de texto
    - `data`: Dados estruturados
    - `user_id`: ID do usuário externo
    - `session_id`: ID da sessão
    
    ## Resposta
    
    Retorna a resposta do agente executado junto com métricas de execução.
    """
)
async def webhook_handler(
    agent_id: UUID,
    payload: CustomPayload,
    request: Request,
    authorization: Optional[str] = Header(None, description="Token Bearer para autenticação"),
    redis_client = Depends(get_redis_client)
):
    """
    Processa uma chamada webhook genérica de sistema externo.
    
    Args:
        agent_id: ID do agente a ser executado
        payload: Dados enviados pelo sistema externo
        request: Objeto de requisição FastAPI
        authorization: Header de autorização com token Bearer
        redis_client: Cliente Redis para rate limiting
        
    Returns:
        WebhookResponse: Resposta do agente executado
    """
    return await process_webhook_with_validation(
        agent_id=agent_id,
        channel="custom",
        payload=payload.dict(),
        request=request,
        authorization=authorization,
        redis_client=redis_client
    )


async def process_webhook_with_validation(
    agent_id: UUID,
    channel: str,
    payload: Dict[str, Any],
    request: Request,
    authorization: Optional[str],
    redis_client
) -> JSONResponse:
    """
    Função principal para processar webhooks com validação abrangente.
    
    Args:
        agent_id: ID do agente
        channel: Canal de integração
        payload: Dados do payload
        request: Requisição HTTP
        authorization: Token de autorização
        redis_client: Cliente Redis
        
    Returns:
        WebhookResponse: Resposta da execução do agente
        
    Raises:
        HTTPException: Para diversos tipos de erro (401, 403, 429, 500)
    """
    start_time = time.time()
    
    try:
        # 1. Validar presença do token
        if not authorization:
            raise WebhookAuthenticationError(
                message="Token Bearer requerido no header Authorization",
                error_code="MISSING_TOKEN",
                details={"agent_id": str(agent_id)}
            )
        
        # 2. Extrair token do header
        if not authorization.startswith("Bearer "):
            raise WebhookAuthenticationError(
                message="Token deve usar formato 'Bearer <token>'",
                error_code="INVALID_TOKEN_FORMAT",
                details={"agent_id": str(agent_id)}
            )
        
        token = authorization.replace("Bearer ", "")
        
        # 3. Obter informações da requisição
        ip_address = get_client_ip(request)
        user_agent = request.headers.get("User-Agent", "")
        
        # 4. Obter serviço de webhook
        webhook_service = get_webhook_service(redis_client)
        
        # 5. Processar webhook
        result = await webhook_service.process_webhook_call(
            agent_id=agent_id,
            token=token,
            payload=payload.dict(),
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        # 6. Preparar resposta de sucesso
        response = WebhookResponse(
            success=result["success"],
            data=result["data"],
            execution_time_ms=result["execution_time_ms"]
        )
        
        # 7. Adicionar headers de rate limiting (se disponível)
        headers = {}
        try:
            # Tentar obter informações de rate limit
            # Isso seria implementado no webhook_service se necessário
            pass
        except Exception:
            # Ignorar erros de rate limit headers
            pass
        
        logger.info(f"Webhook processado com sucesso para agente {agent_id} em {result['execution_time_ms']}ms")
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content=response.dict(),
            headers=headers
        )
        
    except Exception as e:
        # Usar o handler centralizado de erros
        execution_time = int((time.time() - start_time) * 1000)
        
        return handle_webhook_error(
            error=e,
            request=request,
            agent_id=agent_id,
            execution_time_ms=execution_time
        )


@router.get(
    "/webhook/{agent_id}/health",
    summary="Verificar saúde do webhook",
    description="Endpoint para verificar se o webhook está funcionando corretamente"
)
async def webhook_health_check(agent_id: UUID):
    """
    Verifica a saúde do endpoint de webhook.
    
    Args:
        agent_id: ID do agente
        
    Returns:
        Dict: Status de saúde
    """
    return {
        "status": "healthy",
        "agent_id": str(agent_id),
        "timestamp": time.time(),
        "message": "Webhook endpoint está funcionando"
    }


@router.options("/webhook/{agent_id}")
async def webhook_options(agent_id: UUID):
    """
    Endpoint OPTIONS para CORS.
    
    Args:
        agent_id: ID do agente
        
    Returns:
        Dict: Métodos permitidos
    """
    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content={"methods": ["POST", "OPTIONS"]},
        headers={
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST, OPTIONS",
            "Access-Control-Allow-Headers": "Authorization, Content-Type",
            "Access-Control-Max-Age": "86400"
        }
    )


@router.post("/{integration_id}")
async def process_webhook(
    integration_id: str,
    request: Request,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """
    Processa webhook de integração.
    
    Returns:
        JSONResponse: Resposta do webhook processado
    """
    start_time = time.time()
    client_ip = get_client_ip(request)
    
    try:
        # 1. Validação de autenticação
        if not authorization:
            logger.warning(f"Webhook sem token de autorização - Agent: {agent_id}, IP: {client_ip}")
            return create_error_response(
                "Token de autorização não fornecido",
                "MISSING_AUTHORIZATION",
                status.HTTP_401_UNAUTHORIZED
            )
        
        # Extrair token Bearer
        if not authorization.startswith("Bearer "):
            return create_error_response(
                "Formato de token inválido. Use: Bearer <token>",
                "INVALID_TOKEN_FORMAT",
                status.HTTP_401_UNAUTHORIZED
            )
        
        token = authorization[7:]  # Remove "Bearer "
        
        # 2. Validação abrangente do payload
        try:
            validation_result = validate_webhook_payload_comprehensive(payload, request)
            sanitized_payload = validation_result["sanitized_payload"]
        except WebhookValidationError as e:
            logger.warning(f"Validação de payload falhou - Agent: {agent_id}, Error: {str(e)}")
            return create_error_response(
                str(e),
                "PAYLOAD_VALIDATION_FAILED",
                status.HTTP_400_BAD_REQUEST
            )
        
        # 3. Obter serviço de webhook
        webhook_service = get_webhook_service()
        
        # 4. Validar token e obter integração
        try:
            integration = await webhook_service.validate_webhook_token(token, agent_id, channel)
            if not integration:
                logger.warning(f"Token inválido - Agent: {agent_id}, Token: {token[:10]}..., IP: {client_ip}")
                return create_error_response(
                    "Token inválido ou agente não autorizado",
                    "INVALID_TOKEN",
                    status.HTTP_403_FORBIDDEN
                )
        except WebhookAuthenticationError as e:
            return create_error_response(
                str(e),
                "AUTHENTICATION_ERROR",
                status.HTTP_403_FORBIDDEN
            )
        except WebhookAuthorizationError as e:
            return create_error_response(
                str(e),
                "AUTHORIZATION_ERROR",
                status.HTTP_403_FORBIDDEN
            )
        
        # 5. Verificar rate limiting
        try:
            rate_limit_result = await webhook_service.check_rate_limit(
                integration.id, 
                client_ip, 
                redis_client
            )
            
            if not rate_limit_result["allowed"]:
                logger.warning(f"Rate limit excedido - Integration: {integration.id}, IP: {client_ip}")
                
                rate_limit_headers = RateLimitHeaders(
                    limit=rate_limit_result["limit"],
                    remaining=0,
                    reset=rate_limit_result["reset_time"]
                )
                
                return JSONResponse(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    content=WebhookErrorResponse(
                        error="Rate limit excedido",
                        code="RATE_LIMIT_EXCEEDED",
                        details={
                            "limit": rate_limit_result["limit"],
                            "reset_time": rate_limit_result["reset_time"]
                        }
                    ).dict(),
                    headers=rate_limit_headers.to_headers()
                )
                
        except Exception as e:
            logger.error(f"Erro no rate limiting - Integration: {integration.id}, Error: {str(e)}")
            # Continuar processamento em caso de erro no rate limiting
        
        # 6. Processar webhook
        try:
            execution_result = await webhook_service.process_webhook(
                integration_id=integration.id,
                agent_id=agent_id,
                payload=sanitized_payload,
                client_ip=client_ip,
                user_agent=request.headers.get("user-agent", ""),
                channel=channel
            )
            
            # 7. Sanitizar resposta
            sanitized_response = sanitize_webhook_response(execution_result)
            
            # 8. Calcular tempo de execução
            execution_time_ms = int((time.time() - start_time) * 1000)
            
            # 9. Criar resposta de sucesso
            response_data = WebhookResponse(
                success=True,
                data=sanitized_response,
                execution_time_ms=execution_time_ms
            )
            
            # 10. Adicionar headers de rate limit à resposta
            response = JSONResponse(
                status_code=status.HTTP_200_OK,
                content=response_data.dict()
            )
            
            # Adicionar headers de rate limit se disponível
            if 'rate_limit_result' in locals():
                rate_limit_headers = RateLimitHeaders(
                    limit=rate_limit_result["limit"],
                    remaining=max(0, rate_limit_result["remaining"] - 1),
                    reset=rate_limit_result["reset_time"]
                )
                
                for header, value in rate_limit_headers.to_headers().items():
                    response.headers[header] = value
            
            # Adicionar headers de segurança
            security_headers = security_validator.get_security_headers()
            for header, value in security_headers.items():
                response.headers[header] = value
            
            logger.info(f"Webhook processado com sucesso - Integration: {integration.id}, Time: {execution_time_ms}ms")
            return response
            
        except Exception as e:
            logger.error(f"Erro no processamento do webhook - Integration: {integration.id}, Error: {str(e)}")
            
            # Log detalhado para debug
            logger.debug(f"Payload: {sanitized_payload}")
            logger.debug(f"Agent ID: {agent_id}")
            logger.debug(f"Channel: {channel}")
            
            return create_error_response(
                "Erro interno no processamento do webhook",
                "PROCESSING_ERROR",
                status.HTTP_500_INTERNAL_SERVER_ERROR,
                {"execution_time_ms": int((time.time() - start_time) * 1000)}
            )
    
    except Exception as e:
        # Capturar qualquer erro não tratado
        execution_time_ms = int((time.time() - start_time) * 1000)
        logger.error(f"Erro não tratado no webhook - Agent: {agent_id}, Error: {str(e)}, Time: {execution_time_ms}ms")
        
        return create_error_response(
            "Erro interno do servidor",
            "INTERNAL_SERVER_ERROR",
            status.HTTP_500_INTERNAL_SERVER_ERROR,
            {"execution_time_ms": execution_time_ms}
        )


# Endpoint para validação de payload (útil para testes)
@router.post(
    "/webhook/validate",
    summary="Validar payload de webhook",
    description="Endpoint para validar um payload de webhook sem executar o agente."
)
async def validate_webhook_payload_endpoint(
    payload: Dict[str, Any],
    request: Request
) -> JSONResponse:
    """
    Valida um payload de webhook sem executar o agente.
    
    Args:
        payload: Payload a ser validado
        request: Requisição HTTP
        
    Returns:
        JSONResponse: Resultado da validação
    """
    try:
        validation_result = validate_webhook_payload_comprehensive(payload, request)
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "valid": True,
                "message": "Payload válido",
                "sanitized_payload": validation_result["sanitized_payload"]
            }
        )
        
    except WebhookValidationError as e:
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={
                "valid": False,
                "error": str(e),
                "code": "VALIDATION_FAILED"
            }
        )
    except Exception as e:
        logger.error(f"Erro na validação de payload: {str(e)}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "valid": False,
                "error": "Erro interno na validação",
                "code": "INTERNAL_ERROR"
            }
        )


# Endpoint para obter informações sobre validação
@router.get(
    "/webhook/validation-info",
    summary="Informações sobre validação",
    description="Retorna informações sobre os critérios de validação de payload."
)
async def get_validation_info() -> JSONResponse:
    """
    Retorna informações sobre os critérios de validação.
    
    Returns:
        JSONResponse: Informações de validação
    """
    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content={
            "validation_criteria": {
                "max_payload_size_bytes": 1024 * 1024,  # 1MB
                "max_string_length": 10000,
                "max_nested_depth": 10,
                "allowed_content_types": [
                    "application/json",
                    "application/x-www-form-urlencoded",
                    "text/plain"
                ],
                "security_checks": [
                    "SQL injection detection",
                    "XSS detection", 
                    "Command injection detection",
                    "LDAP injection detection",
                    "Dangerous character filtering",
                    "Encoded payload detection"
                ],
                "channel_specific_validation": {
                    "whatsapp": {
                        "required_fields": ["message", "phone"],
                        "phone_format": "International format (+country_code)",
                        "message_max_length": 4096
                    },
                    "telegram": {
                        "required_fields": ["message", "chat_id", "user_id"],
                        "id_format": "Positive integers",
                        "message_max_length": 4096
                    },
                    "zapier": {
                        "required_fields": ["trigger_event", "data"],
                        "data_structure": "Nested object with max 10 levels"
                    },
                    "n8n": {
                        "required_fields": ["workflow_id", "execution_id", "data"],
                        "data_structure": "Nested object with max 10 levels"
                    },
                    "make": {
                        "required_fields": ["scenario_id", "execution_id", "data"],
                        "data_structure": "Nested object with max 10 levels"
                    },
                    "custom": {
                        "required_fields": [],
                        "flexible_structure": "Allows additional fields"
                    }
                }
            }
        }
    )