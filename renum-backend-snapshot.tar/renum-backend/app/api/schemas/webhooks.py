"""
Módulo que define os esquemas para os endpoints de webhooks.

Este módulo contém as classes que representam os esquemas de requisição e resposta
para os endpoints de webhooks de integrações de agentes, incluindo validação
abrangente de entrada e schemas específicos por canal.
"""

import re
import json
from datetime import datetime
from typing import Optional, Dict, Any, List, Union, Literal
from uuid import UUID

from pydantic import BaseModel, Field, validator, root_validator, constr, conint, confloat
from pydantic.networks import HttpUrl, EmailStr

from app.models.integrations import IntegrationChannel, IntegrationStatus


# Constantes para validação
MAX_PAYLOAD_SIZE = 1024 * 1024  # 1MB
MAX_STRING_LENGTH = 10000
MAX_NESTED_DEPTH = 10
ALLOWED_CONTENT_TYPES = [
    "application/json",
    "application/x-www-form-urlencoded",
    "text/plain"
]

# Padrões de validação
PHONE_PATTERN = re.compile(r'^\+?[1-9]\d{1,14}$')
EMAIL_PATTERN = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
URL_PATTERN = re.compile(r'^https?://[^\s/$.?#].[^\s]*$')
SAFE_STRING_PATTERN = re.compile(r'^[a-zA-Z0-9\s\-_.,!?@#$%&*()+=\[\]{}|;:\'\"<>/\\]*$')

# Schemas específicos por canal
class WhatsAppPayload(BaseModel):
    """Schema específico para payloads do WhatsApp."""
    
    message: constr(min_length=1, max_length=4096) = Field(..., description="Mensagem do usuário")
    phone: constr(pattern=r'^\+?[1-9]\d{1,14}$') = Field(..., description="Número de telefone")
    message_type: Literal["text", "image", "audio", "video", "document"] = Field("text", description="Tipo da mensagem")
    media_url: Optional[HttpUrl] = Field(None, description="URL da mídia (se aplicável)")
    timestamp: Optional[datetime] = Field(None, description="Timestamp da mensagem")
    
    @validator('message')
    def validate_message_content(cls, v):
        if not SAFE_STRING_PATTERN.match(v):
            raise ValueError("Mensagem contém caracteres não permitidos")
        return v.strip()
    
    class Config:
        extra = "forbid"


class TelegramPayload(BaseModel):
    """Schema específico para payloads do Telegram."""
    
    message: constr(min_length=1, max_length=4096) = Field(..., description="Mensagem do usuário")
    chat_id: conint(gt=0) = Field(..., description="ID do chat")
    user_id: conint(gt=0) = Field(..., description="ID do usuário")
    username: Optional[constr(min_length=1, max_length=32)] = Field(None, description="Username do usuário")
    message_type: Literal["text", "photo", "audio", "video", "document", "sticker"] = Field("text", description="Tipo da mensagem")
    file_id: Optional[str] = Field(None, description="ID do arquivo (se aplicável)")
    
    @validator('message')
    def validate_message_content(cls, v):
        if not SAFE_STRING_PATTERN.match(v):
            raise ValueError("Mensagem contém caracteres não permitidos")
        return v.strip()
    
    class Config:
        extra = "forbid"


class ZapierPayload(BaseModel):
    """Schema específico para payloads do Zapier."""
    
    trigger_event: constr(min_length=1, max_length=100) = Field(..., description="Evento que disparou o webhook")
    data: Dict[str, Any] = Field(..., description="Dados do evento")
    zap_id: Optional[str] = Field(None, description="ID do Zap")
    user_email: Optional[EmailStr] = Field(None, description="Email do usuário")
    
    @validator('data')
    def validate_data_structure(cls, v):
        if not isinstance(v, dict):
            raise ValueError("Data deve ser um objeto JSON válido")
        
        # Validar profundidade máxima
        def check_depth(obj, current_depth=0):
            if current_depth > MAX_NESTED_DEPTH:
                raise ValueError(f"Profundidade máxima de {MAX_NESTED_DEPTH} níveis excedida")
            
            if isinstance(obj, dict):
                for value in obj.values():
                    check_depth(value, current_depth + 1)
            elif isinstance(obj, list):
                for item in obj:
                    check_depth(item, current_depth + 1)
        
        check_depth(v)
        return v
    
    class Config:
        extra = "forbid"


class N8nPayload(BaseModel):
    """Schema específico para payloads do n8n."""
    
    workflow_id: constr(min_length=1, max_length=100) = Field(..., description="ID do workflow")
    execution_id: constr(min_length=1, max_length=100) = Field(..., description="ID da execução")
    data: Dict[str, Any] = Field(..., description="Dados do workflow")
    node_name: Optional[str] = Field(None, description="Nome do nó que disparou")
    
    @validator('data')
    def validate_data_structure(cls, v):
        if not isinstance(v, dict):
            raise ValueError("Data deve ser um objeto JSON válido")
        
        # Validar profundidade máxima
        def check_depth(obj, current_depth=0):
            if current_depth > MAX_NESTED_DEPTH:
                raise ValueError(f"Profundidade máxima de {MAX_NESTED_DEPTH} níveis excedida")
            
            if isinstance(obj, dict):
                for value in obj.values():
                    check_depth(value, current_depth + 1)
            elif isinstance(obj, list):
                for item in obj:
                    check_depth(item, current_depth + 1)
        
        check_depth(v)
        return v
    
    class Config:
        extra = "forbid"


class MakePayload(BaseModel):
    """Schema específico para payloads do Make (Integromat)."""
    
    scenario_id: constr(min_length=1, max_length=100) = Field(..., description="ID do cenário")
    execution_id: constr(min_length=1, max_length=100) = Field(..., description="ID da execução")
    data: Dict[str, Any] = Field(..., description="Dados do cenário")
    module_name: Optional[str] = Field(None, description="Nome do módulo que disparou")
    
    @validator('data')
    def validate_data_structure(cls, v):
        if not isinstance(v, dict):
            raise ValueError("Data deve ser um objeto JSON válido")
        
        # Validar profundidade máxima
        def check_depth(obj, current_depth=0):
            if current_depth > MAX_NESTED_DEPTH:
                raise ValueError(f"Profundidade máxima de {MAX_NESTED_DEPTH} níveis excedida")
            
            if isinstance(obj, dict):
                for value in obj.values():
                    check_depth(value, current_depth + 1)
            elif isinstance(obj, list):
                for item in obj:
                    check_depth(item, current_depth + 1)
        
        check_depth(v)
        return v
    
    class Config:
        extra = "forbid"


class CustomPayload(BaseModel):
    """Schema genérico para payloads customizados."""
    
    message: Optional[constr(max_length=MAX_STRING_LENGTH)] = Field(None, description="Mensagem principal")
    data: Optional[Dict[str, Any]] = Field(None, description="Dados customizados")
    user_id: Optional[str] = Field(None, description="ID do usuário externo")
    session_id: Optional[str] = Field(None, description="ID da sessão")
    
    @validator('data')
    def validate_data_structure(cls, v):
        if v is None:
            return v
            
        if not isinstance(v, dict):
            raise ValueError("Data deve ser um objeto JSON válido")
        
        # Validar profundidade máxima
        def check_depth(obj, current_depth=0):
            if current_depth > MAX_NESTED_DEPTH:
                raise ValueError(f"Profundidade máxima de {MAX_NESTED_DEPTH} níveis excedida")
            
            if isinstance(obj, dict):
                for value in obj.values():
                    check_depth(value, current_depth + 1)
            elif isinstance(obj, list):
                for item in obj:
                    check_depth(item, current_depth + 1)
        
        check_depth(v)
        return v
    
    @validator('message')
    def validate_message_content(cls, v):
        if v and not SAFE_STRING_PATTERN.match(v):
            raise ValueError("Mensagem contém caracteres não permitidos")
        return v.strip() if v else v
    
    class Config:
        extra = "allow"  # Permite campos adicionais para flexibilidade


class WebhookPayload(BaseModel):
    """Schema principal para payloads de webhook com validação por canal."""
    
    # Campos obrigatórios
    channel: IntegrationChannel = Field(..., description="Canal de integração")
    
    # Payload específico do canal (union type)
    payload: Union[
        WhatsAppPayload,
        TelegramPayload, 
        ZapierPayload,
        N8nPayload,
        MakePayload,
        CustomPayload
    ] = Field(..., description="Payload específico do canal")
    
    # Metadados opcionais
    timestamp: Optional[datetime] = Field(None, description="Timestamp da requisição")
    request_id: Optional[str] = Field(None, description="ID único da requisição")
    
    @root_validator(skip_on_failure=True)
    def validate_payload_channel_match(cls, values):
        """Valida se o payload corresponde ao canal especificado."""
        channel = values.get('channel')
        payload = values.get('payload')
        
        if not channel or not payload:
            return values
        
        # Mapeamento de canais para tipos de payload
        channel_payload_map = {
            IntegrationChannel.WHATSAPP: WhatsAppPayload,
            IntegrationChannel.TELEGRAM: TelegramPayload,
            IntegrationChannel.ZAPIER: ZapierPayload,
            IntegrationChannel.N8N: N8nPayload,
            IntegrationChannel.MAKE: MakePayload,
            IntegrationChannel.CUSTOM: CustomPayload
        }
        
        expected_type = channel_payload_map.get(channel)
        if expected_type and not isinstance(payload, expected_type):
            raise ValueError(f"Payload deve ser do tipo {expected_type.__name__} para canal {channel}")
        
        return values
    
    @validator('payload', pre=True)
    def validate_payload_size(cls, v):
        """Valida o tamanho do payload."""
        if isinstance(v, dict):
            payload_str = json.dumps(v)
            if len(payload_str.encode('utf-8')) > MAX_PAYLOAD_SIZE:
                raise ValueError(f"Payload excede o tamanho máximo de {MAX_PAYLOAD_SIZE} bytes")
        return v
    
    class Config:
        extra = "forbid"


class WebhookResponse(BaseModel):
    """Esquema para resposta de webhook."""
    
    success: bool = Field(..., description="Se a execução foi bem-sucedida")
    data: Optional[Dict[str, Any]] = Field(None, description="Dados de resposta do agente")
    execution_time_ms: Optional[int] = Field(None, description="Tempo de execução em milissegundos")
    error: Optional[str] = Field(None, description="Mensagem de erro, se houver")
    
    class Config:
        schema_extra = {
            "example": {
                "success": True,
                "data": {
                    "response": "Olá! Como posso ajudar você hoje?",
                    "agent_id": "123e4567-e89b-12d3-a456-426614174000"
                },
                "execution_time_ms": 150
            }
        }


class WebhookErrorResponse(BaseModel):
    """Esquema para resposta de erro de webhook."""
    
    success: bool = Field(False, description="Sempre false para erros")
    error: str = Field(..., description="Mensagem de erro")
    code: Optional[str] = Field(None, description="Código do erro")
    details: Optional[Dict[str, Any]] = Field(None, description="Detalhes adicionais do erro")
    
    class Config:
        schema_extra = {
            "example": {
                "success": False,
                "error": "Token inválido ou agente não autorizado",
                "code": "INVALID_TOKEN",
                "details": {
                    "agent_id": "123e4567-e89b-12d3-a456-426614174000",
                    "timestamp": "2024-01-15T10:30:00Z"
                }
            }
        }


class IntegrationBase(BaseModel):
    """Esquema base para integrações."""
    
    agent_id: UUID = Field(..., description="ID do agente")
    channel: IntegrationChannel = Field(..., description="Canal de integração")
    rate_limit_per_minute: int = Field(60, description="Limite de chamadas por minuto", ge=1, le=1000)
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Metadados do canal")


class IntegrationCreate(IntegrationBase):
    """Esquema para criação de integração."""
    
    pass


class IntegrationUpdate(BaseModel):
    """Esquema para atualização de integração."""
    
    status: Optional[IntegrationStatus] = Field(None, description="Status da integração")
    rate_limit_per_minute: Optional[int] = Field(None, description="Limite de chamadas por minuto", ge=1, le=1000)
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados do canal")


class IntegrationResponse(IntegrationBase):
    """Esquema para resposta de integração."""
    
    id: UUID = Field(..., description="ID da integração")
    client_id: UUID = Field(..., description="ID do cliente")
    webhook_token: str = Field(..., description="Token de autenticação")
    webhook_url: str = Field(..., description="URL completa do webhook")
    status: IntegrationStatus = Field(..., description="Status da integração")
    created_at: datetime = Field(..., description="Data de criação")
    updated_at: datetime = Field(..., description="Data de atualização")
    created_by: Optional[UUID] = Field(None, description="ID do usuário criador")
    
    class Config:
        schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "agent_id": "987fcdeb-51a2-43d1-9f12-345678901234",
                "client_id": "456789ab-cdef-1234-5678-90abcdef1234",
                "channel": "whatsapp",
                "webhook_token": "whk_abc123def456ghi789jkl012mno345pqr678",
                "webhook_url": "https://api.renum.com/webhook/987fcdeb-51a2-43d1-9f12-345678901234",
                "status": "active",
                "rate_limit_per_minute": 60,
                "metadata": {"phone": "+5511999999999"},
                "created_at": "2024-01-15T10:30:00Z",
                "updated_at": "2024-01-15T10:30:00Z"
            }
        }


class IntegrationListResponse(BaseModel):
    """Esquema para lista de integrações."""
    
    integrations: List[IntegrationResponse] = Field(..., description="Lista de integrações")
    total: int = Field(..., description="Total de integrações")
    page: int = Field(..., description="Página atual")
    per_page: int = Field(..., description="Itens por página")


class WebhookCallResponse(BaseModel):
    """Esquema para resposta de chamada webhook."""
    
    id: UUID = Field(..., description="ID da chamada")
    integration_id: UUID = Field(..., description="ID da integração")
    status_code: Optional[int] = Field(None, description="Código de status HTTP")
    execution_time_ms: Optional[int] = Field(None, description="Tempo de execução em ms")
    created_at: datetime = Field(..., description="Data da chamada")
    
    # Campos opcionais para debug (apenas para admins)
    request_payload: Optional[Dict[str, Any]] = Field(None, description="Payload da requisição")
    response_payload: Optional[Dict[str, Any]] = Field(None, description="Payload da resposta")
    ip_address: Optional[str] = Field(None, description="IP de origem")
    user_agent: Optional[str] = Field(None, description="User-Agent")
    error_message: Optional[str] = Field(None, description="Mensagem de erro")


class WebhookCallListResponse(BaseModel):
    """Esquema para lista de chamadas webhook."""
    
    calls: List[WebhookCallResponse] = Field(..., description="Lista de chamadas")
    total: int = Field(..., description="Total de chamadas")
    page: int = Field(..., description="Página atual")
    per_page: int = Field(..., description="Itens por página")


class IntegrationStatsResponse(BaseModel):
    """Esquema para estatísticas de integração."""
    
    integration_id: UUID = Field(..., description="ID da integração")
    total_calls: int = Field(..., description="Total de chamadas")
    successful_calls: int = Field(..., description="Chamadas bem-sucedidas")
    failed_calls: int = Field(..., description="Chamadas com falha")
    success_rate: float = Field(..., description="Taxa de sucesso (%)")
    error_rate: float = Field(..., description="Taxa de erro (%)")
    avg_execution_time_ms: Optional[float] = Field(None, description="Tempo médio de execução")
    last_call_at: Optional[datetime] = Field(None, description="Data da última chamada")
    period_hours: int = Field(..., description="Período das estatísticas em horas")
    
    class Config:
        schema_extra = {
            "example": {
                "integration_id": "123e4567-e89b-12d3-a456-426614174000",
                "total_calls": 100,
                "successful_calls": 95,
                "failed_calls": 5,
                "success_rate": 95.0,
                "error_rate": 5.0,
                "avg_execution_time_ms": 250.5,
                "last_call_at": "2024-01-15T15:30:00Z",
                "period_hours": 24
            }
        }


class TokenRegenerateResponse(BaseModel):
    """Esquema para resposta de regeneração de token."""
    
    success: bool = Field(..., description="Se a regeneração foi bem-sucedida")
    webhook_token: str = Field(..., description="Novo token gerado")
    webhook_url: str = Field(..., description="Nova URL do webhook")
    
    class Config:
        schema_extra = {
            "example": {
                "success": True,
                "webhook_token": "whk_new123token456here789abc012def345ghi",
                "webhook_url": "https://api.renum.com/webhook/987fcdeb-51a2-43d1-9f12-345678901234"
            }
        }


class WebhookTestRequest(BaseModel):
    """Esquema para requisição de teste de webhook."""
    
    payload: Dict[str, Any] = Field(..., description="Payload de teste")
    
    class Config:
        schema_extra = {
            "example": {
                "payload": {
                    "message": "Olá, este é um teste!",
                    "user_id": "test_user_123"
                }
            }
        }


class WebhookTestResponse(BaseModel):
    """Esquema para resposta de teste de webhook."""
    
    success: bool = Field(..., description="Se o teste foi bem-sucedido")
    response: Dict[str, Any] = Field(..., description="Resposta do agente")
    execution_time_ms: int = Field(..., description="Tempo de execução")
    
    class Config:
        schema_extra = {
            "example": {
                "success": True,
                "response": {
                    "message": "Olá! Recebi sua mensagem de teste.",
                    "agent_id": "987fcdeb-51a2-43d1-9f12-345678901234"
                },
                "execution_time_ms": 125
            }
        }


class PaginationParams(BaseModel):
    """Parâmetros de paginação."""
    
    page: int = Field(1, description="Número da página", ge=1)
    per_page: int = Field(20, description="Itens por página", ge=1, le=100)


class RateLimitHeaders(BaseModel):
    """Headers de rate limiting."""
    
    limit: int = Field(..., description="Limite de chamadas por minuto")
    remaining: int = Field(..., description="Chamadas restantes")
    reset: int = Field(..., description="Timestamp de reset do limite")
    
    def to_headers(self) -> Dict[str, str]:
        """Converte para headers HTTP."""
        return {
            "X-RateLimit-Limit": str(self.limit),
            "X-RateLimit-Remaining": str(self.remaining),
            "X-RateLimit-Reset": str(self.reset)
        }