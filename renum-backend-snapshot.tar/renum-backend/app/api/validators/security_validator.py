"""
Validador de segurança para entrada de dados em webhooks.

Este módulo contém funções para validação e sanitização de dados de entrada,
incluindo detecção de ataques de injeção, XSS e outros vetores de ataque.
"""

import re
import html
import json
import base64
from typing import Any, Dict, List, Optional, Union
from urllib.parse import urlparse

# Padrões de detecção de ataques
SQL_INJECTION_PATTERNS = [
    r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION)\b)",
    r"(--|#|/\*|\*/)",
    r"(\b(OR|AND)\s+\d+\s*=\s*\d+)",
    r"(\b(OR|AND)\s+['\"]?\w+['\"]?\s*=\s*['\"]?\w+['\"]?)",
    r"(INFORMATION_SCHEMA|SYSOBJECTS|SYSCOLUMNS)",
]

XSS_PATTERNS = [
    r"<script[^>]*>.*?</script>",
    r"javascript:",
    r"on\w+\s*=",
    r"<iframe[^>]*>.*?</iframe>",
    r"<object[^>]*>.*?</object>",
    r"<embed[^>]*>.*?</embed>",
    r"<link[^>]*>",
    r"<meta[^>]*>",
    r"vbscript:",
    r"data:text/html",
]

COMMAND_INJECTION_PATTERNS = [
    r"[;&|`$(){}[\]\\]",
    r"\b(cat|ls|pwd|whoami|id|uname|ps|netstat|ifconfig|ping|wget|curl|nc|telnet|ssh|ftp)\b",
    r"(\.\.\/|\.\.\\)",
    r"(/etc/passwd|/etc/shadow|/proc/|/sys/)",
]

LDAP_INJECTION_PATTERNS = [
    r"[()&|!*]",
    r"\\[0-9a-fA-F]{2}",
]

# Caracteres perigosos
DANGEROUS_CHARS = ['<', '>', '"', "'", '&', '\x00', '\x08', '\x0b', '\x0c', '\x0e', '\x0f']

# Extensões de arquivo perigosas
DANGEROUS_EXTENSIONS = [
    '.exe', '.bat', '.cmd', '.com', '.pif', '.scr', '.vbs', '.js', '.jar',
    '.php', '.asp', '.aspx', '.jsp', '.py', '.rb', '.pl', '.sh', '.ps1'
]


class SecurityValidator:
    """Validador de segurança para dados de entrada."""
    
    def __init__(self, strict_mode: bool = True):
        """
        Inicializa o validador.
        
        Args:
            strict_mode: Se True, aplica validações mais rigorosas
        """
        self.strict_mode = strict_mode
        self.sql_patterns = [re.compile(pattern, re.IGNORECASE) for pattern in SQL_INJECTION_PATTERNS]
        self.xss_patterns = [re.compile(pattern, re.IGNORECASE) for pattern in XSS_PATTERNS]
        self.cmd_patterns = [re.compile(pattern, re.IGNORECASE) for pattern in COMMAND_INJECTION_PATTERNS]
        self.ldap_patterns = [re.compile(pattern, re.IGNORECASE) for pattern in LDAP_INJECTION_PATTERNS]
    
    def validate_string(self, value: str, field_name: str = "field") -> Dict[str, Any]:
        """
        Valida uma string contra vários tipos de ataques.
        
        Args:
            value: String a ser validada
            field_name: Nome do campo para relatórios de erro
            
        Returns:
            Dict com resultado da validação
        """
        if not isinstance(value, str):
            return {"valid": False, "error": f"{field_name} deve ser uma string"}
        
        issues = []
        
        # Verificar SQL Injection
        for pattern in self.sql_patterns:
            if pattern.search(value):
                issues.append(f"Possível SQL injection detectada em {field_name}")
                break
        
        # Verificar XSS
        for pattern in self.xss_patterns:
            if pattern.search(value):
                issues.append(f"Possível XSS detectado em {field_name}")
                break
        
        # Verificar Command Injection
        if self.strict_mode:
            for pattern in self.cmd_patterns:
                if pattern.search(value):
                    issues.append(f"Possível command injection detectada em {field_name}")
                    break
        
        # Verificar LDAP Injection
        for pattern in self.ldap_patterns:
            if pattern.search(value):
                issues.append(f"Possível LDAP injection detectada em {field_name}")
                break
        
        # Verificar caracteres perigosos
        dangerous_found = [char for char in DANGEROUS_CHARS if char in value]
        if dangerous_found and self.strict_mode:
            issues.append(f"Caracteres perigosos encontrados em {field_name}: {dangerous_found}")
        
        # Verificar tamanho excessivo
        if len(value) > 50000:  # 50KB
            issues.append(f"String muito longa em {field_name} ({len(value)} caracteres)")
        
        # Verificar encoding suspeito
        try:
            # Tentar decodificar base64 para detectar payloads codificados
            if len(value) > 20 and len(value) % 4 == 0:
                try:
                    decoded = base64.b64decode(value, validate=True)
                    decoded_str = decoded.decode('utf-8', errors='ignore')
                    if any(pattern.search(decoded_str) for pattern in self.xss_patterns + self.sql_patterns):
                        issues.append(f"Payload malicioso codificado detectado em {field_name}")
                except:
                    pass
        except:
            pass
        
        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "sanitized": self.sanitize_string(value) if issues else value
        }
    
    def sanitize_string(self, value: str) -> str:
        """
        Sanitiza uma string removendo conteúdo perigoso.
        
        Args:
            value: String a ser sanitizada
            
        Returns:
            String sanitizada
        """
        if not isinstance(value, str):
            return str(value)
        
        # HTML escape
        sanitized = html.escape(value)
        
        # Remover caracteres de controle
        sanitized = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', sanitized)
        
        # Remover múltiplos espaços
        sanitized = re.sub(r'\s+', ' ', sanitized)
        
        # Trim
        sanitized = sanitized.strip()
        
        return sanitized
    
    def validate_url(self, url: str, field_name: str = "url") -> Dict[str, Any]:
        """
        Valida uma URL.
        
        Args:
            url: URL a ser validada
            field_name: Nome do campo
            
        Returns:
            Dict com resultado da validação
        """
        if not isinstance(url, str):
            return {"valid": False, "error": f"{field_name} deve ser uma string"}
        
        issues = []
        
        try:
            parsed = urlparse(url)
            
            # Verificar esquema
            if parsed.scheme not in ['http', 'https']:
                issues.append(f"Esquema de URL não permitido em {field_name}: {parsed.scheme}")
            
            # Verificar se não é localhost/IP privado em produção
            if self.strict_mode:
                hostname = parsed.hostname
                if hostname:
                    if hostname in ['localhost', '127.0.0.1', '0.0.0.0']:
                        issues.append(f"URL localhost não permitida em {field_name}")
                    elif hostname.startswith('192.168.') or hostname.startswith('10.') or hostname.startswith('172.'):
                        issues.append(f"URL de rede privada não permitida em {field_name}")
            
            # Verificar caracteres suspeitos na URL
            if any(char in url for char in ['<', '>', '"', "'"]):
                issues.append(f"Caracteres suspeitos na URL {field_name}")
            
        except Exception as e:
            issues.append(f"URL inválida em {field_name}: {str(e)}")
        
        return {
            "valid": len(issues) == 0,
            "issues": issues
        }
    
    def validate_email(self, email: str, field_name: str = "email") -> Dict[str, Any]:
        """
        Valida um endereço de email.
        
        Args:
            email: Email a ser validado
            field_name: Nome do campo
            
        Returns:
            Dict com resultado da validação
        """
        if not isinstance(email, str):
            return {"valid": False, "error": f"{field_name} deve ser uma string"}
        
        issues = []
        
        # Padrão básico de email
        email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
        
        if not email_pattern.match(email):
            issues.append(f"Formato de email inválido em {field_name}")
        
        # Verificar caracteres perigosos
        dangerous_found = [char for char in DANGEROUS_CHARS if char in email]
        if dangerous_found:
            issues.append(f"Caracteres perigosos no email {field_name}: {dangerous_found}")
        
        # Verificar tamanho
        if len(email) > 254:  # RFC 5321
            issues.append(f"Email muito longo em {field_name}")
        
        return {
            "valid": len(issues) == 0,
            "issues": issues
        }
    
    def validate_phone(self, phone: str, field_name: str = "phone") -> Dict[str, Any]:
        """
        Valida um número de telefone.
        
        Args:
            phone: Telefone a ser validado
            field_name: Nome do campo
            
        Returns:
            Dict com resultado da validação
        """
        if not isinstance(phone, str):
            return {"valid": False, "error": f"{field_name} deve ser uma string"}
        
        issues = []
        
        # Remover espaços e caracteres comuns
        clean_phone = re.sub(r'[\s\-\(\)]', '', phone)
        
        # Padrão básico de telefone internacional
        phone_pattern = re.compile(r'^\+?[1-9]\d{1,14}$')
        
        if not phone_pattern.match(clean_phone):
            issues.append(f"Formato de telefone inválido em {field_name}")
        
        # Verificar caracteres suspeitos
        if re.search(r'[^+\d\s\-\(\)]', phone):
            issues.append(f"Caracteres não permitidos no telefone {field_name}")
        
        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "sanitized": clean_phone
        }
    
    def validate_dict(self, data: Dict[str, Any], field_name: str = "data", max_depth: int = 10) -> Dict[str, Any]:
        """
        Valida um dicionário recursivamente.
        
        Args:
            data: Dicionário a ser validado
            field_name: Nome do campo
            max_depth: Profundidade máxima permitida
            
        Returns:
            Dict com resultado da validação
        """
        if not isinstance(data, dict):
            return {"valid": False, "error": f"{field_name} deve ser um dicionário"}
        
        issues = []
        
        def validate_recursive(obj, current_field: str, depth: int = 0):
            if depth > max_depth:
                issues.append(f"Profundidade máxima excedida em {current_field}")
                return
            
            if isinstance(obj, dict):
                for key, value in obj.items():
                    # Validar chave
                    key_validation = self.validate_string(str(key), f"{current_field}.{key}")
                    if not key_validation["valid"]:
                        issues.extend(key_validation["issues"])
                    
                    # Validar valor recursivamente
                    validate_recursive(value, f"{current_field}.{key}", depth + 1)
            
            elif isinstance(obj, list):
                for i, item in enumerate(obj):
                    validate_recursive(item, f"{current_field}[{i}]", depth + 1)
            
            elif isinstance(obj, str):
                str_validation = self.validate_string(obj, current_field)
                if not str_validation["valid"]:
                    issues.extend(str_validation["issues"])
        
        validate_recursive(data, field_name)
        
        return {
            "valid": len(issues) == 0,
            "issues": issues
        }
    
    def validate_file_upload(self, filename: str, content: bytes, field_name: str = "file") -> Dict[str, Any]:
        """
        Valida um upload de arquivo.
        
        Args:
            filename: Nome do arquivo
            content: Conteúdo do arquivo
            field_name: Nome do campo
            
        Returns:
            Dict com resultado da validação
        """
        issues = []
        
        # Validar nome do arquivo
        if not isinstance(filename, str):
            issues.append(f"Nome do arquivo deve ser uma string em {field_name}")
        else:
            # Verificar extensão perigosa
            file_ext = '.' + filename.split('.')[-1].lower() if '.' in filename else ''
            if file_ext in DANGEROUS_EXTENSIONS:
                issues.append(f"Extensão de arquivo não permitida em {field_name}: {file_ext}")
            
            # Verificar caracteres perigosos no nome
            if any(char in filename for char in ['<', '>', '"', "'", '&', '/', '\\', '|', '?', '*']):
                issues.append(f"Caracteres perigosos no nome do arquivo {field_name}")
            
            # Verificar path traversal
            if '..' in filename or filename.startswith('/') or ':' in filename:
                issues.append(f"Tentativa de path traversal detectada em {field_name}")
        
        # Validar conteúdo
        if not isinstance(content, bytes):
            issues.append(f"Conteúdo do arquivo deve ser bytes em {field_name}")
        else:
            # Verificar tamanho
            if len(content) > 10 * 1024 * 1024:  # 10MB
                issues.append(f"Arquivo muito grande em {field_name} ({len(content)} bytes)")
            
            # Verificar assinatura de arquivo (magic bytes)
            if len(content) > 0:
                # Verificar se não é um executável
                if content.startswith(b'MZ') or content.startswith(b'\x7fELF'):
                    issues.append(f"Arquivo executável detectado em {field_name}")
        
        return {
            "valid": len(issues) == 0,
            "issues": issues
        }
    
    def get_security_headers(self) -> Dict[str, str]:
        """
        Retorna headers de segurança recomendados.
        
        Returns:
            Dict com headers de segurança
        """
        return {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
            "Content-Security-Policy": "default-src 'self'",
            "Referrer-Policy": "strict-origin-when-cross-origin"
        }


# Instância global do validador
security_validator = SecurityValidator(strict_mode=True)


def validate_webhook_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Função de conveniência para validar payloads de webhook.
    
    Args:
        payload: Payload a ser validado
        
    Returns:
        Dict com resultado da validação
    """
    return security_validator.validate_dict(payload, "webhook_payload")


def sanitize_webhook_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Função de conveniência para sanitizar payloads de webhook.
    
    Args:
        payload: Payload a ser sanitizado
        
    Returns:
        Payload sanitizado
    """
    def sanitize_recursive(obj):
        if isinstance(obj, dict):
            return {key: sanitize_recursive(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [sanitize_recursive(item) for item in obj]
        elif isinstance(obj, str):
            return security_validator.sanitize_string(obj)
        else:
            return obj
    
    return sanitize_recursive(payload)