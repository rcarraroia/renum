"""
Configuração de WebSocket para o Renum Backend.

Este módulo define as configurações para WebSocket, incluindo
a opção de desabilitar WebSockets locais em favor do proxy.
"""

import os
from typing import Dict, Any

class WebSocketConfig:
    """Configuração de WebSocket."""
    
    def __init__(self):
        """Inicializa a configuração de WebSocket."""
        # Por padrão, desabilitar WebSockets locais em favor do proxy
        self.enable_local_websocket = os.getenv('ENABLE_LOCAL_WEBSOCKET', 'false').lower() == 'true'
        self.enable_websocket_proxy = os.getenv('ENABLE_WEBSOCKET_PROXY', 'true').lower() == 'true'
        
        # URLs de WebSocket
        self.suna_websocket_url = os.getenv('SUNA_WEBSOCKET_URL', 'ws://localhost:8000/ws')
        
        # Configurações de proxy
        self.proxy_timeout = int(os.getenv('WEBSOCKET_PROXY_TIMEOUT', '60'))
        self.proxy_retry_attempts = int(os.getenv('WEBSOCKET_PROXY_RETRY_ATTEMPTS', '3'))
        
    def is_local_websocket_enabled(self) -> bool:
        """
        Verifica se o WebSocket local está habilitado.
        
        Returns:
            True se o WebSocket local estiver habilitado, False caso contrário
        """
        return self.enable_local_websocket
    
    def is_websocket_proxy_enabled(self) -> bool:
        """
        Verifica se o proxy WebSocket está habilitado.
        
        Returns:
            True se o proxy WebSocket estiver habilitado, False caso contrário
        """
        return self.enable_websocket_proxy
    
    def get_config(self) -> Dict[str, Any]:
        """
        Obtém a configuração completa de WebSocket.
        
        Returns:
            Dicionário com as configurações de WebSocket
        """
        return {
            'enable_local_websocket': self.enable_local_websocket,
            'enable_websocket_proxy': self.enable_websocket_proxy,
            'suna_websocket_url': self.suna_websocket_url,
            'proxy_timeout': self.proxy_timeout,
            'proxy_retry_attempts': self.proxy_retry_attempts
        }


# Instância global da configuração
websocket_config = WebSocketConfig()