"""
Pacote core do Backend Renum.

Este pacote contém os módulos core do Backend Renum.
"""