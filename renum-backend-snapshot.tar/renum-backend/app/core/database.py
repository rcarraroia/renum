"""
Database module for the Renum backend.

This module provides database functionality for the Renum backend.
"""

from typing import Optional
import asyncio
from supabase import create_client, Client

from app.core.config import get_settings
from app.core.logger import logger


# Global database client
_db_client: Optional[Client] = None
_db_lock = asyncio.Lock()


async def initialize_db() -> Client:
    """Initialize the database client.
    
    Returns:
        Database client.
    """
    global _db_client
    
    if _db_client is not None:
        return _db_client
    
    async with _db_lock:
        if _db_client is not None:
            return _db_client
        
        settings = get_settings()
        
        try:
            logger.info("Initializing database client")
            _db_client = create_client(
                settings.supabase_url,
                settings.supabase_key
            )
            logger.info("Database client initialized successfully")
            return _db_client
        except Exception as e:
            logger.error(f"Error initializing database client: {str(e)}")
            raise


async def get_db_client() -> Client:
    """Get the database client.
    
    Returns:
        Database client.
    """
    global _db_client
    
    if _db_client is None:
        return await initialize_db()
    
    return _db_client


async def close_db() -> None:
    """Close the database client."""
    global _db_client
    
    if _db_client is not None:
        logger.info("Closing database client")
        _db_client = None
# SQLAlchemy Base para modelos ORM
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
# Função para obter sessão assíncrona
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

# Engine assíncrono
async_engine = None
AsyncSessionLocal = None

def get_async_engine():
    """Obtém o engine assíncrono SQLAlchemy."""
    global async_engine
    if async_engine is None:
        # Usar configurações do Supabase para PostgreSQL
        settings = get_settings()
        database_url = settings.SUPABASE_DB_URL or f"postgresql+asyncpg://postgres:{settings.SUPABASE_KEY}@{settings.SUPABASE_URL.replace('https://', '').replace('http://', '')}/postgres"
        async_engine = create_async_engine(database_url)
    return async_engine

def get_async_session_maker():
    """Obtém o session maker assíncrono."""
    global AsyncSessionLocal
    if AsyncSessionLocal is None:
        AsyncSessionLocal = sessionmaker(
            get_async_engine(),
            class_=AsyncSession,
            expire_on_commit=False
        )
    return AsyncSessionLocal

async def get_async_session() -> AsyncSession:
    """Obtém uma sessão assíncrona do banco de dados."""
    session_maker = get_async_session_maker()
    async with session_maker() as session:
        yield session