"""
Configuração de middlewares para a aplicação.

Este módulo contém a configuração e inicialização dos middlewares
de validação, rate limiting e segurança avançada.
"""

from fastapi import FastAPI
from app.api.middleware.validation_middleware import (
    PayloadValidationMiddleware,
    RateLimitMiddleware,
    SecurityHeadersMiddleware
)
from app.api.middleware.advanced_security_middleware import (
    AdvancedSecurityMiddleware,
    CORSSecurityMiddleware,
    configure_advanced_security
)
from app.core.config import settings


def configure_middlewares(app: FastAPI) -> None:
    """
    Configura todos os middlewares da aplicação.
    
    Args:
        app: Instância da aplicação FastAPI
    """
    
    # Configurar segurança avançada (inclui CORS e proteções)
    app = configure_advanced_security(
        app,
        enable_cors=getattr(settings, 'ENABLE_CORS', True),
        cors_origins=getattr(settings, 'CORS_ORIGINS', ["https://localhost:3000"]),
        blocked_countries=getattr(settings, 'BLOCKED_COUNTRIES', []),
        enable_honeypot=getattr(settings, 'ENABLE_HONEYPOT', True)
    )
    
    # Middleware de segurança avançado
    app.add_middleware(
        AdvancedSecurityMiddleware,
        enable_csp=getattr(settings, 'ENABLE_CSP', True),
        enable_hsts=getattr(settings, 'ENABLE_HSTS', True),
        enable_attack_detection=getattr(settings, 'ENABLE_ATTACK_DETECTION', True),
        allowed_origins=getattr(settings, 'CORS_ORIGINS', []),
        blocked_countries=getattr(settings, 'BLOCKED_COUNTRIES', []),
        max_request_size=getattr(settings, 'MAX_REQUEST_SIZE', 10 * 1024 * 1024),
        enable_honeypot=getattr(settings, 'ENABLE_HONEYPOT', True)
    )
    
    # Middleware de rate limiting
    app.add_middleware(
        RateLimitMiddleware,
        default_rate_limit=getattr(settings, 'DEFAULT_RATE_LIMIT', 60),
        rate_limit_window=getattr(settings, 'RATE_LIMIT_WINDOW', 60),
        enable_ip_based_limiting=getattr(settings, 'ENABLE_IP_RATE_LIMITING', True)
    )
    
    # Middleware de validação de payload (último a ser aplicado)
    app.add_middleware(
        PayloadValidationMiddleware,
        max_payload_size=getattr(settings, 'MAX_PAYLOAD_SIZE', 1024 * 1024),  # 1MB
        allowed_content_types=[
            "application/json",
            "application/x-www-form-urlencoded", 
            "text/plain"
        ],
        enable_security_validation=getattr(settings, 'ENABLE_SECURITY_VALIDATION', True)
    )


def configure_production_security(app: FastAPI) -> None:
    """
    Configura middlewares de segurança para produção.
    
    Args:
        app: Instância da aplicação FastAPI
    """
    
    # Configurações mais restritivas para produção
    app = configure_advanced_security(
        app,
        enable_cors=True,
        cors_origins=getattr(settings, 'PRODUCTION_CORS_ORIGINS', []),
        blocked_countries=getattr(settings, 'BLOCKED_COUNTRIES', []),
        enable_honeypot=True
    )
    
    # Middleware de segurança com configurações de produção
    app.add_middleware(
        AdvancedSecurityMiddleware,
        enable_csp=True,
        enable_hsts=True,
        enable_attack_detection=True,
        allowed_origins=getattr(settings, 'PRODUCTION_CORS_ORIGINS', []),
        blocked_countries=getattr(settings, 'BLOCKED_COUNTRIES', []),
        max_request_size=1 * 1024 * 1024,  # 1MB mais restritivo
        enable_honeypot=True
    )
    
    # Rate limiting mais agressivo
    app.add_middleware(
        RateLimitMiddleware,
        default_rate_limit=30,  # Mais restritivo
        rate_limit_window=60,
        enable_ip_based_limiting=True
    )
    
    # Validação mais rigorosa
    app.add_middleware(
        PayloadValidationMiddleware,
        max_payload_size=512 * 1024,  # 512KB mais restritivo
        allowed_content_types=["application/json"],  # Apenas JSON
        enable_security_validation=True
    )


def get_middleware_config() -> dict:
    """
    Retorna a configuração atual dos middlewares.
    
    Returns:
        Dict com configuração dos middlewares
    """
    return {
        "payload_validation": {
            "max_payload_size": getattr(settings, 'MAX_PAYLOAD_SIZE', 1024 * 1024),
            "allowed_content_types": [
                "application/json",
                "application/x-www-form-urlencoded",
                "text/plain"
            ],
            "enable_security_validation": getattr(settings, 'ENABLE_SECURITY_VALIDATION', True)
        },
        "rate_limiting": {
            "default_rate_limit": getattr(settings, 'DEFAULT_RATE_LIMIT', 60),
            "rate_limit_window": getattr(settings, 'RATE_LIMIT_WINDOW', 60),
            "enable_ip_based_limiting": getattr(settings, 'ENABLE_IP_RATE_LIMITING', True)
        },
        "security_headers": {
            "enabled": True,
            "custom_headers": {
                "X-API-Version": "1.0",
                "X-Service": "Suna-Webhooks"
            }
        }
    }