"""
Pacote de banco de dados do Backend Renum.

Este pacote contém os módulos de acesso a banco de dados do Backend Renum.
"""