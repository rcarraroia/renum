"""
Middleware de autenticação Supabase para o Renum Backend.

Este módulo implementa middleware de autenticação que valida tokens JWT
do Supabase e extrai informações do usuário para uso no sistema.
"""

import logging
import json
from typing import Optional, Dict, Any
from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
import jwt
from supabase import create_client, Client

from app.core.config import get_settings
from app.services.supabase_service import supabase_service

logger = logging.getLogger(__name__)

class SupabaseAuthMiddleware(BaseHTTPMiddleware):
    """Middleware para autenticação usando Supabase Auth."""
    
    def __init__(self, app, skip_paths: Optional[list] = None):
        """
        Inicializa o middleware de autenticação Supabase.
        
        Args:
            app: Aplicação FastAPI
            skip_paths: Lista de caminhos que devem pular a autenticação
        """
        super().__init__(app)
        self.settings = get_settings()
        self.skip_paths = skip_paths or [
            "/health", 
            "/", 
            "/docs", 
            "/redoc", 
            "/openapi.json",
            "/api/v1/health",
            "/proxy/suna/health"
        ]
        
        # Inicializa cliente Supabase
        try:
            self.supabase: Client = create_client(
                self.settings.SUPABASE_URL,
                self.settings.SUPABASE_KEY
            )
        except Exception as e:
            logger.error(f"Erro ao inicializar cliente Supabase: {str(e)}")
            self.supabase = None
    
    async def dispatch(self, request: Request, call_next):
        """
        Processa a requisição com autenticação Supabase.
        
        Args:
            request: Requisição HTTP
            call_next: Próxima função a ser chamada
            
        Returns:
            Resposta HTTP
        """
        # Verifica se deve pular autenticação para esta rota
        if self._should_skip_auth(request):
            return await call_next(request)
        
        # Extrai o token de autenticação
        auth_header = request.headers.get("Authorization")
        if not auth_header:
            return self._unauthorized_response("Token de autenticação necessário")
        
        try:
            # Valida o formato do header
            parts = auth_header.split()
            if len(parts) != 2 or parts[0].lower() != "bearer":
                return self._unauthorized_response("Formato de autenticação inválido")
            
            token = parts[1]
            
            # Valida o token e obtém dados do usuário
            user_data = await self._validate_token(token)
            if not user_data:
                return self._unauthorized_response("Token inválido ou expirado")
            
            # Adiciona dados do usuário ao estado da requisição
            request.state.user = user_data
            request.state.token = token
            
            # Continua o processamento
            response = await call_next(request)
            return response
            
        except HTTPException as e:
            return JSONResponse(
                status_code=e.status_code,
                content={"detail": e.detail}
            )
        except Exception as e:
            logger.error(f"Erro no middleware de autenticação: {str(e)}")
            return self._unauthorized_response("Erro interno de autenticação")
    
    def _should_skip_auth(self, request: Request) -> bool:
        """
        Verifica se deve pular autenticação para esta requisição.
        
        Args:
            request: Requisição HTTP
            
        Returns:
            True se deve pular autenticação, False caso contrário
        """
        path = request.url.path
        
        # Verifica caminhos exatos
        if path in self.skip_paths:
            return True
        
        # Verifica se é uma rota de proxy que não requer autenticação
        if path.startswith("/proxy/suna/health"):
            return True
        
        # Verifica se é uma rota OPTIONS (preflight CORS)
        if request.method == "OPTIONS":
            return True
        
        return False
    
    async def _validate_token(self, token: str) -> Optional[Dict[str, Any]]:
        """
        Valida um token JWT do Supabase e retorna dados do usuário.
        
        Args:
            token: Token JWT do Supabase
            
        Returns:
            Dados do usuário se o token for válido, None caso contrário
        """
        try:
            # Usa o serviço Supabase para validar o token
            user_data = await supabase_service.validate_jwt_token(token)
            return user_data
            
        except Exception as e:
            logger.error(f"Erro ao validar token: {str(e)}")
            return None
    
    def _unauthorized_response(self, message: str) -> JSONResponse:
        """
        Cria uma resposta de não autorizado.
        
        Args:
            message: Mensagem de erro
            
        Returns:
            Resposta JSON com status 401
        """
        return JSONResponse(
            status_code=401,
            content={
                "detail": message,
                "type": "authentication_error"
            },
            headers={"WWW-Authenticate": "Bearer"}
        )


class OptionalSupabaseAuthMiddleware(BaseHTTPMiddleware):
    """Middleware de autenticação Supabase opcional (não bloqueia se não autenticado)."""
    
    def __init__(self, app):
        """
        Inicializa o middleware de autenticação opcional.
        
        Args:
            app: Aplicação FastAPI
        """
        super().__init__(app)
        self.settings = get_settings()
        
        # Inicializa cliente Supabase
        try:
            self.supabase: Client = create_client(
                self.settings.SUPABASE_URL,
                self.settings.SUPABASE_KEY
            )
        except Exception as e:
            logger.error(f"Erro ao inicializar cliente Supabase: {str(e)}")
            self.supabase = None
    
    async def dispatch(self, request: Request, call_next):
        """
        Processa a requisição com autenticação opcional.
        
        Args:
            request: Requisição HTTP
            call_next: Próxima função a ser chamada
            
        Returns:
            Resposta HTTP
        """
        # Tenta extrair e validar token se presente
        auth_header = request.headers.get("Authorization")
        if auth_header:
            try:
                parts = auth_header.split()
                if len(parts) == 2 and parts[0].lower() == "bearer":
                    token = parts[1]
                    user_data = await self._validate_token(token)
                    if user_data:
                        request.state.user = user_data
                        request.state.token = token
                    else:
                        # Token inválido, mas não bloqueia a requisição
                        request.state.user = None
                        request.state.token = None
                else:
                    request.state.user = None
                    request.state.token = None
            except Exception as e:
                logger.warning(f"Erro ao processar token opcional: {str(e)}")
                request.state.user = None
                request.state.token = None
        else:
            request.state.user = None
            request.state.token = None
        
        # Continua o processamento independentemente da autenticação
        return await call_next(request)
    
    async def _validate_token(self, token: str) -> Optional[Dict[str, Any]]:
        """
        Valida um token JWT do Supabase.
        
        Args:
            token: Token JWT do Supabase
            
        Returns:
            Dados do usuário se o token for válido, None caso contrário
        """
        try:
            # Usa o serviço Supabase para validar o token
            user_data = await supabase_service.validate_jwt_token(token)
            return user_data
            
        except Exception as e:
            logger.debug(f"Erro ao validar token opcional: {str(e)}")
            return None