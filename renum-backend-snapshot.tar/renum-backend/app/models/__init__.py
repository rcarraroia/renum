"""
Pacote de modelos do Backend Renum.

Este pacote contém os modelos de dados do Backend Renum.
"""

# Importar modelos de integração
from .integrations import (
    AgentIntegration,
    WebhookCall,
    IntegrationStats,
    WebhookValidationResult,
    CreateIntegrationRequest,
    UpdateIntegrationRequest,
    IntegrationResponse,
    WebhookCallResponse,
    IntegrationStatus,
    IntegrationChannel
)

__all__ = [
    # Modelos de integração
    "AgentIntegration",
    "WebhookCall", 
    "IntegrationStats",
    "WebhookValidationResult",
    "CreateIntegrationRequest",
    "UpdateIntegrationRequest",
    "IntegrationResponse",
    "WebhookCallResponse",
    "IntegrationStatus",
    "IntegrationChannel",
]