"""
Módulo que define os modelos de dados para integrações de agentes da Plataforma Renum.

Este módulo contém as classes que representam integrações de agentes com sistemas externos
via webhooks e os logs de chamadas realizadas.
"""

from datetime import datetime
from typing import Optional, Dict, Any
from uuid import UUID
from enum import Enum
from pydantic import Field, validator
from ipaddress import IPv4Address, IPv6Address

from app.models.base import TimestampedEntity, Entity


class IntegrationStatus(str, Enum):
    """Enum para status de integrações."""
    ACTIVE = "active"
    INACTIVE = "inactive"


class IntegrationChannel(str, Enum):
    """Enum para canais de integração suportados."""
    WHATSAPP = "whatsapp"
    ZAPIER = "zapier"
    N8N = "n8n"
    TELEGRAM = "telegram"
    CUSTOM = "custom"


class AgentIntegration(TimestampedEntity):
    """
    Modelo para integrações de agentes com sistemas externos.
    
    Representa uma integração configurada entre um agente da plataforma
    e um sistema externo via webhook.
    """
    
    agent_id: UUID = Field(..., description="ID do agente no sistema Suna Core")
    client_id: UUID = Field(..., description="ID do cliente proprietário da integração")
    channel: IntegrationChannel = Field(..., description="Canal de integração")
    webhook_token: str = Field(..., description="Token único para autenticação do webhook")
    status: IntegrationStatus = Field(default=IntegrationStatus.ACTIVE, description="Status da integração")
    rate_limit_per_minute: int = Field(default=60, description="Limite de chamadas por minuto")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Metadados específicos do canal")
    created_by: Optional[UUID] = Field(None, description="ID do usuário que criou a integração")
    
    @validator('webhook_token')
    def validate_webhook_token(cls, v):
        """Valida o formato do token de webhook."""
        if not v.startswith('whk_'):
            raise ValueError('Token deve começar com "whk_"')
        if len(v) < 36:  # whk_ + 32 caracteres mínimo
            raise ValueError('Token deve ter pelo menos 36 caracteres')
        return v
    
    @validator('rate_limit_per_minute')
    def validate_rate_limit(cls, v):
        """Valida o limite de rate limiting."""
        if v < 1:
            raise ValueError('Rate limit deve ser pelo menos 1 chamada por minuto')
        if v > 1000:
            raise ValueError('Rate limit não pode exceder 1000 chamadas por minuto')
        return v
    
    class Config:
        """Configuração do modelo."""
        use_enum_values = True


class WebhookCall(Entity):
    """
    Modelo para logs de chamadas webhook.
    
    Armazena informações detalhadas sobre cada chamada webhook recebida,
    incluindo payload, resposta, métricas de performance e dados de auditoria.
    """
    
    integration_id: UUID = Field(..., description="ID da integração que recebeu a chamada")
    request_payload: Optional[Dict[str, Any]] = Field(None, description="Payload da requisição recebida")
    response_payload: Optional[Dict[str, Any]] = Field(None, description="Payload da resposta enviada")
    status_code: Optional[int] = Field(None, description="Código de status HTTP da resposta")
    execution_time_ms: Optional[int] = Field(None, description="Tempo de execução em milissegundos")
    ip_address: Optional[str] = Field(None, description="Endereço IP de origem da chamada")
    user_agent: Optional[str] = Field(None, description="User-Agent do cliente")
    error_message: Optional[str] = Field(None, description="Mensagem de erro, se houver")
    created_at: datetime = Field(default_factory=datetime.now, description="Data e hora da chamada")
    
    @validator('status_code')
    def validate_status_code(cls, v):
        """Valida o código de status HTTP."""
        if v is not None and (v < 100 or v > 599):
            raise ValueError('Status code deve estar entre 100 e 599')
        return v
    
    @validator('execution_time_ms')
    def validate_execution_time(cls, v):
        """Valida o tempo de execução."""
        if v is not None and v < 0:
            raise ValueError('Tempo de execução não pode ser negativo')
        return v
    
    @validator('ip_address')
    def validate_ip_address(cls, v):
        """Valida o formato do endereço IP."""
        if v is not None:
            try:
                # Tenta validar como IPv4 ou IPv6
                from ipaddress import ip_address
                ip_address(v)
            except ValueError:
                raise ValueError('Endereço IP inválido')
        return v


class IntegrationStats(Entity):
    """
    Modelo para estatísticas de uso de integrações.
    
    Representa métricas agregadas de uso de uma integração específica.
    """
    
    integration_id: UUID = Field(..., description="ID da integração")
    total_calls: int = Field(default=0, description="Total de chamadas realizadas")
    successful_calls: int = Field(default=0, description="Chamadas bem-sucedidas (2xx)")
    failed_calls: int = Field(default=0, description="Chamadas com falha (4xx, 5xx)")
    avg_execution_time_ms: Optional[float] = Field(None, description="Tempo médio de execução em ms")
    last_call_at: Optional[datetime] = Field(None, description="Data da última chamada")
    period_hours: int = Field(default=24, description="Período das estatísticas em horas")
    
    @property
    def success_rate(self) -> float:
        """Calcula a taxa de sucesso das chamadas."""
        if self.total_calls == 0:
            return 0.0
        return (self.successful_calls / self.total_calls) * 100
    
    @property
    def error_rate(self) -> float:
        """Calcula a taxa de erro das chamadas."""
        if self.total_calls == 0:
            return 0.0
        return (self.failed_calls / self.total_calls) * 100


class WebhookValidationResult(Entity):
    """
    Modelo para resultado de validação de webhook.
    
    Representa o resultado da validação de um token de webhook.
    """
    
    integration_id: Optional[UUID] = Field(None, description="ID da integração válida")
    client_id: Optional[UUID] = Field(None, description="ID do cliente da integração")
    rate_limit_per_minute: Optional[int] = Field(None, description="Limite de rate para a integração")
    is_valid: bool = Field(..., description="Se o token é válido")
    
    @property
    def is_invalid(self) -> bool:
        """Verifica se o token é inválido."""
        return not self.is_valid


# Modelos para criação e atualização (DTOs)

class CreateIntegrationRequest(Entity):
    """Modelo para requisição de criação de integração."""
    
    agent_id: UUID = Field(..., description="ID do agente")
    channel: IntegrationChannel = Field(..., description="Canal de integração")
    rate_limit_per_minute: int = Field(default=60, description="Limite de chamadas por minuto")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Metadados do canal")
    
    class Config:
        use_enum_values = True


class UpdateIntegrationRequest(Entity):
    """Modelo para requisição de atualização de integração."""
    
    status: Optional[IntegrationStatus] = Field(None, description="Novo status da integração")
    rate_limit_per_minute: Optional[int] = Field(None, description="Novo limite de chamadas")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Novos metadados")
    
    @validator('rate_limit_per_minute')
    def validate_rate_limit(cls, v):
        """Valida o limite de rate limiting."""
        if v is not None:
            if v < 1:
                raise ValueError('Rate limit deve ser pelo menos 1 chamada por minuto')
            if v > 1000:
                raise ValueError('Rate limit não pode exceder 1000 chamadas por minuto')
        return v
    
    class Config:
        use_enum_values = True


class IntegrationResponse(TimestampedEntity):
    """Modelo para resposta de integração com dados completos."""
    
    agent_id: UUID
    client_id: UUID
    channel: IntegrationChannel
    webhook_token: str
    webhook_url: str  # URL completa do webhook
    status: IntegrationStatus
    rate_limit_per_minute: int
    metadata: Dict[str, Any]
    created_by: Optional[UUID]
    
    # Estatísticas opcionais
    stats: Optional[IntegrationStats] = Field(None, description="Estatísticas de uso")
    
    class Config:
        use_enum_values = True


class WebhookCallResponse(Entity):
    """Modelo para resposta de chamada webhook."""
    
    integration_id: UUID
    status_code: Optional[int]
    execution_time_ms: Optional[int]
    error_message: Optional[str]
    created_at: datetime
    
    # Dados opcionais para debug (apenas para admins)
    request_payload: Optional[Dict[str, Any]] = Field(None, description="Payload da requisição")
    response_payload: Optional[Dict[str, Any]] = Field(None, description="Payload da resposta")
    ip_address: Optional[str] = Field(None, description="IP de origem")
    user_agent: Optional[str] = Field(None, description="User-Agent")

class WebhookToken(Entity):
    """Modelo para tokens de webhook."""
    
    integration_id: UUID = Field(..., description="ID da integração")
    token: str = Field(..., description="Token do webhook")
    is_active: bool = Field(True, description="Se o token está ativo")
    expires_at: Optional[datetime] = Field(None, description="Data de expiração")
    created_at: datetime = Field(default_factory=datetime.now, description="Data de criação")
    
    class Config:
        use_enum_values = True


# Aliases para compatibilidade com imports existentes
Integration = AgentIntegration