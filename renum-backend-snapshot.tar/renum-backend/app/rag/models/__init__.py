"""
Models for the RAG module.

This package contains data models for the RAG module.
"""