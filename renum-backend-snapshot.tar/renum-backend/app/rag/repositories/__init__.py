"""
Repositories for the RAG module.

This package contains repository classes for the RAG module.
"""