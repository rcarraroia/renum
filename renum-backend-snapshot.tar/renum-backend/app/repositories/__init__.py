"""
Pacote de repositórios do Backend Renum.

Este pacote contém os repositórios para acesso a dados do Backend Renum.
"""