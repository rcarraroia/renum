"""
Pacote de serviços do Backend Renum.

Este pacote contém os serviços do Backend Renum.
"""