"""
Serviço avançado de rate limiting com detecção de atividade suspeita.

Este módulo implementa rate limiting progressivo, bloqueio por IP,
detecção de padrões suspeitos e escalação de penalidades.
"""

import time
import json
import hashlib
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum

import redis
from app.core.config import settings


class ThreatLevel(Enum):
    """Níveis de ameaça para atividade suspeita."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class BlockReason(Enum):
    """Razões para bloqueio de IP."""
    RATE_LIMIT_EXCEEDED = "rate_limit_exceeded"
    SUSPICIOUS_PATTERNS = "suspicious_patterns"
    MALICIOUS_PAYLOAD = "malicious_payload"
    BRUTE_FORCE = "brute_force"
    SECURITY_VIOLATION = "security_violation"


@dataclass
class RateLimitResult:
    """Resultado da verificação de rate limit."""
    allowed: bool
    remaining: int
    reset_time: int
    delay_seconds: int = 0
    threat_level: ThreatLevel = ThreatLevel.LOW
    block_reason: Optional[BlockReason] = None


@dataclass
class SecurityEvent:
    """Evento de segurança detectado."""
    ip_address: str
    event_type: str
    threat_level: ThreatLevel
    details: Dict[str, Any]
    timestamp: datetime
    integration_id: Optional[str] = None


class AdvancedRateLimiter:
    """Rate limiter avançado com detecção de ameaças."""
    
    def __init__(self, redis_client: redis.Redis):
        """
        Inicializa o rate limiter avançado.
        
        Args:
            redis_client: Cliente Redis para armazenamento
        """
        self.redis = redis_client
        self.base_window = 60  # 1 minuto
        self.progressive_multipliers = [1, 2, 4, 8, 16]  # Escalação progressiva
        self.suspicious_threshold = 10  # Tentativas suspeitas por minuto
        self.block_duration_base = 300  # 5 minutos base
        
        # Padrões suspeitos
        self.suspicious_patterns = {
            "rapid_fire": {"requests_per_second": 10, "duration": 5},
            "burst_attack": {"requests_per_minute": 100, "duration": 1},
            "distributed_attack": {"unique_tokens": 5, "requests": 50},
            "payload_bombing": {"payload_size_mb": 5, "frequency": 3}
        }
    
    async def check_rate_limit(
        self,
        integration_id: str,
        ip_address: str,
        user_agent: str = "",
        payload_size: int = 0,
        token: str = ""
    ) -> RateLimitResult:
        """
        Verifica rate limit com análise de ameaças.
        
        Args:
            integration_id: ID da integração
            ip_address: IP do cliente
            user_agent: User-Agent do cliente
            payload_size: Tamanho do payload em bytes
            token: Token de autenticação
            
        Returns:
            RateLimitResult: Resultado da verificação
        """
        current_time = int(time.time())
        
        # 1. Verificar se IP está bloqueado
        block_info = await self._check_ip_block(ip_address)
        if block_info:
            return RateLimitResult(
                allowed=False,
                remaining=0,
                reset_time=block_info["expires_at"],
                delay_seconds=block_info["expires_at"] - current_time,
                threat_level=ThreatLevel(block_info["threat_level"]),
                block_reason=BlockReason(block_info["reason"])
            )
        
        # 2. Obter configuração de rate limit
        integration_config = await self._get_integration_config(integration_id)
        base_limit = integration_config.get("rate_limit_per_minute", 60)
        
        # 3. Verificar rate limit básico
        basic_result = await self._check_basic_rate_limit(
            integration_id, ip_address, base_limit, current_time
        )
        
        # 4. Analisar padrões suspeitos
        threat_analysis = await self._analyze_threat_patterns(
            ip_address, user_agent, payload_size, token, current_time
        )
        
        # 5. Aplicar rate limiting progressivo se necessário
        if threat_analysis.threat_level != ThreatLevel.LOW:
            progressive_result = await self._apply_progressive_limiting(
                integration_id, ip_address, basic_result, threat_analysis
            )
            
            # Registrar evento de segurança
            await self._log_security_event(SecurityEvent(
                ip_address=ip_address,
                event_type="threat_detected",
                threat_level=threat_analysis.threat_level,
                details={
                    "integration_id": integration_id,
                    "user_agent": user_agent,
                    "payload_size": payload_size,
                    "patterns": threat_analysis.details
                },
                timestamp=datetime.utcnow(),
                integration_id=integration_id
            ))
            
            return progressive_result
        
        # 6. Registrar requisição normal
        await self._record_request(integration_id, ip_address, current_time)
        
        return basic_result
    
    async def _check_ip_block(self, ip_address: str) -> Optional[Dict[str, Any]]:
        """
        Verifica se um IP está bloqueado.
        
        Args:
            ip_address: IP a verificar
            
        Returns:
            Dict com informações do bloqueio ou None
        """
        block_key = f"blocked_ip:{ip_address}"
        block_data = await self.redis.get(block_key)
        
        if block_data:
            return json.loads(block_data)
        
        return None
    
    async def _get_integration_config(self, integration_id: str) -> Dict[str, Any]:
        """
        Obtém configuração da integração.
        
        Args:
            integration_id: ID da integração
            
        Returns:
            Dict com configuração
        """
        config_key = f"integration_config:{integration_id}"
        config_data = await self.redis.get(config_key)
        
        if config_data:
            return json.loads(config_data)
        
        # Configuração padrão
        return {
            "rate_limit_per_minute": 60,
            "burst_limit": 10,
            "progressive_enabled": True
        }
    
    async def _check_basic_rate_limit(
        self,
        integration_id: str,
        ip_address: str,
        limit: int,
        current_time: int
    ) -> RateLimitResult:
        """
        Verifica rate limit básico.
        
        Args:
            integration_id: ID da integração
            ip_address: IP do cliente
            limit: Limite de requisições
            current_time: Timestamp atual
            
        Returns:
            RateLimitResult: Resultado básico
        """
        window_start = current_time - (current_time % self.base_window)
        rate_key = f"rate_limit:{integration_id}:{ip_address}:{window_start}"
        
        # Incrementar contador
        current_count = await self.redis.incr(rate_key)
        
        # Definir TTL na primeira requisição
        if current_count == 1:
            await self.redis.expire(rate_key, self.base_window)
        
        # Calcular tempo de reset
        reset_time = window_start + self.base_window
        remaining = max(0, limit - current_count)
        
        return RateLimitResult(
            allowed=current_count <= limit,
            remaining=remaining,
            reset_time=reset_time,
            threat_level=ThreatLevel.LOW
        )
    
    async def _analyze_threat_patterns(
        self,
        ip_address: str,
        user_agent: str,
        payload_size: int,
        token: str,
        current_time: int
    ) -> 'ThreatAnalysis':
        """
        Analisa padrões de ameaça.
        
        Args:
            ip_address: IP do cliente
            user_agent: User-Agent
            payload_size: Tamanho do payload
            token: Token de autenticação
            current_time: Timestamp atual
            
        Returns:
            ThreatAnalysis: Análise de ameaças
        """
        threats = []
        threat_level = ThreatLevel.LOW
        
        # 1. Verificar rapid fire (muitas requisições em pouco tempo)
        rapid_fire = await self._check_rapid_fire(ip_address, current_time)
        if rapid_fire:
            threats.append("rapid_fire")
            threat_level = max(threat_level, ThreatLevel.MEDIUM)
        
        # 2. Verificar burst attack
        burst_attack = await self._check_burst_attack(ip_address, current_time)
        if burst_attack:
            threats.append("burst_attack")
            threat_level = max(threat_level, ThreatLevel.HIGH)
        
        # 3. Verificar distributed attack (mesmo token, múltiplos IPs)
        distributed = await self._check_distributed_attack(token, ip_address, current_time)
        if distributed:
            threats.append("distributed_attack")
            threat_level = max(threat_level, ThreatLevel.HIGH)
        
        # 4. Verificar payload bombing
        if payload_size > 5 * 1024 * 1024:  # 5MB
            payload_bomb = await self._check_payload_bombing(ip_address, current_time)
            if payload_bomb:
                threats.append("payload_bombing")
                threat_level = max(threat_level, ThreatLevel.CRITICAL)
        
        # 5. Verificar User-Agent suspeito
        if self._is_suspicious_user_agent(user_agent):
            threats.append("suspicious_user_agent")
            threat_level = max(threat_level, ThreatLevel.MEDIUM)
        
        # 6. Verificar padrões de IP
        ip_patterns = await self._check_ip_patterns(ip_address)
        if ip_patterns:
            threats.extend(ip_patterns)
            threat_level = max(threat_level, ThreatLevel.MEDIUM)
        
        return ThreatAnalysis(
            threat_level=threat_level,
            patterns=threats,
            details={
                "ip_address": ip_address,
                "user_agent": user_agent,
                "payload_size": payload_size,
                "detected_patterns": threats
            }
        )
    
    async def _check_rapid_fire(self, ip_address: str, current_time: int) -> bool:
        """Verifica ataques rapid fire."""
        window = 5  # 5 segundos
        key = f"rapid_fire:{ip_address}"
        
        # Adicionar timestamp atual
        await self.redis.zadd(key, {str(current_time): current_time})
        
        # Remover entradas antigas
        cutoff = current_time - window
        await self.redis.zremrangebyscore(key, 0, cutoff)
        
        # Definir TTL
        await self.redis.expire(key, window)
        
        # Contar requisições na janela
        count = await self.redis.zcard(key)
        
        return count > self.suspicious_patterns["rapid_fire"]["requests_per_second"] * window
    
    async def _check_burst_attack(self, ip_address: str, current_time: int) -> bool:
        """Verifica ataques burst."""
        window = 60  # 1 minuto
        key = f"burst_attack:{ip_address}"
        
        await self.redis.zadd(key, {str(current_time): current_time})
        
        cutoff = current_time - window
        await self.redis.zremrangebyscore(key, 0, cutoff)
        await self.redis.expire(key, window)
        
        count = await self.redis.zcard(key)
        
        return count > self.suspicious_patterns["burst_attack"]["requests_per_minute"]
    
    async def _check_distributed_attack(self, token: str, ip_address: str, current_time: int) -> bool:
        """Verifica ataques distribuídos."""
        if not token:
            return False
        
        window = 300  # 5 minutos
        key = f"distributed:{hashlib.sha256(token.encode()).hexdigest()[:16]}"
        
        # Adicionar IP atual
        await self.redis.sadd(key, ip_address)
        await self.redis.expire(key, window)
        
        # Contar IPs únicos
        unique_ips = await self.redis.scard(key)
        
        # Contar requisições totais para este token
        requests_key = f"token_requests:{hashlib.sha256(token.encode()).hexdigest()[:16]}"
        await self.redis.incr(requests_key)
        await self.redis.expire(requests_key, window)
        
        total_requests = int(await self.redis.get(requests_key) or 0)
        
        return (unique_ips >= self.suspicious_patterns["distributed_attack"]["unique_tokens"] and
                total_requests >= self.suspicious_patterns["distributed_attack"]["requests"])
    
    async def _check_payload_bombing(self, ip_address: str, current_time: int) -> bool:
        """Verifica payload bombing."""
        window = 300  # 5 minutos
        key = f"payload_bomb:{ip_address}"
        
        count = await self.redis.incr(key)
        if count == 1:
            await self.redis.expire(key, window)
        
        return count >= self.suspicious_patterns["payload_bombing"]["frequency"]
    
    def _is_suspicious_user_agent(self, user_agent: str) -> bool:
        """Verifica User-Agent suspeito."""
        if not user_agent:
            return True
        
        suspicious_patterns = [
            "bot", "crawler", "spider", "scraper",
            "curl", "wget", "python-requests",
            "sqlmap", "nmap", "nikto", "burp"
        ]
        
        user_agent_lower = user_agent.lower()
        return any(pattern in user_agent_lower for pattern in suspicious_patterns)
    
    async def _check_ip_patterns(self, ip_address: str) -> List[str]:
        """Verifica padrões suspeitos de IP."""
        patterns = []
        
        # Verificar se é IP privado tentando acessar externamente
        if self._is_private_ip(ip_address):
            patterns.append("private_ip_external_access")
        
        # Verificar se está em lista de IPs conhecidamente maliciosos
        if await self._is_known_malicious_ip(ip_address):
            patterns.append("known_malicious_ip")
        
        # Verificar geolocalização suspeita (se configurado)
        geo_suspicious = await self._check_geo_patterns(ip_address)
        if geo_suspicious:
            patterns.extend(geo_suspicious)
        
        return patterns
    
    def _is_private_ip(self, ip_address: str) -> bool:
        """Verifica se é IP privado."""
        import ipaddress
        try:
            ip = ipaddress.ip_address(ip_address)
            return ip.is_private
        except ValueError:
            return False
    
    async def _is_known_malicious_ip(self, ip_address: str) -> bool:
        """Verifica se IP está em lista de maliciosos."""
        malicious_key = f"malicious_ip:{ip_address}"
        return await self.redis.exists(malicious_key)
    
    async def _check_geo_patterns(self, ip_address: str) -> List[str]:
        """Verifica padrões geográficos suspeitos."""
        # Implementação simplificada - em produção usaria serviço de geolocalização
        patterns = []
        
        # Verificar se IP mudou de país rapidamente
        geo_key = f"geo_history:{ip_address}"
        # ... implementação de geolocalização
        
        return patterns
    
    async def _apply_progressive_limiting(
        self,
        integration_id: str,
        ip_address: str,
        basic_result: RateLimitResult,
        threat_analysis: 'ThreatAnalysis'
    ) -> RateLimitResult:
        """
        Aplica rate limiting progressivo baseado no nível de ameaça.
        
        Args:
            integration_id: ID da integração
            ip_address: IP do cliente
            basic_result: Resultado básico do rate limit
            threat_analysis: Análise de ameaças
            
        Returns:
            RateLimitResult: Resultado com limitação progressiva
        """
        # Obter nível de escalação atual
        escalation_level = await self._get_escalation_level(ip_address)
        
        # Calcular multiplicador baseado no nível de ameaça
        threat_multiplier = {
            ThreatLevel.LOW: 1,
            ThreatLevel.MEDIUM: 2,
            ThreatLevel.HIGH: 4,
            ThreatLevel.CRITICAL: 8
        }[threat_analysis.threat_level]
        
        # Aplicar escalação progressiva
        total_multiplier = min(
            self.progressive_multipliers[min(escalation_level, len(self.progressive_multipliers) - 1)],
            threat_multiplier
        )
        
        # Calcular delay progressivo
        base_delay = 1  # 1 segundo base
        progressive_delay = base_delay * total_multiplier
        
        # Verificar se deve bloquear IP
        should_block = (
            threat_analysis.threat_level == ThreatLevel.CRITICAL or
            escalation_level >= 3 or
            not basic_result.allowed
        )
        
        if should_block:
            await self._block_ip(
                ip_address,
                threat_analysis.threat_level,
                BlockReason.SUSPICIOUS_PATTERNS,
                duration_multiplier=total_multiplier
            )
            
            return RateLimitResult(
                allowed=False,
                remaining=0,
                reset_time=int(time.time()) + self.block_duration_base * total_multiplier,
                delay_seconds=self.block_duration_base * total_multiplier,
                threat_level=threat_analysis.threat_level,
                block_reason=BlockReason.SUSPICIOUS_PATTERNS
            )
        
        # Incrementar nível de escalação
        await self._increment_escalation_level(ip_address)
        
        # Aplicar delay progressivo
        return RateLimitResult(
            allowed=basic_result.allowed,
            remaining=max(0, basic_result.remaining // total_multiplier),
            reset_time=basic_result.reset_time,
            delay_seconds=progressive_delay,
            threat_level=threat_analysis.threat_level
        )
    
    async def _get_escalation_level(self, ip_address: str) -> int:
        """Obtém nível de escalação atual para um IP."""
        escalation_key = f"escalation:{ip_address}"
        level = await self.redis.get(escalation_key)
        return int(level) if level else 0
    
    async def _increment_escalation_level(self, ip_address: str):
        """Incrementa nível de escalação para um IP."""
        escalation_key = f"escalation:{ip_address}"
        await self.redis.incr(escalation_key)
        await self.redis.expire(escalation_key, 3600)  # 1 hora
    
    async def _block_ip(
        self,
        ip_address: str,
        threat_level: ThreatLevel,
        reason: BlockReason,
        duration_multiplier: int = 1
    ):
        """
        Bloqueia um IP por atividade suspeita.
        
        Args:
            ip_address: IP a bloquear
            threat_level: Nível de ameaça
            reason: Razão do bloqueio
            duration_multiplier: Multiplicador de duração
        """
        block_duration = self.block_duration_base * duration_multiplier
        expires_at = int(time.time()) + block_duration
        
        block_data = {
            "ip_address": ip_address,
            "threat_level": threat_level.value,
            "reason": reason.value,
            "blocked_at": int(time.time()),
            "expires_at": expires_at,
            "duration_seconds": block_duration
        }
        
        block_key = f"blocked_ip:{ip_address}"
        await self.redis.setex(
            block_key,
            block_duration,
            json.dumps(block_data)
        )
        
        # Adicionar à lista de IPs bloqueados para monitoramento
        blocked_list_key = "blocked_ips_list"
        await self.redis.zadd(blocked_list_key, {ip_address: expires_at})
    
    async def _record_request(self, integration_id: str, ip_address: str, timestamp: int):
        """Registra uma requisição normal."""
        request_key = f"requests:{integration_id}:{ip_address}"
        await self.redis.zadd(request_key, {str(timestamp): timestamp})
        
        # Manter apenas últimas 24 horas
        cutoff = timestamp - 86400
        await self.redis.zremrangebyscore(request_key, 0, cutoff)
        await self.redis.expire(request_key, 86400)
    
    async def _log_security_event(self, event: SecurityEvent):
        """Registra evento de segurança."""
        event_data = {
            "ip_address": event.ip_address,
            "event_type": event.event_type,
            "threat_level": event.threat_level.value,
            "details": event.details,
            "timestamp": event.timestamp.isoformat(),
            "integration_id": event.integration_id
        }
        
        # Adicionar à lista de eventos de segurança
        events_key = "security_events"
        await self.redis.zadd(
            events_key,
            {json.dumps(event_data): int(event.timestamp.timestamp())}
        )
        
        # Manter apenas últimos 7 dias
        cutoff = int(time.time()) - 604800
        await self.redis.zremrangebyscore(events_key, 0, cutoff)
    
    async def get_blocked_ips(self) -> List[Dict[str, Any]]:
        """Retorna lista de IPs bloqueados."""
        blocked_list_key = "blocked_ips_list"
        current_time = int(time.time())
        
        # Remover IPs expirados
        await self.redis.zremrangebyscore(blocked_list_key, 0, current_time)
        
        # Obter IPs ativos
        blocked_ips = await self.redis.zrange(blocked_list_key, 0, -1, withscores=True)
        
        result = []
        for ip, expires_at in blocked_ips:
            block_key = f"blocked_ip:{ip}"
            block_data = await self.redis.get(block_key)
            if block_data:
                result.append(json.loads(block_data))
        
        return result
    
    async def unblock_ip(self, ip_address: str) -> bool:
        """
        Remove bloqueio de um IP.
        
        Args:
            ip_address: IP a desbloquear
            
        Returns:
            bool: True se foi desbloqueado
        """
        block_key = f"blocked_ip:{ip_address}"
        blocked_list_key = "blocked_ips_list"
        
        # Remover bloqueio
        deleted = await self.redis.delete(block_key)
        await self.redis.zrem(blocked_list_key, ip_address)
        
        # Resetar escalação
        escalation_key = f"escalation:{ip_address}"
        await self.redis.delete(escalation_key)
        
        return deleted > 0
    
    async def get_security_events(
        self,
        limit: int = 100,
        threat_level: Optional[ThreatLevel] = None
    ) -> List[Dict[str, Any]]:
        """
        Obtém eventos de segurança recentes.
        
        Args:
            limit: Limite de eventos
            threat_level: Filtrar por nível de ameaça
            
        Returns:
            Lista de eventos de segurança
        """
        events_key = "security_events"
        
        # Obter eventos mais recentes
        events = await self.redis.zrevrange(events_key, 0, limit - 1)
        
        result = []
        for event_json in events:
            event_data = json.loads(event_json)
            
            # Filtrar por nível de ameaça se especificado
            if threat_level and event_data["threat_level"] != threat_level.value:
                continue
            
            result.append(event_data)
        
        return result


@dataclass
class ThreatAnalysis:
    """Resultado da análise de ameaças."""
    threat_level: ThreatLevel
    patterns: List[str]
    details: Dict[str, Any]


# Instância global do rate limiter avançado
_advanced_rate_limiter: Optional[AdvancedRateLimiter] = None


def get_advanced_rate_limiter(redis_client: redis.Redis) -> AdvancedRateLimiter:
    """
    Obtém instância do rate limiter avançado.
    
    Args:
        redis_client: Cliente Redis
        
    Returns:
        AdvancedRateLimiter: Instância do rate limiter
    """
    global _advanced_rate_limiter
    
    if _advanced_rate_limiter is None:
        _advanced_rate_limiter = AdvancedRateLimiter(redis_client)
    
    return _advanced_rate_limiter