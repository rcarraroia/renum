"""
Serviço de alertas e notificações.

Este módulo implementa sistema de alertas com múltiplos canais de notificação,
escalação automática e integração com sistemas externos de monitoramento.
"""

import asyncio
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass, asdict
from enum import Enum
from abc import ABC, abstractmethod

import aiohttp
import redis.asyncio as redis
from app.services.metrics_collector import Alert, AlertLevel


# Configurar logger
logger = logging.getLogger(__name__)


class NotificationChannel(Enum):
    """Canais de notificação disponíveis."""
    EMAIL = "email"
    SLACK = "slack"
    WEBHOOK = "webhook"
    SMS = "sms"
    DISCORD = "discord"
    TEAMS = "teams"


class EscalationLevel(Enum):
    """Níveis de escalação."""
    L1 = "l1"  # Primeiro nível
    L2 = "l2"  # Segundo nível
    L3 = "l3"  # Terceiro nível (crítico)


@dataclass
class NotificationConfig:
    """Configuração de notificação."""
    channel: NotificationChannel
    enabled: bool = True
    config: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.config is None:
            self.config = {}


@dataclass
class EscalationRule:
    """Regra de escalação de alertas."""
    alert_level: AlertLevel
    escalation_level: EscalationLevel
    delay_minutes: int
    notification_channels: List[NotificationChannel]
    repeat_interval_minutes: Optional[int] = None
    max_repeats: Optional[int] = None


class NotificationProvider(ABC):
    """Interface base para provedores de notificação."""
    
    @abstractmethod
    async def send_notification(
        self,
        alert: Alert,
        config: Dict[str, Any]
    ) -> bool:
        """
        Envia notificação.
        
        Args:
            alert: Alerta a ser notificado
            config: Configuração do provedor
            
        Returns:
            bool: True se enviado com sucesso
        """
        pass


class SlackNotificationProvider(NotificationProvider):
    """Provedor de notificação para Slack."""
    
    async def send_notification(self, alert: Alert, config: Dict[str, Any]) -> bool:
        """Envia notificação para Slack."""
        try:
            webhook_url = config.get("webhook_url")
            if not webhook_url:
                logger.error("Slack webhook URL não configurada")
                return False
            
            # Mapear nível de alerta para cor
            color_map = {
                AlertLevel.INFO: "#36a64f",      # Verde
                AlertLevel.WARNING: "#ff9500",   # Laranja
                AlertLevel.CRITICAL: "#ff0000"   # Vermelho
            }
            
            # Criar payload do Slack
            payload = {
                "attachments": [{
                    "color": color_map.get(alert.level, "#cccccc"),
                    "title": f"🚨 Alerta: {alert.name}",
                    "text": alert.message,
                    "fields": [
                        {
                            "title": "Nível",
                            "value": alert.level.value.upper(),
                            "short": True
                        },
                        {
                            "title": "Métrica",
                            "value": alert.metric_name,
                            "short": True
                        },
                        {
                            "title": "Valor Atual",
                            "value": str(alert.current_value),
                            "short": True
                        },
                        {
                            "title": "Limite",
                            "value": str(alert.threshold),
                            "short": True
                        },
                        {
                            "title": "Timestamp",
                            "value": alert.timestamp.strftime("%Y-%m-%d %H:%M:%S UTC"),
                            "short": False
                        }
                    ],
                    "footer": "Sistema de Monitoramento Webhook",
                    "ts": int(alert.timestamp.timestamp())
                }]
            }
            
            # Enviar para Slack
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    webhook_url,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.status == 200:
                        logger.info(f"Notificação Slack enviada para alerta {alert.id}")
                        return True
                    else:
                        logger.error(f"Erro enviando notificação Slack: {response.status}")
                        return False
                        
        except Exception as e:
            logger.error(f"Erro no provedor Slack: {str(e)}")
            return False


class WebhookNotificationProvider(NotificationProvider):
    """Provedor de notificação via webhook."""
    
    async def send_notification(self, alert: Alert, config: Dict[str, Any]) -> bool:
        """Envia notificação via webhook."""
        try:
            webhook_url = config.get("url")
            if not webhook_url:
                logger.error("Webhook URL não configurada")
                return False
            
            # Criar payload
            payload = {
                "alert": {
                    "id": alert.id,
                    "name": alert.name,
                    "level": alert.level.value,
                    "message": alert.message,
                    "metric_name": alert.metric_name,
                    "current_value": alert.current_value,
                    "threshold": alert.threshold,
                    "timestamp": alert.timestamp.isoformat(),
                    "labels": alert.labels,
                    "resolved": alert.resolved
                },
                "system": "webhook-monitoring",
                "version": "1.0"
            }
            
            # Headers customizados
            headers = {
                "Content-Type": "application/json",
                "User-Agent": "WebhookMonitoring/1.0"
            }
            
            # Adicionar headers customizados da configuração
            custom_headers = config.get("headers", {})
            headers.update(custom_headers)
            
            # Enviar webhook
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    webhook_url,
                    json=payload,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=15)
                ) as response:
                    if 200 <= response.status < 300:
                        logger.info(f"Notificação webhook enviada para alerta {alert.id}")
                        return True
                    else:
                        logger.error(f"Erro enviando notificação webhook: {response.status}")
                        return False
                        
        except Exception as e:
            logger.error(f"Erro no provedor webhook: {str(e)}")
            return False


class EmailNotificationProvider(NotificationProvider):
    """Provedor de notificação por email (simulado)."""
    
    async def send_notification(self, alert: Alert, config: Dict[str, Any]) -> bool:
        """Envia notificação por email (simulado)."""
        try:
            # Em produção, integraria com serviço de email real (SendGrid, SES, etc.)
            recipients = config.get("recipients", [])
            if not recipients:
                logger.error("Nenhum destinatário de email configurado")
                return False
            
            # Simular envio de email
            logger.info(f"[SIMULADO] Email enviado para {recipients} - Alerta: {alert.name}")
            
            # Em produção, aqui seria a integração real
            # smtp_server = config.get("smtp_server")
            # smtp_port = config.get("smtp_port", 587)
            # username = config.get("username")
            # password = config.get("password")
            # ... código de envio de email real
            
            return True
            
        except Exception as e:
            logger.error(f"Erro no provedor email: {str(e)}")
            return False


class DiscordNotificationProvider(NotificationProvider):
    """Provedor de notificação para Discord."""
    
    async def send_notification(self, alert: Alert, config: Dict[str, Any]) -> bool:
        """Envia notificação para Discord."""
        try:
            webhook_url = config.get("webhook_url")
            if not webhook_url:
                logger.error("Discord webhook URL não configurada")
                return False
            
            # Mapear nível de alerta para cor (formato decimal)
            color_map = {
                AlertLevel.INFO: 3581519,      # Verde
                AlertLevel.WARNING: 16753920,  # Laranja
                AlertLevel.CRITICAL: 16711680  # Vermelho
            }
            
            # Emoji por nível
            emoji_map = {
                AlertLevel.INFO: "ℹ️",
                AlertLevel.WARNING: "⚠️",
                AlertLevel.CRITICAL: "🚨"
            }
            
            # Criar embed do Discord
            embed = {
                "title": f"{emoji_map.get(alert.level, '🔔')} Alerta: {alert.name}",
                "description": alert.message,
                "color": color_map.get(alert.level, 8421504),  # Cinza padrão
                "fields": [
                    {
                        "name": "Nível",
                        "value": alert.level.value.upper(),
                        "inline": True
                    },
                    {
                        "name": "Métrica",
                        "value": alert.metric_name,
                        "inline": True
                    },
                    {
                        "name": "Valor Atual",
                        "value": str(alert.current_value),
                        "inline": True
                    },
                    {
                        "name": "Limite",
                        "value": str(alert.threshold),
                        "inline": True
                    }
                ],
                "timestamp": alert.timestamp.isoformat(),
                "footer": {
                    "text": "Sistema de Monitoramento Webhook"
                }
            }
            
            payload = {"embeds": [embed]}
            
            # Enviar para Discord
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    webhook_url,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.status == 204:  # Discord retorna 204 para sucesso
                        logger.info(f"Notificação Discord enviada para alerta {alert.id}")
                        return True
                    else:
                        logger.error(f"Erro enviando notificação Discord: {response.status}")
                        return False
                        
        except Exception as e:
            logger.error(f"Erro no provedor Discord: {str(e)}")
            return False


class AlertingService:
    """Serviço principal de alertas."""
    
    def __init__(self, redis_client: redis.Redis):
        """
        Inicializa o serviço de alertas.
        
        Args:
            redis_client: Cliente Redis para persistência
        """
        self.redis = redis_client
        self.notification_providers = {
            NotificationChannel.SLACK: SlackNotificationProvider(),
            NotificationChannel.WEBHOOK: WebhookNotificationProvider(),
            NotificationChannel.EMAIL: EmailNotificationProvider(),
            NotificationChannel.DISCORD: DiscordNotificationProvider()
        }
        
        # Configurações padrão
        self.notification_configs = {}
        self.escalation_rules = []
        
        # Estado do serviço
        self.is_running = False
        self.pending_escalations = {}
        
        # Configurar regras de escalação padrão
        self._setup_default_escalation_rules()
    
    def _setup_default_escalation_rules(self):
        """Configura regras de escalação padrão."""
        
        # Alertas INFO - apenas notificação
        self.escalation_rules.append(EscalationRule(
            alert_level=AlertLevel.INFO,
            escalation_level=EscalationLevel.L1,
            delay_minutes=0,  # Imediato
            notification_channels=[NotificationChannel.SLACK]
        ))
        
        # Alertas WARNING - notificação imediata + escalação
        self.escalation_rules.append(EscalationRule(
            alert_level=AlertLevel.WARNING,
            escalation_level=EscalationLevel.L1,
            delay_minutes=0,  # Imediato
            notification_channels=[NotificationChannel.SLACK, NotificationChannel.EMAIL]
        ))
        
        self.escalation_rules.append(EscalationRule(
            alert_level=AlertLevel.WARNING,
            escalation_level=EscalationLevel.L2,
            delay_minutes=15,  # Após 15 minutos se não resolvido
            notification_channels=[NotificationChannel.WEBHOOK],
            repeat_interval_minutes=30,
            max_repeats=3
        ))
        
        # Alertas CRITICAL - escalação agressiva
        self.escalation_rules.append(EscalationRule(
            alert_level=AlertLevel.CRITICAL,
            escalation_level=EscalationLevel.L1,
            delay_minutes=0,  # Imediato
            notification_channels=[
                NotificationChannel.SLACK,
                NotificationChannel.EMAIL,
                NotificationChannel.WEBHOOK
            ]
        ))
        
        self.escalation_rules.append(EscalationRule(
            alert_level=AlertLevel.CRITICAL,
            escalation_level=EscalationLevel.L2,
            delay_minutes=5,  # Após 5 minutos
            notification_channels=[
                NotificationChannel.DISCORD,
                NotificationChannel.WEBHOOK
            ],
            repeat_interval_minutes=15,
            max_repeats=5
        ))
        
        self.escalation_rules.append(EscalationRule(
            alert_level=AlertLevel.CRITICAL,
            escalation_level=EscalationLevel.L3,
            delay_minutes=15,  # Após 15 minutos
            notification_channels=[NotificationChannel.WEBHOOK],
            repeat_interval_minutes=10,
            max_repeats=10
        ))
    
    def configure_notification(
        self,
        channel: NotificationChannel,
        config: Dict[str, Any],
        enabled: bool = True
    ):
        """
        Configura canal de notificação.
        
        Args:
            channel: Canal de notificação
            config: Configuração do canal
            enabled: Se o canal está habilitado
        """
        self.notification_configs[channel] = NotificationConfig(
            channel=channel,
            enabled=enabled,
            config=config
        )
        
        logger.info(f"Canal de notificação {channel.value} configurado")
    
    async def process_alert(self, alert: Alert):
        """
        Processa um alerta aplicando regras de escalação.
        
        Args:
            alert: Alerta a ser processado
        """
        try:
            logger.info(f"Processando alerta {alert.id}: {alert.name}")
            
            # Encontrar regras aplicáveis
            applicable_rules = [
                rule for rule in self.escalation_rules
                if rule.alert_level == alert.level
            ]
            
            if not applicable_rules:
                logger.warning(f"Nenhuma regra de escalação encontrada para alerta {alert.id}")
                return
            
            # Processar cada regra
            for rule in applicable_rules:
                await self._schedule_escalation(alert, rule)
            
            # Persistir estado do alerta
            await self._persist_alert_state(alert)
            
        except Exception as e:
            logger.error(f"Erro processando alerta {alert.id}: {str(e)}")
    
    async def _schedule_escalation(self, alert: Alert, rule: EscalationRule):
        """Agenda escalação de alerta."""
        
        escalation_id = f"{alert.id}_{rule.escalation_level.value}"
        
        # Calcular tempo de execução
        execution_time = alert.timestamp + timedelta(minutes=rule.delay_minutes)
        
        # Criar escalação
        escalation = {
            "alert_id": alert.id,
            "alert": asdict(alert),
            "rule": asdict(rule),
            "execution_time": execution_time.isoformat(),
            "executed": False,
            "repeat_count": 0,
            "created_at": datetime.utcnow().isoformat()
        }
        
        # Converter datetime para string no alert
        escalation["alert"]["timestamp"] = alert.timestamp.isoformat()
        if escalation["alert"]["resolved_at"]:
            escalation["alert"]["resolved_at"] = alert.resolved_at.isoformat()
        
        # Armazenar no Redis
        await self.redis.setex(
            f"escalation:{escalation_id}",
            86400,  # 24 horas
            json.dumps(escalation)
        )
        
        # Adicionar à fila de escalações
        await self.redis.zadd(
            "escalation_queue",
            {escalation_id: int(execution_time.timestamp())}
        )
        
        logger.info(f"Escalação agendada: {escalation_id} para {execution_time}")
    
    async def _execute_escalation(self, escalation_id: str, escalation_data: Dict[str, Any]):
        """Executa uma escalação."""
        
        try:
            alert_data = escalation_data["alert"]
            rule_data = escalation_data["rule"]
            
            # Recriar objetos
            alert = Alert(
                id=alert_data["id"],
                name=alert_data["name"],
                level=AlertLevel(alert_data["level"]),
                message=alert_data["message"],
                timestamp=datetime.fromisoformat(alert_data["timestamp"]),
                metric_name=alert_data["metric_name"],
                current_value=alert_data["current_value"],
                threshold=alert_data["threshold"],
                labels=alert_data["labels"],
                resolved=alert_data["resolved"],
                resolved_at=datetime.fromisoformat(alert_data["resolved_at"]) if alert_data["resolved_at"] else None
            )
            
            # Verificar se alerta foi resolvido
            if alert.resolved:
                logger.info(f"Escalação {escalation_id} cancelada - alerta resolvido")
                return
            
            # Enviar notificações
            channels = [NotificationChannel(ch) for ch in rule_data["notification_channels"]]
            
            for channel in channels:
                await self._send_notification(alert, channel)
            
            # Atualizar contador de repetições
            escalation_data["repeat_count"] += 1
            escalation_data["executed"] = True
            escalation_data["last_executed"] = datetime.utcnow().isoformat()
            
            # Verificar se deve repetir
            rule = EscalationRule(
                alert_level=AlertLevel(rule_data["alert_level"]),
                escalation_level=EscalationLevel(rule_data["escalation_level"]),
                delay_minutes=rule_data["delay_minutes"],
                notification_channels=channels,
                repeat_interval_minutes=rule_data.get("repeat_interval_minutes"),
                max_repeats=rule_data.get("max_repeats")
            )
            
            if (rule.repeat_interval_minutes and 
                rule.max_repeats and 
                escalation_data["repeat_count"] < rule.max_repeats):
                
                # Agendar próxima repetição
                next_execution = datetime.utcnow() + timedelta(minutes=rule.repeat_interval_minutes)
                escalation_data["execution_time"] = next_execution.isoformat()
                escalation_data["executed"] = False
                
                # Atualizar no Redis
                await self.redis.setex(
                    f"escalation:{escalation_id}",
                    86400,
                    json.dumps(escalation_data)
                )
                
                # Reagendar
                await self.redis.zadd(
                    "escalation_queue",
                    {escalation_id: int(next_execution.timestamp())}
                )
                
                logger.info(f"Escalação {escalation_id} reagendada para {next_execution}")
            
            else:
                logger.info(f"Escalação {escalation_id} finalizada")
            
        except Exception as e:
            logger.error(f"Erro executando escalação {escalation_id}: {str(e)}")
    
    async def _send_notification(self, alert: Alert, channel: NotificationChannel):
        """Envia notificação para um canal específico."""
        
        try:
            # Verificar se canal está configurado e habilitado
            if channel not in self.notification_configs:
                logger.warning(f"Canal {channel.value} não configurado")
                return False
            
            config = self.notification_configs[channel]
            if not config.enabled:
                logger.info(f"Canal {channel.value} desabilitado")
                return False
            
            # Obter provedor
            provider = self.notification_providers.get(channel)
            if not provider:
                logger.error(f"Provedor não encontrado para canal {channel.value}")
                return False
            
            # Enviar notificação
            success = await provider.send_notification(alert, config.config)
            
            if success:
                logger.info(f"Notificação enviada via {channel.value} para alerta {alert.id}")
            else:
                logger.error(f"Falha enviando notificação via {channel.value} para alerta {alert.id}")
            
            return success
            
        except Exception as e:
            logger.error(f"Erro enviando notificação via {channel.value}: {str(e)}")
            return False
    
    async def _persist_alert_state(self, alert: Alert):
        """Persiste estado do alerta."""
        
        try:
            alert_data = asdict(alert)
            
            # Converter datetime para string
            alert_data["timestamp"] = alert.timestamp.isoformat()
            if alert_data["resolved_at"]:
                alert_data["resolved_at"] = alert.resolved_at.isoformat()
            
            # Armazenar no Redis
            await self.redis.setex(
                f"alert_state:{alert.id}",
                86400,  # 24 horas
                json.dumps(alert_data)
            )
            
        except Exception as e:
            logger.error(f"Erro persistindo estado do alerta {alert.id}: {str(e)}")
    
    async def start_escalation_processor(self):
        """Inicia processador de escalações."""
        
        if self.is_running:
            return
        
        self.is_running = True
        logger.info("Iniciando processador de escalações")
        
        while self.is_running:
            try:
                current_time = int(datetime.utcnow().timestamp())
                
                # Obter escalações prontas para execução
                ready_escalations = await self.redis.zrangebyscore(
                    "escalation_queue",
                    0,
                    current_time,
                    withscores=True
                )
                
                for escalation_id, score in ready_escalations:
                    # Remover da fila
                    await self.redis.zrem("escalation_queue", escalation_id)
                    
                    # Obter dados da escalação
                    escalation_data = await self.redis.get(f"escalation:{escalation_id}")
                    
                    if escalation_data:
                        escalation_dict = json.loads(escalation_data)
                        
                        # Executar escalação
                        await self._execute_escalation(escalation_id, escalation_dict)
                
                # Aguardar antes da próxima verificação
                await asyncio.sleep(30)  # Verificar a cada 30 segundos
                
            except Exception as e:
                logger.error(f"Erro no processador de escalações: {str(e)}")
                await asyncio.sleep(30)
    
    def stop_escalation_processor(self):
        """Para processador de escalações."""
        self.is_running = False
        logger.info("Parando processador de escalações")
    
    async def resolve_alert(self, alert_id: str):
        """
        Marca alerta como resolvido.
        
        Args:
            alert_id: ID do alerta a resolver
        """
        try:
            # Atualizar estado do alerta
            alert_state_key = f"alert_state:{alert_id}"
            alert_data = await self.redis.get(alert_state_key)
            
            if alert_data:
                alert_dict = json.loads(alert_data)
                alert_dict["resolved"] = True
                alert_dict["resolved_at"] = datetime.utcnow().isoformat()
                
                await self.redis.setex(
                    alert_state_key,
                    86400,
                    json.dumps(alert_dict)
                )
                
                logger.info(f"Alerta {alert_id} marcado como resolvido")
            
        except Exception as e:
            logger.error(f"Erro resolvendo alerta {alert_id}: {str(e)}")
    
    async def get_active_alerts(self) -> List[Dict[str, Any]]:
        """
        Obtém alertas ativos.
        
        Returns:
            Lista de alertas ativos
        """
        try:
            # Buscar todos os estados de alerta
            alert_keys = await self.redis.keys("alert_state:*")
            
            active_alerts = []
            
            for key in alert_keys:
                alert_data = await self.redis.get(key)
                if alert_data:
                    alert_dict = json.loads(alert_data)
                    
                    # Incluir apenas alertas não resolvidos
                    if not alert_dict.get("resolved", False):
                        active_alerts.append(alert_dict)
            
            return active_alerts
            
        except Exception as e:
            logger.error(f"Erro obtendo alertas ativos: {str(e)}")
            return []


# Instância global do serviço de alertas
_alerting_service: Optional[AlertingService] = None


def get_alerting_service(redis_client: redis.Redis) -> AlertingService:
    """
    Obtém instância do serviço de alertas.
    
    Args:
        redis_client: Cliente Redis
        
    Returns:
        AlertingService: Instância do serviço
    """
    global _alerting_service
    
    if _alerting_service is None:
        _alerting_service = AlertingService(redis_client)
    
    return _alerting_service