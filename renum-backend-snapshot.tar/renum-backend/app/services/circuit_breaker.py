"""
Circuit Breaker pattern implementation for agent executions.
Provides automatic failure detection, retry logic, and fallback strategies.
"""

import asyncio
import time
from typing import Dict, Any, Optional, Callable, Awaitable
from enum import Enum
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class CircuitState(str, Enum):
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Circuit is open, requests fail fast
    HALF_OPEN = "half_open"  # Testing if service is back

@dataclass
class CircuitBreakerConfig:
    """Configuração do Circuit Breaker"""
    failure_threshold: int = 5  # Número de falhas para abrir o circuito
    recovery_timeout: int = 60  # Tempo em segundos para tentar fechar
    success_threshold: int = 3  # Sucessos necessários para fechar no half-open
    timeout: float = 30.0  # Timeout para operações
    
class CircuitBreakerStats:
    """Estatísticas do Circuit Breaker"""
    
    def __init__(self):
        self.total_requests = 0
        self.successful_requests = 0
        self.failed_requests = 0
        self.circuit_open_count = 0
        self.last_failure_time: Optional[datetime] = None
        self.last_success_time: Optional[datetime] = None
        
    @property
    def failure_rate(self) -> float:
        if self.total_requests == 0:
            return 0.0
        return self.failed_requests / self.total_requests
    
    @property
    def success_rate(self) -> float:
        if self.total_requests == 0:
            return 0.0
        return self.successful_requests / self.total_requests

class CircuitBreaker:
    """
    Circuit Breaker para execuções de agentes.
    
    Implementa o padrão Circuit Breaker para prevenir cascata de falhas
    e permitir recuperação automática de serviços.
    """
    
    def __init__(self, name: str, config: CircuitBreakerConfig = None):
        self.name = name
        self.config = config or CircuitBreakerConfig()
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time: Optional[float] = None
        self.stats = CircuitBreakerStats()
        self._lock = asyncio.Lock()
        
    async def call(self, func: Callable[..., Awaitable[Any]], *args, **kwargs) -> Any:
        """
        Executa uma função através do circuit breaker.
        
        Args:
            func: Função assíncrona para executar
            *args: Argumentos posicionais
            **kwargs: Argumentos nomeados
            
        Returns:
            Resultado da função
            
        Raises:
            CircuitBreakerOpenError: Se o circuito estiver aberto
            TimeoutError: Se a operação exceder o timeout
            Exception: Qualquer exceção da função original
        """
        async with self._lock:
            self.stats.total_requests += 1
            
            # Verificar estado do circuito
            if self.state == CircuitState.OPEN:
                if self._should_attempt_reset():
                    self.state = CircuitState.HALF_OPEN
                    self.success_count = 0
                    logger.info(f"Circuit breaker {self.name} moved to HALF_OPEN")
                else:
                    self.stats.failed_requests += 1
                    raise CircuitBreakerOpenError(f"Circuit breaker {self.name} is OPEN")
        
        # Executar função com timeout
        try:
            result = await asyncio.wait_for(
                func(*args, **kwargs),
                timeout=self.config.timeout
            )
            await self._on_success()
            return result
            
        except asyncio.TimeoutError:
            await self._on_failure()
            raise TimeoutError(f"Operation timed out after {self.config.timeout}s")
            
        except Exception as e:
            await self._on_failure()
            raise
    
    async def _on_success(self):
        """Chamado quando uma operação é bem-sucedida"""
        async with self._lock:
            self.stats.successful_requests += 1
            self.stats.last_success_time = datetime.utcnow()
            
            if self.state == CircuitState.HALF_OPEN:
                self.success_count += 1
                if self.success_count >= self.config.success_threshold:
                    self._reset()
                    logger.info(f"Circuit breaker {self.name} CLOSED after recovery")
            else:
                self.failure_count = 0
    
    async def _on_failure(self):
        """Chamado quando uma operação falha"""
        async with self._lock:
            self.stats.failed_requests += 1
            self.stats.last_failure_time = datetime.utcnow()
            self.failure_count += 1
            self.last_failure_time = time.time()
            
            if self.failure_count >= self.config.failure_threshold:
                self.state = CircuitState.OPEN
                self.stats.circuit_open_count += 1
                logger.warning(f"Circuit breaker {self.name} OPENED after {self.failure_count} failures")
    
    def _should_attempt_reset(self) -> bool:
        """Verifica se deve tentar resetar o circuito"""
        if self.last_failure_time is None:
            return True
        return time.time() - self.last_failure_time >= self.config.recovery_timeout
    
    def _reset(self):
        """Reseta o circuit breaker para estado fechado"""
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time = None
    
    def get_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas do circuit breaker"""
        return {
            "name": self.name,
            "state": self.state.value,
            "failure_count": self.failure_count,
            "success_count": self.success_count,
            "total_requests": self.stats.total_requests,
            "successful_requests": self.stats.successful_requests,
            "failed_requests": self.stats.failed_requests,
            "failure_rate": self.stats.failure_rate,
            "success_rate": self.stats.success_rate,
            "circuit_open_count": self.stats.circuit_open_count,
            "last_failure_time": self.stats.last_failure_time.isoformat() if self.stats.last_failure_time else None,
            "last_success_time": self.stats.last_success_time.isoformat() if self.stats.last_success_time else None,
        }

class CircuitBreakerOpenError(Exception):
    """Exceção lançada quando o circuit breaker está aberto"""
    pass

class RetryConfig:
    """Configuração para retry automático"""
    
    def __init__(
        self,
        max_attempts: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        exponential_base: float = 2.0,
        jitter: bool = True
    ):
        self.max_attempts = max_attempts
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
        self.jitter = jitter

class RetryableCircuitBreaker(CircuitBreaker):
    """
    Circuit Breaker com retry automático e backoff exponencial.
    """
    
    def __init__(
        self,
        name: str,
        circuit_config: CircuitBreakerConfig = None,
        retry_config: RetryConfig = None
    ):
        super().__init__(name, circuit_config)
        self.retry_config = retry_config or RetryConfig()
    
    async def call_with_retry(
        self,
        func: Callable[..., Awaitable[Any]],
        *args,
        **kwargs
    ) -> Any:
        """
        Executa função com retry automático e backoff exponencial.
        """
        last_exception = None
        
        for attempt in range(self.retry_config.max_attempts):
            try:
                return await self.call(func, *args, **kwargs)
                
            except CircuitBreakerOpenError:
                # Não fazer retry se o circuito estiver aberto
                raise
                
            except Exception as e:
                last_exception = e
                
                if attempt < self.retry_config.max_attempts - 1:
                    delay = self._calculate_delay(attempt)
                    logger.warning(
                        f"Attempt {attempt + 1} failed for {self.name}, "
                        f"retrying in {delay:.2f}s: {str(e)}"
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.error(
                        f"All {self.retry_config.max_attempts} attempts failed for {self.name}"
                    )
        
        raise last_exception
    
    def _calculate_delay(self, attempt: int) -> float:
        """Calcula delay com backoff exponencial"""
        delay = self.retry_config.base_delay * (
            self.retry_config.exponential_base ** attempt
        )
        delay = min(delay, self.retry_config.max_delay)
        
        # Adicionar jitter para evitar thundering herd
        if self.retry_config.jitter:
            import random
            delay *= (0.5 + random.random() * 0.5)
        
        return delay

class CircuitBreakerManager:
    """
    Gerenciador de múltiplos circuit breakers.
    """
    
    def __init__(self):
        self.circuit_breakers: Dict[str, CircuitBreaker] = {}
    
    def get_circuit_breaker(
        self,
        name: str,
        config: CircuitBreakerConfig = None
    ) -> CircuitBreaker:
        """Obtém ou cria um circuit breaker"""
        if name not in self.circuit_breakers:
            self.circuit_breakers[name] = CircuitBreaker(name, config)
        return self.circuit_breakers[name]
    
    def get_retryable_circuit_breaker(
        self,
        name: str,
        circuit_config: CircuitBreakerConfig = None,
        retry_config: RetryConfig = None
    ) -> RetryableCircuitBreaker:
        """Obtém ou cria um circuit breaker com retry"""
        retry_name = f"{name}_retry"
        if retry_name not in self.circuit_breakers:
            self.circuit_breakers[retry_name] = RetryableCircuitBreaker(
                name, circuit_config, retry_config
            )
        return self.circuit_breakers[retry_name]
    
    def get_all_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas de todos os circuit breakers"""
        return {
            name: cb.get_stats()
            for name, cb in self.circuit_breakers.items()
        }
    
    def reset_all(self):
        """Reseta todos os circuit breakers"""
        for cb in self.circuit_breakers.values():
            cb._reset()
        logger.info("All circuit breakers have been reset")

# Instância global do gerenciador
circuit_breaker_manager = CircuitBreakerManager()

def get_circuit_breaker_manager() -> CircuitBreakerManager:
    """Obtém instância do gerenciador de circuit breakers"""
    return circuit_breaker_manager

# Decorador para facilitar uso
def circuit_breaker(
    name: str,
    config: CircuitBreakerConfig = None,
    retry_config: RetryConfig = None
):
    """
    Decorador para aplicar circuit breaker a funções.
    
    Usage:
        @circuit_breaker("agent_execution")
        async def execute_agent(agent_id: str):
            # função que pode falhar
            pass
    """
    def decorator(func: Callable[..., Awaitable[Any]]):
        async def wrapper(*args, **kwargs):
            manager = get_circuit_breaker_manager()
            
            if retry_config:
                cb = manager.get_retryable_circuit_breaker(name, config, retry_config)
                return await cb.call_with_retry(func, *args, **kwargs)
            else:
                cb = manager.get_circuit_breaker(name, config)
                return await cb.call(func, *args, **kwargs)
        
        return wrapper
    return decorator