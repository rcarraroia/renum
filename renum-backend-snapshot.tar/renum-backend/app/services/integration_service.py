"""
Serviço para gerenciamento de integrações de agentes.

Este módulo implementa a lógica de negócio para CRUD de integrações,
incluindo criação, listagem, atualização e exclusão de integrações.
"""

import logging
from typing import List, Optional, Dict, Any
from uuid import UUID, uuid4
from datetime import datetime

from app.models.integrations import (
    AgentIntegration,
    IntegrationStats,
    CreateIntegrationRequest,
    UpdateIntegrationRequest,
    IntegrationResponse,
    IntegrationStatus,
    IntegrationChannel
)
from app.services.webhook_service import WebhookTokenService
from app.core.supabase_client import SupabaseClient

# Configurar logger
logger = logging.getLogger(__name__)


class IntegrationService:
    """Serviço para gerenciamento de integrações."""
    
    def __init__(self):
        """Inicializa o serviço de integrações."""
        self.supabase = SupabaseClient.get_instance().client
        self.token_service = WebhookTokenService()
        
        logger.info("IntegrationService inicializado")
    
    async def create_integration(
        self,
        request: CreateIntegrationRequest,
        client_id: UUID,
        created_by: UUID
    ) -> IntegrationResponse:
        """
        Cria uma nova integração.
        
        Args:
            request: Dados da integração
            client_id: ID do cliente
            created_by: ID do usuário criador
            
        Returns:
            IntegrationResponse: Integração criada
            
        Raises:
            ValueError: Se dados inválidos
            Exception: Se erro na criação
        """
        try:
            # Gerar token único
            webhook_token = self.token_service.generate_webhook_token()
            
            # Preparar dados para inserção
            integration_data = {
                "id": str(uuid4()),
                "agent_id": str(request.agent_id),
                "client_id": str(client_id),
                "channel": request.channel.value,
                "webhook_token": webhook_token,
                "status": IntegrationStatus.ACTIVE.value,
                "rate_limit_per_minute": request.rate_limit_per_minute,
                "metadata": request.metadata,
                "created_by": str(created_by),
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
            
            # Inserir no banco
            result = self.supabase.table('renum_agent_integrations').insert(integration_data).execute()
            
            if not result.data:
                raise Exception("Falha ao criar integração")
            
            created_integration = result.data[0]
            
            # Construir URL do webhook
            webhook_url = f"https://api.renum.com/webhook/{request.agent_id}"
            
            # Preparar resposta
            response = IntegrationResponse(
                id=UUID(created_integration["id"]),
                agent_id=UUID(created_integration["agent_id"]),
                client_id=UUID(created_integration["client_id"]),
                channel=IntegrationChannel(created_integration["channel"]),
                webhook_token=created_integration["webhook_token"],
                webhook_url=webhook_url,
                status=IntegrationStatus(created_integration["status"]),
                rate_limit_per_minute=created_integration["rate_limit_per_minute"],
                metadata=created_integration["metadata"],
                created_at=datetime.fromisoformat(created_integration["created_at"]),
                updated_at=datetime.fromisoformat(created_integration["updated_at"]),
                created_by=UUID(created_integration["created_by"]) if created_integration["created_by"] else None
            )
            
            logger.info(f"Integração criada: {response.id} para agente {request.agent_id}")
            return response
            
        except Exception as e:
            logger.error(f"Erro ao criar integração: {e}")
            raise
    
    async def get_integration(
        self,
        integration_id: UUID,
        client_id: UUID
    ) -> Optional[IntegrationResponse]:
        """
        Obtém uma integração por ID.
        
        Args:
            integration_id: ID da integração
            client_id: ID do cliente (para verificação de acesso)
            
        Returns:
            IntegrationResponse ou None se não encontrada
        """
        try:
            result = self.supabase.table('renum_agent_integrations').select('*').eq(
                'id', str(integration_id)
            ).eq(
                'client_id', str(client_id)
            ).execute()
            
            if not result.data:
                return None
            
            integration_data = result.data[0]
            
            # Construir URL do webhook
            webhook_url = f"https://api.renum.com/webhook/{integration_data['agent_id']}"
            
            return IntegrationResponse(
                id=UUID(integration_data["id"]),
                agent_id=UUID(integration_data["agent_id"]),
                client_id=UUID(integration_data["client_id"]),
                channel=IntegrationChannel(integration_data["channel"]),
                webhook_token=integration_data["webhook_token"],
                webhook_url=webhook_url,
                status=IntegrationStatus(integration_data["status"]),
                rate_limit_per_minute=integration_data["rate_limit_per_minute"],
                metadata=integration_data["metadata"],
                created_at=datetime.fromisoformat(integration_data["created_at"]),
                updated_at=datetime.fromisoformat(integration_data["updated_at"]),
                created_by=UUID(integration_data["created_by"]) if integration_data["created_by"] else None
            )
            
        except Exception as e:
            logger.error(f"Erro ao obter integração {integration_id}: {e}")
            return None
    
    async def list_integrations(
        self,
        client_id: UUID,
        agent_id: Optional[UUID] = None,
        channel: Optional[IntegrationChannel] = None,
        status: Optional[IntegrationStatus] = None,
        limit: int = 50,
        offset: int = 0
    ) -> List[IntegrationResponse]:
        """
        Lista integrações do cliente.
        
        Args:
            client_id: ID do cliente
            agent_id: Filtrar por agente (opcional)
            channel: Filtrar por canal (opcional)
            status: Filtrar por status (opcional)
            limit: Limite de resultados
            offset: Offset para paginação
            
        Returns:
            Lista de integrações
        """
        try:
            query = self.supabase.table('renum_agent_integrations').select('*').eq(
                'client_id', str(client_id)
            )
            
            # Aplicar filtros opcionais
            if agent_id:
                query = query.eq('agent_id', str(agent_id))
            
            if channel:
                query = query.eq('channel', channel.value)
            
            if status:
                query = query.eq('status', status.value)
            
            # Aplicar paginação e ordenação
            query = query.order('created_at', desc=True).range(offset, offset + limit - 1)
            
            result = query.execute()
            
            integrations = []
            for integration_data in result.data:
                webhook_url = f"https://api.renum.com/webhook/{integration_data['agent_id']}"
                
                integration = IntegrationResponse(
                    id=UUID(integration_data["id"]),
                    agent_id=UUID(integration_data["agent_id"]),
                    client_id=UUID(integration_data["client_id"]),
                    channel=IntegrationChannel(integration_data["channel"]),
                    webhook_token=integration_data["webhook_token"],
                    webhook_url=webhook_url,
                    status=IntegrationStatus(integration_data["status"]),
                    rate_limit_per_minute=integration_data["rate_limit_per_minute"],
                    metadata=integration_data["metadata"],
                    created_at=datetime.fromisoformat(integration_data["created_at"]),
                    updated_at=datetime.fromisoformat(integration_data["updated_at"]),
                    created_by=UUID(integration_data["created_by"]) if integration_data["created_by"] else None
                )
                
                integrations.append(integration)
            
            logger.info(f"Listadas {len(integrations)} integrações para cliente {client_id}")
            return integrations
            
        except Exception as e:
            logger.error(f"Erro ao listar integrações: {e}")
            return []
    
    async def update_integration(
        self,
        integration_id: UUID,
        request: UpdateIntegrationRequest,
        client_id: UUID
    ) -> Optional[IntegrationResponse]:
        """
        Atualiza uma integração.
        
        Args:
            integration_id: ID da integração
            request: Dados de atualização
            client_id: ID do cliente (para verificação de acesso)
            
        Returns:
            IntegrationResponse atualizada ou None se não encontrada
        """
        try:
            # Preparar dados de atualização
            update_data = {
                "updated_at": datetime.now().isoformat()
            }
            
            if request.status is not None:
                update_data["status"] = request.status.value
            
            if request.rate_limit_per_minute is not None:
                update_data["rate_limit_per_minute"] = request.rate_limit_per_minute
            
            if request.metadata is not None:
                update_data["metadata"] = request.metadata
            
            # Atualizar no banco
            result = self.supabase.table('renum_agent_integrations').update(update_data).eq(
                'id', str(integration_id)
            ).eq(
                'client_id', str(client_id)
            ).execute()
            
            if not result.data:
                return None
            
            updated_integration = result.data[0]
            
            # Construir URL do webhook
            webhook_url = f"https://api.renum.com/webhook/{updated_integration['agent_id']}"
            
            response = IntegrationResponse(
                id=UUID(updated_integration["id"]),
                agent_id=UUID(updated_integration["agent_id"]),
                client_id=UUID(updated_integration["client_id"]),
                channel=IntegrationChannel(updated_integration["channel"]),
                webhook_token=updated_integration["webhook_token"],
                webhook_url=webhook_url,
                status=IntegrationStatus(updated_integration["status"]),
                rate_limit_per_minute=updated_integration["rate_limit_per_minute"],
                metadata=updated_integration["metadata"],
                created_at=datetime.fromisoformat(updated_integration["created_at"]),
                updated_at=datetime.fromisoformat(updated_integration["updated_at"]),
                created_by=UUID(updated_integration["created_by"]) if updated_integration["created_by"] else None
            )
            
            logger.info(f"Integração atualizada: {integration_id}")
            return response
            
        except Exception as e:
            logger.error(f"Erro ao atualizar integração {integration_id}: {e}")
            return None
    
    async def delete_integration(
        self,
        integration_id: UUID,
        client_id: UUID
    ) -> bool:
        """
        Exclui uma integração.
        
        Args:
            integration_id: ID da integração
            client_id: ID do cliente (para verificação de acesso)
            
        Returns:
            bool: True se excluída com sucesso
        """
        try:
            result = self.supabase.table('renum_agent_integrations').delete().eq(
                'id', str(integration_id)
            ).eq(
                'client_id', str(client_id)
            ).execute()
            
            success = len(result.data) > 0
            
            if success:
                logger.info(f"Integração excluída: {integration_id}")
            else:
                logger.warning(f"Integração não encontrada para exclusão: {integration_id}")
            
            return success
            
        except Exception as e:
            logger.error(f"Erro ao excluir integração {integration_id}: {e}")
            return False
    
    async def count_integrations(
        self,
        client_id: UUID,
        agent_id: Optional[UUID] = None,
        channel: Optional[IntegrationChannel] = None,
        status: Optional[IntegrationStatus] = None
    ) -> int:
        """
        Conta o número de integrações.
        
        Args:
            client_id: ID do cliente
            agent_id: Filtrar por agente (opcional)
            channel: Filtrar por canal (opcional)
            status: Filtrar por status (opcional)
            
        Returns:
            int: Número de integrações
        """
        try:
            query = self.supabase.table('renum_agent_integrations').select(
                'id', count='exact'
            ).eq('client_id', str(client_id))
            
            # Aplicar filtros opcionais
            if agent_id:
                query = query.eq('agent_id', str(agent_id))
            
            if channel:
                query = query.eq('channel', channel.value)
            
            if status:
                query = query.eq('status', status.value)
            
            result = query.execute()
            return result.count or 0
            
        except Exception as e:
            logger.error(f"Erro ao contar integrações: {e}")
            return 0
    
    async def get_integration_by_agent(
        self,
        agent_id: UUID,
        client_id: UUID,
        channel: Optional[IntegrationChannel] = None
    ) -> Optional[IntegrationResponse]:
        """
        Obtém integração por agente e canal.
        
        Args:
            agent_id: ID do agente
            client_id: ID do cliente
            channel: Canal específico (opcional)
            
        Returns:
            IntegrationResponse ou None
        """
        try:
            query = self.supabase.table('renum_agent_integrations').select('*').eq(
                'agent_id', str(agent_id)
            ).eq(
                'client_id', str(client_id)
            )
            
            if channel:
                query = query.eq('channel', channel.value)
            
            result = query.execute()
            
            if not result.data:
                return None
            
            # Retornar a primeira integração encontrada
            integration_data = result.data[0]
            webhook_url = f"https://api.renum.com/webhook/{integration_data['agent_id']}"
            
            return IntegrationResponse(
                id=UUID(integration_data["id"]),
                agent_id=UUID(integration_data["agent_id"]),
                client_id=UUID(integration_data["client_id"]),
                channel=IntegrationChannel(integration_data["channel"]),
                webhook_token=integration_data["webhook_token"],
                webhook_url=webhook_url,
                status=IntegrationStatus(integration_data["status"]),
                rate_limit_per_minute=integration_data["rate_limit_per_minute"],
                metadata=integration_data["metadata"],
                created_at=datetime.fromisoformat(integration_data["created_at"]),
                updated_at=datetime.fromisoformat(integration_data["updated_at"]),
                created_by=UUID(integration_data["created_by"]) if integration_data["created_by"] else None
            )
            
        except Exception as e:
            logger.error(f"Erro ao obter integração por agente {agent_id}: {e}")
            return None
    
    async def regenerate_token(
        self,
        integration_id: UUID,
        client_id: UUID
    ) -> Optional[IntegrationResponse]:
        """
        Regenera o token de uma integração.
        
        Args:
            integration_id: ID da integração
            client_id: ID do cliente (para verificação de acesso)
            
        Returns:
            IntegrationResponse com novo token ou None se não encontrada
        """
        try:
            # Gerar novo token
            new_token = self.token_service.generate_webhook_token()
            
            # Atualizar no banco
            update_data = {
                "webhook_token": new_token,
                "updated_at": datetime.now().isoformat()
            }
            
            result = self.supabase.table('renum_agent_integrations').update(update_data).eq(
                'id', str(integration_id)
            ).eq(
                'client_id', str(client_id)
            ).execute()
            
            if not result.data:
                return None
            
            updated_integration = result.data[0]
            webhook_url = f"https://api.renum.com/webhook/{updated_integration['agent_id']}"
            
            response = IntegrationResponse(
                id=UUID(updated_integration["id"]),
                agent_id=UUID(updated_integration["agent_id"]),
                client_id=UUID(updated_integration["client_id"]),
                channel=IntegrationChannel(updated_integration["channel"]),
                webhook_token=updated_integration["webhook_token"],
                webhook_url=webhook_url,
                status=IntegrationStatus(updated_integration["status"]),
                rate_limit_per_minute=updated_integration["rate_limit_per_minute"],
                metadata=updated_integration["metadata"],
                created_at=datetime.fromisoformat(updated_integration["created_at"]),
                updated_at=datetime.fromisoformat(updated_integration["updated_at"]),
                created_by=UUID(updated_integration["created_by"]) if updated_integration["created_by"] else None
            )
            
            logger.info(f"Token regenerado para integração: {integration_id}")
            return response
            
        except Exception as e:
            logger.error(f"Erro ao regenerar token da integração {integration_id}: {e}")
            return None
    
    async def test_integration(
        self,
        integration_id: UUID,
        client_id: UUID,
        test_payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Testa uma integração enviando um payload simulado.
        
        Args:
            integration_id: ID da integração
            client_id: ID do cliente
            test_payload: Payload de teste
            
        Returns:
            Dict com resultado do teste
        """
        try:
            # Obter integração
            integration = await self.get_integration(integration_id, client_id)
            
            if not integration:
                return {
                    "success": False,
                    "error": "Integração não encontrada"
                }
            
            if integration.status != IntegrationStatus.ACTIVE:
                return {
                    "success": False,
                    "error": "Integração não está ativa"
                }
            
            # TODO: Implementar teste real chamando o webhook
            # Por enquanto, simular resposta de sucesso
            test_result = {
                "success": True,
                "integration_id": str(integration_id),
                "agent_id": str(integration.agent_id),
                "channel": integration.channel.value,
                "test_payload": test_payload,
                "simulated_response": {
                    "message": "Teste simulado executado com sucesso",
                    "agent_response": "Esta é uma resposta simulada do agente",
                    "execution_time_ms": 125
                },
                "timestamp": datetime.now().isoformat()
            }
            
            logger.info(f"Teste de integração executado: {integration_id}")
            return test_result
            
        except Exception as e:
            logger.error(f"Erro ao testar integração {integration_id}: {e}")
            return {
                "success": False,
                "error": f"Erro interno: {str(e)}"
            }
    
    async def get_webhook_calls(
        self,
        integration_id: UUID,
        client_id: UUID,
        limit: int = 50,
        offset: int = 0,
        status_code: Optional[int] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> List[Dict[str, Any]]:
        """
        Obtém histórico de chamadas webhook de uma integração.
        
        Args:
            integration_id: ID da integração
            client_id: ID do cliente
            limit: Limite de resultados
            offset: Offset para paginação
            status_code: Filtrar por código de status (opcional)
            start_date: Data inicial (opcional)
            end_date: Data final (opcional)
            
        Returns:
            Lista de chamadas webhook
        """
        try:
            # Verificar se a integração pertence ao cliente
            integration = await self.get_integration(integration_id, client_id)
            if not integration:
                return []
            
            # Construir query
            query = self.supabase.table('renum_webhook_calls').select('*').eq(
                'integration_id', str(integration_id)
            )
            
            # Aplicar filtros opcionais
            if status_code:
                query = query.eq('status_code', status_code)
            
            if start_date:
                query = query.gte('created_at', start_date.isoformat())
            
            if end_date:
                query = query.lte('created_at', end_date.isoformat())
            
            # Aplicar paginação e ordenação
            query = query.order('created_at', desc=True).range(offset, offset + limit - 1)
            
            result = query.execute()
            
            calls = []
            for call_data in result.data:
                call = {
                    "id": call_data["id"],
                    "integration_id": call_data["integration_id"],
                    "status_code": call_data["status_code"],
                    "execution_time_ms": call_data["execution_time_ms"],
                    "ip_address": call_data["ip_address"],
                    "user_agent": call_data["user_agent"],
                    "error_message": call_data["error_message"],
                    "created_at": call_data["created_at"],
                    # Incluir payloads apenas se necessário (podem ser grandes)
                    "has_request_payload": call_data["request_payload"] is not None,
                    "has_response_payload": call_data["response_payload"] is not None
                }
                calls.append(call)
            
            logger.info(f"Obtidas {len(calls)} chamadas webhook para integração {integration_id}")
            return calls
            
        except Exception as e:
            logger.error(f"Erro ao obter chamadas webhook: {e}")
            return []
    
    async def get_integration_analytics(
        self,
        integration_id: UUID,
        client_id: UUID,
        period_hours: int = 24
    ) -> Dict[str, Any]:
        """
        Obtém analytics detalhados de uma integração.
        
        Args:
            integration_id: ID da integração
            client_id: ID do cliente
            period_hours: Período em horas
            
        Returns:
            Dict com analytics da integração
        """
        try:
            # Verificar se a integração pertence ao cliente
            integration = await self.get_integration(integration_id, client_id)
            if not integration:
                return {}
            
            # Obter estatísticas básicas via função do banco
            result = self.supabase.rpc('renum_get_integration_stats', {
                'p_integration_id': str(integration_id),
                'p_hours': period_hours
            }).execute()
            
            if not result.data or len(result.data) == 0:
                # Retornar analytics vazios
                return {
                    "integration_id": str(integration_id),
                    "period_hours": period_hours,
                    "total_calls": 0,
                    "successful_calls": 0,
                    "failed_calls": 0,
                    "success_rate": 0.0,
                    "error_rate": 0.0,
                    "avg_execution_time_ms": None,
                    "last_call_at": None,
                    "status_distribution": {},
                    "hourly_distribution": [],
                    "error_types": {}
                }
            
            stats_data = result.data[0]
            
            # Obter distribuição por status code
            status_query = self.supabase.table('renum_webhook_calls').select(
                'status_code'
            ).eq('integration_id', str(integration_id))
            
            if period_hours < 8760:  # Menos de 1 ano
                start_time = datetime.now() - timedelta(hours=period_hours)
                status_query = status_query.gte('created_at', start_time.isoformat())
            
            status_result = status_query.execute()
            
            # Calcular distribuição de status
            status_distribution = {}
            for call in status_result.data:
                status = call["status_code"]
                if status:
                    status_distribution[str(status)] = status_distribution.get(str(status), 0) + 1
            
            # Obter distribuição horária (últimas 24 horas)
            hourly_distribution = []
            if period_hours <= 24:
                for hour in range(24):
                    hour_start = datetime.now().replace(minute=0, second=0, microsecond=0) - timedelta(hours=hour)
                    hour_end = hour_start + timedelta(hours=1)
                    
                    hour_query = self.supabase.table('renum_webhook_calls').select(
                        'id', count='exact'
                    ).eq('integration_id', str(integration_id)).gte(
                        'created_at', hour_start.isoformat()
                    ).lt('created_at', hour_end.isoformat())
                    
                    hour_result = hour_query.execute()
                    
                    hourly_distribution.append({
                        "hour": hour_start.strftime("%H:00"),
                        "calls": hour_result.count or 0
                    })
            
            # Obter tipos de erro mais comuns
            error_query = self.supabase.table('renum_webhook_calls').select(
                'error_message'
            ).eq('integration_id', str(integration_id)).not_.is_('error_message', 'null')
            
            if period_hours < 8760:
                start_time = datetime.now() - timedelta(hours=period_hours)
                error_query = error_query.gte('created_at', start_time.isoformat())
            
            error_result = error_query.execute()
            
            error_types = {}
            for call in error_result.data:
                error_msg = call["error_message"]
                if error_msg:
                    # Simplificar mensagem de erro para agrupamento
                    error_key = error_msg[:50] + "..." if len(error_msg) > 50 else error_msg
                    error_types[error_key] = error_types.get(error_key, 0) + 1
            
            # Montar resposta completa
            analytics = {
                "integration_id": str(integration_id),
                "period_hours": period_hours,
                "total_calls": stats_data.get('total_calls', 0),
                "successful_calls": stats_data.get('successful_calls', 0),
                "failed_calls": stats_data.get('failed_calls', 0),
                "success_rate": float(stats_data.get('successful_calls', 0)) / max(stats_data.get('total_calls', 1), 1) * 100,
                "error_rate": float(stats_data.get('failed_calls', 0)) / max(stats_data.get('total_calls', 1), 1) * 100,
                "avg_execution_time_ms": float(stats_data['avg_execution_time_ms']) if stats_data.get('avg_execution_time_ms') else None,
                "last_call_at": stats_data.get('last_call_at'),
                "status_distribution": status_distribution,
                "hourly_distribution": hourly_distribution,
                "error_types": error_types,
                "generated_at": datetime.now().isoformat()
            }
            
            logger.info(f"Analytics gerados para integração {integration_id}")
            return analytics
            
        except Exception as e:
            logger.error(f"Erro ao obter analytics da integração {integration_id}: {e}")
            return {}
    
    async def get_client_analytics_summary(
        self,
        client_id: UUID,
        period_hours: int = 24
    ) -> Dict[str, Any]:
        """
        Obtém resumo de analytics de todas as integrações do cliente.
        
        Args:
            client_id: ID do cliente
            period_hours: Período em horas
            
        Returns:
            Dict com resumo de analytics
        """
        try:
            # Obter todas as integrações do cliente
            integrations = await self.list_integrations(client_id=client_id, limit=1000)
            
            if not integrations:
                return {
                    "client_id": str(client_id),
                    "period_hours": period_hours,
                    "total_integrations": 0,
                    "active_integrations": 0,
                    "total_calls": 0,
                    "successful_calls": 0,
                    "failed_calls": 0,
                    "success_rate": 0.0,
                    "avg_execution_time_ms": None,
                    "top_integrations": [],
                    "channel_distribution": {},
                    "generated_at": datetime.now().isoformat()
                }
            
            # Calcular estatísticas agregadas
            total_calls = 0
            successful_calls = 0
            failed_calls = 0
            execution_times = []
            integration_stats = []
            channel_distribution = {}
            
            for integration in integrations:
                # Contar por canal
                channel = integration.channel.value
                channel_distribution[channel] = channel_distribution.get(channel, 0) + 1
                
                # Obter estatísticas da integração
                stats_result = self.supabase.rpc('renum_get_integration_stats', {
                    'p_integration_id': str(integration.id),
                    'p_hours': period_hours
                }).execute()
                
                if stats_result.data and len(stats_result.data) > 0:
                    stats = stats_result.data[0]
                    
                    integration_total = stats.get('total_calls', 0)
                    integration_successful = stats.get('successful_calls', 0)
                    integration_failed = stats.get('failed_calls', 0)
                    integration_avg_time = stats.get('avg_execution_time_ms')
                    
                    total_calls += integration_total
                    successful_calls += integration_successful
                    failed_calls += integration_failed
                    
                    if integration_avg_time:
                        execution_times.append(float(integration_avg_time))
                    
                    integration_stats.append({
                        "integration_id": str(integration.id),
                        "agent_id": str(integration.agent_id),
                        "channel": channel,
                        "total_calls": integration_total,
                        "success_rate": float(integration_successful) / max(integration_total, 1) * 100
                    })
            
            # Calcular médias
            success_rate = float(successful_calls) / max(total_calls, 1) * 100
            avg_execution_time = sum(execution_times) / len(execution_times) if execution_times else None
            
            # Top 5 integrações por volume
            top_integrations = sorted(
                integration_stats,
                key=lambda x: x["total_calls"],
                reverse=True
            )[:5]
            
            summary = {
                "client_id": str(client_id),
                "period_hours": period_hours,
                "total_integrations": len(integrations),
                "active_integrations": len([i for i in integrations if i.status == IntegrationStatus.ACTIVE]),
                "total_calls": total_calls,
                "successful_calls": successful_calls,
                "failed_calls": failed_calls,
                "success_rate": success_rate,
                "avg_execution_time_ms": avg_execution_time,
                "top_integrations": top_integrations,
                "channel_distribution": channel_distribution,
                "generated_at": datetime.now().isoformat()
            }
            
            logger.info(f"Resumo de analytics gerado para cliente {client_id}")
            return summary
            
        except Exception as e:
            logger.error(f"Erro ao obter resumo de analytics do cliente {client_id}: {e}")
            return {}


# Instância singleton do serviço
_integration_service_instance = None

def get_integration_service() -> IntegrationService:
    """
    Obtém instância singleton do IntegrationService.
    
    Returns:
        IntegrationService: Instância do serviço
    """
    global _integration_service_instance
    
    if _integration_service_instance is None:
        _integration_service_instance = IntegrationService()
    
    return _integration_service_instance