"""
Serviço de coleta de métricas e alertas.

Este módulo implementa coleta automática de métricas, detecção de anomalias
e sistema de alertas para monitoramento proativo do sistema.
"""

import asyncio
import time
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Callable, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
from collections import deque, defaultdict

import psutil
import redis.asyncio as redis
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.models.integrations import Integration, WebhookCall
from app.core.database import get_async_session


# Configurar logger
logger = logging.getLogger(__name__)


class AlertLevel(Enum):
    """Níveis de alerta."""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


class MetricType(Enum):
    """Tipos de métrica."""
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    TIMER = "timer"


@dataclass
class Metric:
    """Estrutura de uma métrica."""
    name: str
    value: float
    metric_type: MetricType
    timestamp: datetime
    labels: Dict[str, str] = None
    
    def __post_init__(self):
        if self.labels is None:
            self.labels = {}


@dataclass
class Alert:
    """Estrutura de um alerta."""
    id: str
    name: str
    level: AlertLevel
    message: str
    timestamp: datetime
    metric_name: str
    current_value: float
    threshold: float
    labels: Dict[str, str] = None
    resolved: bool = False
    resolved_at: Optional[datetime] = None
    
    def __post_init__(self):
        if self.labels is None:
            self.labels = {}


class AlertRule:
    """Regra de alerta."""
    
    def __init__(
        self,
        name: str,
        metric_name: str,
        condition: Callable[[float], bool],
        threshold: float,
        level: AlertLevel,
        message_template: str,
        cooldown_seconds: int = 300  # 5 minutos
    ):
        self.name = name
        self.metric_name = metric_name
        self.condition = condition
        self.threshold = threshold
        self.level = level
        self.message_template = message_template
        self.cooldown_seconds = cooldown_seconds
        self.last_triggered = None
        self.active_alert = None


class MetricsCollector:
    """Coletor de métricas do sistema."""
    
    def __init__(self, redis_client: redis.Redis):
        """
        Inicializa o coletor de métricas.
        
        Args:
            redis_client: Cliente Redis para armazenamento
        """
        self.redis = redis_client
        self.metrics_buffer = deque(maxlen=1000)  # Buffer circular
        self.alert_rules = []
        self.active_alerts = {}
        self.metric_history = defaultdict(lambda: deque(maxlen=100))
        
        # Configurar regras de alerta padrão
        self._setup_default_alert_rules()
        
        # Estado do coletor
        self.is_running = False
        self.collection_interval = 30  # 30 segundos
        
    def _setup_default_alert_rules(self):
        """Configura regras de alerta padrão."""
        
        # Taxa de erro alta
        self.add_alert_rule(AlertRule(
            name="high_error_rate",
            metric_name="webhook_error_rate",
            condition=lambda x: x > 10,  # Mais de 10%
            threshold=10,
            level=AlertLevel.WARNING,
            message_template="Taxa de erro elevada: {value:.1f}% (limite: {threshold}%)"
        ))
        
        self.add_alert_rule(AlertRule(
            name="critical_error_rate",
            metric_name="webhook_error_rate",
            condition=lambda x: x > 20,  # Mais de 20%
            threshold=20,
            level=AlertLevel.CRITICAL,
            message_template="Taxa de erro crítica: {value:.1f}% (limite: {threshold}%)"
        ))
        
        # Tempo de resposta alto
        self.add_alert_rule(AlertRule(
            name="slow_response_time",
            metric_name="webhook_avg_response_time",
            condition=lambda x: x > 2000,  # Mais de 2 segundos
            threshold=2000,
            level=AlertLevel.WARNING,
            message_template="Tempo de resposta lento: {value:.0f}ms (limite: {threshold}ms)"
        ))
        
        self.add_alert_rule(AlertRule(
            name="critical_response_time",
            metric_name="webhook_avg_response_time",
            condition=lambda x: x > 5000,  # Mais de 5 segundos
            threshold=5000,
            level=AlertLevel.CRITICAL,
            message_template="Tempo de resposta crítico: {value:.0f}ms (limite: {threshold}ms)"
        ))
        
        # CPU alto
        self.add_alert_rule(AlertRule(
            name="high_cpu_usage",
            metric_name="system_cpu_percent",
            condition=lambda x: x > 80,
            threshold=80,
            level=AlertLevel.WARNING,
            message_template="Uso de CPU elevado: {value:.1f}% (limite: {threshold}%)"
        ))
        
        self.add_alert_rule(AlertRule(
            name="critical_cpu_usage",
            metric_name="system_cpu_percent",
            condition=lambda x: x > 90,
            threshold=90,
            level=AlertLevel.CRITICAL,
            message_template="Uso de CPU crítico: {value:.1f}% (limite: {threshold}%)"
        ))
        
        # Memória alta
        self.add_alert_rule(AlertRule(
            name="high_memory_usage",
            metric_name="system_memory_percent",
            condition=lambda x: x > 80,
            threshold=80,
            level=AlertLevel.WARNING,
            message_template="Uso de memória elevado: {value:.1f}% (limite: {threshold}%)"
        ))
        
        self.add_alert_rule(AlertRule(
            name="critical_memory_usage",
            metric_name="system_memory_percent",
            condition=lambda x: x > 90,
            threshold=90,
            level=AlertLevel.CRITICAL,
            message_template="Uso de memória crítico: {value:.1f}% (limite: {threshold}%)"
        ))
        
        # Redis desconectado
        self.add_alert_rule(AlertRule(
            name="redis_connection_failed",
            metric_name="redis_connection_status",
            condition=lambda x: x == 0,  # 0 = desconectado
            threshold=1,
            level=AlertLevel.CRITICAL,
            message_template="Conexão com Redis perdida"
        ))
    
    def add_alert_rule(self, rule: AlertRule):
        """
        Adiciona uma regra de alerta.
        
        Args:
            rule: Regra de alerta a ser adicionada
        """
        self.alert_rules.append(rule)
    
    async def collect_metrics(self) -> List[Metric]:
        """
        Coleta todas as métricas do sistema.
        
        Returns:
            Lista de métricas coletadas
        """
        metrics = []
        current_time = datetime.utcnow()
        
        try:
            # 1. Métricas do sistema
            system_metrics = await self._collect_system_metrics(current_time)
            metrics.extend(system_metrics)
            
            # 2. Métricas de webhook
            webhook_metrics = await self._collect_webhook_metrics(current_time)
            metrics.extend(webhook_metrics)
            
            # 3. Métricas de Redis
            redis_metrics = await self._collect_redis_metrics(current_time)
            metrics.extend(redis_metrics)
            
            # 4. Métricas de banco de dados
            db_metrics = await self._collect_database_metrics(current_time)
            metrics.extend(db_metrics)
            
            # Armazenar métricas no buffer
            for metric in metrics:
                self.metrics_buffer.append(metric)
                self.metric_history[metric.name].append((metric.timestamp, metric.value))
            
            # Persistir métricas no Redis
            await self._persist_metrics(metrics)
            
            logger.debug(f"Coletadas {len(metrics)} métricas")
            
        except Exception as e:
            logger.error(f"Erro na coleta de métricas: {str(e)}")
            
            # Métrica de erro
            error_metric = Metric(
                name="metrics_collection_errors",
                value=1,
                metric_type=MetricType.COUNTER,
                timestamp=current_time,
                labels={"error": str(e)}
            )
            metrics.append(error_metric)
        
        return metrics
    
    async def _collect_system_metrics(self, timestamp: datetime) -> List[Metric]:
        """Coleta métricas do sistema."""
        metrics = []
        
        try:
            # CPU
            cpu_percent = psutil.cpu_percent(interval=0.1)
            metrics.append(Metric(
                name="system_cpu_percent",
                value=cpu_percent,
                metric_type=MetricType.GAUGE,
                timestamp=timestamp
            ))
            
            # Memória
            memory_info = psutil.virtual_memory()
            metrics.extend([
                Metric(
                    name="system_memory_percent",
                    value=memory_info.percent,
                    metric_type=MetricType.GAUGE,
                    timestamp=timestamp
                ),
                Metric(
                    name="system_memory_used_bytes",
                    value=memory_info.used,
                    metric_type=MetricType.GAUGE,
                    timestamp=timestamp
                ),
                Metric(
                    name="system_memory_available_bytes",
                    value=memory_info.available,
                    metric_type=MetricType.GAUGE,
                    timestamp=timestamp
                )
            ])
            
            # Disco
            disk_info = psutil.disk_usage('/')
            metrics.extend([
                Metric(
                    name="system_disk_percent",
                    value=disk_info.percent,
                    metric_type=MetricType.GAUGE,
                    timestamp=timestamp
                ),
                Metric(
                    name="system_disk_free_bytes",
                    value=disk_info.free,
                    metric_type=MetricType.GAUGE,
                    timestamp=timestamp
                )
            ])
            
            # Rede
            network_info = psutil.net_io_counters()
            metrics.extend([
                Metric(
                    name="system_network_bytes_sent",
                    value=network_info.bytes_sent,
                    metric_type=MetricType.COUNTER,
                    timestamp=timestamp
                ),
                Metric(
                    name="system_network_bytes_recv",
                    value=network_info.bytes_recv,
                    metric_type=MetricType.COUNTER,
                    timestamp=timestamp
                )
            ])
            
        except Exception as e:
            logger.error(f"Erro coletando métricas do sistema: {str(e)}")
        
        return metrics
    
    async def _collect_webhook_metrics(self, timestamp: datetime) -> List[Metric]:
        """Coleta métricas de webhook."""
        metrics = []
        
        try:
            async with get_async_session() as session:
                # Período de análise (últimos 5 minutos)
                start_time = timestamp - timedelta(minutes=5)
                
                # Total de calls
                total_calls = await session.execute(
                    select(func.count(WebhookCall.id)).where(
                        WebhookCall.created_at >= start_time
                    )
                )
                
                total = total_calls.scalar() or 0
                
                metrics.append(Metric(
                    name="webhook_calls_total",
                    value=total,
                    metric_type=MetricType.COUNTER,
                    timestamp=timestamp
                ))
                
                if total > 0:
                    # Calls com sucesso
                    success_calls = await session.execute(
                        select(func.count(WebhookCall.id)).where(
                            WebhookCall.created_at >= start_time,
                            WebhookCall.status_code == 200
                        )
                    )
                    
                    success = success_calls.scalar() or 0
                    error_rate = ((total - success) / total * 100) if total > 0 else 0
                    success_rate = (success / total * 100) if total > 0 else 100
                    
                    metrics.extend([
                        Metric(
                            name="webhook_success_rate",
                            value=success_rate,
                            metric_type=MetricType.GAUGE,
                            timestamp=timestamp
                        ),
                        Metric(
                            name="webhook_error_rate",
                            value=error_rate,
                            metric_type=MetricType.GAUGE,
                            timestamp=timestamp
                        )
                    ])
                    
                    # Tempo médio de resposta
                    avg_time = await session.execute(
                        select(func.avg(WebhookCall.execution_time_ms)).where(
                            WebhookCall.created_at >= start_time,
                            WebhookCall.execution_time_ms.isnot(None)
                        )
                    )
                    
                    avg_response_time = avg_time.scalar() or 0
                    
                    metrics.append(Metric(
                        name="webhook_avg_response_time",
                        value=avg_response_time,
                        metric_type=MetricType.GAUGE,
                        timestamp=timestamp
                    ))
                    
                    # Métricas por status code
                    status_codes = await session.execute(
                        select(
                            WebhookCall.status_code,
                            func.count(WebhookCall.id).label('count')
                        ).where(
                            WebhookCall.created_at >= start_time
                        ).group_by(WebhookCall.status_code)
                    )
                    
                    for row in status_codes.fetchall():
                        metrics.append(Metric(
                            name="webhook_calls_by_status",
                            value=row.count,
                            metric_type=MetricType.COUNTER,
                            timestamp=timestamp,
                            labels={"status_code": str(row.status_code)}
                        ))
                
                # Integrações ativas
                active_integrations = await session.execute(
                    select(func.count(Integration.id)).where(
                        Integration.is_active == True
                    )
                )
                
                metrics.append(Metric(
                    name="integrations_active",
                    value=active_integrations.scalar() or 0,
                    metric_type=MetricType.GAUGE,
                    timestamp=timestamp
                ))
                
        except Exception as e:
            logger.error(f"Erro coletando métricas de webhook: {str(e)}")
        
        return metrics
    
    async def _collect_redis_metrics(self, timestamp: datetime) -> List[Metric]:
        """Coleta métricas do Redis."""
        metrics = []
        
        try:
            # Testar conectividade
            await self.redis.ping()
            
            metrics.append(Metric(
                name="redis_connection_status",
                value=1,  # 1 = conectado
                metric_type=MetricType.GAUGE,
                timestamp=timestamp
            ))
            
            # Informações do Redis
            redis_info = await self.redis.info()
            
            metrics.extend([
                Metric(
                    name="redis_used_memory_bytes",
                    value=redis_info.get("used_memory", 0),
                    metric_type=MetricType.GAUGE,
                    timestamp=timestamp
                ),
                Metric(
                    name="redis_connected_clients",
                    value=redis_info.get("connected_clients", 0),
                    metric_type=MetricType.GAUGE,
                    timestamp=timestamp
                ),
                Metric(
                    name="redis_total_commands_processed",
                    value=redis_info.get("total_commands_processed", 0),
                    metric_type=MetricType.COUNTER,
                    timestamp=timestamp
                ),
                Metric(
                    name="redis_keyspace_hits",
                    value=redis_info.get("keyspace_hits", 0),
                    metric_type=MetricType.COUNTER,
                    timestamp=timestamp
                ),
                Metric(
                    name="redis_keyspace_misses",
                    value=redis_info.get("keyspace_misses", 0),
                    metric_type=MetricType.COUNTER,
                    timestamp=timestamp
                )
            ])
            
        except Exception as e:
            logger.error(f"Erro coletando métricas do Redis: {str(e)}")
            
            # Redis desconectado
            metrics.append(Metric(
                name="redis_connection_status",
                value=0,  # 0 = desconectado
                metric_type=MetricType.GAUGE,
                timestamp=timestamp
            ))
        
        return metrics
    
    async def _collect_database_metrics(self, timestamp: datetime) -> List[Metric]:
        """Coleta métricas do banco de dados."""
        metrics = []
        
        try:
            async with get_async_session() as session:
                # Testar conectividade
                start_time = time.time()
                await session.execute(text("SELECT 1"))
                response_time = (time.time() - start_time) * 1000
                
                metrics.extend([
                    Metric(
                        name="database_connection_status",
                        value=1,  # 1 = conectado
                        metric_type=MetricType.GAUGE,
                        timestamp=timestamp
                    ),
                    Metric(
                        name="database_response_time_ms",
                        value=response_time,
                        metric_type=MetricType.GAUGE,
                        timestamp=timestamp
                    )
                ])
                
        except Exception as e:
            logger.error(f"Erro coletando métricas do banco: {str(e)}")
            
            metrics.append(Metric(
                name="database_connection_status",
                value=0,  # 0 = desconectado
                metric_type=MetricType.GAUGE,
                timestamp=timestamp
            ))
        
        return metrics
    
    async def _persist_metrics(self, metrics: List[Metric]):
        """Persiste métricas no Redis."""
        try:
            # Criar pipeline para eficiência
            pipe = self.redis.pipeline()
            
            for metric in metrics:
                # Chave para a métrica
                metric_key = f"metrics:{metric.name}"
                
                # Dados da métrica
                metric_data = {
                    "value": metric.value,
                    "type": metric.metric_type.value,
                    "timestamp": metric.timestamp.isoformat(),
                    "labels": json.dumps(metric.labels)
                }
                
                # Armazenar com TTL de 24 horas
                pipe.hset(f"{metric_key}:{int(metric.timestamp.timestamp())}", mapping=metric_data)
                pipe.expire(f"{metric_key}:{int(metric.timestamp.timestamp())}", 86400)
                
                # Manter lista das últimas 100 métricas
                pipe.zadd(f"{metric_key}:timeline", {
                    int(metric.timestamp.timestamp()): metric.value
                })
                pipe.zremrangebyrank(f"{metric_key}:timeline", 0, -101)  # Manter apenas 100
            
            await pipe.execute()
            
        except Exception as e:
            logger.error(f"Erro persistindo métricas: {str(e)}")
    
    async def check_alerts(self, metrics: List[Metric]) -> List[Alert]:
        """
        Verifica regras de alerta contra as métricas coletadas.
        
        Args:
            metrics: Lista de métricas para verificar
            
        Returns:
            Lista de alertas gerados
        """
        alerts = []
        current_time = datetime.utcnow()
        
        # Criar mapa de métricas por nome
        metrics_by_name = {metric.name: metric for metric in metrics}
        
        for rule in self.alert_rules:
            try:
                # Verificar se temos a métrica necessária
                if rule.metric_name not in metrics_by_name:
                    continue
                
                metric = metrics_by_name[rule.metric_name]
                
                # Verificar cooldown
                if (rule.last_triggered and 
                    (current_time - rule.last_triggered).total_seconds() < rule.cooldown_seconds):
                    continue
                
                # Verificar condição
                if rule.condition(metric.value):
                    # Gerar alerta
                    alert_id = f"{rule.name}_{int(current_time.timestamp())}"
                    
                    alert = Alert(
                        id=alert_id,
                        name=rule.name,
                        level=rule.level,
                        message=rule.message_template.format(
                            value=metric.value,
                            threshold=rule.threshold
                        ),
                        timestamp=current_time,
                        metric_name=rule.metric_name,
                        current_value=metric.value,
                        threshold=rule.threshold,
                        labels=metric.labels.copy()
                    )
                    
                    alerts.append(alert)
                    
                    # Atualizar estado da regra
                    rule.last_triggered = current_time
                    rule.active_alert = alert
                    
                    # Armazenar alerta ativo
                    self.active_alerts[alert_id] = alert
                    
                    logger.warning(f"Alerta gerado: {alert.name} - {alert.message}")
                
                else:
                    # Verificar se alerta ativo deve ser resolvido
                    if rule.active_alert and not rule.active_alert.resolved:
                        rule.active_alert.resolved = True
                        rule.active_alert.resolved_at = current_time
                        
                        logger.info(f"Alerta resolvido: {rule.active_alert.name}")
                        
                        # Remover dos alertas ativos
                        if rule.active_alert.id in self.active_alerts:
                            del self.active_alerts[rule.active_alert.id]
                        
                        rule.active_alert = None
                
            except Exception as e:
                logger.error(f"Erro verificando regra de alerta {rule.name}: {str(e)}")
        
        # Persistir alertas
        if alerts:
            await self._persist_alerts(alerts)
        
        return alerts
    
    async def _persist_alerts(self, alerts: List[Alert]):
        """Persiste alertas no Redis."""
        try:
            pipe = self.redis.pipeline()
            
            for alert in alerts:
                alert_key = f"alerts:{alert.id}"
                alert_data = asdict(alert)
                
                # Converter datetime para string
                alert_data["timestamp"] = alert.timestamp.isoformat()
                if alert_data["resolved_at"]:
                    alert_data["resolved_at"] = alert_data["resolved_at"].isoformat()
                
                # Converter labels para JSON
                alert_data["labels"] = json.dumps(alert_data["labels"])
                
                # Armazenar alerta com TTL de 7 dias
                pipe.hset(alert_key, mapping=alert_data)
                pipe.expire(alert_key, 604800)  # 7 dias
                
                # Adicionar à timeline de alertas
                pipe.zadd("alerts:timeline", {
                    alert.id: int(alert.timestamp.timestamp())
                })
            
            await pipe.execute()
            
        except Exception as e:
            logger.error(f"Erro persistindo alertas: {str(e)}")
    
    async def get_metrics_history(
        self,
        metric_name: str,
        start_time: datetime,
        end_time: datetime
    ) -> List[Tuple[datetime, float]]:
        """
        Obtém histórico de uma métrica.
        
        Args:
            metric_name: Nome da métrica
            start_time: Tempo de início
            end_time: Tempo de fim
            
        Returns:
            Lista de tuplas (timestamp, valor)
        """
        try:
            timeline_key = f"metrics:{metric_name}:timeline"
            
            # Obter dados do período
            start_ts = int(start_time.timestamp())
            end_ts = int(end_time.timestamp())
            
            results = await self.redis.zrangebyscore(
                timeline_key,
                start_ts,
                end_ts,
                withscores=True
            )
            
            return [
                (datetime.fromtimestamp(timestamp), value)
                for value, timestamp in results
            ]
            
        except Exception as e:
            logger.error(f"Erro obtendo histórico de métrica: {str(e)}")
            return []
    
    async def get_active_alerts(self) -> List[Alert]:
        """
        Obtém alertas ativos.
        
        Returns:
            Lista de alertas ativos
        """
        return list(self.active_alerts.values())
    
    async def start_collection(self):
        """Inicia coleta automática de métricas."""
        if self.is_running:
            return
        
        self.is_running = True
        logger.info("Iniciando coleta de métricas")
        
        while self.is_running:
            try:
                # Coletar métricas
                metrics = await self.collect_metrics()
                
                # Verificar alertas
                alerts = await self.check_alerts(metrics)
                
                if alerts:
                    logger.info(f"Gerados {len(alerts)} alertas")
                
                # Aguardar próxima coleta
                await asyncio.sleep(self.collection_interval)
                
            except Exception as e:
                logger.error(f"Erro no loop de coleta de métricas: {str(e)}")
                await asyncio.sleep(self.collection_interval)
    
    def stop_collection(self):
        """Para coleta automática de métricas."""
        self.is_running = False
        logger.info("Parando coleta de métricas")


# Instância global do coletor
_metrics_collector: Optional[MetricsCollector] = None


def get_metrics_collector(redis_client: redis.Redis) -> MetricsCollector:
    """
    Obtém instância do coletor de métricas.
    
    Args:
        redis_client: Cliente Redis
        
    Returns:
        MetricsCollector: Instância do coletor
    """
    global _metrics_collector
    
    if _metrics_collector is None:
        _metrics_collector = MetricsCollector(redis_client)
    
    return _metrics_collector