"""
Sistema de otimização de performance para execuções de equipes de agentes.
Inclui pool de conexões, cache inteligente e otimização de queries.
"""

import asyncio
import time
from typing import Dict, List, Optional, Any, Set
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from collections import defaultdict
import logging
import json
from contextlib import asynccontextmanager

import redis.asyncio as redis
from app.core.database import get_db_client

logger = logging.getLogger(__name__)

@dataclass
class PerformanceMetrics:
    """Métricas de performance"""
    execution_id: str
    start_time: datetime
    end_time: Optional[datetime] = None
    duration: Optional[float] = None
    agent_count: int = 0
    total_tokens: int = 0
    total_cost: float = 0.0
    cache_hits: int = 0
    cache_misses: int = 0
    db_queries: int = 0
    api_calls: int = 0
    memory_usage: float = 0.0
    cpu_usage: float = 0.0
    bottlenecks: List[str] = field(default_factory=list)

@dataclass
class ConnectionPoolStats:
    """Estatísticas do pool de conexões"""
    total_connections: int = 0
    active_connections: int = 0
    idle_connections: int = 0
    failed_connections: int = 0
    average_response_time: float = 0.0
    peak_usage: int = 0

class AgentConnectionPool:
    """Pool de conexões para agentes"""
    
    def __init__(self, max_connections: int = 50, timeout: float = 30.0):
        self.max_connections = max_connections
        self.timeout = timeout
        self.connections: Dict[str, List[Any]] = defaultdict(list)
        self.active_connections: Dict[str, Set[Any]] = defaultdict(set)
        self.connection_stats: Dict[str, ConnectionPoolStats] = defaultdict(ConnectionPoolStats)
        self._lock = asyncio.Lock()
    
    @asynccontextmanager
    async def get_connection(self, agent_type: str):
        """Obtém conexão do pool"""
        connection = None
        start_time = time.time()
        
        try:
            async with self._lock:
                # Tentar reutilizar conexão existente
                if self.connections[agent_type]:
                    connection = self.connections[agent_type].pop()
                    self.active_connections[agent_type].add(connection)
                    self.connection_stats[agent_type].cache_hits += 1
                else:
                    # Criar nova conexão se não exceder limite
                    total_active = sum(len(conns) for conns in self.active_connections.values())
                    if total_active < self.max_connections:
                        connection = await self._create_connection(agent_type)
                        self.active_connections[agent_type].add(connection)
                        self.connection_stats[agent_type].total_connections += 1
                    else:
                        # Aguardar conexão disponível
                        await self._wait_for_available_connection(agent_type)
                        connection = self.connections[agent_type].pop()
                        self.active_connections[agent_type].add(connection)
            
            # Atualizar estatísticas
            response_time = time.time() - start_time
            stats = self.connection_stats[agent_type]
            stats.active_connections = len(self.active_connections[agent_type])
            stats.idle_connections = len(self.connections[agent_type])
            stats.average_response_time = (stats.average_response_time + response_time) / 2
            stats.peak_usage = max(stats.peak_usage, stats.active_connections)
            
            yield connection
            
        except Exception as e:
            logger.error(f"Erro ao obter conexão para {agent_type}: {e}")
            self.connection_stats[agent_type].failed_connections += 1
            raise
        finally:
            # Retornar conexão ao pool
            if connection:
                async with self._lock:
                    self.active_connections[agent_type].discard(connection)
                    if await self._is_connection_healthy(connection):
                        self.connections[agent_type].append(connection)
                    else:
                        await self._close_connection(connection)
    
    async def _create_connection(self, agent_type: str) -> Any:
        """Cria nova conexão para o tipo de agente"""
        # Implementação específica para cada tipo de agente
        # Por enquanto, retorna um objeto mock
        return {
            "agent_type": agent_type,
            "created_at": datetime.utcnow(),
            "id": f"{agent_type}_{int(time.time())}"
        }
    
    async def _wait_for_available_connection(self, agent_type: str, max_wait: float = 10.0):
        """Aguarda conexão disponível"""
        start_time = time.time()
        while time.time() - start_time < max_wait:
            if self.connections[agent_type]:
                return
            await asyncio.sleep(0.1)
        raise TimeoutError(f"Timeout aguardando conexão para {agent_type}")
    
    async def _is_connection_healthy(self, connection: Any) -> bool:
        """Verifica se conexão está saudável"""
        try:
            # Implementar verificação de saúde específica
            return True
        except:
            return False
    
    async def _close_connection(self, connection: Any):
        """Fecha conexão"""
        try:
            # Implementar fechamento específico
            pass
        except Exception as e:
            logger.error(f"Erro ao fechar conexão: {e}")

class IntelligentCache:
    """Cache inteligente com TTL adaptativo e previsão"""
    
    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self.hit_rates: Dict[str, float] = {}
        self.access_patterns: Dict[str, List[datetime]] = defaultdict(list)
        self.adaptive_ttl: Dict[str, int] = {}
    
    async def get(self, key: str, default: Any = None) -> Any:
        """Obtém valor do cache"""
        try:
            # Registrar acesso
            self.access_patterns[key].append(datetime.utcnow())
            
            # Buscar no cache
            value = await self.redis.get(f"cache:{key}")
            
            if value is not None:
                # Cache hit
                self._update_hit_rate(key, True)
                return json.loads(value)
            else:
                # Cache miss
                self._update_hit_rate(key, False)
                return default
                
        except Exception as e:
            logger.error(f"Erro ao obter do cache {key}: {e}")
            return default
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Define valor no cache com TTL adaptativo"""
        try:
            # Calcular TTL adaptativo se não fornecido
            if ttl is None:
                ttl = self._calculate_adaptive_ttl(key)
            
            # Salvar no cache
            serialized_value = json.dumps(value, default=str)
            await self.redis.set(f"cache:{key}", serialized_value, ex=ttl)
            
            # Atualizar TTL adaptativo
            self.adaptive_ttl[key] = ttl
            
            return True
            
        except Exception as e:
            logger.error(f"Erro ao definir cache {key}: {e}")
            return False
    
    def _update_hit_rate(self, key: str, hit: bool):
        """Atualiza taxa de acerto do cache"""
        current_rate = self.hit_rates.get(key, 0.5)
        # Média móvel exponencial
        self.hit_rates[key] = current_rate * 0.9 + (1.0 if hit else 0.0) * 0.1
    
    def _calculate_adaptive_ttl(self, key: str) -> int:
        """Calcula TTL adaptativo baseado no padrão de acesso"""
        base_ttl = 3600  # 1 hora
        
        # Analisar padrão de acesso
        accesses = self.access_patterns.get(key, [])
        if len(accesses) < 2:
            return base_ttl
        
        # Calcular frequência de acesso
        recent_accesses = [a for a in accesses if a > datetime.utcnow() - timedelta(hours=1)]
        access_frequency = len(recent_accesses)
        
        # Ajustar TTL baseado na frequência
        if access_frequency > 10:
            # Acesso muito frequente - TTL maior
            return base_ttl * 2
        elif access_frequency > 5:
            # Acesso moderado - TTL normal
            return base_ttl
        else:
            # Acesso baixo - TTL menor
            return base_ttl // 2
    
    async def invalidate_pattern(self, pattern: str):
        """Invalida chaves que correspondem ao padrão"""
        try:
            keys = await self.redis.keys(f"cache:{pattern}")
            if keys:
                await self.redis.delete(*keys)
                logger.info(f"Invalidadas {len(keys)} chaves do cache com padrão {pattern}")
        except Exception as e:
            logger.error(f"Erro ao invalidar padrão {pattern}: {e}")

class QueryOptimizer:
    """Otimizador de queries do banco de dados"""
    
    def __init__(self):
        self.query_stats: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            "count": 0,
            "total_time": 0.0,
            "avg_time": 0.0,
            "slow_queries": []
        })
        self.slow_query_threshold = 1.0  # 1 segundo
    
    async def execute_optimized_query(self, query: str, params: Dict[str, Any] = None):
        """Executa query otimizada com monitoramento"""
        start_time = time.time()
        query_hash = hash(query)
        
        try:
            # Executar query (implementação específica do banco)
            result = await self._execute_query(query, params)
            
            # Registrar estatísticas
            execution_time = time.time() - start_time
            self._record_query_stats(query_hash, query, execution_time)
            
            return result
            
        except Exception as e:
            logger.error(f"Erro ao executar query: {e}")
            raise
    
    def _execute_query(self, query: str, params: Dict[str, Any] = None):
        """Executa query no banco (mock)"""
        # Implementação específica do banco de dados
        pass
    
    def _record_query_stats(self, query_hash: int, query: str, execution_time: float):
        """Registra estatísticas da query"""
        stats = self.query_stats[query_hash]
        stats["count"] += 1
        stats["total_time"] += execution_time
        stats["avg_time"] = stats["total_time"] / stats["count"]
        
        # Registrar queries lentas
        if execution_time > self.slow_query_threshold:
            stats["slow_queries"].append({
                "query": query[:200],  # Primeiros 200 caracteres
                "execution_time": execution_time,
                "timestamp": datetime.utcnow().isoformat()
            })
            
            # Manter apenas as 10 queries mais lentas
            stats["slow_queries"] = sorted(
                stats["slow_queries"],
                key=lambda x: x["execution_time"],
                reverse=True
            )[:10]
    
    def get_performance_report(self) -> Dict[str, Any]:
        """Gera relatório de performance das queries"""
        total_queries = sum(stats["count"] for stats in self.query_stats.values())
        slow_queries = []
        
        for query_hash, stats in self.query_stats.items():
            slow_queries.extend(stats["slow_queries"])
        
        return {
            "total_queries": total_queries,
            "unique_queries": len(self.query_stats),
            "slow_queries_count": len(slow_queries),
            "slowest_queries": sorted(slow_queries, key=lambda x: x["execution_time"], reverse=True)[:5],
            "average_query_time": sum(stats["avg_time"] for stats in self.query_stats.values()) / len(self.query_stats) if self.query_stats else 0
        }

class PerformanceOptimizer:
    """Sistema principal de otimização de performance"""
    
    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self.connection_pool = AgentConnectionPool()
        self.cache = IntelligentCache(redis_client)
        self.query_optimizer = QueryOptimizer()
        self.metrics: Dict[str, PerformanceMetrics] = {}
    
    async def start_execution_monitoring(self, execution_id: str, agent_count: int) -> PerformanceMetrics:
        """Inicia monitoramento de performance para uma execução"""
        metrics = PerformanceMetrics(
            execution_id=execution_id,
            start_time=datetime.utcnow(),
            agent_count=agent_count
        )
        
        self.metrics[execution_id] = metrics
        
        # Salvar no Redis para persistência
        await self._save_metrics(metrics)
        
        logger.info(f"Iniciado monitoramento de performance para execução {execution_id}")
        return metrics
    
    async def end_execution_monitoring(self, execution_id: str) -> Optional[PerformanceMetrics]:
        """Finaliza monitoramento de performance"""
        metrics = self.metrics.get(execution_id)
        if not metrics:
            return None
        
        metrics.end_time = datetime.utcnow()
        metrics.duration = (metrics.end_time - metrics.start_time).total_seconds()
        
        # Identificar gargalos
        await self._identify_bottlenecks(metrics)
        
        # Salvar métricas finais
        await self._save_metrics(metrics)
        
        # Gerar recomendações de otimização
        recommendations = await self._generate_optimization_recommendations(metrics)
        
        logger.info(f"Finalizado monitoramento para execução {execution_id}. Duração: {metrics.duration}s")
        
        return metrics
    
    async def _identify_bottlenecks(self, metrics: PerformanceMetrics):
        """Identifica gargalos de performance"""
        bottlenecks = []
        
        # Verificar duração excessiva
        if metrics.duration and metrics.duration > 300:  # > 5 minutos
            bottlenecks.append("long_execution_time")
        
        # Verificar baixa taxa de cache
        cache_hit_rate = metrics.cache_hits / (metrics.cache_hits + metrics.cache_misses) if (metrics.cache_hits + metrics.cache_misses) > 0 else 0
        if cache_hit_rate < 0.5:
            bottlenecks.append("low_cache_hit_rate")
        
        # Verificar muitas queries de banco
        if metrics.db_queries > metrics.agent_count * 10:
            bottlenecks.append("excessive_db_queries")
        
        # Verificar muitas chamadas de API
        if metrics.api_calls > metrics.agent_count * 20:
            bottlenecks.append("excessive_api_calls")
        
        # Verificar uso de memória
        if metrics.memory_usage > 1000:  # > 1GB
            bottlenecks.append("high_memory_usage")
        
        # Verificar uso de CPU
        if metrics.cpu_usage > 80:  # > 80%
            bottlenecks.append("high_cpu_usage")
        
        metrics.bottlenecks = bottlenecks
    
    async def _generate_optimization_recommendations(self, metrics: PerformanceMetrics) -> List[str]:
        """Gera recomendações de otimização"""
        recommendations = []
        
        for bottleneck in metrics.bottlenecks:
            if bottleneck == "long_execution_time":
                recommendations.append("Considere usar estratégia paralela para reduzir tempo de execução")
            elif bottleneck == "low_cache_hit_rate":
                recommendations.append("Implemente cache mais agressivo para dados frequentemente acessados")
            elif bottleneck == "excessive_db_queries":
                recommendations.append("Otimize queries do banco ou implemente batch processing")
            elif bottleneck == "excessive_api_calls":
                recommendations.append("Implemente rate limiting e cache para chamadas de API")
            elif bottleneck == "high_memory_usage":
                recommendations.append("Otimize uso de memória ou aumente recursos disponíveis")
            elif bottleneck == "high_cpu_usage":
                recommendations.append("Distribua carga entre mais workers ou otimize algoritmos")
        
        return recommendations
    
    async def _save_metrics(self, metrics: PerformanceMetrics):
        """Salva métricas no Redis"""
        try:
            key = f"performance_metrics:{metrics.execution_id}"
            data = {
                "execution_id": metrics.execution_id,
                "start_time": metrics.start_time.isoformat(),
                "end_time": metrics.end_time.isoformat() if metrics.end_time else None,
                "duration": metrics.duration,
                "agent_count": metrics.agent_count,
                "total_tokens": metrics.total_tokens,
                "total_cost": metrics.total_cost,
                "cache_hits": metrics.cache_hits,
                "cache_misses": metrics.cache_misses,
                "db_queries": metrics.db_queries,
                "api_calls": metrics.api_calls,
                "memory_usage": metrics.memory_usage,
                "cpu_usage": metrics.cpu_usage,
                "bottlenecks": metrics.bottlenecks
            }
            
            await self.redis.set(key, json.dumps(data), ex=86400 * 7)  # 7 dias
            
        except Exception as e:
            logger.error(f"Erro ao salvar métricas: {e}")
    
    async def get_performance_summary(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """Obtém resumo de performance"""
        try:
            key = f"performance_metrics:{execution_id}"
            data = await self.redis.get(key)
            
            if not data:
                return None
            
            metrics_data = json.loads(data)
            
            # Adicionar estatísticas do pool de conexões
            connection_stats = {}
            for agent_type, stats in self.connection_pool.connection_stats.items():
                connection_stats[agent_type] = {
                    "total_connections": stats.total_connections,
                    "active_connections": stats.active_connections,
                    "idle_connections": stats.idle_connections,
                    "failed_connections": stats.failed_connections,
                    "average_response_time": stats.average_response_time,
                    "peak_usage": stats.peak_usage
                }
            
            # Adicionar estatísticas de queries
            query_stats = self.query_optimizer.get_performance_report()
            
            return {
                "metrics": metrics_data,
                "connection_stats": connection_stats,
                "query_stats": query_stats,
                "cache_stats": {
                    "hit_rates": dict(self.cache.hit_rates),
                    "adaptive_ttls": dict(self.cache.adaptive_ttl)
                }
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter resumo de performance: {e}")
            return None
    
    async def cleanup_old_metrics(self, days: int = 7):
        """Limpa métricas antigas"""
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            # Buscar chaves de métricas antigas
            pattern = "performance_metrics:*"
            keys = await self.redis.keys(pattern)
            
            deleted_count = 0
            for key in keys:
                data = await self.redis.get(key)
                if data:
                    metrics_data = json.loads(data)
                    start_time = datetime.fromisoformat(metrics_data["start_time"])
                    
                    if start_time < cutoff_date:
                        await self.redis.delete(key)
                        deleted_count += 1
            
            logger.info(f"Limpas {deleted_count} métricas antigas (> {days} dias)")
            
        except Exception as e:
            logger.error(f"Erro ao limpar métricas antigas: {e}")

# Instância global do otimizador
performance_optimizer: Optional[PerformanceOptimizer] = None

def get_performance_optimizer() -> PerformanceOptimizer:
    """Obtém instância do otimizador de performance"""
    global performance_optimizer
    if performance_optimizer is None:
        # Criar cliente Redis simples para teste
        redis_client = redis.Redis.from_url("redis://localhost:6379", decode_responses=True)
        performance_optimizer = PerformanceOptimizer(redis_client)
    return performance_optimizer