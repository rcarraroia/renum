"""
Serviço de proxy HTTP para comunicação com o Suna Backend.

Este módulo implementa o proxy unificado que redireciona todas as requisições
dos frontends para o suna-backend, mantendo a arquitetura de proxy única.
"""

import logging
import httpx
import json
from typing import Dict, Any, Optional, Union
from fastapi import Request, Response, HTTPException
from fastapi.responses import StreamingResponse
import asyncio
from urllib.parse import urljoin, urlparse

from app.core.config import get_settings

logger = logging.getLogger(__name__)

class SunaProxyService:
    """Serviço de proxy para o Suna Backend."""
    
    def __init__(self):
        """Inicializa o serviço de proxy."""
        self.settings = get_settings()
        self.suna_base_url = self.settings.SUNA_API_URL
        self.timeout = 60.0
        self.max_retries = 3
        self.retry_delay = 1.0
        
        logger.info(f"Suna Proxy Service inicializado - URL: {self.suna_base_url}")
    
    def _get_suna_url(self, path: str) -> str:
        """
        Constrói a URL completa para o suna-backend.
        
        Args:
            path: Caminho da requisição
            
        Returns:
            URL completa para o suna-backend
        """
        # Remove o prefixo /api/v1 se existir, pois o suna-backend pode ter estrutura diferente
        if path.startswith('/api/v1'):
            path = path[7:]  # Remove '/api/v1'
        
        # Garante que o path comece com /
        if not path.startswith('/'):
            path = '/' + path
            
        return urljoin(self.suna_base_url, path)
    
    def _prepare_headers(self, original_headers: Dict[str, str], user_data: Optional[Dict] = None) -> Dict[str, str]:
        """
        Prepara os headers para a requisição ao suna-backend.
        
        Args:
            original_headers: Headers originais da requisição
            user_data: Dados do usuário autenticado
            
        Returns:
            Headers preparados para o suna-backend
        """
        # Headers que devem ser repassados
        allowed_headers = {
            'content-type', 'accept', 'accept-encoding', 'accept-language',
            'user-agent', 'x-forwarded-for', 'x-real-ip'
        }
        
        # Filtra apenas headers permitidos
        filtered_headers = {
            key: value for key, value in original_headers.items()
            if key.lower() in allowed_headers
        }
        
        # Adiciona informações do usuário autenticado se disponível
        if user_data:
            filtered_headers['X-User-ID'] = str(user_data.get('id', ''))
            filtered_headers['X-User-Email'] = str(user_data.get('email', ''))
            filtered_headers['X-User-Role'] = str(user_data.get('role', 'user'))
        
        # Adiciona header de identificação do proxy
        filtered_headers['X-Proxy-Source'] = 'renum-backend'
        
        return filtered_headers
    
    async def _make_request(
        self, 
        method: str, 
        url: str, 
        headers: Dict[str, str],
        data: Optional[bytes] = None,
        params: Optional[Dict[str, str]] = None
    ) -> httpx.Response:
        """
        Faz a requisição HTTP para o suna-backend com retry.
        
        Args:
            method: Método HTTP
            url: URL de destino
            headers: Headers da requisição
            data: Dados do corpo da requisição
            params: Parâmetros de query
            
        Returns:
            Resposta do suna-backend
            
        Raises:
            HTTPException: Se a requisição falhar após todas as tentativas
        """
        last_exception = None
        
        for attempt in range(self.max_retries):
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    response = await client.request(
                        method=method,
                        url=url,
                        headers=headers,
                        content=data,
                        params=params
                    )
                    return response
                    
            except httpx.TimeoutException as e:
                last_exception = e
                logger.warning(f"Timeout na tentativa {attempt + 1} para {url}: {str(e)}")
                
            except httpx.ConnectError as e:
                last_exception = e
                logger.warning(f"Erro de conexão na tentativa {attempt + 1} para {url}: {str(e)}")
                
            except Exception as e:
                last_exception = e
                logger.error(f"Erro inesperado na tentativa {attempt + 1} para {url}: {str(e)}")
            
            # Aguarda antes da próxima tentativa (exceto na última)
            if attempt < self.max_retries - 1:
                await asyncio.sleep(self.retry_delay * (attempt + 1))
        
        # Se chegou aqui, todas as tentativas falharam
        logger.error(f"Falha ao conectar com suna-backend após {self.max_retries} tentativas: {str(last_exception)}")
        raise HTTPException(
            status_code=503,
            detail=f"Serviço temporariamente indisponível. Erro: {str(last_exception)}"
        )
    
    async def forward_request(
        self, 
        request: Request, 
        user_data: Optional[Dict] = None
    ) -> Response:
        """
        Encaminha uma requisição HTTP para o suna-backend.
        
        Args:
            request: Requisição FastAPI original
            user_data: Dados do usuário autenticado
            
        Returns:
            Resposta do suna-backend
        """
        try:
            # Constrói a URL de destino
            target_url = self._get_suna_url(request.url.path)
            
            # Prepara os headers
            headers = self._prepare_headers(dict(request.headers), user_data)
            
            # Lê o corpo da requisição
            body = await request.body()
            
            # Prepara os parâmetros de query
            params = dict(request.query_params) if request.query_params else None
            
            logger.info(f"Proxy: {request.method} {request.url.path} -> {target_url}")
            
            # Faz a requisição para o suna-backend
            suna_response = await self._make_request(
                method=request.method,
                url=target_url,
                headers=headers,
                data=body if body else None,
                params=params
            )
            
            # Prepara a resposta
            response_headers = dict(suna_response.headers)
            
            # Remove headers que podem causar problemas
            headers_to_remove = ['content-encoding', 'transfer-encoding', 'connection']
            for header in headers_to_remove:
                response_headers.pop(header, None)
            
            # Cria a resposta
            response = Response(
                content=suna_response.content,
                status_code=suna_response.status_code,
                headers=response_headers,
                media_type=response_headers.get('content-type')
            )
            
            logger.info(f"Proxy response: {suna_response.status_code} para {request.url.path}")
            return response
            
        except HTTPException:
            # Re-raise HTTPExceptions
            raise
            
        except Exception as e:
            logger.error(f"Erro no proxy para {request.url.path}: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Erro interno do proxy: {str(e)}"
            )
    
    async def forward_streaming_request(
        self, 
        request: Request, 
        user_data: Optional[Dict] = None
    ) -> StreamingResponse:
        """
        Encaminha uma requisição com resposta em streaming para o suna-backend.
        
        Args:
            request: Requisição FastAPI original
            user_data: Dados do usuário autenticado
            
        Returns:
            Resposta em streaming do suna-backend
        """
        try:
            # Constrói a URL de destino
            target_url = self._get_suna_url(request.url.path)
            
            # Prepara os headers
            headers = self._prepare_headers(dict(request.headers), user_data)
            
            # Lê o corpo da requisição
            body = await request.body()
            
            # Prepara os parâmetros de query
            params = dict(request.query_params) if request.query_params else None
            
            logger.info(f"Streaming Proxy: {request.method} {request.url.path} -> {target_url}")
            
            async def generate_response():
                """Gerador para resposta em streaming."""
                try:
                    async with httpx.AsyncClient(timeout=self.timeout) as client:
                        async with client.stream(
                            method=request.method,
                            url=target_url,
                            headers=headers,
                            content=body if body else None,
                            params=params
                        ) as suna_response:
                            async for chunk in suna_response.aiter_bytes():
                                yield chunk
                                
                except Exception as e:
                    logger.error(f"Erro no streaming proxy: {str(e)}")
                    # Em caso de erro, retorna uma mensagem de erro em JSON
                    error_response = json.dumps({
                        "error": "Streaming proxy error",
                        "detail": str(e)
                    }).encode()
                    yield error_response
            
            return StreamingResponse(
                generate_response(),
                media_type="application/json"
            )
            
        except Exception as e:
            logger.error(f"Erro no streaming proxy para {request.url.path}: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Erro interno do streaming proxy: {str(e)}"
            )
    
    async def proxy_websocket(
        self,
        client_websocket,
        path: str,
        query_params: Optional[Dict[str, str]] = None,
        user_data: Optional[Dict] = None
    ):
        """
        Proxy WebSocket para o suna-backend.
        
        Args:
            client_websocket: WebSocket do cliente
            path: Caminho do WebSocket
            query_params: Parâmetros de query
            user_data: Dados do usuário autenticado
        """
        import websockets
        from websockets.exceptions import ConnectionClosed, WebSocketException
        
        try:
            # Constrói a URL WebSocket do suna-backend
            suna_ws_url = self.suna_base_url.replace('http://', 'ws://').replace('https://', 'wss://')
            
            # Remove o prefixo /api/v1 se existir
            if path.startswith('/api/v1'):
                path = path[7:]
            
            # Garante que o path comece com /
            if not path.startswith('/'):
                path = '/' + path
                
            target_url = f"{suna_ws_url}{path}"
            
            # Adiciona parâmetros de query se fornecidos
            if query_params:
                query_string = "&".join([f"{k}={v}" for k, v in query_params.items()])
                target_url = f"{target_url}?{query_string}"
            
            logger.info(f"WebSocket Proxy: {path} -> {target_url}")
            
            # Conecta ao suna-backend WebSocket
            async with websockets.connect(
                target_url,
                timeout=self.timeout,
                extra_headers=self._prepare_websocket_headers(user_data)
            ) as suna_websocket:
                
                # Função para encaminhar mensagens do cliente para o suna-backend
                async def forward_client_to_suna():
                    try:
                        async for message in client_websocket.iter_text():
                            await suna_websocket.send(message)
                    except Exception as e:
                        logger.error(f"Erro ao encaminhar mensagem do cliente: {str(e)}")
                
                # Função para encaminhar mensagens do suna-backend para o cliente
                async def forward_suna_to_client():
                    try:
                        async for message in suna_websocket:
                            await client_websocket.send_text(message)
                    except Exception as e:
                        logger.error(f"Erro ao encaminhar mensagem do suna: {str(e)}")
                
                # Executa ambas as direções simultaneamente
                await asyncio.gather(
                    forward_client_to_suna(),
                    forward_suna_to_client(),
                    return_exceptions=True
                )
                
        except ConnectionClosed:
            logger.info("Conexão WebSocket fechada")
        except WebSocketException as e:
            logger.error(f"Erro WebSocket: {str(e)}")
            if client_websocket.client_state.CONNECTED:
                await client_websocket.close(code=1011, reason=f"Proxy error: {str(e)}")
        except Exception as e:
            logger.error(f"Erro no proxy WebSocket: {str(e)}")
            if client_websocket.client_state.CONNECTED:
                await client_websocket.close(code=1011, reason=f"Internal proxy error: {str(e)}")
    
    def _prepare_websocket_headers(self, user_data: Optional[Dict] = None) -> Dict[str, str]:
        """
        Prepara os headers para conexão WebSocket com o suna-backend.
        
        Args:
            user_data: Dados do usuário autenticado
            
        Returns:
            Headers para a conexão WebSocket
        """
        headers = {
            'X-Proxy-Source': 'renum-backend'
        }
        
        # Adiciona informações do usuário se disponível
        if user_data:
            headers['X-User-ID'] = str(user_data.get('id', ''))
            headers['X-User-Email'] = str(user_data.get('email', ''))
            headers['X-User-Role'] = str(user_data.get('role', 'user'))
        
        return headers

    async def health_check(self) -> Dict[str, Any]:
        """
        Verifica a saúde da conexão com o suna-backend.
        
        Returns:
            Status da conexão com o suna-backend
        """
        try:
            health_url = urljoin(self.suna_base_url, "/health")
            
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(health_url)
                
                return {
                    "suna_backend_status": "healthy" if response.status_code == 200 else "unhealthy",
                    "suna_backend_url": self.suna_base_url,
                    "response_time_ms": response.elapsed.total_seconds() * 1000,
                    "status_code": response.status_code
                }
                
        except Exception as e:
            logger.error(f"Erro no health check do suna-backend: {str(e)}")
            return {
                "suna_backend_status": "unhealthy",
                "suna_backend_url": self.suna_base_url,
                "error": str(e)
            }


# Instância global do serviço de proxy
suna_proxy_service = SunaProxyService()