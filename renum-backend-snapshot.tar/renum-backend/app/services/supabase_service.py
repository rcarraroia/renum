"""
Serviço de integração com Supabase para o Renum Backend.

Este módulo fornece funcionalidades para interagir com o Supabase,
incluindo autenticação, gerenciamento de usuários e operações de banco de dados.
"""

import logging
from typing import Dict, Any, Optional, List
from supabase import create_client, Client
import jwt
from datetime import datetime, timezone

from app.core.config import get_settings

logger = logging.getLogger(__name__)

class SupabaseService:
    """Serviço para integração com Supabase."""
    
    def __init__(self):
        """Inicializa o serviço Supabase."""
        self.settings = get_settings()
        self._client: Optional[Client] = None
        self._admin_client: Optional[Client] = None
        
    @property
    def client(self) -> Client:
        """
        Obtém o cliente Supabase (anônimo).
        
        Returns:
            Cliente Supabase configurado
        """
        if not self._client:
            try:
                self._client = create_client(
                    self.settings.SUPABASE_URL,
                    self.settings.SUPABASE_KEY
                )
                logger.info("Cliente Supabase inicializado com sucesso")
            except Exception as e:
                logger.error(f"Erro ao inicializar cliente Supabase: {str(e)}")
                raise
        
        return self._client
    
    @property
    def admin_client(self) -> Client:
        """
        Obtém o cliente Supabase com privilégios administrativos.
        
        Returns:
            Cliente Supabase com service role
        """
        if not self._admin_client:
            try:
                service_key = self.settings.SUPABASE_SERVICE_KEY
                if not service_key:
                    raise ValueError("SUPABASE_SERVICE_KEY não configurada")
                
                self._admin_client = create_client(
                    self.settings.SUPABASE_URL,
                    service_key
                )
                logger.info("Cliente Supabase admin inicializado com sucesso")
            except Exception as e:
                logger.error(f"Erro ao inicializar cliente Supabase admin: {str(e)}")
                raise
        
        return self._admin_client
    
    async def validate_jwt_token(self, token: str) -> Optional[Dict[str, Any]]:
        """
        Valida um token JWT do Supabase.
        
        Args:
            token: Token JWT a ser validado
            
        Returns:
            Dados do usuário se o token for válido, None caso contrário
        """
        try:
            # Tenta usar o cliente Supabase para validar o token
            response = self.client.auth.get_user(token)
            
            if response.user:
                return {
                    "id": response.user.id,
                    "email": response.user.email,
                    "phone": response.user.phone,
                    "role": response.user.user_metadata.get("role", "user"),
                    "created_at": response.user.created_at,
                    "updated_at": response.user.updated_at,
                    "email_confirmed_at": response.user.email_confirmed_at,
                    "phone_confirmed_at": response.user.phone_confirmed_at,
                    "user_metadata": response.user.user_metadata,
                    "app_metadata": response.user.app_metadata
                }
            
            return None
            
        except Exception as e:
            logger.warning(f"Erro ao validar token via cliente Supabase: {str(e)}")
            
            # Fallback: decodifica JWT manualmente se tiver a chave
            if self.settings.SUPABASE_JWT_SECRET:
                try:
                    payload = jwt.decode(
                        token,
                        self.settings.SUPABASE_JWT_SECRET,
                        algorithms=["HS256"],
                        options={"verify_signature": True}
                    )
                    
                    return {
                        "id": payload.get("sub"),
                        "email": payload.get("email"),
                        "role": payload.get("role", "user"),
                        "aud": payload.get("aud"),
                        "exp": payload.get("exp"),
                        "iat": payload.get("iat"),
                        "iss": payload.get("iss")
                    }
                    
                except jwt.ExpiredSignatureError:
                    logger.warning("Token JWT expirado")
                    return None
                except jwt.InvalidTokenError as e:
                    logger.warning(f"Token JWT inválido: {str(e)}")
                    return None
            
            return None
    
    async def get_user_by_id(self, user_id: str) -> Optional[Dict[str, Any]]:
        """
        Obtém dados de um usuário pelo ID.
        
        Args:
            user_id: ID do usuário
            
        Returns:
            Dados do usuário se encontrado, None caso contrário
        """
        try:
            response = self.admin_client.auth.admin.get_user_by_id(user_id)
            
            if response.user:
                return {
                    "id": response.user.id,
                    "email": response.user.email,
                    "phone": response.user.phone,
                    "role": response.user.user_metadata.get("role", "user"),
                    "created_at": response.user.created_at,
                    "updated_at": response.user.updated_at,
                    "email_confirmed_at": response.user.email_confirmed_at,
                    "phone_confirmed_at": response.user.phone_confirmed_at,
                    "user_metadata": response.user.user_metadata,
                    "app_metadata": response.user.app_metadata
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Erro ao obter usuário por ID {user_id}: {str(e)}")
            return None
    
    async def get_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """
        Obtém dados de um usuário pelo email.
        
        Args:
            email: Email do usuário
            
        Returns:
            Dados do usuário se encontrado, None caso contrário
        """
        try:
            # Usa a API admin para buscar usuário por email
            response = self.admin_client.auth.admin.list_users()
            
            if response.users:
                for user in response.users:
                    if user.email == email:
                        return {
                            "id": user.id,
                            "email": user.email,
                            "phone": user.phone,
                            "role": user.user_metadata.get("role", "user"),
                            "created_at": user.created_at,
                            "updated_at": user.updated_at,
                            "email_confirmed_at": user.email_confirmed_at,
                            "phone_confirmed_at": user.phone_confirmed_at,
                            "user_metadata": user.user_metadata,
                            "app_metadata": user.app_metadata
                        }
            
            return None
            
        except Exception as e:
            logger.error(f"Erro ao obter usuário por email {email}: {str(e)}")
            return None
    
    async def create_user(
        self, 
        email: str, 
        password: str, 
        user_metadata: Optional[Dict[str, Any]] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Cria um novo usuário no Supabase.
        
        Args:
            email: Email do usuário
            password: Senha do usuário
            user_metadata: Metadados adicionais do usuário
            
        Returns:
            Dados do usuário criado se bem-sucedido, None caso contrário
        """
        try:
            response = self.admin_client.auth.admin.create_user({
                "email": email,
                "password": password,
                "user_metadata": user_metadata or {},
                "email_confirm": True  # Confirma email automaticamente
            })
            
            if response.user:
                logger.info(f"Usuário criado com sucesso: {email}")
                return {
                    "id": response.user.id,
                    "email": response.user.email,
                    "phone": response.user.phone,
                    "role": response.user.user_metadata.get("role", "user"),
                    "created_at": response.user.created_at,
                    "updated_at": response.user.updated_at,
                    "user_metadata": response.user.user_metadata,
                    "app_metadata": response.user.app_metadata
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Erro ao criar usuário {email}: {str(e)}")
            return None
    
    async def update_user_metadata(
        self, 
        user_id: str, 
        user_metadata: Dict[str, Any]
    ) -> bool:
        """
        Atualiza metadados de um usuário.
        
        Args:
            user_id: ID do usuário
            user_metadata: Novos metadados do usuário
            
        Returns:
            True se atualizado com sucesso, False caso contrário
        """
        try:
            response = self.admin_client.auth.admin.update_user_by_id(
                user_id,
                {"user_metadata": user_metadata}
            )
            
            if response.user:
                logger.info(f"Metadados do usuário {user_id} atualizados com sucesso")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Erro ao atualizar metadados do usuário {user_id}: {str(e)}")
            return False
    
    async def delete_user(self, user_id: str) -> bool:
        """
        Deleta um usuário do Supabase.
        
        Args:
            user_id: ID do usuário a ser deletado
            
        Returns:
            True se deletado com sucesso, False caso contrário
        """
        try:
            self.admin_client.auth.admin.delete_user(user_id)
            logger.info(f"Usuário {user_id} deletado com sucesso")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao deletar usuário {user_id}: {str(e)}")
            return False
    
    async def refresh_token(self, refresh_token: str) -> Optional[Dict[str, Any]]:
        """
        Renova um token de acesso usando o refresh token.
        
        Args:
            refresh_token: Token de renovação
            
        Returns:
            Novos tokens se bem-sucedido, None caso contrário
        """
        try:
            response = self.client.auth.refresh_session(refresh_token)
            
            if response.session:
                return {
                    "access_token": response.session.access_token,
                    "refresh_token": response.session.refresh_token,
                    "expires_at": response.session.expires_at,
                    "token_type": response.session.token_type,
                    "user": {
                        "id": response.session.user.id,
                        "email": response.session.user.email,
                        "role": response.session.user.user_metadata.get("role", "user")
                    }
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Erro ao renovar token: {str(e)}")
            return None
    
    async def health_check(self) -> Dict[str, Any]:
        """
        Verifica a saúde da conexão com o Supabase.
        
        Returns:
            Status da conexão com o Supabase
        """
        try:
            # Tenta fazer uma operação simples para verificar conectividade
            response = self.client.auth.get_session()
            
            return {
                "supabase_status": "healthy",
                "supabase_url": self.settings.SUPABASE_URL,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "client_initialized": self._client is not None,
                "admin_client_initialized": self._admin_client is not None
            }
            
        except Exception as e:
            logger.error(f"Erro no health check do Supabase: {str(e)}")
            return {
                "supabase_status": "unhealthy",
                "supabase_url": self.settings.SUPABASE_URL,
                "error": str(e),
                "timestamp": datetime.now(timezone.utc).isoformat()
            }


# Instância global do serviço Supabase
supabase_service = SupabaseService()