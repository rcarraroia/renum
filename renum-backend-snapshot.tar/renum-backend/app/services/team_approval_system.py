"""
Sistema de aprovações para execuções de equipes de agentes.
Permite configurar regras de auto-aprovação e interface para aprovações manuais.
"""

from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
from datetime import datetime, timedelta
import json
import logging
from dataclasses import dataclass

from app.core.database import get_db_client
from app.models.team_models import TeamExecutionDB, ExecutionStatus
import redis.asyncio as redis

logger = logging.getLogger(__name__)

class ApprovalStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    AUTO_APPROVED = "auto_approved"
    EXPIRED = "expired"

class ApprovalReason(str, Enum):
    HIGH_COST = "high_cost"
    LONG_DURATION = "long_duration"
    SENSITIVE_DATA = "sensitive_data"
    EXTERNAL_API = "external_api"
    CUSTOM_RULE = "custom_rule"
    MANUAL_REVIEW = "manual_review"

@dataclass
class ApprovalRule:
    """Regra de aprovação"""
    id: str
    name: str
    condition: Dict[str, Any]
    action: str  # "require_approval" | "auto_approve" | "reject"
    priority: int
    enabled: bool
    created_by: str
    created_at: datetime

@dataclass
class ApprovalRequest:
    """Solicitação de aprovação"""
    id: str
    execution_id: str
    team_id: str
    user_id: str
    reason: ApprovalReason
    status: ApprovalStatus
    estimated_cost: Optional[float]
    estimated_duration: Optional[int]
    sensitive_data_types: List[str]
    external_apis: List[str]
    metadata: Dict[str, Any]
    requested_at: datetime
    expires_at: Optional[datetime]
    approved_by: Optional[str]
    approved_at: Optional[datetime]
    rejection_reason: Optional[str]

class TeamApprovalSystem:
    """Sistema de aprovações para equipes de agentes"""
    
    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self.default_rules = self._get_default_rules()
        
    def _get_default_rules(self) -> List[ApprovalRule]:
        """Regras padrão de aprovação"""
        return [
            ApprovalRule(
                id="high_cost_threshold",
                name="Custo Alto",
                condition={
                    "estimated_cost": {"gt": 10.0}  # > $10
                },
                action="require_approval",
                priority=1,
                enabled=True,
                created_by="system",
                created_at=datetime.utcnow()
            ),
            ApprovalRule(
                id="long_duration_threshold",
                name="Duração Longa",
                condition={
                    "estimated_duration": {"gt": 3600}  # > 1 hora
                },
                action="require_approval",
                priority=2,
                enabled=True,
                created_by="system",
                created_at=datetime.utcnow()
            ),
            ApprovalRule(
                id="sensitive_data_access",
                name="Dados Sensíveis",
                condition={
                    "sensitive_data_types": {"contains_any": ["pii", "financial", "medical"]}
                },
                action="require_approval",
                priority=3,
                enabled=True,
                created_by="system",
                created_at=datetime.utcnow()
            ),
            ApprovalRule(
                id="external_api_calls",
                name="APIs Externas",
                condition={
                    "external_apis": {"count": {"gt": 5}}
                },
                action="require_approval",
                priority=4,
                enabled=True,
                created_by="system",
                created_at=datetime.utcnow()
            ),
            ApprovalRule(
                id="low_cost_auto_approve",
                name="Auto-aprovação Custo Baixo",
                condition={
                    "estimated_cost": {"lt": 1.0}  # < $1
                },
                action="auto_approve",
                priority=10,
                enabled=True,
                created_by="system",
                created_at=datetime.utcnow()
            )
        ]
    
    async def evaluate_execution_for_approval(
        self,
        execution: TeamExecutionDB,
        execution_plan: Dict[str, Any]
    ) -> Tuple[bool, Optional[ApprovalRequest]]:
        """
        Avalia se uma execução precisa de aprovação
        
        Returns:
            (needs_approval, approval_request)
        """
        try:
            # Extrair informações da execução
            metadata = self._extract_execution_metadata(execution, execution_plan)
            
            # Obter regras ativas
            rules = await self._get_active_rules(execution.user_id)
            
            # Avaliar regras por prioridade
            for rule in sorted(rules, key=lambda r: r.priority):
                if self._evaluate_rule(rule, metadata):
                    if rule.action == "auto_approve":
                        logger.info(f"Execução {execution.id} auto-aprovada pela regra {rule.name}")
                        return False, None
                    elif rule.action == "require_approval":
                        approval_request = await self._create_approval_request(
                            execution, metadata, rule
                        )
                        logger.info(f"Execução {execution.id} requer aprovação pela regra {rule.name}")
                        return True, approval_request
                    elif rule.action == "reject":
                        logger.warning(f"Execução {execution.id} rejeitada pela regra {rule.name}")
                        raise ValueError(f"Execução rejeitada: {rule.name}")
            
            # Se nenhuma regra se aplicou, auto-aprovar
            logger.info(f"Execução {execution.id} auto-aprovada (nenhuma regra aplicável)")
            return False, None
            
        except Exception as e:
            logger.error(f"Erro ao avaliar aprovação para execução {execution.id}: {e}")
            raise
    
    def _extract_execution_metadata(
        self,
        execution: TeamExecutionDB,
        execution_plan: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Extrai metadados relevantes para avaliação"""
        metadata = {
            "execution_id": execution.id,
            "team_id": execution.team_id,
            "user_id": execution.user_id,
            "estimated_cost": execution_plan.get("estimated_cost", 0.0),
            "estimated_duration": execution_plan.get("estimated_duration", 0),
            "agent_count": len(execution_plan.get("agents", [])),
            "sensitive_data_types": [],
            "external_apis": [],
            "workflow_strategy": execution_plan.get("strategy", "sequential")
        }
        
        # Analisar configurações dos agentes
        for agent_config in execution_plan.get("agents", []):
            # Verificar tipos de dados sensíveis
            if agent_config.get("handles_pii", False):
                metadata["sensitive_data_types"].append("pii")
            if agent_config.get("handles_financial", False):
                metadata["sensitive_data_types"].append("financial")
            if agent_config.get("handles_medical", False):
                metadata["sensitive_data_types"].append("medical")
            
            # Verificar APIs externas
            external_apis = agent_config.get("external_apis", [])
            metadata["external_apis"].extend(external_apis)
        
        # Remover duplicatas
        metadata["sensitive_data_types"] = list(set(metadata["sensitive_data_types"]))
        metadata["external_apis"] = list(set(metadata["external_apis"]))
        
        return metadata
    
    def _evaluate_rule(self, rule: ApprovalRule, metadata: Dict[str, Any]) -> bool:
        """Avalia se uma regra se aplica aos metadados"""
        try:
            for field, condition in rule.condition.items():
                value = metadata.get(field)
                
                if isinstance(condition, dict):
                    # Condições complexas
                    if "gt" in condition and (value is None or value <= condition["gt"]):
                        return False
                    if "lt" in condition and (value is None or value >= condition["lt"]):
                        return False
                    if "eq" in condition and value != condition["eq"]:
                        return False
                    if "contains_any" in condition:
                        if not value or not any(item in value for item in condition["contains_any"]):
                            return False
                    if "count" in condition:
                        count_condition = condition["count"]
                        count = len(value) if value else 0
                        if "gt" in count_condition and count <= count_condition["gt"]:
                            return False
                        if "lt" in count_condition and count >= count_condition["lt"]:
                            return False
                else:
                    # Condição simples
                    if value != condition:
                        return False
            
            return True
            
        except Exception as e:
            logger.error(f"Erro ao avaliar regra {rule.id}: {e}")
            return False
    
    async def _get_active_rules(self, user_id: str) -> List[ApprovalRule]:
        """Obtém regras ativas para um usuário"""
        try:
            # Por enquanto, usar regras padrão
            # No futuro, buscar regras personalizadas do usuário
            return [rule for rule in self.default_rules if rule.enabled]
        except Exception as e:
            logger.error(f"Erro ao obter regras para usuário {user_id}: {e}")
            return []
    
    async def _create_approval_request(
        self,
        execution: TeamExecutionDB,
        metadata: Dict[str, Any],
        triggered_rule: ApprovalRule
    ) -> ApprovalRequest:
        """Cria uma solicitação de aprovação"""
        try:
            approval_id = f"approval_{execution.id}_{int(datetime.utcnow().timestamp())}"
            
            # Determinar razão da aprovação
            reason = ApprovalReason.CUSTOM_RULE
            if "cost" in triggered_rule.name.lower():
                reason = ApprovalReason.HIGH_COST
            elif "duration" in triggered_rule.name.lower():
                reason = ApprovalReason.LONG_DURATION
            elif "sensitive" in triggered_rule.name.lower():
                reason = ApprovalReason.SENSITIVE_DATA
            elif "api" in triggered_rule.name.lower():
                reason = ApprovalReason.EXTERNAL_API
            
            approval_request = ApprovalRequest(
                id=approval_id,
                execution_id=execution.id,
                team_id=execution.team_id,
                user_id=execution.user_id,
                reason=reason,
                status=ApprovalStatus.PENDING,
                estimated_cost=metadata.get("estimated_cost"),
                estimated_duration=metadata.get("estimated_duration"),
                sensitive_data_types=metadata.get("sensitive_data_types", []),
                external_apis=metadata.get("external_apis", []),
                metadata=metadata,
                requested_at=datetime.utcnow(),
                expires_at=datetime.utcnow() + timedelta(hours=24),  # Expira em 24h
                approved_by=None,
                approved_at=None,
                rejection_reason=None
            )
            
            # Salvar no Redis
            await self._save_approval_request(approval_request)
            
            # Notificar administradores
            await self._notify_approval_required(approval_request)
            
            return approval_request
            
        except Exception as e:
            logger.error(f"Erro ao criar solicitação de aprovação: {e}")
            raise
    
    async def _save_approval_request(self, approval_request: ApprovalRequest):
        """Salva solicitação de aprovação no Redis"""
        try:
            key = f"approval_request:{approval_request.id}"
            data = {
                "id": approval_request.id,
                "execution_id": approval_request.execution_id,
                "team_id": approval_request.team_id,
                "user_id": approval_request.user_id,
                "reason": approval_request.reason.value,
                "status": approval_request.status.value,
                "estimated_cost": approval_request.estimated_cost,
                "estimated_duration": approval_request.estimated_duration,
                "sensitive_data_types": approval_request.sensitive_data_types,
                "external_apis": approval_request.external_apis,
                "metadata": approval_request.metadata,
                "requested_at": approval_request.requested_at.isoformat(),
                "expires_at": approval_request.expires_at.isoformat() if approval_request.expires_at else None,
                "approved_by": approval_request.approved_by,
                "approved_at": approval_request.approved_at.isoformat() if approval_request.approved_at else None,
                "rejection_reason": approval_request.rejection_reason
            }
            
            await self.redis.set(key, json.dumps(data), ex=86400 * 7)  # 7 dias
            
            # Adicionar à lista de aprovações pendentes
            await self.redis.sadd("pending_approvals", approval_request.id)
            
        except Exception as e:
            logger.error(f"Erro ao salvar solicitação de aprovação: {e}")
            raise
    
    async def _notify_approval_required(self, approval_request: ApprovalRequest):
        """Notifica administradores sobre aprovação necessária"""
        try:
            notification = {
                "type": "approval_required",
                "approval_id": approval_request.id,
                "execution_id": approval_request.execution_id,
                "user_id": approval_request.user_id,
                "reason": approval_request.reason.value,
                "estimated_cost": approval_request.estimated_cost,
                "estimated_duration": approval_request.estimated_duration,
                "requested_at": approval_request.requested_at.isoformat()
            }
            
            # Publicar notificação
            await self.redis.publish("admin_notifications", json.dumps(notification))
            
        except Exception as e:
            logger.error(f"Erro ao notificar aprovação: {e}")
    
    async def approve_request(
        self,
        approval_id: str,
        approved_by: str,
        notes: Optional[str] = None
    ) -> bool:
        """Aprova uma solicitação"""
        try:
            approval_request = await self._get_approval_request(approval_id)
            if not approval_request:
                return False
            
            if approval_request.status != ApprovalStatus.PENDING:
                return False
            
            # Atualizar status
            approval_request.status = ApprovalStatus.APPROVED
            approval_request.approved_by = approved_by
            approval_request.approved_at = datetime.utcnow()
            
            if notes:
                approval_request.metadata["approval_notes"] = notes
            
            # Salvar alterações
            await self._save_approval_request(approval_request)
            
            # Remover da lista de pendentes
            await self.redis.srem("pending_approvals", approval_id)
            
            # Notificar usuário
            await self._notify_approval_decision(approval_request, True)
            
            logger.info(f"Aprovação {approval_id} aprovada por {approved_by}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao aprovar solicitação {approval_id}: {e}")
            return False
    
    async def reject_request(
        self,
        approval_id: str,
        rejected_by: str,
        reason: str
    ) -> bool:
        """Rejeita uma solicitação"""
        try:
            approval_request = await self._get_approval_request(approval_id)
            if not approval_request:
                return False
            
            if approval_request.status != ApprovalStatus.PENDING:
                return False
            
            # Atualizar status
            approval_request.status = ApprovalStatus.REJECTED
            approval_request.approved_by = rejected_by
            approval_request.approved_at = datetime.utcnow()
            approval_request.rejection_reason = reason
            
            # Salvar alterações
            await self._save_approval_request(approval_request)
            
            # Remover da lista de pendentes
            await self.redis.srem("pending_approvals", approval_id)
            
            # Notificar usuário
            await self._notify_approval_decision(approval_request, False)
            
            logger.info(f"Aprovação {approval_id} rejeitada por {rejected_by}: {reason}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao rejeitar solicitação {approval_id}: {e}")
            return False
    
    async def _get_approval_request(self, approval_id: str) -> Optional[ApprovalRequest]:
        """Obtém solicitação de aprovação"""
        try:
            key = f"approval_request:{approval_id}"
            data = await self.redis.get(key)
            
            if not data:
                return None
            
            data = json.loads(data)
            
            return ApprovalRequest(
                id=data["id"],
                execution_id=data["execution_id"],
                team_id=data["team_id"],
                user_id=data["user_id"],
                reason=ApprovalReason(data["reason"]),
                status=ApprovalStatus(data["status"]),
                estimated_cost=data["estimated_cost"],
                estimated_duration=data["estimated_duration"],
                sensitive_data_types=data["sensitive_data_types"],
                external_apis=data["external_apis"],
                metadata=data["metadata"],
                requested_at=datetime.fromisoformat(data["requested_at"]),
                expires_at=datetime.fromisoformat(data["expires_at"]) if data["expires_at"] else None,
                approved_by=data["approved_by"],
                approved_at=datetime.fromisoformat(data["approved_at"]) if data["approved_at"] else None,
                rejection_reason=data["rejection_reason"]
            )
            
        except Exception as e:
            logger.error(f"Erro ao obter solicitação de aprovação {approval_id}: {e}")
            return None
    
    async def _notify_approval_decision(self, approval_request: ApprovalRequest, approved: bool):
        """Notifica usuário sobre decisão de aprovação"""
        try:
            notification = {
                "type": "approval_decision",
                "approval_id": approval_request.id,
                "execution_id": approval_request.execution_id,
                "approved": approved,
                "decided_by": approval_request.approved_by,
                "decided_at": approval_request.approved_at.isoformat() if approval_request.approved_at else None,
                "rejection_reason": approval_request.rejection_reason
            }
            
            # Publicar notificação para o usuário
            channel = f"user_notifications:{approval_request.user_id}"
            await self.redis.publish(channel, json.dumps(notification))
            
        except Exception as e:
            logger.error(f"Erro ao notificar decisão de aprovação: {e}")
    
    async def get_pending_approvals(self, limit: int = 50) -> List[ApprovalRequest]:
        """Obtém aprovações pendentes"""
        try:
            approval_ids = await self.redis.smembers("pending_approvals")
            approvals = []
            
            for approval_id in approval_ids[:limit]:
                approval = await self._get_approval_request(approval_id)
                if approval and approval.status == ApprovalStatus.PENDING:
                    # Verificar se expirou
                    if approval.expires_at and datetime.utcnow() > approval.expires_at:
                        approval.status = ApprovalStatus.EXPIRED
                        await self._save_approval_request(approval)
                        await self.redis.srem("pending_approvals", approval_id)
                    else:
                        approvals.append(approval)
            
            return sorted(approvals, key=lambda a: a.requested_at, reverse=True)
            
        except Exception as e:
            logger.error(f"Erro ao obter aprovações pendentes: {e}")
            return []
    
    async def get_approval_status(self, execution_id: str) -> Optional[ApprovalRequest]:
        """Obtém status de aprovação para uma execução"""
        try:
            # Buscar por execution_id (pode ser ineficiente, considerar indexação)
            approval_ids = await self.redis.smembers("pending_approvals")
            
            for approval_id in approval_ids:
                approval = await self._get_approval_request(approval_id)
                if approval and approval.execution_id == execution_id:
                    return approval
            
            return None
            
        except Exception as e:
            logger.error(f"Erro ao obter status de aprovação para execução {execution_id}: {e}")
            return None