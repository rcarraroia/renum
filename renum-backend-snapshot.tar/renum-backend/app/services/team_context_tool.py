"""
Ferramenta para agentes acessarem o contexto compartilhado da equipe.

Esta ferramenta permite que agentes individuais leiam e escrevam no contexto
compartilhado da equipe durante a execução.
"""

import logging
from typing import Dict, Any, Optional
from uuid import UUID

from app.services.team_context_manager import TeamContextManager

logger = logging.getLogger(__name__)


class TeamContextTool:
    """Ferramenta para acesso ao contexto compartilhado da equipe."""
    
    def __init__(self, context_manager: TeamContextManager, execution_id: UUID, agent_id: str):
        """
        Inicializa a ferramenta de contexto.
        
        Args:
            context_manager: Gerenciador de contexto compartilhado
            execution_id: ID da execução da equipe
            agent_id: ID do agente que está usando a ferramenta
        """
        self.context_manager = context_manager
        self.execution_id = execution_id
        self.agent_id = agent_id
        self.name = "team_context"
        self.description = "Acessa e modifica o contexto compartilhado da equipe"
    
    async def get_variable(self, key: str) -> Any:
        """
        Obtém uma variável do contexto compartilhado.
        
        Args:
            key: Chave da variável
            
        Returns:
            Valor da variável ou None se não existir
        """
        try:
            value = await self.context_manager.get_variable(self.execution_id, key)
            logger.info(f"Agente {self.agent_id} leu variável '{key}' do contexto")
            return value
        except Exception as e:
            logger.error(f"Erro ao ler variável '{key}' do contexto: {e}")
            return None
    
    async def set_variable(self, key: str, value: Any) -> bool:
        """
        Define uma variável no contexto compartilhado.
        
        Args:
            key: Chave da variável
            value: Valor da variável
            
        Returns:
            True se a operação foi bem-sucedida
        """
        try:
            await self.context_manager.set_shared_memory(
                self.execution_id, key, value, self.agent_id
            )
            logger.info(f"Agente {self.agent_id} definiu variável '{key}' no contexto")
            return True
        except Exception as e:
            logger.error(f"Erro ao definir variável '{key}' no contexto: {e}")
            return False
    
    async def get_all_variables(self) -> Dict[str, Any]:
        """
        Obtém todas as variáveis do contexto compartilhado.
        
        Returns:
            Dicionário com todas as variáveis
        """
        try:
            variables = await self.context_manager.get_all_variables(self.execution_id)
            logger.info(f"Agente {self.agent_id} leu todas as variáveis do contexto")
            return variables
        except Exception as e:
            logger.error(f"Erro ao ler todas as variáveis do contexto: {e}")
            return {}
    
    async def update_context_object(self, updates: Dict[str, Any]) -> bool:
        """
        Atualiza o objeto de contexto com novos dados.
        
        Args:
            updates: Dicionário com as atualizações
            
        Returns:
            True se a operação foi bem-sucedida
        """
        try:
            await self.context_manager.update_context_object(
                self.execution_id, updates, self.agent_id
            )
            logger.info(f"Agente {self.agent_id} atualizou o objeto de contexto")
            return True
        except Exception as e:
            logger.error(f"Erro ao atualizar objeto de contexto: {e}")
            return False
    
    async def get_context_history(self) -> list:
        """
        Obtém o histórico de mudanças no contexto.
        
        Returns:
            Lista com o histórico de mudanças
        """
        try:
            # Implementação simplificada - retorna lista vazia por enquanto
            # Em uma implementação completa, isso buscaria o histórico do Redis
            logger.info(f"Agente {self.agent_id} consultou histórico do contexto")
            return []
        except Exception as e:
            logger.error(f"Erro ao obter histórico do contexto: {e}")
            return []
    
    def get_tool_definition(self) -> Dict[str, Any]:
        """
        Retorna a definição da ferramenta para uso pelo agente.
        
        Returns:
            Definição da ferramenta no formato esperado pelo sistema de agentes
        """
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": ["get", "set", "get_all", "update", "history"],
                        "description": "Ação a ser executada no contexto"
                    },
                    "key": {
                        "type": "string",
                        "description": "Chave da variável (para get e set)"
                    },
                    "value": {
                        "description": "Valor da variável (para set)"
                    },
                    "updates": {
                        "type": "object",
                        "description": "Objeto com atualizações (para update)"
                    }
                },
                "required": ["action"]
            }
        }
    
    async def execute(self, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """
        Executa uma ação na ferramenta de contexto.
        
        Args:
            parameters: Parâmetros da ação
            
        Returns:
            Resultado da ação
        """
        action = parameters.get("action")
        
        try:
            if action == "get":
                key = parameters.get("key")
                if not key:
                    return {"error": "Chave é obrigatória para ação 'get'"}
                
                value = await self.get_variable(key)
                return {"success": True, "value": value}
            
            elif action == "set":
                key = parameters.get("key")
                value = parameters.get("value")
                if not key:
                    return {"error": "Chave é obrigatória para ação 'set'"}
                
                success = await self.set_variable(key, value)
                return {"success": success}
            
            elif action == "get_all":
                variables = await self.get_all_variables()
                return {"success": True, "variables": variables}
            
            elif action == "update":
                updates = parameters.get("updates", {})
                success = await self.update_context_object(updates)
                return {"success": success}
            
            elif action == "history":
                history = await self.get_context_history()
                return {"success": True, "history": history}
            
            else:
                return {"error": f"Ação '{action}' não reconhecida"}
                
        except Exception as e:
            logger.error(f"Erro ao executar ação '{action}' na ferramenta de contexto: {e}")
            return {"error": str(e)}