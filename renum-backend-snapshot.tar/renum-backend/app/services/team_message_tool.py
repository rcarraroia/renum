"""
Ferramenta para agentes se comunicarem entre si durante a execução da equipe.

Esta ferramenta permite que agentes enviem mensagens uns para os outros,
façam broadcasts para toda a equipe e solicitem respostas específicas.
"""

import logging
from typing import Dict, Any, Optional, List
from uuid import UUID

from app.services.team_message_bus import TeamMessageBus
from app.models.team_models import TeamMessage

logger = logging.getLogger(__name__)


class TeamMessageTool:
    """Ferramenta para comunicação entre agentes da equipe."""
    
    def __init__(self, message_bus: TeamMessageBus, execution_id: UUID, agent_id: str):
        """
        Inicializa a ferramenta de mensagens.
        
        Args:
            message_bus: Sistema de mensagens da equipe
            execution_id: ID da execução da equipe
            agent_id: ID do agente que está usando a ferramenta
        """
        self.message_bus = message_bus
        self.execution_id = execution_id
        self.agent_id = agent_id
        self.name = "team_message"
        self.description = "Envia mensagens para outros agentes da equipe"
    
    async def send_message(self, to_agent: str, content: Dict[str, Any], message_type: str = "info") -> bool:
        """
        Envia uma mensagem para um agente específico.
        
        Args:
            to_agent: ID do agente destinatário
            content: Conteúdo da mensagem
            message_type: Tipo da mensagem (info, request, response, error)
            
        Returns:
            True se a mensagem foi enviada com sucesso
        """
        try:
            message = TeamMessage(
                execution_id=self.execution_id,
                from_agent=self.agent_id,
                to_agent=to_agent,
                message_type=message_type,
                content=content
            )
            
            await self.message_bus.send_message(
                self.execution_id, self.agent_id, to_agent, message
            )
            
            logger.info(f"Agente {self.agent_id} enviou mensagem para {to_agent}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao enviar mensagem para {to_agent}: {e}")
            return False
    
    async def broadcast_message(self, content: Dict[str, Any], message_type: str = "info", exclude_agents: List[str] = None) -> bool:
        """
        Envia uma mensagem para todos os agentes da equipe.
        
        Args:
            content: Conteúdo da mensagem
            message_type: Tipo da mensagem
            exclude_agents: Lista de agentes para excluir do broadcast
            
        Returns:
            True se a mensagem foi enviada com sucesso
        """
        try:
            message = TeamMessage(
                execution_id=self.execution_id,
                from_agent=self.agent_id,
                to_agent=None,  # None indica broadcast
                message_type=message_type,
                content=content
            )
            
            await self.message_bus.broadcast_message(
                self.execution_id, self.agent_id, message, exclude_agents or []
            )
            
            logger.info(f"Agente {self.agent_id} fez broadcast para a equipe")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao fazer broadcast: {e}")
            return False
    
    async def request_response(self, to_agent: str, request: Dict[str, Any], timeout: int = 30) -> Optional[Dict[str, Any]]:
        """
        Envia uma solicitação para um agente e aguarda resposta.
        
        Args:
            to_agent: ID do agente destinatário
            request: Conteúdo da solicitação
            timeout: Timeout em segundos para aguardar resposta
            
        Returns:
            Resposta do agente ou None se não houver resposta
        """
        try:
            message = TeamMessage(
                execution_id=self.execution_id,
                from_agent=self.agent_id,
                to_agent=to_agent,
                message_type="request",
                content=request,
                requires_response=True,
                response_timeout=timeout
            )
            
            response = await self.message_bus.request_response(
                self.execution_id, self.agent_id, to_agent, message, timeout
            )
            
            logger.info(f"Agente {self.agent_id} recebeu resposta de {to_agent}")
            return response.content if response else None
            
        except Exception as e:
            logger.error(f"Erro ao solicitar resposta de {to_agent}: {e}")
            return None
    
    async def get_messages(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Obtém mensagens recentes direcionadas a este agente.
        
        Args:
            limit: Número máximo de mensagens para retornar
            
        Returns:
            Lista de mensagens
        """
        try:
            # Implementação simplificada - em uma implementação completa,
            # isso buscaria mensagens do Redis ou banco de dados
            logger.info(f"Agente {self.agent_id} consultou mensagens")
            return []
            
        except Exception as e:
            logger.error(f"Erro ao obter mensagens: {e}")
            return []
    
    async def send_status_update(self, status: str, details: Dict[str, Any] = None) -> bool:
        """
        Envia uma atualização de status para a equipe.
        
        Args:
            status: Status atual do agente
            details: Detalhes adicionais sobre o status
            
        Returns:
            True se a atualização foi enviada com sucesso
        """
        content = {
            "status": status,
            "agent_id": self.agent_id,
            "timestamp": "now",  # Seria substituído por timestamp real
            "details": details or {}
        }
        
        return await self.broadcast_message(content, "status_update")
    
    async def send_error_notification(self, error_message: str, error_details: Dict[str, Any] = None) -> bool:
        """
        Envia uma notificação de erro para a equipe.
        
        Args:
            error_message: Mensagem de erro
            error_details: Detalhes adicionais sobre o erro
            
        Returns:
            True se a notificação foi enviada com sucesso
        """
        content = {
            "error": error_message,
            "agent_id": self.agent_id,
            "timestamp": "now",  # Seria substituído por timestamp real
            "details": error_details or {}
        }
        
        return await self.broadcast_message(content, "error")
    
    def get_tool_definition(self) -> Dict[str, Any]:
        """
        Retorna a definição da ferramenta para uso pelo agente.
        
        Returns:
            Definição da ferramenta no formato esperado pelo sistema de agentes
        """
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": ["send", "broadcast", "request", "get_messages", "status", "error"],
                        "description": "Ação a ser executada"
                    },
                    "to_agent": {
                        "type": "string",
                        "description": "ID do agente destinatário (para send e request)"
                    },
                    "content": {
                        "type": "object",
                        "description": "Conteúdo da mensagem"
                    },
                    "message_type": {
                        "type": "string",
                        "enum": ["info", "request", "response", "error", "status_update"],
                        "description": "Tipo da mensagem"
                    },
                    "timeout": {
                        "type": "integer",
                        "description": "Timeout para aguardar resposta (em segundos)"
                    },
                    "exclude_agents": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Agentes para excluir do broadcast"
                    },
                    "status": {
                        "type": "string",
                        "description": "Status do agente (para action=status)"
                    },
                    "error_message": {
                        "type": "string",
                        "description": "Mensagem de erro (para action=error)"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Limite de mensagens para retornar"
                    }
                },
                "required": ["action"]
            }
        }
    
    async def execute(self, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """
        Executa uma ação na ferramenta de mensagens.
        
        Args:
            parameters: Parâmetros da ação
            
        Returns:
            Resultado da ação
        """
        action = parameters.get("action")
        
        try:
            if action == "send":
                to_agent = parameters.get("to_agent")
                content = parameters.get("content", {})
                message_type = parameters.get("message_type", "info")
                
                if not to_agent:
                    return {"error": "to_agent é obrigatório para ação 'send'"}
                
                success = await self.send_message(to_agent, content, message_type)
                return {"success": success}
            
            elif action == "broadcast":
                content = parameters.get("content", {})
                message_type = parameters.get("message_type", "info")
                exclude_agents = parameters.get("exclude_agents", [])
                
                success = await self.broadcast_message(content, message_type, exclude_agents)
                return {"success": success}
            
            elif action == "request":
                to_agent = parameters.get("to_agent")
                content = parameters.get("content", {})
                timeout = parameters.get("timeout", 30)
                
                if not to_agent:
                    return {"error": "to_agent é obrigatório para ação 'request'"}
                
                response = await self.request_response(to_agent, content, timeout)
                return {"success": response is not None, "response": response}
            
            elif action == "get_messages":
                limit = parameters.get("limit", 10)
                messages = await self.get_messages(limit)
                return {"success": True, "messages": messages}
            
            elif action == "status":
                status = parameters.get("status")
                details = parameters.get("content", {})
                
                if not status:
                    return {"error": "status é obrigatório para ação 'status'"}
                
                success = await self.send_status_update(status, details)
                return {"success": success}
            
            elif action == "error":
                error_message = parameters.get("error_message")
                details = parameters.get("content", {})
                
                if not error_message:
                    return {"error": "error_message é obrigatório para ação 'error'"}
                
                success = await self.send_error_notification(error_message, details)
                return {"success": success}
            
            else:
                return {"error": f"Ação '{action}' não reconhecida"}
                
        except Exception as e:
            logger.error(f"Erro ao executar ação '{action}' na ferramenta de mensagens: {e}")
            return {"error": str(e)}