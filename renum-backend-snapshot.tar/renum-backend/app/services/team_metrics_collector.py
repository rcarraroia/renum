"""
Coletor de métricas para equipes de agentes.

Este módulo implementa a coleta, agregação e análise de métricas
de performance e uso para execuções de equipes de agentes.
"""

import logging
from typing import Dict, Any, List, Optional
from uuid import UUID
from datetime import datetime, timedelta
from dataclasses import dataclass

from app.models.team_models import (
    UsageMetrics,
    CostMetrics,
    ExecutionStatus
)

logger = logging.getLogger(__name__)


@dataclass
class TeamPerformanceMetrics:
    """Métricas de performance de uma equipe."""
    execution_id: UUID
    team_id: UUID
    total_execution_time: float
    average_agent_time: float
    success_rate: float
    total_cost: float
    total_tokens: int
    agent_metrics: Dict[str, Dict[str, Any]]
    workflow_efficiency: float


@dataclass
class AggregatedMetrics:
    """Métricas agregadas para análise."""
    period_start: datetime
    period_end: datetime
    total_executions: int
    successful_executions: int
    failed_executions: int
    average_execution_time: float
    total_cost: float
    cost_per_execution: float
    most_used_agents: List[str]
    performance_trends: Dict[str, List[float]]


class TeamMetricsCollector:
    """Coletor de métricas para equipes de agentes."""
    
    def __init__(self, db_connection):
        """
        Inicializa o coletor de métricas.
        
        Args:
            db_connection: Conexão com o banco de dados
        """
        self.db = db_connection
        self.metrics_cache = {}
    
    async def collect_execution_metrics(
        self, 
        execution_id: UUID,
        team_id: UUID,
        agent_results: Dict[str, Dict[str, Any]]
    ) -> TeamPerformanceMetrics:
        """
        Coleta métricas de uma execução específica.
        
        Args:
            execution_id: ID da execução
            team_id: ID da equipe
            agent_results: Resultados dos agentes individuais
            
        Returns:
            Métricas de performance da equipe
        """
        try:
            # Calcula métricas básicas
            total_execution_time = 0.0
            total_cost = 0.0
            total_tokens = 0
            successful_agents = 0
            agent_metrics = {}
            
            for agent_id, result in agent_results.items():
                execution_time = result.get('execution_time', 0.0)
                cost = result.get('cost_metrics', {}).get('cost_usd', 0.0)
                tokens = result.get('usage_metrics', {}).get('tokens_input', 0) + \
                        result.get('usage_metrics', {}).get('tokens_output', 0)
                success = result.get('success', False)
                
                total_execution_time += execution_time
                total_cost += cost
                total_tokens += tokens
                
                if success:
                    successful_agents += 1
                
                agent_metrics[agent_id] = {
                    'execution_time': execution_time,
                    'cost': cost,
                    'tokens': tokens,
                    'success': success,
                    'efficiency_score': self._calculate_agent_efficiency(result)
                }
            
            # Calcula métricas derivadas
            num_agents = len(agent_results)
            average_agent_time = total_execution_time / num_agents if num_agents > 0 else 0.0
            success_rate = successful_agents / num_agents if num_agents > 0 else 0.0
            workflow_efficiency = self._calculate_workflow_efficiency(agent_results)
            
            metrics = TeamPerformanceMetrics(
                execution_id=execution_id,
                team_id=team_id,
                total_execution_time=total_execution_time,
                average_agent_time=average_agent_time,
                success_rate=success_rate,
                total_cost=total_cost,
                total_tokens=total_tokens,
                agent_metrics=agent_metrics,
                workflow_efficiency=workflow_efficiency
            )
            
            # Salva métricas no banco
            await self._save_metrics_to_db(metrics)
            
            logger.info(f"Métricas coletadas para execução {execution_id}")
            return metrics
            
        except Exception as e:
            logger.error(f"Erro ao coletar métricas da execução {execution_id}: {e}")
            raise
    
    async def get_team_analytics(
        self, 
        team_id: UUID,
        period_days: int = 30
    ) -> Dict[str, Any]:
        """
        Obtém análises de uma equipe específica.
        
        Args:
            team_id: ID da equipe
            period_days: Período em dias para análise
            
        Returns:
            Dicionário com análises da equipe
        """
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=period_days)
            
            # Busca execuções do período
            executions = await self._get_team_executions(team_id, start_date, end_date)
            
            if not executions:
                return {
                    'team_id': str(team_id),
                    'period_days': period_days,
                    'total_executions': 0,
                    'message': 'Nenhuma execução encontrada no período'
                }
            
            # Calcula estatísticas
            total_executions = len(executions)
            successful_executions = sum(1 for e in executions if e.get('success', False))
            failed_executions = total_executions - successful_executions
            
            total_cost = sum(e.get('total_cost', 0.0) for e in executions)
            total_time = sum(e.get('total_execution_time', 0.0) for e in executions)
            
            average_execution_time = total_time / total_executions if total_executions > 0 else 0.0
            cost_per_execution = total_cost / total_executions if total_executions > 0 else 0.0
            success_rate = successful_executions / total_executions if total_executions > 0 else 0.0
            
            # Análise de tendências
            trends = self._calculate_trends(executions)
            
            # Agentes mais utilizados
            agent_usage = self._analyze_agent_usage(executions)
            
            return {
                'team_id': str(team_id),
                'period_days': period_days,
                'period_start': start_date.isoformat(),
                'period_end': end_date.isoformat(),
                'summary': {
                    'total_executions': total_executions,
                    'successful_executions': successful_executions,
                    'failed_executions': failed_executions,
                    'success_rate': round(success_rate * 100, 2),
                    'total_cost': round(total_cost, 4),
                    'cost_per_execution': round(cost_per_execution, 4),
                    'average_execution_time': round(average_execution_time, 2),
                    'total_execution_time': round(total_time, 2)
                },
                'trends': trends,
                'agent_usage': agent_usage,
                'recommendations': self._generate_recommendations(executions)
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter análises da equipe {team_id}: {e}")
            raise
    
    async def get_global_metrics(self, period_days: int = 7) -> AggregatedMetrics:
        """
        Obtém métricas globais do sistema.
        
        Args:
            period_days: Período em dias para análise
            
        Returns:
            Métricas agregadas do sistema
        """
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=period_days)
            
            # Busca todas as execuções do período
            all_executions = await self._get_all_executions(start_date, end_date)
            
            total_executions = len(all_executions)
            successful_executions = sum(1 for e in all_executions if e.get('success', False))
            failed_executions = total_executions - successful_executions
            
            total_cost = sum(e.get('total_cost', 0.0) for e in all_executions)
            total_time = sum(e.get('total_execution_time', 0.0) for e in all_executions)
            
            average_execution_time = total_time / total_executions if total_executions > 0 else 0.0
            cost_per_execution = total_cost / total_executions if total_executions > 0 else 0.0
            
            # Agentes mais utilizados globalmente
            most_used_agents = self._get_most_used_agents(all_executions)
            
            # Tendências de performance
            performance_trends = self._calculate_global_trends(all_executions)
            
            return AggregatedMetrics(
                period_start=start_date,
                period_end=end_date,
                total_executions=total_executions,
                successful_executions=successful_executions,
                failed_executions=failed_executions,
                average_execution_time=average_execution_time,
                total_cost=total_cost,
                cost_per_execution=cost_per_execution,
                most_used_agents=most_used_agents,
                performance_trends=performance_trends
            )
            
        except Exception as e:
            logger.error(f"Erro ao obter métricas globais: {e}")
            raise
    
    def _calculate_agent_efficiency(self, agent_result: Dict[str, Any]) -> float:
        """
        Calcula a eficiência de um agente baseado em seus resultados.
        
        Args:
            agent_result: Resultado do agente
            
        Returns:
            Score de eficiência (0-100)
        """
        try:
            success = agent_result.get('success', False)
            execution_time = agent_result.get('execution_time', 0.0)
            cost = agent_result.get('cost_metrics', {}).get('cost_usd', 0.0)
            
            if not success:
                return 0.0
            
            # Score baseado em tempo e custo (simplificado)
            time_score = max(0, 100 - (execution_time * 2))  # Penaliza tempo alto
            cost_score = max(0, 100 - (cost * 1000))  # Penaliza custo alto
            
            return (time_score + cost_score) / 2
            
        except Exception:
            return 0.0
    
    def _calculate_workflow_efficiency(self, agent_results: Dict[str, Dict[str, Any]]) -> float:
        """
        Calcula a eficiência geral do workflow.
        
        Args:
            agent_results: Resultados de todos os agentes
            
        Returns:
            Score de eficiência do workflow (0-100)
        """
        try:
            if not agent_results:
                return 0.0
            
            agent_efficiencies = [
                self._calculate_agent_efficiency(result) 
                for result in agent_results.values()
            ]
            
            return sum(agent_efficiencies) / len(agent_efficiencies)
            
        except Exception:
            return 0.0
    
    async def _save_metrics_to_db(self, metrics: TeamPerformanceMetrics):
        """
        Salva métricas no banco de dados.
        
        Args:
            metrics: Métricas para salvar
        """
        try:
            # Implementação simplificada - em produção salvaria no banco
            logger.info(f"Salvando métricas da execução {metrics.execution_id}")
            
        except Exception as e:
            logger.error(f"Erro ao salvar métricas: {e}")
    
    async def _get_team_executions(
        self, 
        team_id: UUID, 
        start_date: datetime, 
        end_date: datetime
    ) -> List[Dict[str, Any]]:
        """
        Busca execuções de uma equipe no período especificado.
        
        Args:
            team_id: ID da equipe
            start_date: Data de início
            end_date: Data de fim
            
        Returns:
            Lista de execuções
        """
        try:
            # Implementação simplificada - em produção buscaria do banco
            return []
            
        except Exception as e:
            logger.error(f"Erro ao buscar execuções da equipe {team_id}: {e}")
            return []
    
    async def _get_all_executions(
        self, 
        start_date: datetime, 
        end_date: datetime
    ) -> List[Dict[str, Any]]:
        """
        Busca todas as execuções no período especificado.
        
        Args:
            start_date: Data de início
            end_date: Data de fim
            
        Returns:
            Lista de execuções
        """
        try:
            # Implementação simplificada - em produção buscaria do banco
            return []
            
        except Exception as e:
            logger.error(f"Erro ao buscar todas as execuções: {e}")
            return []
    
    def _calculate_trends(self, executions: List[Dict[str, Any]]) -> Dict[str, List[float]]:
        """
        Calcula tendências baseadas nas execuções.
        
        Args:
            executions: Lista de execuções
            
        Returns:
            Dicionário com tendências
        """
        return {
            'success_rate': [],
            'execution_time': [],
            'cost': [],
            'efficiency': []
        }
    
    def _analyze_agent_usage(self, executions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analisa o uso de agentes nas execuções.
        
        Args:
            executions: Lista de execuções
            
        Returns:
            Análise de uso de agentes
        """
        return {
            'most_used': [],
            'best_performing': [],
            'cost_effective': []
        }
    
    def _get_most_used_agents(self, executions: List[Dict[str, Any]]) -> List[str]:
        """
        Obtém os agentes mais utilizados.
        
        Args:
            executions: Lista de execuções
            
        Returns:
            Lista de agentes mais utilizados
        """
        return []
    
    def _calculate_global_trends(self, executions: List[Dict[str, Any]]) -> Dict[str, List[float]]:
        """
        Calcula tendências globais do sistema.
        
        Args:
            executions: Lista de execuções
            
        Returns:
            Tendências globais
        """
        return {
            'daily_executions': [],
            'success_rate': [],
            'average_cost': [],
            'system_load': []
        }
    
    def _generate_recommendations(self, executions: List[Dict[str, Any]]) -> List[str]:
        """
        Gera recomendações baseadas nas métricas.
        
        Args:
            executions: Lista de execuções
            
        Returns:
            Lista de recomendações
        """
        recommendations = []
        
        if not executions:
            return ["Nenhuma execução encontrada para análise"]
        
        # Análise simplificada
        success_rate = sum(1 for e in executions if e.get('success', False)) / len(executions)
        
        if success_rate < 0.8:
            recommendations.append("Taxa de sucesso baixa. Considere revisar a configuração dos agentes.")
        
        avg_cost = sum(e.get('total_cost', 0.0) for e in executions) / len(executions)
        if avg_cost > 1.0:
            recommendations.append("Custo médio alto. Considere otimizar o uso de modelos de IA.")
        
        if len(recommendations) == 0:
            recommendations.append("Performance da equipe está dentro dos parâmetros esperados.")
        
        return recommendations