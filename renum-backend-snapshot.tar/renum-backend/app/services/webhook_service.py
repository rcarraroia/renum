"""
Serviço de Webhook para integrações de agentes.

Este módulo implementa a lógica de negócio para webhooks de integrações,
incluindo geração e validação de tokens, rate limiting e logging de chamadas.
"""

import secrets
import logging
import time
from typing import Dict, Any, Optional, List
from uuid import UUID
from datetime import datetime, timedelta

from app.models.integrations import (
    AgentIntegration,
    WebhookCall,
    IntegrationStats,
    WebhookValidationResult,
    IntegrationStatus
)
from app.core.supabase_client import SupabaseClient
from app.services.suna_integration import SunaIntegrationService

# Configurar logger
logger = logging.getLogger(__name__)


class WebhookTokenService:
    """Serviço para geração e validação de tokens de webhook."""
    
    TOKEN_PREFIX = "whk_"
    TOKEN_LENGTH = 32  # 32 caracteres após o prefixo
    
    @classmethod
    def generate_webhook_token(cls) -> str:
        """
        Gera um token único para webhook.
        
        Returns:
            str: Token no formato 'whk_' + 32 caracteres aleatórios
        """
        random_part = secrets.token_urlsafe(cls.TOKEN_LENGTH)
        token = f"{cls.TOKEN_PREFIX}{random_part}"
        
        logger.info(f"Token de webhook gerado: {token[:8]}...")
        return token
    
    @classmethod
    async def validate_webhook_token(
        cls, 
        token: str, 
        agent_id: UUID
    ) -> WebhookValidationResult:
        """
        Valida um token de webhook e retorna informações da integração.
        
        Args:
            token: Token a ser validado
            agent_id: ID do agente esperado
            
        Returns:
            WebhookValidationResult: Resultado da validação
        """
        try:
            supabase = SupabaseClient.get_instance().client
            
            # Chamar função do banco para validar token
            result = supabase.rpc('renum_validate_webhook_token', {
                'p_token': token,
                'p_agent_id': str(agent_id)
            }).execute()
            
            if result.data and len(result.data) > 0:
                data = result.data[0]
                
                return WebhookValidationResult(
                    integration_id=UUID(data['integration_id']) if data['integration_id'] else None,
                    client_id=UUID(data['client_id']) if data['client_id'] else None,
                    rate_limit_per_minute=data['rate_limit_per_minute'],
                    is_valid=data['is_valid']
                )
            else:
                return WebhookValidationResult(
                    integration_id=None,
                    client_id=None,
                    rate_limit_per_minute=None,
                    is_valid=False
                )
                
        except Exception as e:
            logger.error(f"Erro ao validar token de webhook: {e}")
            return WebhookValidationResult(
                integration_id=None,
                client_id=None,
                rate_limit_per_minute=None,
                is_valid=False
            )
    
    @classmethod
    def validate_token_format(cls, token: str) -> bool:
        """
        Valida o formato do token.
        
        Args:
            token: Token a ser validado
            
        Returns:
            bool: True se o formato está correto
        """
        if not token or not isinstance(token, str):
            return False
            
        if not token.startswith(cls.TOKEN_PREFIX):
            return False
            
        if len(token) < len(cls.TOKEN_PREFIX) + cls.TOKEN_LENGTH:
            return False
            
        return True


class WebhookRateLimitService:
    """Serviço para controle de rate limiting de webhooks."""
    
    def __init__(self, redis_client=None):
        """
        Inicializa o serviço de rate limiting.
        
        Args:
            redis_client: Cliente Redis para armazenar contadores
        """
        self.redis_client = redis_client
        self.rate_limit_prefix = "webhook_rate_limit:"
    
    async def check_rate_limit(
        self, 
        client_id: UUID, 
        limit_per_minute: int
    ) -> bool:
        """
        Verifica se o cliente não excedeu o rate limit.
        
        Args:
            client_id: ID do cliente
            limit_per_minute: Limite de chamadas por minuto
            
        Returns:
            bool: True se dentro do limite, False se excedeu
        """
        if not self.redis_client:
            # Se Redis não disponível, permitir (modo desenvolvimento)
            logger.warning("Redis não disponível - rate limiting desabilitado")
            return True
        
        try:
            key = f"{self.rate_limit_prefix}{client_id}"
            
            # Obter contador atual
            current_count = await self.redis_client.get(key)
            current_count = int(current_count) if current_count else 0
            
            # Verificar se excedeu o limite
            if current_count >= limit_per_minute:
                logger.warning(f"Rate limit excedido para cliente {client_id}: {current_count}/{limit_per_minute}")
                return False
            
            # Incrementar contador
            await self.redis_client.incr(key)
            
            # Definir TTL de 60 segundos se é a primeira chamada
            if current_count == 0:
                await self.redis_client.expire(key, 60)
            
            logger.debug(f"Rate limit OK para cliente {client_id}: {current_count + 1}/{limit_per_minute}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao verificar rate limit: {e}")
            # Em caso de erro, permitir a chamada
            return True
    
    async def get_rate_limit_info(self, client_id: UUID) -> Dict[str, Any]:
        """
        Obtém informações sobre o rate limit atual do cliente.
        
        Args:
            client_id: ID do cliente
            
        Returns:
            Dict com informações do rate limit
        """
        if not self.redis_client:
            return {
                "current_count": 0,
                "ttl": 0,
                "redis_available": False
            }
        
        try:
            key = f"{self.rate_limit_prefix}{client_id}"
            
            current_count = await self.redis_client.get(key)
            current_count = int(current_count) if current_count else 0
            
            ttl = await self.redis_client.ttl(key)
            ttl = ttl if ttl > 0 else 0
            
            return {
                "current_count": current_count,
                "ttl": ttl,
                "redis_available": True
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter info de rate limit: {e}")
            return {
                "current_count": 0,
                "ttl": 0,
                "redis_available": False,
                "error": str(e)
            }


class WebhookAuditService:
    """Serviço para auditoria e logging de chamadas webhook."""
    
    @classmethod
    async def log_webhook_call(
        cls,
        integration_id: UUID,
        request_payload: Optional[Dict[str, Any]] = None,
        response_payload: Optional[Dict[str, Any]] = None,
        status_code: Optional[int] = None,
        execution_time_ms: Optional[int] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        error_message: Optional[str] = None
    ) -> bool:
        """
        Registra uma chamada webhook no log de auditoria.
        
        Args:
            integration_id: ID da integração
            request_payload: Payload da requisição
            response_payload: Payload da resposta
            status_code: Código de status HTTP
            execution_time_ms: Tempo de execução em ms
            ip_address: IP de origem
            user_agent: User-Agent do cliente
            error_message: Mensagem de erro, se houver
            
        Returns:
            bool: True se logado com sucesso
        """
        try:
            supabase = SupabaseClient.get_instance().client
            
            # Preparar dados para inserção
            log_data = {
                "integration_id": str(integration_id),
                "request_payload": request_payload,
                "response_payload": response_payload,
                "status_code": status_code,
                "execution_time_ms": execution_time_ms,
                "ip_address": ip_address,
                "user_agent": user_agent,
                "error_message": error_message,
                "created_at": datetime.now().isoformat()
            }
            
            # Inserir no banco
            result = supabase.table('renum_webhook_calls').insert(log_data).execute()
            
            if result.data:
                logger.info(f"Chamada webhook logada: {integration_id}")
                return True
            else:
                logger.error(f"Falha ao logar chamada webhook: {integration_id}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao logar chamada webhook: {e}")
            return False
    
    @classmethod
    async def get_integration_stats(
        cls,
        integration_id: UUID,
        hours: int = 24
    ) -> Optional[IntegrationStats]:
        """
        Obtém estatísticas de uso de uma integração.
        
        Args:
            integration_id: ID da integração
            hours: Período em horas para as estatísticas
            
        Returns:
            IntegrationStats ou None se erro
        """
        try:
            supabase = SupabaseClient.get_instance().client
            
            # Chamar função do banco para obter estatísticas
            result = supabase.rpc('renum_get_integration_stats', {
                'p_integration_id': str(integration_id),
                'p_hours': hours
            }).execute()
            
            if result.data and len(result.data) > 0:
                data = result.data[0]
                
                return IntegrationStats(
                    integration_id=integration_id,
                    total_calls=data['total_calls'] or 0,
                    successful_calls=data['successful_calls'] or 0,
                    failed_calls=data['failed_calls'] or 0,
                    avg_execution_time_ms=float(data['avg_execution_time_ms']) if data['avg_execution_time_ms'] else None,
                    last_call_at=datetime.fromisoformat(data['last_call_at']) if data['last_call_at'] else None,
                    period_hours=hours
                )
            else:
                # Retornar estatísticas vazias se não há dados
                return IntegrationStats(
                    integration_id=integration_id,
                    total_calls=0,
                    successful_calls=0,
                    failed_calls=0,
                    avg_execution_time_ms=None,
                    last_call_at=None,
                    period_hours=hours
                )
                
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas da integração: {e}")
            return None


class WebhookExecutionService:
    """Serviço para execução de agentes via webhook."""
    
    def __init__(self):
        """Inicializa o serviço de execução."""
        self.suna_service = SunaIntegrationService.get_instance()
    
    async def execute_agent_via_webhook(
        self,
        agent_id: UUID,
        client_id: UUID,
        payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Executa um agente via webhook.
        
        Args:
            agent_id: ID do agente
            client_id: ID do cliente
            payload: Dados de entrada
            
        Returns:
            Dict com resposta do agente
        """
        try:
            # Extrair prompt do payload
            # Tentar diferentes campos comuns para o prompt
            prompt = None
            if "message" in payload:
                prompt = payload["message"]
            elif "prompt" in payload:
                prompt = payload["prompt"]
            elif "text" in payload:
                prompt = payload["text"]
            elif "input" in payload:
                prompt = payload["input"]
            else:
                # Se não encontrar campos conhecidos, usar o payload inteiro como contexto
                prompt = f"Dados recebidos via webhook: {payload}"
            
            # Preparar metadados do webhook
            metadata = {
                "source": "webhook",
                "webhook_payload": payload,
                "client_id": str(client_id),
                "timestamp": datetime.now().isoformat()
            }
            
            # Executar agente via Suna Integration Service
            # Usar um user_id genérico para webhooks (pode ser configurável)
            webhook_user_id = client_id  # Por enquanto, usar client_id como user_id
            
            execution = await self.suna_service.execute_agent(
                agent_id=agent_id,
                user_id=webhook_user_id,
                prompt=prompt,
                metadata=metadata
            )
            
            # Preparar resposta baseada na execução
            result = {
                "execution_id": str(execution.id),
                "agent_id": str(agent_id),
                "status": execution.status.value,
                "response": execution.output,
                "tokens_used": execution.tokens_used,
                "context_used": execution.context_used
            }
            
            logger.info(f"Agente {agent_id} executado via webhook com sucesso - Execução: {execution.id}")
            return result
            
        except Exception as e:
            logger.error(f"Erro ao executar agente via webhook: {e}")
            raise


class WebhookService:
    """Serviço principal para gerenciamento de webhooks."""
    
    def __init__(self, redis_client=None):
        """
        Inicializa o serviço de webhook.
        
        Args:
            redis_client: Cliente Redis para rate limiting
        """
        self.token_service = WebhookTokenService()
        self.rate_limit_service = WebhookRateLimitService(redis_client)
        self.audit_service = WebhookAuditService()
        self.execution_service = WebhookExecutionService()
        
        logger.info("WebhookService inicializado")
    
    async def process_webhook_call(
        self,
        agent_id: UUID,
        token: str,
        payload: Dict[str, Any],
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Processa uma chamada webhook completa.
        
        Args:
            agent_id: ID do agente
            token: Token de autenticação
            payload: Dados da requisição
            ip_address: IP de origem
            user_agent: User-Agent do cliente
            
        Returns:
            Dict com resposta da execução
            
        Raises:
            ValueError: Se token inválido
            PermissionError: Se rate limit excedido
            Exception: Se erro na execução
        """
        start_time = time.time()
        integration_id = None
        
        try:
            # 1. Validar formato do token
            if not self.token_service.validate_token_format(token):
                raise ValueError("Formato de token inválido")
            
            # 2. Validar token no banco
            validation_result = await self.token_service.validate_webhook_token(token, agent_id)
            
            if not validation_result.is_valid:
                raise ValueError("Token inválido ou agente não autorizado")
            
            integration_id = validation_result.integration_id
            client_id = validation_result.client_id
            rate_limit = validation_result.rate_limit_per_minute
            
            # 3. Verificar rate limiting
            if not await self.rate_limit_service.check_rate_limit(client_id, rate_limit):
                raise PermissionError("Rate limit excedido")
            
            # 4. Executar agente
            response = await self.execution_service.execute_agent_via_webhook(
                agent_id=agent_id,
                client_id=client_id,
                payload=payload
            )
            
            # 5. Calcular tempo de execução
            execution_time_ms = int((time.time() - start_time) * 1000)
            
            # 6. Logar chamada bem-sucedida
            await self.audit_service.log_webhook_call(
                integration_id=integration_id,
                request_payload=payload,
                response_payload=response,
                status_code=200,
                execution_time_ms=execution_time_ms,
                ip_address=ip_address,
                user_agent=user_agent
            )
            
            return {
                "success": True,
                "data": response,
                "execution_time_ms": execution_time_ms
            }
            
        except Exception as e:
            # Calcular tempo até o erro
            execution_time_ms = int((time.time() - start_time) * 1000)
            
            # Determinar status code baseado no tipo de erro
            if isinstance(e, ValueError):
                status_code = 403
            elif isinstance(e, PermissionError):
                status_code = 429
            else:
                status_code = 500
            
            # Logar chamada com erro
            if integration_id:
                await self.audit_service.log_webhook_call(
                    integration_id=integration_id,
                    request_payload=payload,
                    response_payload={"error": str(e)},
                    status_code=status_code,
                    execution_time_ms=execution_time_ms,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    error_message=str(e)
                )
            
            # Re-raise para tratamento no endpoint
            raise


# Instância singleton do serviço
_webhook_service_instance = None

def get_webhook_service(redis_client=None) -> WebhookService:
    """
    Obtém instância singleton do WebhookService.
    
    Args:
        redis_client: Cliente Redis (opcional)
        
    Returns:
        WebhookService: Instância do serviço
    """
    global _webhook_service_instance
    
    if _webhook_service_instance is None:
        _webhook_service_instance = WebhookService(redis_client)
    
    return _webhook_service_instance