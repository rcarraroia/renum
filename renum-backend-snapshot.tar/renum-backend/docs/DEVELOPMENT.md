# Desenvolvimento

## Estrutura do Projeto

```
renum-backend/
├── app/
│   ├── api/
│   │   ├── routes/
│   │   │   ├── teams.py
│   │   │   └── team_executions.py
│   ├── core/
│   │   ├── auth.py
│   │   ├── config.py
│   │   ├── dependencies.py
│   │   └── logger.py
│   ├── db/
│   │   └── database.py
│   ├── models/
│   │   └── team_models.py
│   ├── repositories/
│   │   ├── team_repository.py
│   │   └── team_execution_repository.py
│   ├── services/
│   │   ├── api_key_manager.py
│   │   ├── execution_engine.py
│   │   ├── suna_api_client.py
│   │   ├── team_context_manager.py
│   │   ├── team_message_bus.py
│   │   └── team_orchestrator.py
│   └── main.py
├── scripts/
│   ├── apply_team_tables.py
│   ├── create_team_tables.sql
│   ├── run_server.py
│   ├── test_installation.py
│   └── test_team_api.py
├── tests/
│   ├── conftest.py
│   ├── test_api.py
│   ├── test_execution_engine.py
│   ├── test_suna_api_client.py
│   ├── test_team_orchestrator.py
│   └── test_team_repository.py
├── .env.example
├── .gitignore
├── API_DOCUMENTATION.md
├── CONCLUSAO.md
├── docker-compose.yml
├── Dockerfile
├── EXECUTION_INSTRUCTIONS.md
├── IMPLEMENTATION_SUMMARY.md
├── pyproject.toml
├── README.md
└── requirements.txt
```

## Testes

```bash
# Execute os testes
pytest

# Execute os testes com cobertura
pytest --cov=app

# Execute testes específicos
pytest tests/test_team_repository.py
pytest tests/test_team_orchestrator.py
pytest tests/test_execution_engine.py
pytest tests/test_suna_api_client.py
pytest tests/test_api.py
```

## Próximos Passos

1. **Testes de Integração**: Implementar testes end-to-end das estratégias e fluxos completos.
2. **Frontend**: Desenvolver a interface para gerenciamento de equipes, visualizador de fluxo e dashboard de monitoramento.
3. **Otimizações de Performance**: Implementar otimizações para melhorar a performance do sistema.
4. **Recursos Avançados**: Implementar recursos avançados como sistema de aprovações, ferramentas para agentes e templates de equipe.