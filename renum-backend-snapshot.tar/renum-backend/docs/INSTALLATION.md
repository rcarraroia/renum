# Instalação do Renum Backend

## Requisitos

- Python 3.9+
- Redis 6.0+
- Supabase (PostgreSQL 13+)
- Acesso ao Suna Core API

## Instalação

### Usando Docker

```bash
# Clone o repositório
git clone https://github.com/renum/renum-backend.git
cd renum-backend

# Configure as variáveis de ambiente
cp .env.example .env
# Edite o arquivo .env com suas configurações

# Inicie os contêineres
docker-compose up -d
```

### Instalação Local

```bash
# Clone o repositório
git clone https://github.com/renum/renum-backend.git
cd renum-backend

# Crie e ative um ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\\Scripts\\activate  # Windows

# Instale as dependências
pip install -r requirements.txt
pip install -e .

# Configure as variáveis de ambiente
cp .env.example .env
# Edite o arquivo .env com suas configurações

# Aplique o schema do banco de dados
python scripts/apply_team_tables.py

# Teste a instalação
python scripts/test_installation.py

# Inicie o servidor
python scripts/run_server.py
# ou
uvicorn app.main:app --host 0.0.0.0 --port 9000 --reload
```