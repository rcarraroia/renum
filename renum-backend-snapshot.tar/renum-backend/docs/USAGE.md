# Uso do Renum Backend

## API

A API está disponível em `http://localhost:9000/api/v1`.

A documentação da API está disponível em `http://localhost:9000/docs`.

## Exemplos

### Criar uma equipe

```bash
curl -X POST http://localhost:9000/api/v1/teams \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "name": "Equipe de Análise de Dados",
    "description": "Equipe para análise de dados financeiros",
    "agent_ids": ["agent-123", "agent-456", "agent-789"],
    "workflow_definition": {
      "type": "sequential",
      "agents": [
        {
          "agent_id": "agent-123",
          "role": "leader",
          "execution_order": 1,
          "input": {
            "source": "initial_prompt"
          }
        },
        {
          "agent_id": "agent-456",
          "role": "member",
          "execution_order": 2,
          "input": {
            "source": "agent_result",
            "agent_id": "agent-123"
          }
        },
        {
          "agent_id": "agent-789",
          "role": "member",
          "execution_order": 3,
          "input": {
            "source": "combined",
            "sources": [
              {"type": "agent_result", "agent_id": "agent-123"},
              {"type": "agent_result", "agent_id": "agent-456"}
            ]
          }
        }
      ]
    }
  }'
```

### Executar uma equipe

```bash
curl -X POST http://localhost:9000/api/v1/teams/TEAM_ID/execute \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "team_id": "TEAM_ID",
    "initial_prompt": "Analise os dados financeiros da empresa XYZ e prepare um relatório."
  }'
```