-- Migration: webhook_integrations_001_initial.sql
-- Description: Create initial tables for webhook integrations
-- Version: 1.0.0
-- Date: 2024-01-15

BEGIN;

-- Create enum for integration channels
CREATE TYPE integration_channel AS ENUM (
    'whatsapp',
    'telegram', 
    'zapier',
    'n8n',
    'make',
    'custom'
);

-- Create enum for webhook call status
CREATE TYPE webhook_call_status AS ENUM (
    'success',
    'error',
    'timeout',
    'rate_limited'
);

-- Create renum_agent_integrations table
CREATE TABLE IF NOT EXISTS renum_agent_integrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    agent_id UUID NOT NULL,
    channel integration_channel NOT NULL,
    webhook_token VARCHAR(255) UNIQUE NOT NULL,
    webhook_url TEXT NOT NULL,
    is_active BOOLEAN DEFAULT true,
    rate_limit_per_minute INTEGER DEFAULT 60 CHECK (rate_limit_per_minute > 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by UUID,
    
    -- Constraints
    CONSTRAINT unique_agent_channel UNIQUE (agent_id, channel),
    CONSTRAINT valid_webhook_token CHECK (webhook_token ~ '^whk_[a-zA-Z0-9]{48,}$'),
    CONSTRAINT valid_rate_limit CHECK (rate_limit_per_minute BETWEEN 1 AND 10000)
);

-- Create renum_webhook_calls table
CREATE TABLE IF NOT EXISTS renum_webhook_calls (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_id UUID NOT NULL REFERENCES renum_agent_integrations(id) ON DELETE CASCADE,
    agent_id UUID NOT NULL,
    channel integration_channel NOT NULL,
    status webhook_call_status NOT NULL,
    http_status_code INTEGER,
    request_payload JSONB,
    response_payload JSONB,
    error_message TEXT,
    execution_time_ms INTEGER,
    ip_address INET,
    user_agent TEXT,
    request_id VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT valid_http_status CHECK (http_status_code BETWEEN 100 AND 599),
    CONSTRAINT valid_execution_time CHECK (execution_time_ms >= 0),
    CONSTRAINT payload_size_limit CHECK (
        pg_column_size(request_payload) <= 10485760 AND 
        pg_column_size(response_payload) <= 10485760
    )
);

-- Create indexes for performance
CREATE INDEX idx_agent_integrations_agent_id ON renum_agent_integrations(agent_id);
CREATE INDEX idx_agent_integrations_channel ON renum_agent_integrations(channel);
CREATE INDEX idx_agent_integrations_active ON renum_agent_integrations(is_active) WHERE is_active = true;
CREATE INDEX idx_agent_integrations_token ON renum_agent_integrations(webhook_token);
CREATE INDEX idx_agent_integrations_created_at ON renum_agent_integrations(created_at);

CREATE INDEX idx_webhook_calls_integration_id ON renum_webhook_calls(integration_id);
CREATE INDEX idx_webhook_calls_agent_id ON renum_webhook_calls(agent_id);
CREATE INDEX idx_webhook_calls_channel ON renum_webhook_calls(channel);
CREATE INDEX idx_webhook_calls_status ON renum_webhook_calls(status);
CREATE INDEX idx_webhook_calls_created_at ON renum_webhook_calls(created_at);
CREATE INDEX idx_webhook_calls_ip_address ON renum_webhook_calls(ip_address);
CREATE INDEX idx_webhook_calls_request_id ON renum_webhook_calls(request_id);

-- Composite indexes for common queries
CREATE INDEX idx_webhook_calls_integration_status_date ON renum_webhook_calls(integration_id, status, created_at);
CREATE INDEX idx_webhook_calls_agent_date ON renum_webhook_calls(agent_id, created_at DESC);
CREATE INDEX idx_webhook_calls_error_analysis ON renum_webhook_calls(status, http_status_code, created_at) 
    WHERE status = 'error';

-- GIN index for JSONB payload searches
CREATE INDEX idx_webhook_calls_request_payload_gin ON renum_webhook_calls USING GIN (request_payload);
CREATE INDEX idx_webhook_calls_response_payload_gin ON renum_webhook_calls USING GIN (response_payload);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
CREATE TRIGGER update_agent_integrations_updated_at 
    BEFORE UPDATE ON renum_agent_integrations 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Create function for webhook call statistics
CREATE OR REPLACE FUNCTION get_webhook_stats(
    p_integration_id UUID DEFAULT NULL,
    p_agent_id UUID DEFAULT NULL,
    p_start_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP - INTERVAL '24 hours',
    p_end_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
)
RETURNS TABLE (
    total_calls BIGINT,
    successful_calls BIGINT,
    error_calls BIGINT,
    success_rate NUMERIC,
    avg_execution_time NUMERIC,
    p95_execution_time NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COUNT(*) as total_calls,
        COUNT(*) FILTER (WHERE status = 'success') as successful_calls,
        COUNT(*) FILTER (WHERE status = 'error') as error_calls,
        ROUND(
            (COUNT(*) FILTER (WHERE status = 'success')::NUMERIC / NULLIF(COUNT(*), 0)) * 100, 
            2
        ) as success_rate,
        ROUND(AVG(execution_time_ms), 2) as avg_execution_time,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY execution_time_ms), 2) as p95_execution_time
    FROM renum_webhook_calls
    WHERE 
        created_at BETWEEN p_start_date AND p_end_date
        AND (p_integration_id IS NULL OR integration_id = p_integration_id)
        AND (p_agent_id IS NULL OR agent_id = p_agent_id);
END;
$$ LANGUAGE plpgsql;

-- Create function for rate limiting cleanup
CREATE OR REPLACE FUNCTION cleanup_old_webhook_calls(
    p_retention_days INTEGER DEFAULT 90
)
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM renum_webhook_calls 
    WHERE created_at < CURRENT_TIMESTAMP - (p_retention_days || ' days')::INTERVAL;
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    -- Log the cleanup
    INSERT INTO renum_webhook_calls (
        integration_id, agent_id, channel, status, 
        request_payload, response_payload, 
        execution_time_ms, created_at
    ) VALUES (
        '00000000-0000-0000-0000-000000000000'::UUID,
        '00000000-0000-0000-0000-000000000000'::UUID,
        'custom',
        'success',
        jsonb_build_object('cleanup', true, 'deleted_count', deleted_count),
        jsonb_build_object('message', 'Cleanup completed successfully'),
        0,
        CURRENT_TIMESTAMP
    );
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Create view for integration analytics
CREATE VIEW webhook_integration_analytics AS
SELECT 
    ai.id,
    ai.name,
    ai.agent_id,
    ai.channel,
    ai.is_active,
    ai.rate_limit_per_minute,
    ai.created_at,
    COUNT(wc.id) as total_calls,
    COUNT(wc.id) FILTER (WHERE wc.status = 'success') as successful_calls,
    COUNT(wc.id) FILTER (WHERE wc.status = 'error') as error_calls,
    COUNT(wc.id) FILTER (WHERE wc.status = 'rate_limited') as rate_limited_calls,
    ROUND(
        (COUNT(wc.id) FILTER (WHERE wc.status = 'success')::NUMERIC / NULLIF(COUNT(wc.id), 0)) * 100, 
        2
    ) as success_rate,
    ROUND(AVG(wc.execution_time_ms), 2) as avg_execution_time,
    MAX(wc.created_at) as last_call_at
FROM renum_agent_integrations ai
LEFT JOIN renum_webhook_calls wc ON ai.id = wc.integration_id
GROUP BY ai.id, ai.name, ai.agent_id, ai.channel, ai.is_active, ai.rate_limit_per_minute, ai.created_at;

-- Grant permissions
GRANT SELECT, INSERT, UPDATE, DELETE ON renum_agent_integrations TO suna_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON renum_webhook_calls TO suna_app;
GRANT SELECT ON webhook_integration_analytics TO suna_app;
GRANT EXECUTE ON FUNCTION get_webhook_stats TO suna_app;
GRANT EXECUTE ON FUNCTION cleanup_old_webhook_calls TO suna_app;

-- Insert initial data for testing (optional)
-- INSERT INTO renum_agent_integrations (
--     name, agent_id, channel, webhook_token, webhook_url, created_by
-- ) VALUES (
--     'Test WhatsApp Integration',
--     '00000000-0000-0000-0000-000000000001'::UUID,
--     'whatsapp',
--     'whk_test_token_for_development_only_12345678901234567890',
--     'https://api.suna.com/v1/webhook/00000000-0000-0000-0000-000000000001/whatsapp',
--     '00000000-0000-0000-0000-000000000000'::UUID
-- );

COMMIT;

-- Migration completed successfully
-- Run the following command to verify:
-- SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name LIKE 'renum_%webhook%' OR table_name LIKE 'renum_agent_integrations';