-- Rollback: webhook_integrations_001_rollback.sql
-- Description: Rollback initial webhook integrations tables
-- Version: 1.0.0
-- Date: 2024-01-15

BEGIN;

-- Drop view
DROP VIEW IF EXISTS webhook_integration_analytics;

-- Drop functions
DROP FUNCTION IF EXISTS get_webhook_stats(UUID, UUID, TIMESTAMP WITH TIME ZONE, TIMESTAMP WITH TIME ZONE);
DROP FUNCTION IF EXISTS cleanup_old_webhook_calls(INTEGER);
DROP FUNCTION IF EXISTS update_updated_at_column();

-- Drop indexes
DROP INDEX IF EXISTS idx_webhook_calls_response_payload_gin;
DROP INDEX IF EXISTS idx_webhook_calls_request_payload_gin;
DROP INDEX IF EXISTS idx_webhook_calls_error_analysis;
DROP INDEX IF EXISTS idx_webhook_calls_agent_date;
DROP INDEX IF EXISTS idx_webhook_calls_integration_status_date;
DROP INDEX IF EXISTS idx_webhook_calls_request_id;
DROP INDEX IF EXISTS idx_webhook_calls_ip_address;
DROP INDEX IF EXISTS idx_webhook_calls_created_at;
DROP INDEX IF EXISTS idx_webhook_calls_status;
DROP INDEX IF EXISTS idx_webhook_calls_channel;
DROP INDEX IF EXISTS idx_webhook_calls_agent_id;
DROP INDEX IF EXISTS idx_webhook_calls_integration_id;
DROP INDEX IF EXISTS idx_agent_integrations_created_at;
DROP INDEX IF EXISTS idx_agent_integrations_token;
DROP INDEX IF EXISTS idx_agent_integrations_active;
DROP INDEX IF EXISTS idx_agent_integrations_channel;
DROP INDEX IF EXISTS idx_agent_integrations_agent_id;

-- Drop tables
DROP TABLE IF EXISTS renum_webhook_calls;
DROP TABLE IF EXISTS renum_agent_integrations;

-- Drop enums
DROP TYPE IF EXISTS webhook_call_status;
DROP TYPE IF EXISTS integration_channel;

COMMIT;

-- Rollback completed successfully
-- Verify with: SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND (table_name LIKE 'renum_%webhook%' OR table_name LIKE 'renum_agent_integrations');