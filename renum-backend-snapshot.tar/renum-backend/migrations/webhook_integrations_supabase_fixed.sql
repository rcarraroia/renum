-- Migration: webhook_integrations_supabase_fixed.sql
-- Description: Create initial tables for webhook integrations (Supabase - Fixed Version)
-- Execute this script in parts if needed

-- PART 1: Extensions and Types
-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enum for integration channels
DO $$ BEGIN
    CREATE TYPE integration_channel AS ENUM (
        'whatsapp',
        'telegram', 
        'zapier',
        'n8n',
        'make',
        'custom'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create enum for webhook call status
DO $$ BEGIN
    CREATE TYPE webhook_call_status AS ENUM (
        'success',
        'error',
        'timeout',
        'rate_limited'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- PART 2: Create Tables
-- Create renum_agent_integrations table
CREATE TABLE IF NOT EXISTS renum_agent_integrations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    agent_id UUID NOT NULL,
    channel integration_channel NOT NULL,
    webhook_token VARCHAR(255) UNIQUE NOT NULL,
    webhook_url TEXT NOT NULL,
    is_active BOOLEAN DEFAULT true,
    rate_limit_per_minute INTEGER DEFAULT 60,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID,
    
    -- Constraints
    CONSTRAINT unique_agent_channel UNIQUE (agent_id, channel),
    CONSTRAINT valid_webhook_token CHECK (webhook_token ~ '^whk_[a-zA-Z0-9]{48,}$'),
    CONSTRAINT valid_rate_limit CHECK (rate_limit_per_minute BETWEEN 1 AND 10000)
);

-- Create renum_webhook_calls table
CREATE TABLE IF NOT EXISTS renum_webhook_calls (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    integration_id UUID NOT NULL REFERENCES renum_agent_integrations(id) ON DELETE CASCADE,
    agent_id UUID NOT NULL,
    channel integration_channel NOT NULL,
    status webhook_call_status NOT NULL,
    http_status_code INTEGER,
    request_payload JSONB,
    response_payload JSONB,
    error_message TEXT,
    execution_time_ms INTEGER,
    ip_address INET,
    user_agent TEXT,
    request_id VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraints
    CONSTRAINT valid_http_status CHECK (http_status_code BETWEEN 100 AND 599),
    CONSTRAINT valid_execution_time CHECK (execution_time_ms >= 0)
);

-- PART 3: Create Indexes
-- Indexes for renum_agent_integrations
CREATE INDEX IF NOT EXISTS idx_agent_integrations_agent_id ON renum_agent_integrations(agent_id);
CREATE INDEX IF NOT EXISTS idx_agent_integrations_channel ON renum_agent_integrations(channel);
CREATE INDEX IF NOT EXISTS idx_agent_integrations_active ON renum_agent_integrations(is_active) WHERE is_active = true;
CREATE INDEX IF NOT EXISTS idx_agent_integrations_token ON renum_agent_integrations(webhook_token);
CREATE INDEX IF NOT EXISTS idx_agent_integrations_created_at ON renum_agent_integrations(created_at);

-- Indexes for renum_webhook_calls
CREATE INDEX IF NOT EXISTS idx_webhook_calls_integration_id ON renum_webhook_calls(integration_id);
CREATE INDEX IF NOT EXISTS idx_webhook_calls_agent_id ON renum_webhook_calls(agent_id);
CREATE INDEX IF NOT EXISTS idx_webhook_calls_channel ON renum_webhook_calls(channel);
CREATE INDEX IF NOT EXISTS idx_webhook_calls_status ON renum_webhook_calls(status);
CREATE INDEX IF NOT EXISTS idx_webhook_calls_created_at ON renum_webhook_calls(created_at);
CREATE INDEX IF NOT EXISTS idx_webhook_calls_ip_address ON renum_webhook_calls(ip_address);
CREATE INDEX IF NOT EXISTS idx_webhook_calls_request_id ON renum_webhook_calls(request_id);

-- Composite indexes for common queries
CREATE INDEX IF NOT EXISTS idx_webhook_calls_integration_status_date ON renum_webhook_calls(integration_id, status, created_at);
CREATE INDEX IF NOT EXISTS idx_webhook_calls_agent_date ON renum_webhook_calls(agent_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_webhook_calls_error_analysis ON renum_webhook_calls(status, http_status_code, created_at) 
    WHERE status = 'error';

-- GIN indexes for JSONB payload searches
CREATE INDEX IF NOT EXISTS idx_webhook_calls_request_payload_gin ON renum_webhook_calls USING GIN (request_payload);
CREATE INDEX IF NOT EXISTS idx_webhook_calls_response_payload_gin ON renum_webhook_calls USING GIN (response_payload);

-- PART 4: Functions and Triggers
-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
DROP TRIGGER IF EXISTS update_agent_integrations_updated_at ON renum_agent_integrations;
CREATE TRIGGER update_agent_integrations_updated_at 
    BEFORE UPDATE ON renum_agent_integrations 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- PART 5: Statistics Functions
-- Create function for webhook call statistics
CREATE OR REPLACE FUNCTION get_webhook_stats(
    p_integration_id UUID DEFAULT NULL,
    p_agent_id UUID DEFAULT NULL,
    p_start_date TIMESTAMP WITH TIME ZONE DEFAULT NOW() - INTERVAL '24 hours',
    p_end_date TIMESTAMP WITH TIME ZONE DEFAULT NOW()
)
RETURNS TABLE (
    total_calls BIGINT,
    successful_calls BIGINT,
    error_calls BIGINT,
    success_rate NUMERIC,
    avg_execution_time NUMERIC,
    p95_execution_time NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COUNT(*) as total_calls,
        COUNT(*) FILTER (WHERE status = 'success') as successful_calls,
        COUNT(*) FILTER (WHERE status = 'error') as error_calls,
        ROUND(
            (COUNT(*) FILTER (WHERE status = 'success')::NUMERIC / NULLIF(COUNT(*), 0)) * 100, 
            2
        ) as success_rate,
        ROUND(AVG(execution_time_ms), 2) as avg_execution_time,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY execution_time_ms), 2) as p95_execution_time
    FROM renum_webhook_calls
    WHERE 
        created_at BETWEEN p_start_date AND p_end_date
        AND (p_integration_id IS NULL OR integration_id = p_integration_id)
        AND (p_agent_id IS NULL OR agent_id = p_agent_id);
END;
$$ LANGUAGE plpgsql;

-- Create function for cleanup
CREATE OR REPLACE FUNCTION cleanup_old_webhook_calls(
    p_retention_days INTEGER DEFAULT 90
)
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM renum_webhook_calls 
    WHERE created_at < NOW() - (p_retention_days || ' days')::INTERVAL;
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- PART 6: Views
-- Create view for integration analytics
CREATE OR REPLACE VIEW webhook_integration_analytics AS
SELECT 
    ai.id,
    ai.name,
    ai.agent_id,
    ai.channel,
    ai.is_active,
    ai.rate_limit_per_minute,
    ai.created_at,
    COUNT(wc.id) as total_calls,
    COUNT(wc.id) FILTER (WHERE wc.status = 'success') as successful_calls,
    COUNT(wc.id) FILTER (WHERE wc.status = 'error') as error_calls,
    COUNT(wc.id) FILTER (WHERE wc.status = 'rate_limited') as rate_limited_calls,
    ROUND(
        (COUNT(wc.id) FILTER (WHERE wc.status = 'success')::NUMERIC / NULLIF(COUNT(wc.id), 0)) * 100, 
        2
    ) as success_rate,
    ROUND(AVG(wc.execution_time_ms), 2) as avg_execution_time,
    MAX(wc.created_at) as last_call_at
FROM renum_agent_integrations ai
LEFT JOIN renum_webhook_calls wc ON ai.id = wc.integration_id
GROUP BY ai.id, ai.name, ai.agent_id, ai.channel, ai.is_active, ai.rate_limit_per_minute, ai.created_at;

-- PART 7: Row Level Security (RLS)
-- Enable Row Level Security
ALTER TABLE renum_agent_integrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE renum_webhook_calls ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
-- Policy for authenticated users to manage their own integrations
CREATE POLICY "Users can manage their own integrations" ON renum_agent_integrations
    FOR ALL USING (auth.uid()::text = created_by::text);

-- Policy for webhook calls - allow insert for service role, select for owners
CREATE POLICY "Allow webhook call inserts" ON renum_webhook_calls
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view their integration calls" ON renum_webhook_calls
    FOR SELECT USING (
        integration_id IN (
            SELECT id FROM renum_agent_integrations 
            WHERE created_by = auth.uid()
        )
    );

-- PART 8: Permissions
-- Grant permissions to authenticated role
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT ALL ON renum_agent_integrations TO authenticated;
GRANT ALL ON renum_webhook_calls TO authenticated;
GRANT SELECT ON webhook_integration_analytics TO authenticated;
GRANT EXECUTE ON FUNCTION get_webhook_stats TO authenticated;
GRANT EXECUTE ON FUNCTION cleanup_old_webhook_calls TO authenticated;

-- Grant permissions to service role (for API operations)
GRANT ALL ON renum_agent_integrations TO service_role;
GRANT ALL ON renum_webhook_calls TO service_role;
GRANT SELECT ON webhook_integration_analytics TO service_role;
GRANT EXECUTE ON FUNCTION get_webhook_stats TO service_role;
GRANT EXECUTE ON FUNCTION cleanup_old_webhook_calls TO service_role;

-- Verification query
-- Run this to verify everything was created:
-- SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND (table_name LIKE 'renum_%webhook%' OR table_name LIKE 'renum_agent_integrations');