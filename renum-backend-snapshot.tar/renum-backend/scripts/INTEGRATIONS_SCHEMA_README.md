# Schema de Integrações - Documentação

## Visão Geral

Este diretório contém os scripts e documentação para o schema de integrações de agentes da Plataforma Renum. O módulo permite que agentes sejam acionados por sistemas externos via webhooks autenticados.

## Arquivos

### Scripts SQL
- `create_integrations_tables.sql` - Script principal com definição das tabelas e funções

### Scripts de Aplicação
- `apply_integrations_schema.py` - Script Python para aplicar o schema
- `apply_integrations_schema.bat` - Script batch para Windows

### Documentação
- `INTEGRATIONS_SCHEMA_README.md` - Este arquivo

## Estrutura do Schema

### Tabelas Criadas

#### `renum_agent_integrations`
Tabela principal que armazena as integrações configuradas entre agentes e sistemas externos.

**Colunas:**
- `id` (UUID) - Identificador único da integração
- `agent_id` (UUID) - ID do agente no sistema Suna Core
- `client_id` (UUID) - ID do cliente proprietário (FK para renum_clients)
- `channel` (VARCHAR) - Canal de integração (whatsapp, zapier, n8n, telegram, custom)
- `webhook_token` (VARCHAR) - Token único para autenticação
- `status` (VARCHAR) - Status da integração (active, inactive)
- `rate_limit_per_minute` (INTEGER) - Limite de chamadas por minuto (padrão: 60)
- `metadata` (JSONB) - Metadados específicos do canal
- `created_at` (TIMESTAMP) - Data de criação
- `updated_at` (TIMESTAMP) - Data de última atualização
- `created_by` (UUID) - ID do usuário criador (FK para auth.users)

**Índices:**
- `idx_renum_agent_integrations_agent_client` - Busca por agente e cliente
- `idx_renum_agent_integrations_token` - Busca por token (único)
- `idx_renum_agent_integrations_client_status` - Busca por cliente e status
- `idx_renum_agent_integrations_channel` - Busca por canal

#### `renum_webhook_calls`
Tabela de auditoria que registra todas as chamadas webhook recebidas.

**Colunas:**
- `id` (UUID) - Identificador único da chamada
- `integration_id` (UUID) - ID da integração (FK para renum_agent_integrations)
- `request_payload` (JSONB) - Payload da requisição recebida
- `response_payload` (JSONB) - Payload da resposta enviada
- `status_code` (INTEGER) - Código de status HTTP da resposta
- `execution_time_ms` (INTEGER) - Tempo de execução em milissegundos
- `ip_address` (INET) - Endereço IP de origem
- `user_agent` (TEXT) - User-Agent do cliente
- `error_message` (TEXT) - Mensagem de erro, se houver
- `created_at` (TIMESTAMP) - Data e hora da chamada

**Índices:**
- `idx_renum_webhook_calls_integration` - Busca por integração
- `idx_renum_webhook_calls_created_at` - Busca por data
- `idx_renum_webhook_calls_status_code` - Busca por status
- `idx_renum_webhook_calls_ip_address` - Busca por IP

### Funções Criadas

#### `renum_validate_webhook_token(p_token TEXT, p_agent_id UUID)`
Valida um token de webhook e retorna informações da integração.

**Parâmetros:**
- `p_token` - Token a ser validado
- `p_agent_id` - ID do agente esperado

**Retorna:**
- `integration_id` - ID da integração válida
- `client_id` - ID do cliente
- `rate_limit_per_minute` - Limite de rate da integração
- `is_valid` - Boolean indicando se é válido

#### `renum_get_integration_stats(p_integration_id UUID, p_hours INTEGER)`
Obtém estatísticas de uso de uma integração.

**Parâmetros:**
- `p_integration_id` - ID da integração
- `p_hours` - Período em horas (padrão: 24)

**Retorna:**
- `total_calls` - Total de chamadas
- `successful_calls` - Chamadas bem-sucedidas (2xx)
- `failed_calls` - Chamadas com falha (4xx, 5xx)
- `avg_execution_time_ms` - Tempo médio de execução
- `last_call_at` - Data da última chamada

### Políticas RLS (Row Level Security)

#### Para `renum_agent_integrations`:
- **SELECT**: Usuários podem ver integrações do seu cliente
- **INSERT**: Usuários podem criar integrações para seu cliente
- **UPDATE**: Usuários podem atualizar integrações do seu cliente
- **DELETE**: Usuários podem excluir integrações do seu cliente
- **ALL (Admin)**: Administradores podem gerenciar todas as integrações

#### Para `renum_webhook_calls`:
- **SELECT**: Usuários podem ver logs das suas integrações
- **INSERT**: Sistema pode inserir logs (uso interno da API)
- **SELECT (Admin)**: Administradores podem ver todos os logs

## Como Aplicar o Schema

### Método 1: Script Python (Recomendado)
```bash
cd renum-backend
python scripts/apply_integrations_schema.py
```

### Método 2: Script Batch (Windows)
```cmd
cd renum-backend
scripts\apply_integrations_schema.bat
```

### Método 3: SQL Direto
Execute o conteúdo de `create_integrations_tables.sql` diretamente no Supabase SQL Editor.

## Verificação da Instalação

Após aplicar o schema, verifique se:

1. **Tabelas foram criadas:**
   ```sql
   SELECT table_name FROM information_schema.tables 
   WHERE table_name IN ('renum_agent_integrations', 'renum_webhook_calls');
   ```

2. **Funções foram criadas:**
   ```sql
   SELECT routine_name FROM information_schema.routines 
   WHERE routine_name IN ('renum_validate_webhook_token', 'renum_get_integration_stats');
   ```

3. **Políticas RLS estão ativas:**
   ```sql
   SELECT tablename, rowsecurity FROM pg_tables 
   WHERE tablename IN ('renum_agent_integrations', 'renum_webhook_calls');
   ```

## Exemplos de Uso

### Criar uma Integração
```sql
INSERT INTO renum_agent_integrations (
    agent_id, 
    client_id, 
    channel, 
    webhook_token, 
    rate_limit_per_minute,
    metadata,
    created_by
) VALUES (
    'agent-uuid-here',
    'client-uuid-here',
    'whatsapp',
    'whk_generated_token_here',
    60,
    '{"phone": "+5511999999999"}'::jsonb,
    'user-uuid-here'
);
```

### Validar Token
```sql
SELECT * FROM renum_validate_webhook_token(
    'whk_generated_token_here', 
    'agent-uuid-here'
);
```

### Obter Estatísticas
```sql
SELECT * FROM renum_get_integration_stats(
    'integration-uuid-here', 
    24
);
```

### Registrar Chamada Webhook
```sql
INSERT INTO renum_webhook_calls (
    integration_id,
    request_payload,
    response_payload,
    status_code,
    execution_time_ms,
    ip_address,
    user_agent
) VALUES (
    'integration-uuid-here',
    '{"message": "Hello"}'::jsonb,
    '{"response": "Hi there"}'::jsonb,
    200,
    150,
    '192.168.1.1',
    'WhatsApp/1.0'
);
```

## Segurança

### Tokens de Webhook
- Formato: `whk_` + 32 caracteres aleatórios
- Únicos por integração
- Armazenados de forma segura no banco
- Podem ser regenerados a qualquer momento

### Rate Limiting
- Configurável por integração
- Padrão: 60 chamadas por minuto
- Implementado via Redis (não no banco)
- Limites entre 1 e 1000 chamadas/minuto

### Auditoria
- Todas as chamadas são registradas
- Inclui IP, User-Agent e payloads
- Dados sensíveis podem ser sanitizados
- Retenção configurável

## Troubleshooting

### Erro: "relation does not exist"
- Verifique se o schema foi aplicado corretamente
- Confirme se está conectado ao banco correto
- Execute o script de aplicação novamente

### Erro: "permission denied"
- Verifique as credenciais do Supabase
- Confirme se o usuário tem permissões de criação
- Verifique as políticas RLS

### Erro: "function does not exist"
- Confirme se todas as funções foram criadas
- Verifique se não houve erro na execução do SQL
- Execute apenas a parte das funções novamente

## Próximos Passos

Após aplicar o schema:

1. **Implementar Serviços** - Criar os serviços de webhook no backend
2. **Criar APIs** - Desenvolver endpoints REST para gerenciar integrações
3. **Interface Frontend** - Construir painéis admin e cliente
4. **Testes** - Implementar testes de integração completos
5. **Documentação** - Criar guias para desenvolvedores externos

## Suporte

Para dúvidas ou problemas:
1. Verifique os logs de execução do script
2. Consulte a documentação do Supabase
3. Execute os comandos de verificação
4. Entre em contato com a equipe de desenvolvimento