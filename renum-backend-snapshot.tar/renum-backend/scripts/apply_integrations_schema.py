#!/usr/bin/env python3
"""
Script para aplicar o schema de integrações no banco de dados Supabase.

Este script executa o arquivo SQL create_integrations_tables.sql
no banco de dados configurado.
"""

import os
import sys
import asyncio
from pathlib import Path

# Adicionar o diretório raiz ao path
sys.path.insert(0, str(Path(__file__).parent.parent))

from app.core.config import get_settings
from app.db.supabase_client import get_supabase_client


async def apply_integrations_schema():
    """Aplica o schema de integrações no banco de dados."""
    
    print("🚀 Iniciando aplicação do schema de integrações...")
    
    try:
        # Carregar configurações
        settings = get_settings()
        print(f"📊 Conectando ao banco: {settings.SUPABASE_URL}")
        
        # Obter cliente Supabase
        supabase = get_supabase_client()
        
        # Ler o arquivo SQL
        sql_file_path = Path(__file__).parent / "create_integrations_tables.sql"
        
        if not sql_file_path.exists():
            raise FileNotFoundError(f"Arquivo SQL não encontrado: {sql_file_path}")
        
        with open(sql_file_path, 'r', encoding='utf-8') as f:
            sql_content = f.read()
        
        print("📄 Arquivo SQL carregado com sucesso")
        print(f"📏 Tamanho do script: {len(sql_content)} caracteres")
        
        # Dividir o SQL em comandos individuais
        sql_commands = [cmd.strip() for cmd in sql_content.split(';') if cmd.strip()]
        
        print(f"🔧 Executando {len(sql_commands)} comandos SQL...")
        
        # Executar cada comando
        for i, command in enumerate(sql_commands, 1):
            if command.strip():
                try:
                    print(f"  [{i}/{len(sql_commands)}] Executando comando...")
                    
                    # Usar rpc para executar SQL bruto
                    result = supabase.rpc('exec_sql', {'sql_query': command}).execute()
                    
                    if result.data:
                        print(f"    ✓ Comando {i} executado com sucesso")
                    else:
                        print(f"    ⚠️ Comando {i} executado (sem retorno)")
                        
                except Exception as cmd_error:
                    print(f"    ❌ Erro no comando {i}: {cmd_error}")
                    # Continuar com os próximos comandos
                    continue
        
        print("\n✅ Schema de integrações aplicado com sucesso!")
        print("\n📋 Tabelas criadas:")
        print("  • renum_agent_integrations - Integrações de agentes")
        print("  • renum_webhook_calls - Logs de chamadas webhook")
        print("\n🔧 Funções criadas:")
        print("  • renum_validate_webhook_token() - Validação de tokens")
        print("  • renum_get_integration_stats() - Estatísticas de uso")
        print("\n🛡️ Políticas RLS configuradas para ambas as tabelas")
        
    except Exception as e:
        print(f"\n❌ Erro ao aplicar schema: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


async def verify_schema():
    """Verifica se o schema foi aplicado corretamente."""
    
    print("\n🔍 Verificando schema aplicado...")
    
    try:
        supabase = get_supabase_client()
        
        # Verificar se as tabelas existem
        tables_to_check = [
            'renum_agent_integrations',
            'renum_webhook_calls'
        ]
        
        for table in tables_to_check:
            try:
                # Tentar fazer uma query simples na tabela
                result = supabase.table(table).select('*').limit(1).execute()
                print(f"  ✓ Tabela {table} existe e está acessível")
            except Exception as e:
                print(f"  ❌ Problema com tabela {table}: {e}")
        
        # Verificar se as funções existem
        functions_to_check = [
            'renum_validate_webhook_token',
            'renum_get_integration_stats'
        ]
        
        for function in functions_to_check:
            try:
                # Tentar chamar a função com parâmetros de teste
                if function == 'renum_validate_webhook_token':
                    result = supabase.rpc(function, {
                        'p_token': 'test_token',
                        'p_agent_id': '00000000-0000-0000-0000-000000000000'
                    }).execute()
                elif function == 'renum_get_integration_stats':
                    result = supabase.rpc(function, {
                        'p_integration_id': '00000000-0000-0000-0000-000000000000',
                        'p_hours': 24
                    }).execute()
                
                print(f"  ✓ Função {function} existe e está acessível")
            except Exception as e:
                print(f"  ❌ Problema com função {function}: {e}")
        
        print("\n✅ Verificação do schema concluída!")
        
    except Exception as e:
        print(f"\n❌ Erro na verificação: {e}")


async def main():
    """Função principal."""
    
    print("=" * 60)
    print("🔧 APLICAÇÃO DO SCHEMA DE INTEGRAÇÕES - RENUM")
    print("=" * 60)
    
    # Aplicar schema
    await apply_integrations_schema()
    
    # Verificar schema
    await verify_schema()
    
    print("\n" + "=" * 60)
    print("✅ PROCESSO CONCLUÍDO COM SUCESSO!")
    print("=" * 60)
    print("\n💡 Próximos passos:")
    print("  1. Implementar os serviços de webhook")
    print("  2. Criar os endpoints da API")
    print("  3. Desenvolver a interface frontend")


if __name__ == "__main__":
    asyncio.run(main())