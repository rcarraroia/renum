-- Script para criar as tabelas de integrações de agentes no banco de dados Supabase
-- Tabelas para o módulo de Webhooks Externos da Plataforma Renum

-- Criar extensão uuid-ossp se ainda não existir
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabela principal de integrações de agentes
CREATE TABLE IF NOT EXISTS public.renum_agent_integrations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agent_id UUID NOT NULL, -- Referência ao agente no Suna Core
    client_id UUID NOT NULL REFERENCES public.renum_clients(id) ON DELETE CASCADE,
    channel VARCHAR(50) NOT NULL, -- 'whatsapp', 'zapier', 'n8n', 'telegram', 'custom'
    webhook_token VARCHAR(255) NOT NULL UNIQUE,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    rate_limit_per_minute INTEGER DEFAULT 60,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    created_by UUID REFERENCES auth.users(id)
);

-- Adicionar comentários à tabela e colunas
COMMENT ON TABLE public.renum_agent_integrations IS 'Tabela para armazenar integrações de agentes com sistemas externos via webhooks';
COMMENT ON COLUMN public.renum_agent_integrations.id IS 'ID único da integração';
COMMENT ON COLUMN public.renum_agent_integrations.agent_id IS 'ID do agente no sistema Suna Core';
COMMENT ON COLUMN public.renum_agent_integrations.client_id IS 'ID do cliente proprietário da integração';
COMMENT ON COLUMN public.renum_agent_integrations.channel IS 'Canal de integração (whatsapp, zapier, n8n, telegram, custom)';
COMMENT ON COLUMN public.renum_agent_integrations.webhook_token IS 'Token único para autenticação do webhook';
COMMENT ON COLUMN public.renum_agent_integrations.status IS 'Status da integração (active, inactive)';
COMMENT ON COLUMN public.renum_agent_integrations.rate_limit_per_minute IS 'Limite de chamadas por minuto para esta integração';
COMMENT ON COLUMN public.renum_agent_integrations.metadata IS 'Metadados adicionais da integração (configurações específicas do canal)';
COMMENT ON COLUMN public.renum_agent_integrations.created_at IS 'Data de criação da integração';
COMMENT ON COLUMN public.renum_agent_integrations.updated_at IS 'Data de última atualização da integração';
COMMENT ON COLUMN public.renum_agent_integrations.created_by IS 'ID do usuário que criou a integração';

-- Tabela de logs de chamadas webhook
CREATE TABLE IF NOT EXISTS public.renum_webhook_calls (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    integration_id UUID NOT NULL REFERENCES public.renum_agent_integrations(id) ON DELETE CASCADE,
    request_payload JSONB,
    response_payload JSONB,
    status_code INTEGER,
    execution_time_ms INTEGER,
    ip_address INET,
    user_agent TEXT,
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Adicionar comentários à tabela de logs
COMMENT ON TABLE public.renum_webhook_calls IS 'Tabela para armazenar logs de todas as chamadas webhook realizadas';
COMMENT ON COLUMN public.renum_webhook_calls.id IS 'ID único da chamada webhook';
COMMENT ON COLUMN public.renum_webhook_calls.integration_id IS 'ID da integração que recebeu a chamada';
COMMENT ON COLUMN public.renum_webhook_calls.request_payload IS 'Payload da requisição recebida';
COMMENT ON COLUMN public.renum_webhook_calls.response_payload IS 'Payload da resposta enviada';
COMMENT ON COLUMN public.renum_webhook_calls.status_code IS 'Código de status HTTP da resposta';
COMMENT ON COLUMN public.renum_webhook_calls.execution_time_ms IS 'Tempo de execução em milissegundos';
COMMENT ON COLUMN public.renum_webhook_calls.ip_address IS 'Endereço IP de origem da chamada';
COMMENT ON COLUMN public.renum_webhook_calls.user_agent IS 'User-Agent do cliente que fez a chamada';
COMMENT ON COLUMN public.renum_webhook_calls.error_message IS 'Mensagem de erro, se houver';
COMMENT ON COLUMN public.renum_webhook_calls.created_at IS 'Data e hora da chamada';

-- Criar índices para melhorar performance
CREATE INDEX IF NOT EXISTS idx_renum_agent_integrations_agent_client ON public.renum_agent_integrations(agent_id, client_id);
CREATE INDEX IF NOT EXISTS idx_renum_agent_integrations_token ON public.renum_agent_integrations(webhook_token);
CREATE INDEX IF NOT EXISTS idx_renum_agent_integrations_client_status ON public.renum_agent_integrations(client_id, status);
CREATE INDEX IF NOT EXISTS idx_renum_agent_integrations_channel ON public.renum_agent_integrations(channel);

CREATE INDEX IF NOT EXISTS idx_renum_webhook_calls_integration ON public.renum_webhook_calls(integration_id);
CREATE INDEX IF NOT EXISTS idx_renum_webhook_calls_created_at ON public.renum_webhook_calls(created_at);
CREATE INDEX IF NOT EXISTS idx_renum_webhook_calls_status_code ON public.renum_webhook_calls(status_code);
CREATE INDEX IF NOT EXISTS idx_renum_webhook_calls_ip_address ON public.renum_webhook_calls(ip_address);

-- Criar trigger para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION public.update_renum_agent_integrations_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_renum_agent_integrations_updated_at_trigger ON public.renum_agent_integrations;
CREATE TRIGGER update_renum_agent_integrations_updated_at_trigger
BEFORE UPDATE ON public.renum_agent_integrations
FOR EACH ROW
EXECUTE FUNCTION public.update_renum_agent_integrations_updated_at();

-- Habilitar RLS nas tabelas
ALTER TABLE public.renum_agent_integrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.renum_webhook_calls ENABLE ROW LEVEL SECURITY;

-- Remover políticas existentes (se houver)
DROP POLICY IF EXISTS "Users can view their client integrations" ON public.renum_agent_integrations;
DROP POLICY IF EXISTS "Users can create integrations for their client" ON public.renum_agent_integrations;
DROP POLICY IF EXISTS "Users can update their client integrations" ON public.renum_agent_integrations;
DROP POLICY IF EXISTS "Users can delete their client integrations" ON public.renum_agent_integrations;
DROP POLICY IF EXISTS "Admins can manage all integrations" ON public.renum_agent_integrations;

DROP POLICY IF EXISTS "Users can view webhook calls for their integrations" ON public.renum_webhook_calls;
DROP POLICY IF EXISTS "System can insert webhook calls" ON public.renum_webhook_calls;
DROP POLICY IF EXISTS "Admins can view all webhook calls" ON public.renum_webhook_calls;

-- Criar políticas RLS para renum_agent_integrations

-- Política para visualização: usuários podem ver integrações do seu cliente
CREATE POLICY "Users can view their client integrations"
ON public.renum_agent_integrations
FOR SELECT
USING (
    client_id IN (
        SELECT client_id FROM public.renum_users WHERE auth_user_id = auth.uid()
    )
);

-- Política para criação: usuários podem criar integrações para seu cliente
CREATE POLICY "Users can create integrations for their client"
ON public.renum_agent_integrations
FOR INSERT
WITH CHECK (
    client_id IN (
        SELECT client_id FROM public.renum_users WHERE auth_user_id = auth.uid()
    )
);

-- Política para atualização: usuários podem atualizar integrações do seu cliente
CREATE POLICY "Users can update their client integrations"
ON public.renum_agent_integrations
FOR UPDATE
USING (
    client_id IN (
        SELECT client_id FROM public.renum_users WHERE auth_user_id = auth.uid()
    )
);

-- Política para exclusão: usuários podem excluir integrações do seu cliente
CREATE POLICY "Users can delete their client integrations"
ON public.renum_agent_integrations
FOR DELETE
USING (
    client_id IN (
        SELECT client_id FROM public.renum_users WHERE auth_user_id = auth.uid()
    )
);

-- Política para administradores: podem gerenciar todas as integrações
CREATE POLICY "Admins can manage all integrations"
ON public.renum_agent_integrations
FOR ALL
USING (
    auth.uid() IN (
        SELECT auth_user_id FROM public.renum_users 
        WHERE id IN (SELECT user_id FROM public.renum_admins WHERE is_active = true)
    )
);

-- Criar políticas RLS para renum_webhook_calls

-- Política para visualização: usuários podem ver logs de webhook das suas integrações
CREATE POLICY "Users can view webhook calls for their integrations"
ON public.renum_webhook_calls
FOR SELECT
USING (
    integration_id IN (
        SELECT id FROM public.renum_agent_integrations 
        WHERE client_id IN (
            SELECT client_id FROM public.renum_users WHERE auth_user_id = auth.uid()
        )
    )
);

-- Política para inserção: sistema pode inserir logs de webhook (para uso interno da API)
CREATE POLICY "System can insert webhook calls"
ON public.renum_webhook_calls
FOR INSERT
WITH CHECK (true); -- Permitir inserção para o sistema

-- Política para administradores: podem ver todos os logs de webhook
CREATE POLICY "Admins can view all webhook calls"
ON public.renum_webhook_calls
FOR SELECT
USING (
    auth.uid() IN (
        SELECT auth_user_id FROM public.renum_users 
        WHERE id IN (SELECT user_id FROM public.renum_admins WHERE is_active = true)
    )
);

-- Função para validar token de webhook
CREATE OR REPLACE FUNCTION public.renum_validate_webhook_token(p_token TEXT, p_agent_id UUID)
RETURNS TABLE(
    integration_id UUID,
    client_id UUID,
    rate_limit_per_minute INTEGER,
    is_valid BOOLEAN
) AS $$
DECLARE
    integration_record RECORD;
BEGIN
    -- Buscar integração ativa com o token fornecido
    SELECT 
        id,
        agent_id,
        client_id,
        rate_limit_per_minute,
        status
    INTO integration_record
    FROM public.renum_agent_integrations
    WHERE webhook_token = p_token
    AND status = 'active';
    
    -- Verificar se encontrou a integração e se o agent_id confere
    IF integration_record.id IS NOT NULL AND integration_record.agent_id = p_agent_id THEN
        RETURN QUERY SELECT 
            integration_record.id,
            integration_record.client_id,
            integration_record.rate_limit_per_minute,
            true;
    ELSE
        RETURN QUERY SELECT 
            NULL::UUID,
            NULL::UUID,
            NULL::INTEGER,
            false;
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para obter estatísticas de uso de integrações
CREATE OR REPLACE FUNCTION public.renum_get_integration_stats(p_integration_id UUID, p_hours INTEGER DEFAULT 24)
RETURNS TABLE(
    total_calls INTEGER,
    successful_calls INTEGER,
    failed_calls INTEGER,
    avg_execution_time_ms NUMERIC,
    last_call_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COUNT(*)::INTEGER as total_calls,
        COUNT(CASE WHEN status_code BETWEEN 200 AND 299 THEN 1 END)::INTEGER as successful_calls,
        COUNT(CASE WHEN status_code >= 400 OR error_message IS NOT NULL THEN 1 END)::INTEGER as failed_calls,
        ROUND(AVG(execution_time_ms), 2) as avg_execution_time_ms,
        MAX(created_at) as last_call_at
    FROM public.renum_webhook_calls
    WHERE integration_id = p_integration_id
    AND created_at >= now() - (p_hours || ' hours')::INTERVAL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;