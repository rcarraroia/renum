#!/usr/bin/env python3
"""
Webhook Integrations Migration Script

This script handles database migrations for the webhook integrations system.
It can apply migrations, rollback changes, and verify the database state.

Usage:
    python scripts/migrate_webhooks.py apply
    python scripts/migrate_webhooks.py rollback
    python scripts/migrate_webhooks.py verify
    python scripts/migrate_webhooks.py status
"""

import os
import sys
import argparse
import logging
from pathlib import Path
from typing import Optional, List, Dict, Any
import psycopg2
from psycopg2.extras import RealDictCursor
import json
from datetime import datetime

# Add the app directory to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

from app.core.config import settings

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class WebhookMigrator:
    """Handles webhook integration database migrations."""
    
    def __init__(self):
        self.migrations_dir = Path(__file__).parent.parent / "migrations"
        self.connection = None
        
    def connect(self) -> None:
        """Connect to the database."""
        try:
            self.connection = psycopg2.connect(
                settings.DATABASE_URL,
                cursor_factory=RealDictCursor
            )
            self.connection.autocommit = False
            logger.info("Connected to database successfully")
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            sys.exit(1)
    
    def disconnect(self) -> None:
        """Disconnect from the database."""
        if self.connection:
            self.connection.close()
            logger.info("Disconnected from database")
    
    def execute_sql_file(self, file_path: Path) -> bool:
        """Execute SQL commands from a file."""
        try:
            with open(file_path, 'r') as f:
                sql_content = f.read()
            
            with self.connection.cursor() as cursor:
                cursor.execute(sql_content)
                self.connection.commit()
                
            logger.info(f"Successfully executed {file_path.name}")
            return True
            
        except Exception as e:
            self.connection.rollback()
            logger.error(f"Failed to execute {file_path.name}: {e}")
            return False
    
    def check_table_exists(self, table_name: str) -> bool:
        """Check if a table exists in the database."""
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_schema = 'public' 
                        AND table_name = %s
                    );
                """, (table_name,))
                return cursor.fetchone()[0]
        except Exception as e:
            logger.error(f"Failed to check table existence: {e}")
            return False
    
    def get_migration_status(self) -> Dict[str, Any]:
        """Get the current migration status."""
        status = {
            'tables_exist': False,
            'tables': {},
            'indexes': {},
            'functions': {},
            'views': {}
        }
        
        try:
            with self.connection.cursor() as cursor:
                # Check tables
                tables_to_check = ['renum_agent_integrations', 'renum_webhook_calls']
                for table in tables_to_check:
                    exists = self.check_table_exists(table)
                    status['tables'][table] = exists
                    if exists:
                        # Get row count
                        cursor.execute(f"SELECT COUNT(*) FROM {table};")
                        status['tables'][f"{table}_count"] = cursor.fetchone()[0]
                
                status['tables_exist'] = all(status['tables'][table] for table in tables_to_check)
                
                # Check indexes
                cursor.execute("""
                    SELECT indexname FROM pg_indexes 
                    WHERE tablename IN ('renum_agent_integrations', 'renum_webhook_calls')
                    AND schemaname = 'public';
                """)
                indexes = [row[0] for row in cursor.fetchall()]
                status['indexes'] = {idx: True for idx in indexes}
                
                # Check functions
                cursor.execute("""
                    SELECT routine_name FROM information_schema.routines 
                    WHERE routine_schema = 'public' 
                    AND routine_name IN ('get_webhook_stats', 'cleanup_old_webhook_calls', 'update_updated_at_column');
                """)
                functions = [row[0] for row in cursor.fetchall()]
                status['functions'] = {func: True for func in functions}
                
                # Check views
                cursor.execute("""
                    SELECT table_name FROM information_schema.views 
                    WHERE table_schema = 'public' 
                    AND table_name = 'webhook_integration_analytics';
                """)
                views = [row[0] for row in cursor.fetchall()]
                status['views'] = {view: True for view in views}
                
        except Exception as e:
            logger.error(f"Failed to get migration status: {e}")
        
        return status
    
    def apply_migration(self) -> bool:
        """Apply the webhook integrations migration."""
        logger.info("Applying webhook integrations migration...")
        
        # Check if already applied
        if self.check_table_exists('renum_agent_integrations'):
            logger.warning("Migration appears to already be applied")
            response = input("Continue anyway? (y/N): ")
            if response.lower() != 'y':
                return False
        
        migration_file = self.migrations_dir / "webhook_integrations_001_initial.sql"
        if not migration_file.exists():
            logger.error(f"Migration file not found: {migration_file}")
            return False
        
        success = self.execute_sql_file(migration_file)
        if success:
            logger.info("Migration applied successfully!")
            self.log_migration_event("apply", "webhook_integrations_001_initial", True)
        else:
            logger.error("Migration failed!")
            self.log_migration_event("apply", "webhook_integrations_001_initial", False)
        
        return success
    
    def rollback_migration(self) -> bool:
        """Rollback the webhook integrations migration."""
        logger.info("Rolling back webhook integrations migration...")
        
        # Check if migration is applied
        if not self.check_table_exists('renum_agent_integrations'):
            logger.warning("Migration doesn't appear to be applied")
            response = input("Continue anyway? (y/N): ")
            if response.lower() != 'y':
                return False
        
        rollback_file = self.migrations_dir / "webhook_integrations_001_rollback.sql"
        if not rollback_file.exists():
            logger.error(f"Rollback file not found: {rollback_file}")
            return False
        
        success = self.execute_sql_file(rollback_file)
        if success:
            logger.info("Rollback completed successfully!")
            self.log_migration_event("rollback", "webhook_integrations_001_initial", True)
        else:
            logger.error("Rollback failed!")
            self.log_migration_event("rollback", "webhook_integrations_001_initial", False)
        
        return success
    
    def verify_migration(self) -> bool:
        """Verify the migration was applied correctly."""
        logger.info("Verifying webhook integrations migration...")
        
        status = self.get_migration_status()
        
        # Check required tables
        required_tables = ['renum_agent_integrations', 'renum_webhook_calls']
        missing_tables = [table for table in required_tables if not status['tables'].get(table, False)]
        
        if missing_tables:
            logger.error(f"Missing tables: {missing_tables}")
            return False
        
        # Check required functions
        required_functions = ['get_webhook_stats', 'cleanup_old_webhook_calls', 'update_updated_at_column']
        missing_functions = [func for func in required_functions if not status['functions'].get(func, False)]
        
        if missing_functions:
            logger.error(f"Missing functions: {missing_functions}")
            return False
        
        # Check required views
        required_views = ['webhook_integration_analytics']
        missing_views = [view for view in required_views if not status['views'].get(view, False)]
        
        if missing_views:
            logger.error(f"Missing views: {missing_views}")
            return False
        
        logger.info("Migration verification passed!")
        return True
    
    def show_status(self) -> None:
        """Show the current migration status."""
        logger.info("Checking webhook integrations migration status...")
        
        status = self.get_migration_status()
        
        print("\n" + "="*50)
        print("WEBHOOK INTEGRATIONS MIGRATION STATUS")
        print("="*50)
        
        print(f"\nOverall Status: {'✅ APPLIED' if status['tables_exist'] else '❌ NOT APPLIED'}")
        
        print("\nTables:")
        for table, exists in status['tables'].items():
            if not table.endswith('_count'):
                count = status['tables'].get(f"{table}_count", 0)
                print(f"  {table}: {'✅' if exists else '❌'} ({count} rows)")
        
        print("\nFunctions:")
        expected_functions = ['get_webhook_stats', 'cleanup_old_webhook_calls', 'update_updated_at_column']
        for func in expected_functions:
            exists = status['functions'].get(func, False)
            print(f"  {func}: {'✅' if exists else '❌'}")
        
        print("\nViews:")
        expected_views = ['webhook_integration_analytics']
        for view in expected_views:
            exists = status['views'].get(view, False)
            print(f"  {view}: {'✅' if exists else '❌'}")
        
        print("\nIndexes:")
        index_count = len(status['indexes'])
        print(f"  Total indexes: {index_count}")
        
        print("\n" + "="*50)
    
    def log_migration_event(self, action: str, migration: str, success: bool) -> None:
        """Log migration events for audit purposes."""
        try:
            log_entry = {
                'timestamp': datetime.utcnow().isoformat(),
                'action': action,
                'migration': migration,
                'success': success,
                'user': os.getenv('USER', 'unknown'),
                'hostname': os.getenv('HOSTNAME', 'unknown')
            }
            
            log_file = Path(__file__).parent.parent / "logs" / "migrations.log"
            log_file.parent.mkdir(exist_ok=True)
            
            with open(log_file, 'a') as f:
                f.write(json.dumps(log_entry) + '\n')
                
        except Exception as e:
            logger.warning(f"Failed to log migration event: {e}")
    
    def create_test_data(self) -> bool:
        """Create test data for development."""
        logger.info("Creating test data...")
        
        try:
            with self.connection.cursor() as cursor:
                # Insert test integration
                cursor.execute("""
                    INSERT INTO renum_agent_integrations (
                        name, agent_id, channel, webhook_token, webhook_url, created_by
                    ) VALUES (
                        'Test WhatsApp Integration',
                        '00000000-0000-0000-0000-000000000001'::UUID,
                        'whatsapp',
                        'whk_test_token_for_development_only_12345678901234567890',
                        'https://api.suna.com/v1/webhook/00000000-0000-0000-0000-000000000001/whatsapp',
                        '00000000-0000-0000-0000-000000000000'::UUID
                    ) ON CONFLICT (agent_id, channel) DO NOTHING;
                """)
                
                # Insert test webhook call
                cursor.execute("""
                    INSERT INTO renum_webhook_calls (
                        integration_id, agent_id, channel, status, http_status_code,
                        request_payload, response_payload, execution_time_ms, ip_address
                    ) SELECT 
                        id, agent_id, channel, 'success', 200,
                        '{"message": "Test message", "phone": "+5511999999999"}'::jsonb,
                        '{"success": true, "response": "Test response"}'::jsonb,
                        250, '127.0.0.1'::inet
                    FROM renum_agent_integrations 
                    WHERE webhook_token = 'whk_test_token_for_development_only_12345678901234567890'
                    LIMIT 1;
                """)
                
                self.connection.commit()
                logger.info("Test data created successfully!")
                return True
                
        except Exception as e:
            self.connection.rollback()
            logger.error(f"Failed to create test data: {e}")
            return False

def main():
    """Main function to handle command line arguments."""
    parser = argparse.ArgumentParser(description='Webhook Integrations Migration Tool')
    parser.add_argument('action', choices=['apply', 'rollback', 'verify', 'status', 'test-data'],
                       help='Action to perform')
    parser.add_argument('--force', action='store_true',
                       help='Force action without confirmation')
    
    args = parser.parse_args()
    
    migrator = WebhookMigrator()
    
    try:
        migrator.connect()
        
        if args.action == 'apply':
            success = migrator.apply_migration()
            sys.exit(0 if success else 1)
            
        elif args.action == 'rollback':
            if not args.force:
                response = input("Are you sure you want to rollback? This will delete all webhook data! (y/N): ")
                if response.lower() != 'y':
                    logger.info("Rollback cancelled")
                    sys.exit(0)
            
            success = migrator.rollback_migration()
            sys.exit(0 if success else 1)
            
        elif args.action == 'verify':
            success = migrator.verify_migration()
            sys.exit(0 if success else 1)
            
        elif args.action == 'status':
            migrator.show_status()
            sys.exit(0)
            
        elif args.action == 'test-data':
            success = migrator.create_test_data()
            sys.exit(0 if success else 1)
            
    except KeyboardInterrupt:
        logger.info("Operation cancelled by user")
        sys.exit(1)
        
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        sys.exit(1)
        
    finally:
        migrator.disconnect()

if __name__ == '__main__':
    main()