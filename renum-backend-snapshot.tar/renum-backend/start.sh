#!/bin/bash

# Carrega as variáveis de ambiente do arquivo .env
if [ -f .env ]; then
    # Carrega apenas as variáveis essenciais de forma segura
    while IFS='=' read -r key value; do
        # Ignora linhas vazias e comentários
        if [[ ! -z "$key" && ! "$key" =~ ^[[:space:]]*# ]]; then
            # Remove aspas do valor se existirem
            value=$(echo "$value" | sed 's/^"\(.*\)"$/\1/')
            export "$key"="$value"
        fi
    done < .env
    echo "Variáveis de ambiente carregadas do arquivo .env"
else
    echo "Arquivo .env não encontrado!"
    exit 1
fi

# Verifica se as variáveis obrigatórias estão definidas
if [ -z "$SUPABASE_URL" ] || [ -z "$SUPABASE_KEY" ]; then
    echo "Erro: SUPABASE_URL e SUPABASE_KEY são obrigatórias"
    exit 1
fi

# Define valores padrão se não estiverem definidos
PORT=${PORT:-9000}
HOST=${HOST:-0.0.0.0}

echo "Iniciando Renum Backend..."
echo "SUPABASE_URL: $SUPABASE_URL"
echo "PORT: $PORT"
echo "HOST: $HOST"

# Inicia a aplicação FastAPI
uvicorn app.main:app --host "$HOST" --port "$PORT" --reload