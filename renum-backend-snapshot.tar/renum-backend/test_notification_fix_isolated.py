"""
Teste isolado para validar a correção do notification_service sem dependências de configuração.
"""

import sys
import os
import tempfile

# Cria um arquivo .env temporário com configurações mínimas
temp_env_content = """
SUPABASE_URL=https://test.supabase.co
SUPABASE_KEY=test-key
CORS_ORIGINS=http://localhost:3000
DEBUG=True
LOG_LEVEL=INFO
ENVIRONMENT=test
"""

def create_temp_env():
    """Cria um arquivo .env temporário para os testes"""
    temp_dir = tempfile.mkdtemp()
    env_file = os.path.join(temp_dir, '.env')
    
    with open(env_file, 'w') as f:
        f.write(temp_env_content)
    
    return env_file, temp_dir

def test_notification_service_direct():
    """Testa a importação direta do notification_service sem configurações complexas"""
    try:
        # Adiciona o diretório da aplicação ao path
        app_path = os.path.join(os.path.dirname(__file__), 'app')
        if app_path not in sys.path:
            sys.path.insert(0, app_path)
        
        # Cria arquivo .env temporário
        env_file, temp_dir = create_temp_env()
        
        # Define a variável de ambiente para o arquivo .env
        original_env_file = os.environ.get('ENV_FILE')
        os.environ['ENV_FILE'] = env_file
        
        try:
            # Importa diretamente a classe NotificationService
            from app.services.notification_service import NotificationService
            
            # Cria uma instância diretamente
            service = NotificationService()
            
            print("✅ NotificationService criado com sucesso")
            print(f"✅ Instância válida: {service is not None}")
            print(f"✅ Tipo correto: {isinstance(service, NotificationService)}")
            
            # Testa atribuição de websocket_manager
            service.websocket_manager = "test_manager"
            print(f"✅ Atribuição de websocket_manager funcionou: {service.websocket_manager == 'test_manager'}")
            
            return True
            
        finally:
            # Limpa o ambiente
            if original_env_file:
                os.environ['ENV_FILE'] = original_env_file
            else:
                os.environ.pop('ENV_FILE', None)
            
            # Remove arquivo temporário
            try:
                os.remove(env_file)
                os.rmdir(temp_dir)
            except:
                pass
                
    except Exception as e:
        print(f"❌ Erro no teste direto: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_websocket_manager_direct():
    """Testa a importação direta do websocket_manager"""
    try:
        # Adiciona o diretório da aplicação ao path
        app_path = os.path.join(os.path.dirname(__file__), 'app')
        if app_path not in sys.path:
            sys.path.insert(0, app_path)
        
        # Importa diretamente a classe WebSocketManager
        from app.services.websocket_manager import WebSocketManager
        
        # Cria uma instância diretamente
        manager = WebSocketManager()
        
        print("✅ WebSocketManager criado com sucesso")
        print(f"✅ Instância válida: {manager is not None}")
        print(f"✅ Tipo correto: {isinstance(manager, WebSocketManager)}")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro no teste direto do WebSocketManager: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_integration_direct():
    """Testa a integração entre os serviços diretamente"""
    try:
        # Adiciona o diretório da aplicação ao path
        app_path = os.path.join(os.path.dirname(__file__), 'app')
        if app_path not in sys.path:
            sys.path.insert(0, app_path)
        
        # Importa as classes diretamente
        from app.services.notification_service import NotificationService
        from app.services.websocket_manager import WebSocketManager
        
        # Cria instâncias
        notification_service = NotificationService()
        websocket_manager = WebSocketManager()
        
        # Testa a integração
        notification_service.websocket_manager = websocket_manager
        
        print("✅ Integração entre serviços funcionou")
        print(f"✅ WebSocket manager atribuído: {notification_service.websocket_manager is websocket_manager}")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro no teste de integração: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Executa todos os testes diretos"""
    print("🧪 Executando testes diretos de correção do notification_service...\n")
    
    tests = [
        ("Criação direta do NotificationService", test_notification_service_direct),
        ("Criação direta do WebSocketManager", test_websocket_manager_direct),
        ("Integração direta entre serviços", test_integration_direct),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"🔍 Testando: {test_name}")
        result = test_func()
        results.append((test_name, result))
        print()
    
    # Resumo dos resultados
    print("📊 Resumo dos Testes:")
    print("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASSOU" if result else "❌ FALHOU"
        print(f"{status}: {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 Resultado: {passed}/{len(tests)} testes passaram")
    
    if passed == len(tests):
        print("🎉 Todos os testes passaram! A correção foi bem-sucedida.")
        return True
    else:
        print("⚠️  Alguns testes falharam. Verifique os erros acima.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)