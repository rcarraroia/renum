"""
Teste simples para validar a correção do notification_service.
"""

import sys
import os

# Adiciona o diretório da aplicação ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'app'))

def test_notification_service_import():
    """Testa se o notification_service pode ser importado sem erro"""
    try:
        from app.services.notification_service import notification_service, NotificationService
        
        print("✅ notification_service importado com sucesso")
        print(f"✅ notification_service é uma instância: {notification_service is not None}")
        print(f"✅ notification_service é do tipo correto: {isinstance(notification_service, NotificationService)}")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro ao importar notification_service: {str(e)}")
        return False

def test_websocket_manager_import():
    """Testa se o websocket_manager pode ser importado sem erro"""
    try:
        from app.services.websocket_manager import websocket_manager, WebSocketManager
        
        print("✅ websocket_manager importado com sucesso")
        print(f"✅ websocket_manager é uma instância: {websocket_manager is not None}")
        print(f"✅ websocket_manager é do tipo correto: {isinstance(websocket_manager, WebSocketManager)}")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro ao importar websocket_manager: {str(e)}")
        return False

def test_websocket_manager_assignment():
    """Testa se o websocket_manager pode ser atribuído ao notification_service"""
    try:
        from app.services.notification_service import notification_service
        from app.services.websocket_manager import websocket_manager
        
        # Salva o estado original
        original_websocket_manager = notification_service.websocket_manager
        
        # Testa a atribuição
        notification_service.websocket_manager = websocket_manager
        
        print("✅ websocket_manager atribuído com sucesso")
        print(f"✅ Atribuição funcionou: {notification_service.websocket_manager is websocket_manager}")
        
        # Restaura o estado original
        notification_service.websocket_manager = original_websocket_manager
        
        return True
        
    except Exception as e:
        print(f"❌ Erro ao atribuir websocket_manager: {str(e)}")
        return False

def main():
    """Executa todos os testes"""
    print("🧪 Executando testes de correção do notification_service...\n")
    
    tests = [
        ("Importação do notification_service", test_notification_service_import),
        ("Importação do websocket_manager", test_websocket_manager_import),
        ("Atribuição do websocket_manager", test_websocket_manager_assignment),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"🔍 Testando: {test_name}")
        result = test_func()
        results.append((test_name, result))
        print()
    
    # Resumo dos resultados
    print("📊 Resumo dos Testes:")
    print("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASSOU" if result else "❌ FALHOU"
        print(f"{status}: {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 Resultado: {passed}/{len(tests)} testes passaram")
    
    if passed == len(tests):
        print("🎉 Todos os testes passaram! A correção foi bem-sucedida.")
        return True
    else:
        print("⚠️  Alguns testes falharam. Verifique os erros acima.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)