"""
Teste de startup da aplicação.
"""

import asyncio
import sys
from app.main import lifespan
from fastapi import FastAPI

async def test_startup():
    """Testa se a aplicação inicia corretamente"""
    try:
        app = FastAPI()
        print('🔍 Testando inicialização da aplicação...')
        
        async with lifespan(app):
            print('✅ Aplicação iniciada com sucesso!')
            print('✅ Lifespan executado sem erros')
            print('✅ Notification service inicializado corretamente')
            return True
            
    except Exception as e:
        print(f'❌ Erro na inicialização: {str(e)}')
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    result = asyncio.run(test_startup())
    print(f'\n🎯 Resultado: {"SUCESSO" if result else "FALHA"}')
    sys.exit(0 if result else 1)