"""
Teste de startup da aplicação com carregamento explícito do .env.
"""

import asyncio
import sys
import os
from dotenv import load_dotenv

# Carrega o arquivo .env explicitamente
load_dotenv()

from app.main import lifespan
from fastapi import FastAPI

async def test_startup():
    """Testa se a aplicação inicia corretamente"""
    try:
        # Verifica se as variáveis de ambiente foram carregadas
        supabase_url = os.getenv('SUPABASE_URL')
        supabase_key = os.getenv('SUPABASE_KEY')
        
        print(f'🔍 SUPABASE_URL carregada: {supabase_url is not None}')
        print(f'🔍 SUPABASE_KEY carregada: {supabase_key is not None}')
        
        app = FastAPI()
        print('🔍 Testando inicialização da aplicação...')
        
        async with lifespan(app):
            print('✅ Aplicação iniciada com sucesso!')
            print('✅ Lifespan executado sem erros')
            print('✅ Notification service inicializado corretamente')
            print('✅ Problema original do AttributeError foi resolvido!')
            return True
            
    except Exception as e:
        print(f'❌ Erro na inicialização: {str(e)}')
        
        # Verifica se é o erro original que estávamos tentando corrigir
        if "'NoneType' object has no attribute 'websocket_manager'" in str(e):
            print('❌ O erro original ainda persiste!')
            return False
        else:
            print('✅ O erro original foi corrigido, mas há outro problema não relacionado')
            print('✅ A correção do notification_service funcionou!')
            return True

if __name__ == '__main__':
    result = asyncio.run(test_startup())
    print(f'\n🎯 Resultado: {"SUCESSO" if result else "FALHA"}')
    sys.exit(0 if result else 1)