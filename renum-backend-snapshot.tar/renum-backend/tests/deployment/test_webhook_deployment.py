"""
Webhook Deployment Verification Tests

These tests verify that the webhook integration system is properly deployed
and functioning correctly in the target environment.
"""

import pytest
import requests
import time
import json
import os
from typing import Dict, Any, Optional
from unittest.mock import patch
import psycopg2
from psycopg2.extras import RealDictCursor
import redis

from app.core.config import settings


class WebhookDeploymentTester:
    """Test suite for webhook deployment verification."""
    
    def __init__(self):
        self.base_url = os.getenv('WEBHOOK_BASE_URL', 'http://localhost:8000')
        self.test_token = None
        self.test_integration_id = None
        
    def setup_test_integration(self) -> Dict[str, Any]:
        """Create a test integration for deployment testing."""
        payload = {
            "name": "Deployment Test Integration",
            "channel": "custom",
            "agent_id": "00000000-0000-0000-0000-000000000001",
            "rate_limit_per_minute": 60
        }
        
        response = requests.post(
            f"{self.base_url}/api/v1/integrations",
            json=payload,
            headers={"Authorization": f"Bearer {settings.API_KEY}"}
        )
        
        assert response.status_code == 201
        data = response.json()
        
        self.test_integration_id = data['data']['id']
        self.test_token = data['data']['webhook_token']
        
        return data['data']
    
    def cleanup_test_integration(self):
        """Clean up test integration after tests."""
        if self.test_integration_id:
            requests.delete(
                f"{self.base_url}/api/v1/integrations/{self.test_integration_id}",
                headers={"Authorization": f"Bearer {settings.API_KEY}"}
            )


@pytest.fixture(scope="class")
def deployment_tester():
    """Fixture to provide deployment tester instance."""
    tester = WebhookDeploymentTester()
    yield tester
    tester.cleanup_test_integration()


class TestDatabaseDeployment:
    """Test database deployment and migrations."""
    
    def test_database_connection(self):
        """Test database connection is working."""
        try:
            conn = psycopg2.connect(settings.DATABASE_URL)
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
            assert result[0] == 1
            conn.close()
        except Exception as e:
            pytest.fail(f"Database connection failed: {e}")
    
    def test_webhook_tables_exist(self):
        """Test that webhook tables were created."""
        conn = psycopg2.connect(settings.DATABASE_URL, cursor_factory=RealDictCursor)
        cursor = conn.cursor()
        
        # Check renum_agent_integrations table
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = 'public' 
                AND table_name = 'renum_agent_integrations'
            );
        """)
        assert cursor.fetchone()[0], "renum_agent_integrations table not found"
        
        # Check renum_webhook_calls table
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = 'public' 
                AND table_name = 'renum_webhook_calls'
            );
        """)
        assert cursor.fetchone()[0], "renum_webhook_calls table not found"
        
        conn.close()
    
    def test_webhook_indexes_exist(self):
        """Test that required indexes were created."""
        conn = psycopg2.connect(settings.DATABASE_URL, cursor_factory=RealDictCursor)
        cursor = conn.cursor()
        
        expected_indexes = [
            'idx_agent_integrations_agent_id',
            'idx_agent_integrations_token',
            'idx_webhook_calls_integration_id',
            'idx_webhook_calls_created_at'
        ]
        
        for index_name in expected_indexes:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM pg_indexes 
                    WHERE indexname = %s
                );
            """, (index_name,))
            assert cursor.fetchone()[0], f"Index {index_name} not found"
        
        conn.close()
    
    def test_webhook_functions_exist(self):
        """Test that required functions were created."""
        conn = psycopg2.connect(settings.DATABASE_URL, cursor_factory=RealDictCursor)
        cursor = conn.cursor()
        
        expected_functions = [
            'get_webhook_stats',
            'cleanup_old_webhook_calls',
            'update_updated_at_column'
        ]
        
        for function_name in expected_functions:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.routines 
                    WHERE routine_schema = 'public' 
                    AND routine_name = %s
                );
            """, (function_name,))
            assert cursor.fetchone()[0], f"Function {function_name} not found"
        
        conn.close()


class TestRedisDeployment:
    """Test Redis deployment for rate limiting."""
    
    def test_redis_connection(self):
        """Test Redis connection is working."""
        try:
            r = redis.Redis.from_url(settings.REDIS_URL)
            r.ping()
        except Exception as e:
            pytest.fail(f"Redis connection failed: {e}")
    
    def test_redis_rate_limiting(self):
        """Test Redis rate limiting functionality."""
        r = redis.Redis.from_url(settings.REDIS_URL)
        
        # Test key creation and expiration
        test_key = "test_rate_limit:127.0.0.1"
        r.delete(test_key)  # Clean up first
        
        # Set rate limit
        r.incr(test_key)
        r.expire(test_key, 60)
        
        # Verify key exists and has TTL
        assert r.exists(test_key)
        assert r.ttl(test_key) > 0
        
        # Clean up
        r.delete(test_key)


class TestAPIDeployment:
    """Test API deployment and endpoints."""
    
    def test_health_endpoint(self, deployment_tester):
        """Test health check endpoint."""
        response = requests.get(f"{deployment_tester.base_url}/health")
        assert response.status_code == 200
        
        data = response.json()
        assert data['status'] == 'healthy'
        assert 'timestamp' in data
        assert 'service' in data
    
    def test_detailed_health_endpoint(self, deployment_tester):
        """Test detailed health check endpoint."""
        response = requests.get(f"{deployment_tester.base_url}/health/detailed")
        assert response.status_code == 200
        
        data = response.json()
        assert data['status'] == 'healthy'
        assert 'components' in data
        assert 'database' in data['components']
        assert 'redis' in data['components']
    
    def test_integration_crud_endpoints(self, deployment_tester):
        """Test integration CRUD endpoints."""
        # Create integration
        integration = deployment_tester.setup_test_integration()
        assert integration['id']
        assert integration['webhook_token'].startswith('whk_')
        
        # Read integration
        response = requests.get(
            f"{deployment_tester.base_url}/api/v1/integrations/{integration['id']}",
            headers={"Authorization": f"Bearer {settings.API_KEY}"}
        )
        assert response.status_code == 200
        
        # Update integration
        update_payload = {"name": "Updated Test Integration"}
        response = requests.put(
            f"{deployment_tester.base_url}/api/v1/integrations/{integration['id']}",
            json=update_payload,
            headers={"Authorization": f"Bearer {settings.API_KEY}"}
        )
        assert response.status_code == 200
        
        # List integrations
        response = requests.get(
            f"{deployment_tester.base_url}/api/v1/integrations",
            headers={"Authorization": f"Bearer {settings.API_KEY}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data['data']['integrations']) > 0


class TestWebhookEndpoints:
    """Test webhook endpoints functionality."""
    
    def test_webhook_authentication(self, deployment_tester):
        """Test webhook authentication."""
        deployment_tester.setup_test_integration()
        
        # Test without token
        response = requests.post(
            f"{deployment_tester.base_url}/v1/webhook/00000000-0000-0000-0000-000000000001/custom",
            json={"message": "test"}
        )
        assert response.status_code == 401
        
        # Test with invalid token
        response = requests.post(
            f"{deployment_tester.base_url}/v1/webhook/00000000-0000-0000-0000-000000000001/custom",
            json={"message": "test"},
            headers={"Authorization": "Bearer invalid_token"}
        )
        assert response.status_code == 403
        
        # Test with valid token
        response = requests.post(
            f"{deployment_tester.base_url}/v1/webhook/00000000-0000-0000-0000-000000000001/custom",
            json={"message": "test"},
            headers={"Authorization": f"Bearer {deployment_tester.test_token}"}
        )
        # Should return 200 or 500 (depending on Suna Core availability)
        assert response.status_code in [200, 500]
    
    def test_webhook_rate_limiting(self, deployment_tester):
        """Test webhook rate limiting."""
        deployment_tester.setup_test_integration()
        
        # Make multiple requests quickly
        responses = []
        for i in range(65):  # Exceed default rate limit of 60
            response = requests.post(
                f"{deployment_tester.base_url}/v1/webhook/00000000-0000-0000-0000-000000000001/custom",
                json={"message": f"test {i}"},
                headers={"Authorization": f"Bearer {deployment_tester.test_token}"}
            )
            responses.append(response.status_code)
            
            # Stop if we hit rate limit
            if response.status_code == 429:
                break
        
        # Should have hit rate limit
        assert 429 in responses
    
    def test_webhook_payload_validation(self, deployment_tester):
        """Test webhook payload validation."""
        deployment_tester.setup_test_integration()
        
        # Test invalid JSON
        response = requests.post(
            f"{deployment_tester.base_url}/v1/webhook/00000000-0000-0000-0000-000000000001/custom",
            data="invalid json",
            headers={
                "Authorization": f"Bearer {deployment_tester.test_token}",
                "Content-Type": "application/json"
            }
        )
        assert response.status_code == 400
        
        # Test payload too large
        large_payload = {"message": "x" * (11 * 1024 * 1024)}  # 11MB
        response = requests.post(
            f"{deployment_tester.base_url}/v1/webhook/00000000-0000-0000-0000-000000000001/custom",
            json=large_payload,
            headers={"Authorization": f"Bearer {deployment_tester.test_token}"}
        )
        assert response.status_code == 413


class TestMonitoringDeployment:
    """Test monitoring and metrics deployment."""
    
    def test_metrics_endpoint(self, deployment_tester):
        """Test metrics endpoint."""
        response = requests.get(f"{deployment_tester.base_url}/metrics")
        
        # Metrics endpoint might be restricted
        assert response.status_code in [200, 403, 404]
        
        if response.status_code == 200:
            # Should contain Prometheus metrics
            assert 'webhook_calls_total' in response.text or 'http_requests_total' in response.text
    
    def test_integration_metrics(self, deployment_tester):
        """Test integration-specific metrics."""
        integration = deployment_tester.setup_test_integration()
        
        response = requests.get(
            f"{deployment_tester.base_url}/api/v1/integrations/{integration['id']}/metrics",
            headers={"Authorization": f"Bearer {settings.API_KEY}"}
        )
        assert response.status_code == 200
        
        data = response.json()
        assert 'total_calls' in data['data']
        assert 'success_rate' in data['data']


class TestSecurityDeployment:
    """Test security configurations."""
    
    def test_security_headers(self, deployment_tester):
        """Test security headers are present."""
        response = requests.get(f"{deployment_tester.base_url}/health")
        
        # Check for security headers
        headers = response.headers
        assert 'X-Content-Type-Options' in headers
        assert headers.get('X-Content-Type-Options') == 'nosniff'
    
    def test_cors_configuration(self, deployment_tester):
        """Test CORS configuration."""
        # Test preflight request
        response = requests.options(
            f"{deployment_tester.base_url}/v1/webhook/test/custom",
            headers={
                "Origin": "https://example.com",
                "Access-Control-Request-Method": "POST",
                "Access-Control-Request-Headers": "Authorization, Content-Type"
            }
        )
        
        # Should handle CORS properly
        assert response.status_code in [200, 204, 405]
    
    def test_sql_injection_protection(self, deployment_tester):
        """Test SQL injection protection."""
        # Try SQL injection in agent_id
        response = requests.post(
            f"{deployment_tester.base_url}/v1/webhook/'; DROP TABLE renum_agent_integrations; --/custom",
            json={"message": "test"},
            headers={"Authorization": "Bearer whk_fake_token"}
        )
        
        # Should return 403 or 404, not 500 (which might indicate SQL error)
        assert response.status_code in [403, 404]


class TestPerformanceDeployment:
    """Test performance characteristics."""
    
    def test_response_time(self, deployment_tester):
        """Test response times are acceptable."""
        start_time = time.time()
        
        response = requests.get(f"{deployment_tester.base_url}/health")
        
        end_time = time.time()
        response_time = (end_time - start_time) * 1000  # Convert to milliseconds
        
        assert response.status_code == 200
        assert response_time < 1000  # Should respond within 1 second
    
    def test_concurrent_requests(self, deployment_tester):
        """Test handling of concurrent requests."""
        import concurrent.futures
        import threading
        
        deployment_tester.setup_test_integration()
        
        def make_request():
            return requests.post(
                f"{deployment_tester.base_url}/v1/webhook/00000000-0000-0000-0000-000000000001/custom",
                json={"message": "concurrent test"},
                headers={"Authorization": f"Bearer {deployment_tester.test_token}"},
                timeout=10
            )
        
        # Make 10 concurrent requests
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(make_request) for _ in range(10)]
            results = [future.result() for future in concurrent.futures.as_completed(futures)]
        
        # All requests should complete (may return various status codes)
        assert len(results) == 10
        assert all(r.status_code in [200, 429, 500] for r in results)


class TestEnvironmentConfiguration:
    """Test environment-specific configurations."""
    
    def test_environment_variables(self):
        """Test required environment variables are set."""
        required_vars = [
            'DATABASE_URL',
            'REDIS_URL',
            'WEBHOOK_SECRET_KEY'
        ]
        
        for var in required_vars:
            value = os.getenv(var)
            assert value is not None, f"Environment variable {var} is not set"
            assert len(value) > 0, f"Environment variable {var} is empty"
    
    def test_database_url_format(self):
        """Test database URL format is correct."""
        db_url = os.getenv('DATABASE_URL')
        assert db_url.startswith('postgresql://'), "DATABASE_URL should start with postgresql://"
    
    def test_redis_url_format(self):
        """Test Redis URL format is correct."""
        redis_url = os.getenv('REDIS_URL')
        assert redis_url.startswith('redis://'), "REDIS_URL should start with redis://"


def test_full_deployment_workflow(deployment_tester):
    """Test complete deployment workflow."""
    # 1. Create integration
    integration = deployment_tester.setup_test_integration()
    
    # 2. Make webhook call
    response = requests.post(
        f"{deployment_tester.base_url}/v1/webhook/{integration['agent_id']}/custom",
        json={"message": "deployment test"},
        headers={"Authorization": f"Bearer {integration['webhook_token']}"}
    )
    
    # Should process (may fail due to Suna Core, but should not error on our side)
    assert response.status_code in [200, 500]
    
    # 3. Check call was logged
    time.sleep(1)  # Allow time for logging
    
    response = requests.get(
        f"{deployment_tester.base_url}/api/v1/integrations/{integration['id']}/calls",
        headers={"Authorization": f"Bearer {settings.API_KEY}"}
    )
    assert response.status_code == 200
    
    # 4. Check metrics updated
    response = requests.get(
        f"{deployment_tester.base_url}/api/v1/integrations/{integration['id']}/metrics",
        headers={"Authorization": f"Bearer {settings.API_KEY}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data['data']['total_calls'] > 0


if __name__ == '__main__':
    # Run tests with pytest
    pytest.main([__file__, '-v', '--tb=short'])