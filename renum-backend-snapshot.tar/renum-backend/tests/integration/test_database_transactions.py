"""
Testes de integração para transações de banco de dados com rollback.

Este módulo testa cenários complexos de transações, incluindo rollbacks,
deadlocks, transações aninhadas e recuperação de falhas.
"""

import pytest
import asyncio
from datetime import datetime, timedelta
from typing import List, Dict, Any
from unittest.mock import Mock, patch, AsyncMock
from uuid import uuid4

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy import select, func, text

from app.models.integrations import Integration, WebhookCall, WebhookToken
from app.services.integration_service import IntegrationService
from app.services.webhook_service import WebhookService
from app.core.database import Base


class TestDatabaseTransactions:
    """Testes para transações de banco de dados."""
    
    @pytest.fixture(autouse=True)
    async def setup_database(self):
        """Setup do banco de dados para testes."""
        
        # Criar engine de teste
        self.test_engine = create_async_engine(
            "sqlite+aiosqlite:///./test_transactions.db",
            echo=False
        )
        
        # Criar tabelas
        async with self.test_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        
        # Criar session factory
        self.TestSessionLocal = sessionmaker(
            self.test_engine,
            class_=AsyncSession,
            expire_on_commit=False
        )
        
        # Criar serviços
        self.integration_service = IntegrationService()
        self.webhook_service = WebhookService()
        
        yield
        
        # Cleanup
        async with self.test_engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
        
        await self.test_engine.dispose()
    
    async def test_successful_transaction_commit(self):
        """Testa commit bem-sucedido de transação."""
        
        async with self.TestSessionLocal() as session:
            async with session.begin():
                # Criar integração
                integration = Integration(
                    id=str(uuid4()),
                    name="Transaction Test Integration",
                    channel="whatsapp",
                    agent_id=str(uuid4()),
                    webhook_url="https://test-transaction.com/webhook",
                    is_active=True,
                    rate_limit_per_minute=60,
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow()
                )
                
                session.add(integration)
                
                # Criar token
                token = WebhookToken(
                    integration_id=integration.id,
                    token="whk_transaction_test_token_123",
                    token_type="bearer",
                    is_active=True,
                    expires_at=datetime.utcnow() + timedelta(days=30),
                    created_at=datetime.utcnow()
                )
                
                session.add(token)
                
                # Criar webhook call
                webhook_call = WebhookCall(
                    integration_id=integration.id,
                    status_code=200,
                    execution_time_ms=150,
                    payload={"message": "Transaction test"},
                    response={"success": True},
                    ip_address="192.168.1.100",
                    user_agent="TransactionTestAgent/1.0",
                    created_at=datetime.utcnow()
                )
                
                session.add(webhook_call)
                
                # Commit implícito ao sair do bloco
        
        # Verificar se dados foram persistidos
        async with self.TestSessionLocal() as session:
            # Verificar integração
            integration_result = await session.execute(
                select(Integration).where(Integration.name == "Transaction Test Integration")
            )
            saved_integration = integration_result.scalar_one_or_none()
            
            assert saved_integration is not None
            assert saved_integration.name == "Transaction Test Integration"
            
            # Verificar token
            token_result = await session.execute(
                select(WebhookToken).where(WebhookToken.integration_id == saved_integration.id)
            )
            saved_token = token_result.scalar_one_or_none()
            
            assert saved_token is not None
            assert saved_token.token == "whk_transaction_test_token_123"
            
            # Verificar webhook call
            call_result = await session.execute(
                select(WebhookCall).where(WebhookCall.integration_id == saved_integration.id)
            )
            saved_call = call_result.scalar_one_or_none()
            
            assert saved_call is not None
            assert saved_call.status_code == 200
    
    async def test_transaction_rollback_on_error(self):
        """Testa rollback de transação em caso de erro."""
        
        async with self.TestSessionLocal() as session:
            try:
                async with session.begin():
                    # Criar integração válida
                    integration = Integration(
                        id=str(uuid4()),
                        name="Rollback Test Integration",
                        channel="telegram",
                        agent_id=str(uuid4()),
                        webhook_url="https://test-rollback.com/webhook",
                        is_active=True,
                        rate_limit_per_minute=60,
                        created_at=datetime.utcnow(),
                        updated_at=datetime.utcnow()
                    )
                    
                    session.add(integration)
                    
                    # Criar token válido
                    token = WebhookToken(
                        integration_id=integration.id,
                        token="whk_rollback_test_token_123",
                        token_type="bearer",
                        is_active=True,
                        expires_at=datetime.utcnow() + timedelta(days=30),
                        created_at=datetime.utcnow()
                    )
                    
                    session.add(token)
                    
                    # Forçar erro - tentar criar token duplicado
                    duplicate_token = WebhookToken(
                        integration_id=integration.id,
                        token="whk_rollback_test_token_123",  # Token duplicado
                        token_type="bearer",
                        is_active=True,
                        expires_at=datetime.utcnow() + timedelta(days=30),
                        created_at=datetime.utcnow()
                    )
                    
                    session.add(duplicate_token)
                    
                    # Isso deve causar erro de integridade
                    await session.flush()
                    
            except (IntegrityError, SQLAlchemyError):
                # Erro esperado - transação será automaticamente revertida
                pass
        
        # Verificar se nenhum dado foi persistido (rollback funcionou)
        async with self.TestSessionLocal() as session:
            integration_result = await session.execute(
                select(Integration).where(Integration.name == "Rollback Test Integration")
            )
            saved_integration = integration_result.scalar_one_or_none()
            
            assert saved_integration is None  # Rollback funcionou
            
            token_result = await session.execute(
                select(WebhookToken).where(WebhookToken.token == "whk_rollback_test_token_123")
            )
            saved_token = token_result.scalar_one_or_none()
            
            assert saved_token is None  # Rollback funcionou
    
    async def test_nested_transaction_rollback(self):
        """Testa rollback de transações aninhadas."""
        
        async with self.TestSessionLocal() as session:
            async with session.begin():
                # Transação externa - criar integração
                integration = Integration(
                    id=str(uuid4()),
                    name="Nested Transaction Test",
                    channel="zapier",
                    agent_id=str(uuid4()),
                    webhook_url="https://test-nested.com/webhook",
                    is_active=True,
                    rate_limit_per_minute=60,
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow()
                )
                
                session.add(integration)
                await session.flush()  # Flush para obter ID
                
                try:
                    # Savepoint para transação aninhada
                    savepoint = await session.begin_nested()
                    
                    # Criar token válido
                    token = WebhookToken(
                        integration_id=integration.id,
                        token="whk_nested_test_token_123",
                        token_type="bearer",
                        is_active=True,
                        expires_at=datetime.utcnow() + timedelta(days=30),
                        created_at=datetime.utcnow()
                    )
                    
                    session.add(token)
                    
                    # Criar webhook call que vai causar erro
                    invalid_call = WebhookCall(
                        integration_id="invalid-id",  # ID inválido
                        status_code=200,
                        execution_time_ms=150,
                        payload={"test": "nested"},
                        ip_address="192.168.1.100",
                        user_agent="NestedTestAgent/1.0",
                        created_at=datetime.utcnow()
                    )
                    
                    session.add(invalid_call)
                    
                    # Tentar commit do savepoint
                    await savepoint.commit()
                    
                except (IntegrityError, SQLAlchemyError):
                    # Rollback apenas do savepoint
                    await savepoint.rollback()
                
                # Transação externa continua - adicionar webhook call válido
                valid_call = WebhookCall(
                    integration_id=integration.id,
                    status_code=200,
                    execution_time_ms=150,
                    payload={"test": "nested_valid"},
                    ip_address="192.168.1.100",
                    user_agent="NestedTestAgent/1.0",
                    created_at=datetime.utcnow()
                )
                
                session.add(valid_call)
                
                # Commit da transação externa
        
        # Verificar resultados
        async with self.TestSessionLocal() as session:
            # Integração deve existir
            integration_result = await session.execute(
                select(Integration).where(Integration.name == "Nested Transaction Test")
            )
            saved_integration = integration_result.scalar_one_or_none()
            
            assert saved_integration is not None
            
            # Token não deve existir (rollback do savepoint)
            token_result = await session.execute(
                select(WebhookToken).where(WebhookToken.token == "whk_nested_test_token_123")
            )
            saved_token = token_result.scalar_one_or_none()
            
            assert saved_token is None
            
            # Webhook call válido deve existir
            call_result = await session.execute(
                select(WebhookCall).where(
                    WebhookCall.integration_id == saved_integration.id
                )
            )
            saved_call = call_result.scalar_one_or_none()
            
            assert saved_call is not None
            assert saved_call.payload == {"test": "nested_valid"}
    
    async def test_concurrent_transaction_handling(self):
        """Testa tratamento de transações concorrentes."""
        
        # Criar integração base
        base_integration_id = str(uuid4())
        
        async with self.TestSessionLocal() as session:
            integration = Integration(
                id=base_integration_id,
                name="Concurrent Transaction Test",
                channel="whatsapp",
                agent_id=str(uuid4()),
                webhook_url="https://test-concurrent.com/webhook",
                is_active=True,
                rate_limit_per_minute=60,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            session.add(integration)
            await session.commit()
        
        async def create_webhook_call(call_id: int):
            """Cria uma webhook call em transação separada."""
            async with self.TestSessionLocal() as session:
                async with session.begin():
                    webhook_call = WebhookCall(
                        integration_id=base_integration_id,
                        status_code=200,
                        execution_time_ms=100 + call_id,
                        payload={"concurrent_test": call_id},
                        response={"success": True, "call_id": call_id},
                        ip_address=f"192.168.1.{100 + (call_id % 50)}",
                        user_agent="ConcurrentTestAgent/1.0",
                        created_at=datetime.utcnow()
                    )
                    
                    session.add(webhook_call)
                    
                    # Simular processamento
                    await asyncio.sleep(0.01)
                    
                    return call_id
        
        # Executar 20 transações concorrentes
        concurrent_count = 20
        tasks = [create_webhook_call(i) for i in range(concurrent_count)]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Verificar resultados
        successful_calls = [r for r in results if isinstance(r, int)]
        exceptions = [r for r in results if isinstance(r, Exception)]
        
        assert len(successful_calls) == concurrent_count
        assert len(exceptions) == 0
        
        # Verificar se todas as calls foram persistidas
        async with self.TestSessionLocal() as session:
            call_count = await session.execute(
                select(func.count(WebhookCall.id)).where(
                    WebhookCall.integration_id == base_integration_id
                )
            )
            
            total_calls = call_count.scalar()
            assert total_calls == concurrent_count
    
    async def test_transaction_isolation_levels(self):
        """Testa diferentes níveis de isolamento de transação."""
        
        # Criar integração base
        integration_id = str(uuid4())
        
        async with self.TestSessionLocal() as session:
            integration = Integration(
                id=integration_id,
                name="Isolation Test Integration",
                channel="telegram",
                agent_id=str(uuid4()),
                webhook_url="https://test-isolation.com/webhook",
                is_active=True,
                rate_limit_per_minute=60,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            session.add(integration)
            await session.commit()
        
        # Transação 1 - Lê dados iniciais
        async def transaction_1():
            async with self.TestSessionLocal() as session:
                # Ler contagem inicial
                initial_count = await session.execute(
                    select(func.count(WebhookCall.id)).where(
                        WebhookCall.integration_id == integration_id
                    )
                )
                
                count_1 = initial_count.scalar()
                
                # Aguardar um pouco
                await asyncio.sleep(0.1)
                
                # Ler contagem novamente
                final_count = await session.execute(
                    select(func.count(WebhookCall.id)).where(
                        WebhookCall.integration_id == integration_id
                    )
                )
                
                count_2 = final_count.scalar()
                
                return {"initial": count_1, "final": count_2}
        
        # Transação 2 - Adiciona dados durante transação 1
        async def transaction_2():
            await asyncio.sleep(0.05)  # Aguardar transação 1 começar
            
            async with self.TestSessionLocal() as session:
                async with session.begin():
                    webhook_call = WebhookCall(
                        integration_id=integration_id,
                        status_code=200,
                        execution_time_ms=150,
                        payload={"isolation_test": True},
                        response={"success": True},
                        ip_address="192.168.1.200",
                        user_agent="IsolationTestAgent/1.0",
                        created_at=datetime.utcnow()
                    )
                    
                    session.add(webhook_call)
        
        # Executar transações concorrentemente
        results = await asyncio.gather(
            transaction_1(),
            transaction_2(),
            return_exceptions=True
        )
        
        transaction_1_result = results[0]
        
        # Verificar isolamento
        assert isinstance(transaction_1_result, dict)
        
        # Em SQLite, o comportamento pode variar, mas não deve haver erro
        assert "initial" in transaction_1_result
        assert "final" in transaction_1_result
    
    async def test_deadlock_detection_and_recovery(self):
        """Testa detecção e recuperação de deadlocks."""
        
        # Criar duas integrações
        integration_1_id = str(uuid4())
        integration_2_id = str(uuid4())
        
        async with self.TestSessionLocal() as session:
            integration_1 = Integration(
                id=integration_1_id,
                name="Deadlock Test Integration 1",
                channel="whatsapp",
                agent_id=str(uuid4()),
                webhook_url="https://test-deadlock-1.com/webhook",
                is_active=True,
                rate_limit_per_minute=60,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            integration_2 = Integration(
                id=integration_2_id,
                name="Deadlock Test Integration 2",
                channel="telegram",
                agent_id=str(uuid4()),
                webhook_url="https://test-deadlock-2.com/webhook",
                is_active=True,
                rate_limit_per_minute=60,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            session.add_all([integration_1, integration_2])
            await session.commit()
        
        async def transaction_a():
            """Transação A - atualiza integração 1, depois 2."""
            try:
                async with self.TestSessionLocal() as session:
                    async with session.begin():
                        # Bloquear integração 1
                        integration_1 = await session.get(Integration, integration_1_id)
                        integration_1.updated_at = datetime.utcnow()
                        
                        await asyncio.sleep(0.1)  # Simular processamento
                        
                        # Tentar bloquear integração 2
                        integration_2 = await session.get(Integration, integration_2_id)
                        integration_2.updated_at = datetime.utcnow()
                        
                        return "transaction_a_success"
                        
            except Exception as e:
                return f"transaction_a_error: {str(e)}"
        
        async def transaction_b():
            """Transação B - atualiza integração 2, depois 1."""
            try:
                async with self.TestSessionLocal() as session:
                    async with session.begin():
                        # Bloquear integração 2
                        integration_2 = await session.get(Integration, integration_2_id)
                        integration_2.updated_at = datetime.utcnow()
                        
                        await asyncio.sleep(0.1)  # Simular processamento
                        
                        # Tentar bloquear integração 1
                        integration_1 = await session.get(Integration, integration_1_id)
                        integration_1.updated_at = datetime.utcnow()
                        
                        return "transaction_b_success"
                        
            except Exception as e:
                return f"transaction_b_error: {str(e)}"
        
        # Executar transações que podem causar deadlock
        results = await asyncio.gather(
            transaction_a(),
            transaction_b(),
            return_exceptions=True
        )
        
        # Verificar que pelo menos uma transação foi bem-sucedida
        # (SQLite pode não ter deadlocks reais, mas teste é válido)
        success_count = sum(1 for r in results if "success" in str(r))
        assert success_count >= 1
    
    async def test_transaction_timeout_handling(self):
        """Testa tratamento de timeout de transações."""
        
        async def long_running_transaction():
            """Transação que demora muito para completar."""
            async with self.TestSessionLocal() as session:
                async with session.begin():
                    integration = Integration(
                        id=str(uuid4()),
                        name="Timeout Test Integration",
                        channel="zapier",
                        agent_id=str(uuid4()),
                        webhook_url="https://test-timeout.com/webhook",
                        is_active=True,
                        rate_limit_per_minute=60,
                        created_at=datetime.utcnow(),
                        updated_at=datetime.utcnow()
                    )
                    
                    session.add(integration)
                    
                    # Simular processamento longo
                    await asyncio.sleep(2.0)  # 2 segundos
                    
                    return "completed"
        
        # Executar com timeout
        try:
            result = await asyncio.wait_for(
                long_running_transaction(),
                timeout=1.0  # 1 segundo de timeout
            )
            assert False, "Deveria ter dado timeout"
            
        except asyncio.TimeoutError:
            # Timeout esperado
            pass
        
        # Verificar que dados não foram persistidos
        async with self.TestSessionLocal() as session:
            integration_result = await session.execute(
                select(Integration).where(Integration.name == "Timeout Test Integration")
            )
            saved_integration = integration_result.scalar_one_or_none()
            
            assert saved_integration is None
    
    async def test_bulk_operation_transaction(self):
        """Testa transação com operações em lote."""
        
        integration_id = str(uuid4())
        
        # Criar integração base
        async with self.TestSessionLocal() as session:
            integration = Integration(
                id=integration_id,
                name="Bulk Operation Test",
                channel="whatsapp",
                agent_id=str(uuid4()),
                webhook_url="https://test-bulk.com/webhook",
                is_active=True,
                rate_limit_per_minute=60,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            session.add(integration)
            await session.commit()
        
        # Operação em lote
        async with self.TestSessionLocal() as session:
            async with session.begin():
                # Criar 1000 webhook calls em uma transação
                webhook_calls = []
                
                for i in range(1000):
                    call = WebhookCall(
                        integration_id=integration_id,
                        status_code=200,
                        execution_time_ms=100 + (i % 100),
                        payload={"bulk_test": i, "batch": "large"},
                        response={"success": True, "index": i},
                        ip_address=f"192.168.{1 + (i // 256)}.{i % 256}",
                        user_agent="BulkTestAgent/1.0",
                        created_at=datetime.utcnow()
                    )
                    
                    webhook_calls.append(call)
                
                # Adicionar todos de uma vez
                session.add_all(webhook_calls)
        
        # Verificar se todos foram persistidos
        async with self.TestSessionLocal() as session:
            call_count = await session.execute(
                select(func.count(WebhookCall.id)).where(
                    WebhookCall.integration_id == integration_id
                )
            )
            
            total_calls = call_count.scalar()
            assert total_calls == 1000
            
            # Verificar alguns registros específicos
            first_call = await session.execute(
                select(WebhookCall).where(
                    WebhookCall.integration_id == integration_id
                ).order_by(WebhookCall.created_at).limit(1)
            )
            
            first = first_call.scalar_one()
            assert first.payload["bulk_test"] == 0
            
            last_call = await session.execute(
                select(WebhookCall).where(
                    WebhookCall.integration_id == integration_id
                ).order_by(WebhookCall.created_at.desc()).limit(1)
            )
            
            last = last_call.scalar_one()
            assert first.payload["batch"] == "large"
    
    async def test_transaction_with_service_layer(self):
        """Testa transações através da camada de serviço."""
        
        async with self.TestSessionLocal() as session:
            # Usar serviço para criar integração
            integration_data = {
                "name": "Service Layer Transaction Test",
                "channel": "telegram",
                "agent_id": str(uuid4()),
                "rate_limit_per_minute": 60,
                "is_active": True
            }
            
            created_integration = await self.integration_service.create_integration(
                session, integration_data
            )
            
            assert created_integration is not None
            assert created_integration.name == "Service Layer Transaction Test"
            
            # Usar serviço para processar webhook
            webhook_data = {
                "integration_id": created_integration.id,
                "payload": {"service_test": True},
                "ip_address": "192.168.1.100",
                "user_agent": "ServiceTestAgent/1.0"
            }
            
            with patch('app.services.webhook_service.suna_client') as mock_suna:
                mock_suna.execute_agent = AsyncMock(return_value={
                    "success": True,
                    "response": "Service layer test response"
                })
                
                result = await self.webhook_service.process_webhook(
                    session,
                    created_integration.id,
                    created_integration.agent_id,
                    webhook_data["payload"],
                    webhook_data["ip_address"],
                    webhook_data["user_agent"],
                    "telegram"
                )
                
                assert result is not None
                assert result["success"] is True
            
            # Verificar se webhook call foi registrada
            webhook_calls = await session.execute(
                select(WebhookCall).where(
                    WebhookCall.integration_id == created_integration.id
                )
            )
            
            calls = webhook_calls.scalars().all()
            assert len(calls) == 1
            
            call = calls[0]
            assert call.payload == {"service_test": True}
            assert call.status_code == 200