"""
Testes de integração Redis para rate limiting sob carga.

Este módulo testa o comportamento do rate limiting com Redis sob
diferentes cenários de carga, incluindo alta concorrência,
falhas de conexão e recuperação.
"""

import pytest
import asyncio
import time
import json
from datetime import datetime, timedelta
from typing import Dict, Any, List
from unittest.mock import Mock, patch, AsyncMock
from uuid import uuid4

import redis.asyncio as redis
from app.services.advanced_rate_limiting import (
    AdvancedRateLimiter,
    ThreatLevel,
    BlockReason,
    get_advanced_rate_limiter
)


class TestRedisRateLimitingIntegration:
    """Testes de integração para rate limiting com Redis."""
    
    @pytest.fixture(autouse=True)
    async def setup_redis(self):
        """Setup do Redis para testes."""
        
        # Conectar ao Redis de teste
        self.redis_client = redis.Redis(
            host="localhost",
            port=6379,
            db=14,  # DB separado para testes de rate limiting
            decode_responses=True
        )
        
        # Limpar dados de teste
        await self.redis_client.flushdb()
        
        # Criar rate limiter
        self.rate_limiter = AdvancedRateLimiter(self.redis_client)
        
        # Dados de teste
        self.test_integration_id = str(uuid4())
        self.test_ip = "192.168.1.100"
        self.test_token = "whk_test_token_redis_123"
        
        yield
        
        # Cleanup
        await self.redis_client.flushdb()
        await self.redis_client.close()
    
    async def test_basic_rate_limiting_functionality(self):
        """Testa funcionalidade básica de rate limiting."""
        
        # Configurar limite baixo para teste
        rate_limit = 5
        
        # Fazer requisições dentro do limite
        for i in range(rate_limit):
            result = await self.rate_limiter.check_rate_limit(
                integration_id=self.test_integration_id,
                ip_address=self.test_ip,
                user_agent="TestAgent/1.0"
            )
            
            assert result.allowed is True
            assert result.remaining == rate_limit - (i + 1)
            assert result.threat_level == ThreatLevel.LOW
        
        # Próxima requisição deve ser bloqueada
        result = await self.rate_limiter.check_rate_limit(
            integration_id=self.test_integration_id,
            ip_address=self.test_ip,
            user_agent="TestAgent/1.0"
        )
        
        assert result.allowed is False
        assert result.remaining == 0
    
    async def test_concurrent_rate_limiting(self):
        """Testa rate limiting sob alta concorrência."""
        
        async def make_rate_limit_check(request_id: int):
            """Faz uma verificação de rate limit."""
            try:
                result = await self.rate_limiter.check_rate_limit(
                    integration_id=self.test_integration_id,
                    ip_address=f"192.168.1.{100 + (request_id % 50)}",
                    user_agent=f"ConcurrentTestAgent/{request_id}",
                    payload_size=1024
                )
                
                return {
                    "request_id": request_id,
                    "allowed": result.allowed,
                    "remaining": result.remaining,
                    "threat_level": result.threat_level.value,
                    "success": True
                }
                
            except Exception as e:
                return {
                    "request_id": request_id,
                    "success": False,
                    "error": str(e)
                }
        
        # Fazer 100 verificações concorrentes
        concurrent_requests = 100
        start_time = time.time()
        
        tasks = [make_rate_limit_check(i) for i in range(concurrent_requests)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        end_time = time.time()
        total_time = (end_time - start_time) * 1000  # ms
        
        # Analisar resultados
        successful_results = [r for r in results if isinstance(r, dict) and r.get("success")]
        failed_results = [r for r in results if isinstance(r, dict) and not r.get("success")]
        exceptions = [r for r in results if isinstance(r, Exception)]
        
        print(f"Concurrent rate limiting results:")
        print(f"  Total requests: {concurrent_requests}")
        print(f"  Successful: {len(successful_results)}")
        print(f"  Failed: {len(failed_results)}")
        print(f"  Exceptions: {len(exceptions)}")
        print(f"  Total time: {total_time:.2f}ms")
        print(f"  Average time per request: {total_time/concurrent_requests:.2f}ms")
        
        # Verificações
        assert len(successful_results) >= 90  # Pelo menos 90% de sucesso
        assert len(exceptions) == 0  # Nenhuma exceção não tratada
        
        # Verificar que rate limiting funcionou
        allowed_requests = [r for r in successful_results if r["allowed"]]
        blocked_requests = [r for r in successful_results if not r["allowed"]]
        
        print(f"  Allowed requests: {len(allowed_requests)}")
        print(f"  Blocked requests: {len(blocked_requests)}")
        
        # Deve haver tanto requisições permitidas quanto bloqueadas
        assert len(allowed_requests) > 0
        assert len(blocked_requests) > 0
    
    async def test_rate_limiting_with_different_ips(self):
        """Testa rate limiting com diferentes IPs."""
        
        rate_limit = 3
        ip_addresses = [f"192.168.1.{100 + i}" for i in range(10)]
        
        # Cada IP deve ter seu próprio limite
        for ip in ip_addresses:
            for i in range(rate_limit):
                result = await self.rate_limiter.check_rate_limit(
                    integration_id=self.test_integration_id,
                    ip_address=ip,
                    user_agent="MultiIPTestAgent/1.0"
                )
                
                assert result.allowed is True
                assert result.remaining == rate_limit - (i + 1)
            
            # Próxima requisição para este IP deve ser bloqueada
            result = await self.rate_limiter.check_rate_limit(
                integration_id=self.test_integration_id,
                ip_address=ip,
                user_agent="MultiIPTestAgent/1.0"
            )
            
            assert result.allowed is False
            assert result.remaining == 0
    
    async def test_rate_limit_window_expiration(self):
        """Testa expiração da janela de rate limit."""
        
        rate_limit = 2
        
        # Esgotar limite
        for i in range(rate_limit):
            result = await self.rate_limiter.check_rate_limit(
                integration_id=self.test_integration_id,
                ip_address=self.test_ip,
                user_agent="ExpirationTestAgent/1.0"
            )
            
            assert result.allowed is True
        
        # Próxima deve ser bloqueada
        result = await self.rate_limiter.check_rate_limit(
            integration_id=self.test_integration_id,
            ip_address=self.test_ip,
            user_agent="ExpirationTestAgent/1.0"
        )
        
        assert result.allowed is False
        
        # Simular passagem de tempo (modificar timestamp no Redis)
        current_time = int(time.time())
        future_time = current_time + 70  # 70 segundos no futuro
        
        # Patch time.time para simular futuro
        with patch('time.time', return_value=future_time):
            result = await self.rate_limiter.check_rate_limit(
                integration_id=self.test_integration_id,
                ip_address=self.test_ip,
                user_agent="ExpirationTestAgent/1.0"
            )
            
            # Deve ser permitido novamente (nova janela)
            assert result.allowed is True
    
    async def test_threat_detection_and_blocking(self):
        """Testa detecção de ameaças e bloqueio automático."""
        
        # Simular comportamento suspeito - muitas requisições rapidamente
        suspicious_requests = 50
        
        for i in range(suspicious_requests):
            result = await self.rate_limiter.check_rate_limit(
                integration_id=self.test_integration_id,
                ip_address=self.test_ip,
                user_agent="SuspiciousBot/1.0",
                payload_size=1024 * 1024  # 1MB payload
            )
            
            # Após algumas requisições, deve detectar ameaça
            if i > 10:
                if not result.allowed:
                    assert result.threat_level in [ThreatLevel.MEDIUM, ThreatLevel.HIGH, ThreatLevel.CRITICAL]
                    break
        
        # Verificar se IP foi bloqueado
        blocked_ips = await self.rate_limiter.get_blocked_ips()
        blocked_ip_addresses = [ip["ip_address"] for ip in blocked_ips]
        
        # IP suspeito pode ter sido bloqueado
        if self.test_ip in blocked_ip_addresses:
            # Verificar detalhes do bloqueio
            blocked_ip_info = next(ip for ip in blocked_ips if ip["ip_address"] == self.test_ip)
            
            assert blocked_ip_info["threat_level"] in ["medium", "high", "critical"]
            assert blocked_ip_info["reason"] in [reason.value for reason in BlockReason]
    
    async def test_distributed_attack_detection(self):
        """Testa detecção de ataques distribuídos."""
        
        # Simular mesmo token sendo usado por múltiplos IPs
        token = self.test_token
        ip_addresses = [f"192.168.1.{100 + i}" for i in range(20)]
        
        # Fazer muitas requisições com mesmo token de IPs diferentes
        for ip in ip_addresses:
            for i in range(10):
                result = await self.rate_limiter.check_rate_limit(
                    integration_id=self.test_integration_id,
                    ip_address=ip,
                    user_agent="DistributedAttackBot/1.0",
                    token=token
                )
                
                # Após detectar padrão distribuído, deve bloquear
                if not result.allowed and result.threat_level == ThreatLevel.HIGH:
                    break
        
        # Verificar se ataque distribuído foi detectado
        security_events = await self.rate_limiter.get_security_events(limit=100)
        
        distributed_events = [
            event for event in security_events
            if "distributed_attack" in event.get("details", {}).get("detected_patterns", [])
        ]
        
        # Pode ter detectado ataque distribuído
        if distributed_events:
            assert len(distributed_events) > 0
            event = distributed_events[0]
            assert event["threat_level"] in ["high", "critical"]
    
    async def test_redis_connection_failure_handling(self):
        """Testa tratamento de falhas de conexão Redis."""
        
        # Simular falha de conexão
        original_redis = self.rate_limiter.redis
        
        # Mock Redis que falha
        mock_redis = Mock()
        mock_redis.incr = AsyncMock(side_effect=redis.ConnectionError("Connection failed"))
        mock_redis.get = AsyncMock(side_effect=redis.ConnectionError("Connection failed"))
        mock_redis.setex = AsyncMock(side_effect=redis.ConnectionError("Connection failed"))
        
        self.rate_limiter.redis = mock_redis
        
        try:
            # Tentar fazer verificação de rate limit
            result = await self.rate_limiter.check_rate_limit(
                integration_id=self.test_integration_id,
                ip_address=self.test_ip,
                user_agent="ConnectionFailureTest/1.0"
            )
            
            # Deve falhar graciosamente ou usar fallback
            # (comportamento depende da implementação)
            assert result is not None
            
        except Exception as e:
            # Se exceção for lançada, deve ser tratada adequadamente
            assert "Connection failed" in str(e)
        
        finally:
            # Restaurar Redis original
            self.rate_limiter.redis = original_redis
    
    async def test_redis_memory_usage_under_load(self):
        """Testa uso de memória Redis sob carga."""
        
        # Obter uso de memória inicial
        initial_memory = await self.redis_client.memory_usage("nonexistent_key") or 0
        
        # Gerar muitos dados de rate limiting
        integration_ids = [str(uuid4()) for _ in range(100)]
        ip_addresses = [f"192.168.{i//256}.{i%256}" for i in range(1000)]
        
        # Fazer muitas verificações para gerar dados
        for integration_id in integration_ids[:10]:  # Limitar para não sobrecarregar
            for ip in ip_addresses[:50]:  # Limitar para não sobrecarregar
                await self.rate_limiter.check_rate_limit(
                    integration_id=integration_id,
                    ip_address=ip,
                    user_agent="MemoryTestAgent/1.0"
                )
        
        # Verificar uso de memória
        memory_info = await self.redis_client.info("memory")
        used_memory = memory_info.get("used_memory", 0)
        
        print(f"Redis memory usage after load test: {used_memory} bytes")
        
        # Verificar se há limpeza automática de dados antigos
        # (implementação específica do rate limiter)
        
        # Simular passagem de tempo e verificar limpeza
        await asyncio.sleep(1)
        
        # Verificar se algumas chaves expiraram
        all_keys = await self.redis_client.keys("*")
        print(f"Total Redis keys after load test: {len(all_keys)}")
        
        # Deve haver um número razoável de chaves (não infinito)
        assert len(all_keys) < 10000  # Limite razoável
    
    async def test_rate_limiting_performance_benchmarks(self):
        """Testa benchmarks de performance do rate limiting."""
        
        # Benchmark 1: Verificações sequenciais
        sequential_count = 1000
        start_time = time.time()
        
        for i in range(sequential_count):
            await self.rate_limiter.check_rate_limit(
                integration_id=self.test_integration_id,
                ip_address=f"192.168.1.{100 + (i % 50)}",
                user_agent="SequentialBenchmark/1.0"
            )
        
        sequential_time = (time.time() - start_time) * 1000  # ms
        sequential_avg = sequential_time / sequential_count
        
        print(f"Sequential rate limiting benchmark:")
        print(f"  Total requests: {sequential_count}")
        print(f"  Total time: {sequential_time:.2f}ms")
        print(f"  Average time per request: {sequential_avg:.2f}ms")
        print(f"  Requests per second: {sequential_count / (sequential_time / 1000):.2f}")
        
        # Benchmark 2: Verificações concorrentes
        concurrent_count = 100
        start_time = time.time()
        
        async def concurrent_check(request_id):
            return await self.rate_limiter.check_rate_limit(
                integration_id=self.test_integration_id,
                ip_address=f"192.168.2.{100 + (request_id % 50)}",
                user_agent="ConcurrentBenchmark/1.0"
            )
        
        tasks = [concurrent_check(i) for i in range(concurrent_count)]
        await asyncio.gather(*tasks)
        
        concurrent_time = (time.time() - start_time) * 1000  # ms
        concurrent_avg = concurrent_time / concurrent_count
        
        print(f"Concurrent rate limiting benchmark:")
        print(f"  Total requests: {concurrent_count}")
        print(f"  Total time: {concurrent_time:.2f}ms")
        print(f"  Average time per request: {concurrent_avg:.2f}ms")
        print(f"  Requests per second: {concurrent_count / (concurrent_time / 1000):.2f}")
        
        # Verificações de performance
        assert sequential_avg < 50  # Menos de 50ms por verificação sequencial
        assert concurrent_avg < 100  # Menos de 100ms por verificação concorrente
        
        # Concorrência deve ser mais eficiente que sequencial para muitas requisições
        if concurrent_count >= sequential_count / 10:
            assert concurrent_time < sequential_time
    
    async def test_rate_limiting_data_consistency(self):
        """Testa consistência de dados no rate limiting."""
        
        # Fazer verificações concorrentes para mesmo IP
        same_ip = "192.168.1.150"
        concurrent_checks = 20
        
        async def check_rate_limit_with_id(check_id):
            result = await self.rate_limiter.check_rate_limit(
                integration_id=self.test_integration_id,
                ip_address=same_ip,
                user_agent=f"ConsistencyTest/{check_id}"
            )
            
            return {
                "check_id": check_id,
                "allowed": result.allowed,
                "remaining": result.remaining
            }
        
        # Executar verificações concorrentes
        tasks = [check_rate_limit_with_id(i) for i in range(concurrent_checks)]
        results = await asyncio.gather(*tasks)
        
        # Analisar consistência
        allowed_results = [r for r in results if r["allowed"]]
        blocked_results = [r for r in results if not r["allowed"]]
        
        print(f"Rate limiting consistency test:")
        print(f"  Total checks: {concurrent_checks}")
        print(f"  Allowed: {len(allowed_results)}")
        print(f"  Blocked: {len(blocked_results)}")
        
        # Verificar que contadores são consistentes
        if allowed_results:
            # Remaining deve ser decrescente para requisições permitidas
            remaining_values = [r["remaining"] for r in allowed_results]
            print(f"  Remaining values: {remaining_values}")
            
            # Deve haver uma progressão lógica (pode não ser perfeitamente sequencial devido à concorrência)
            assert min(remaining_values) >= 0
            assert max(remaining_values) < 60  # Assumindo limite padrão
        
        # Verificar que dados no Redis são consistentes
        rate_limit_keys = await self.redis_client.keys(f"rate_limit:{self.test_integration_id}:{same_ip}:*")
        
        if rate_limit_keys:
            # Verificar valores dos contadores
            for key in rate_limit_keys:
                value = await self.redis_client.get(key)
                if value:
                    count = int(value)
                    assert count >= 0
                    assert count <= 100  # Limite razoável
    
    async def test_security_events_logging(self):
        """Testa logging de eventos de segurança no Redis."""
        
        # Gerar eventos de segurança
        suspicious_ips = [f"10.0.0.{i}" for i in range(10)]
        
        for ip in suspicious_ips:
            # Fazer requisições suspeitas
            for i in range(20):
                await self.rate_limiter.check_rate_limit(
                    integration_id=self.test_integration_id,
                    ip_address=ip,
                    user_agent="MaliciousBot/1.0",
                    payload_size=5 * 1024 * 1024  # 5MB payload suspeito
                )
        
        # Verificar eventos de segurança
        security_events = await self.rate_limiter.get_security_events(limit=100)
        
        print(f"Security events logged: {len(security_events)}")
        
        if security_events:
            # Verificar estrutura dos eventos
            for event in security_events[:5]:  # Verificar primeiros 5
                assert "ip_address" in event
                assert "event_type" in event
                assert "threat_level" in event
                assert "timestamp" in event
                assert "details" in event
                
                # Verificar que timestamp é válido
                timestamp = event["timestamp"]
                parsed_time = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                assert parsed_time <= datetime.utcnow()
        
        # Verificar que eventos são filtráveis por nível de ameaça
        high_threat_events = await self.rate_limiter.get_security_events(
            limit=50,
            threat_level=ThreatLevel.HIGH
        )
        
        for event in high_threat_events:
            assert event["threat_level"] == "high"
    
    async def test_ip_blocking_and_unblocking(self):
        """Testa bloqueio e desbloqueio de IPs."""
        
        test_ip = "192.168.1.200"
        
        # Verificar que IP não está bloqueado inicialmente
        result = await self.rate_limiter.check_rate_limit(
            integration_id=self.test_integration_id,
            ip_address=test_ip,
            user_agent="BlockingTest/1.0"
        )
        
        assert result.allowed is True
        
        # Simular comportamento que leva ao bloqueio
        for i in range(100):
            result = await self.rate_limiter.check_rate_limit(
                integration_id=self.test_integration_id,
                ip_address=test_ip,
                user_agent="AttackBot/1.0",
                payload_size=10 * 1024 * 1024  # 10MB payload
            )
            
            if not result.allowed and result.block_reason:
                break
        
        # Verificar se IP foi bloqueado
        blocked_ips = await self.rate_limiter.get_blocked_ips()
        blocked_ip_addresses = [ip["ip_address"] for ip in blocked_ips]
        
        if test_ip in blocked_ip_addresses:
            print(f"IP {test_ip} was blocked successfully")
            
            # Tentar desbloquear IP
            unblock_success = await self.rate_limiter.unblock_ip(test_ip)
            assert unblock_success is True
            
            # Verificar que IP foi desbloqueado
            updated_blocked_ips = await self.rate_limiter.get_blocked_ips()
            updated_blocked_addresses = [ip["ip_address"] for ip in updated_blocked_ips]
            
            assert test_ip not in updated_blocked_addresses
            
            # Verificar que IP pode fazer requisições novamente
            result = await self.rate_limiter.check_rate_limit(
                integration_id=self.test_integration_id,
                ip_address=test_ip,
                user_agent="UnblockedTest/1.0"
            )
            
            assert result.allowed is True
        else:
            print(f"IP {test_ip} was not blocked (may need more aggressive behavior)")
    
    async def test_redis_key_expiration(self):
        """Testa expiração de chaves Redis."""
        
        # Fazer algumas verificações de rate limit
        for i in range(5):
            await self.rate_limiter.check_rate_limit(
                integration_id=self.test_integration_id,
                ip_address=self.test_ip,
                user_agent="ExpirationTest/1.0"
            )
        
        # Verificar chaves criadas
        initial_keys = await self.redis_client.keys("*")
        print(f"Initial Redis keys: {len(initial_keys)}")
        
        # Verificar TTL das chaves
        for key in initial_keys[:5]:  # Verificar algumas chaves
            ttl = await self.redis_client.ttl(key)
            if ttl > 0:
                print(f"Key {key} TTL: {ttl} seconds")
                assert ttl <= 3600  # Máximo 1 hora
                assert ttl > 0  # Deve ter TTL definido
        
        # Simular passagem de tempo (não podemos realmente esperar)
        # Em teste real, aguardaria a expiração
        
        # Verificar que chaves antigas são limpas
        # (implementação específica do rate limiter deve fazer limpeza)