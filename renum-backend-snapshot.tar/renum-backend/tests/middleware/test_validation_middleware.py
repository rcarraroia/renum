"""
Testes para middleware de validação de entrada.

Este módulo contém testes para os middlewares de validação de payload,
rate limiting e headers de segurança.
"""

import pytest
import json
import time
from unittest.mock import Mock, patch, AsyncMock
from fastapi import FastAPI, Request, Response
from fastapi.testclient import TestClient
from starlette.responses import JSONResponse

from app.api.middleware.validation_middleware import (
    PayloadValidationMiddleware,
    RateLimitMiddleware,
    SecurityHeadersMiddleware
)


class TestPayloadValidationMiddleware:
    """Testes para middleware de validação de payload."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.post("/webhook/test")
        async def test_webhook(request: Request):
            body = await request.body()
            return {"success": True, "received": json.loads(body.decode())}
        
        @self.app.get("/api/test")
        async def test_api():
            return {"message": "API endpoint"}
    
    def test_valid_json_payload(self):
        """Testa processamento de payload JSON válido."""
        
        # Adicionar middleware
        self.app.add_middleware(PayloadValidationMiddleware, max_payload_size=1024*1024)
        client = TestClient(self.app)
        
        payload = {"message": "Hello, world!", "user_id": "123"}
        
        response = client.post(
            "/webhook/test",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 200
        assert response.json()["success"] is True
        assert response.json()["received"] == payload
    
    def test_unsupported_content_type(self):
        """Testa rejeição de content-type não suportado."""
        
        self.app.add_middleware(PayloadValidationMiddleware)
        client = TestClient(self.app)
        
        response = client.post(
            "/webhook/test",
            data="test data",
            headers={"Content-Type": "application/xml"}
        )
        
        assert response.status_code == 415
        assert response.json()["code"] == "UNSUPPORTED_CONTENT_TYPE"
        assert "application/xml" in response.json()["error"]
    
    def test_payload_too_large_content_length(self):
        """Testa rejeição de payload muito grande via Content-Length."""
        
        max_size = 1024  # 1KB para teste
        self.app.add_middleware(PayloadValidationMiddleware, max_payload_size=max_size)
        client = TestClient(self.app)
        
        large_payload = {"data": "x" * (max_size + 100)}
        
        response = client.post(
            "/webhook/test",
            json=large_payload,
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 413
        assert response.json()["code"] == "PAYLOAD_TOO_LARGE"
        assert str(max_size) in response.json()["error"]
    
    def test_payload_too_large_actual_size(self):
        """Testa rejeição de payload muito grande pelo tamanho real."""
        
        max_size = 100  # 100 bytes para teste
        self.app.add_middleware(PayloadValidationMiddleware, max_payload_size=max_size)
        client = TestClient(self.app)
        
        # Criar payload que excede o limite
        large_payload = {"message": "x" * 200}
        
        response = client.post(
            "/webhook/test",
            json=large_payload,
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 413
        assert response.json()["code"] == "PAYLOAD_TOO_LARGE"
    
    def test_invalid_json(self):
        """Testa rejeição de JSON inválido."""
        
        self.app.add_middleware(PayloadValidationMiddleware)
        client = TestClient(self.app)
        
        invalid_json = '{"message": "test", "invalid": }'
        
        response = client.post(
            "/webhook/test",
            data=invalid_json,
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 400
        assert response.json()["code"] == "INVALID_JSON"
    
    def test_invalid_encoding(self):
        """Testa rejeição de encoding inválido."""
        
        self.app.add_middleware(PayloadValidationMiddleware)
        client = TestClient(self.app)
        
        # Dados com encoding inválido
        invalid_data = b'\\xff\\xfe{"message": "test"}'
        
        response = client.post(
            "/webhook/test",
            content=invalid_data,
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 400
        assert response.json()["code"] == "INVALID_ENCODING"
    
    @patch('app.api.middleware.validation_middleware.security_validator')
    def test_security_validation_failure(self, mock_validator):
        """Testa falha na validação de segurança."""
        
        # Mock do validador retornando falha
        mock_validator.validate_dict.return_value = {
            "valid": False,
            "issues": ["XSS detectado", "SQL injection detectada"]
        }
        
        self.app.add_middleware(PayloadValidationMiddleware, enable_security_validation=True)
        client = TestClient(self.app)
        
        payload = {"message": "<script>alert('xss')</script>"}
        
        response = client.post(
            "/webhook/test",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 400
        assert response.json()["code"] == "SECURITY_VALIDATION_FAILED"
        assert "XSS detectado" in response.json()["issues"]
        assert "SQL injection detectada" in response.json()["issues"]
    
    def test_suspicious_headers_detection(self):
        """Testa detecção de headers suspeitos."""
        
        self.app.add_middleware(PayloadValidationMiddleware)
        client = TestClient(self.app)
        
        payload = {"message": "test"}
        
        response = client.post(
            "/webhook/test",
            json=payload,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "<script>alert('xss')</script>",
                "X-Forwarded-For": "invalid-ip-format"
            }
        )
        
        assert response.status_code == 400
        assert response.json()["code"] == "SUSPICIOUS_HEADERS"
    
    def test_non_webhook_endpoint_bypass(self):
        """Testa que endpoints não-webhook não são validados."""
        
        self.app.add_middleware(PayloadValidationMiddleware)
        client = TestClient(self.app)
        
        response = client.get("/api/test")
        
        assert response.status_code == 200
        assert response.json()["message"] == "API endpoint"
    
    def test_security_headers_added(self):
        """Testa adição de headers de segurança."""
        
        self.app.add_middleware(PayloadValidationMiddleware)
        client = TestClient(self.app)
        
        payload = {"message": "test"}
        
        response = client.post(
            "/webhook/test",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 200
        
        # Verificar headers de segurança
        assert "X-Content-Type-Options" in response.headers
        assert "X-Frame-Options" in response.headers
        assert "X-XSS-Protection" in response.headers
        assert response.headers["X-Content-Type-Options"] == "nosniff"


class TestRateLimitMiddleware:
    """Testes para middleware de rate limiting."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.post("/webhook/test")
        async def test_webhook():
            return {"success": True}
        
        @self.app.get("/api/test")
        async def test_api():
            return {"message": "API endpoint"}
    
    def test_rate_limit_within_limit(self):
        """Testa requisições dentro do limite."""
        
        rate_limit = 5  # 5 requests per minute
        self.app.add_middleware(
            RateLimitMiddleware,
            default_rate_limit=rate_limit,
            rate_limit_window=60
        )
        client = TestClient(self.app)
        
        # Fazer 3 requisições (dentro do limite)
        for i in range(3):
            response = client.post("/webhook/test")
            assert response.status_code == 200
            
            # Verificar headers de rate limit
            assert "X-RateLimit-Limit" in response.headers
            assert "X-RateLimit-Remaining" in response.headers
            assert "X-RateLimit-Reset" in response.headers
            
            assert response.headers["X-RateLimit-Limit"] == str(rate_limit)
            remaining = int(response.headers["X-RateLimit-Remaining"])
            assert remaining == rate_limit - (i + 1)
    
    def test_rate_limit_exceeded(self):
        """Testa excesso do limite de rate limit."""
        
        rate_limit = 2  # 2 requests per minute
        self.app.add_middleware(
            RateLimitMiddleware,
            default_rate_limit=rate_limit,
            rate_limit_window=60
        )
        client = TestClient(self.app)
        
        # Fazer requisições até o limite
        for i in range(rate_limit):
            response = client.post("/webhook/test")
            assert response.status_code == 200
        
        # Próxima requisição deve ser rejeitada
        response = client.post("/webhook/test")
        assert response.status_code == 429
        assert response.json()["code"] == "RATE_LIMIT_EXCEEDED"
        
        # Verificar headers de rate limit
        assert response.headers["X-RateLimit-Remaining"] == "0"
        assert "Retry-After" in response.headers
    
    def test_rate_limit_window_reset(self):
        """Testa reset da janela de rate limit."""
        
        rate_limit = 2
        window = 1  # 1 segundo para teste rápido
        self.app.add_middleware(
            RateLimitMiddleware,
            default_rate_limit=rate_limit,
            rate_limit_window=window
        )
        client = TestClient(self.app)
        
        # Esgotar o limite
        for i in range(rate_limit):
            response = client.post("/webhook/test")
            assert response.status_code == 200
        
        # Próxima requisição deve ser rejeitada
        response = client.post("/webhook/test")
        assert response.status_code == 429
        
        # Aguardar reset da janela
        time.sleep(window + 0.1)
        
        # Agora deve funcionar novamente
        response = client.post("/webhook/test")
        assert response.status_code == 200
    
    def test_rate_limit_different_ips(self):
        """Testa rate limiting por IP diferente."""
        
        rate_limit = 2
        self.app.add_middleware(
            RateLimitMiddleware,
            default_rate_limit=rate_limit,
            enable_ip_based_limiting=True
        )
        
        # Simular diferentes IPs usando headers
        with TestClient(self.app) as client:
            # IP 1 - esgotar limite
            for i in range(rate_limit):
                response = client.post(
                    "/webhook/test",
                    headers={"X-Forwarded-For": "192.168.1.1"}
                )
                assert response.status_code == 200
            
            # IP 1 - deve ser rejeitado
            response = client.post(
                "/webhook/test",
                headers={"X-Forwarded-For": "192.168.1.1"}
            )
            assert response.status_code == 429
            
            # IP 2 - deve funcionar
            response = client.post(
                "/webhook/test",
                headers={"X-Forwarded-For": "192.168.1.2"}
            )
            assert response.status_code == 200
    
    def test_rate_limit_non_webhook_bypass(self):
        """Testa que endpoints não-webhook não são limitados."""
        
        self.app.add_middleware(
            RateLimitMiddleware,
            default_rate_limit=1  # Limite muito baixo
        )
        client = TestClient(self.app)
        
        # Múltiplas requisições para endpoint não-webhook
        for i in range(5):
            response = client.get("/api/test")
            assert response.status_code == 200
    
    def test_rate_limit_cleanup(self):
        """Testa limpeza de contadores antigos."""
        
        middleware = RateLimitMiddleware(
            app=Mock(),
            default_rate_limit=10,
            rate_limit_window=60
        )
        
        # Adicionar contadores antigos
        current_time = time.time()
        middleware.request_counts = {
            "old_key": {
                "count": 5,
                "window_start": current_time - 200  # Muito antigo
            },
            "recent_key": {
                "count": 3,
                "window_start": current_time - 30  # Recente
            }
        }
        
        # Executar limpeza
        middleware._cleanup_old_counts(current_time)
        
        # Verificar que apenas o recente permaneceu
        assert "old_key" not in middleware.request_counts
        assert "recent_key" in middleware.request_counts


class TestSecurityHeadersMiddleware:
    """Testes para middleware de headers de segurança."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.get("/test")
        async def test_endpoint():
            return {"message": "test"}
    
    def test_default_security_headers(self):
        """Testa adição de headers de segurança padrão."""
        
        self.app.add_middleware(SecurityHeadersMiddleware)
        client = TestClient(self.app)
        
        response = client.get("/test")
        
        assert response.status_code == 200
        
        # Verificar headers de segurança padrão
        expected_headers = [
            "X-Content-Type-Options",
            "X-Frame-Options",
            "X-XSS-Protection",
            "Referrer-Policy",
            "X-Permitted-Cross-Domain-Policies"
        ]
        
        for header in expected_headers:
            assert header in response.headers
        
        # Verificar valores específicos
        assert response.headers["X-Content-Type-Options"] == "nosniff"
        assert response.headers["X-Frame-Options"] == "DENY"
        assert response.headers["X-XSS-Protection"] == "1; mode=block"
    
    def test_custom_security_headers(self):
        """Testa adição de headers customizados."""
        
        custom_headers = {
            "Custom-Security-Header": "custom-value",
            "X-Custom-Protection": "enabled"
        }
        
        self.app.add_middleware(SecurityHeadersMiddleware, custom_headers=custom_headers)
        client = TestClient(self.app)
        
        response = client.get("/test")
        
        assert response.status_code == 200
        
        # Verificar headers customizados
        for header, value in custom_headers.items():
            assert response.headers[header] == value
        
        # Verificar que headers padrão ainda estão presentes
        assert "X-Content-Type-Options" in response.headers
    
    def test_header_override(self):
        """Testa sobrescrita de headers padrão."""
        
        custom_headers = {
            "X-Frame-Options": "SAMEORIGIN"  # Sobrescrever padrão
        }
        
        self.app.add_middleware(SecurityHeadersMiddleware, custom_headers=custom_headers)
        client = TestClient(self.app)
        
        response = client.get("/test")
        
        assert response.status_code == 200
        assert response.headers["X-Frame-Options"] == "SAMEORIGIN"


class TestMiddlewareIntegration:
    """Testes de integração entre middlewares."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.post("/webhook/test")
        async def test_webhook(request: Request):
            body = await request.body()
            return {"success": True, "received": json.loads(body.decode())}
    
    def test_all_middlewares_together(self):
        """Testa todos os middlewares funcionando juntos."""
        
        # Adicionar todos os middlewares
        self.app.add_middleware(SecurityHeadersMiddleware)
        self.app.add_middleware(RateLimitMiddleware, default_rate_limit=10)
        self.app.add_middleware(PayloadValidationMiddleware, max_payload_size=1024)
        
        client = TestClient(self.app)
        
        payload = {"message": "test integration"}
        
        response = client.post(
            "/webhook/test",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 200
        assert response.json()["success"] is True
        
        # Verificar headers de todos os middlewares
        assert "X-Content-Type-Options" in response.headers  # Security
        assert "X-RateLimit-Limit" in response.headers       # Rate limit
        assert "X-Frame-Options" in response.headers         # Security
    
    def test_middleware_order_matters(self):
        """Testa que a ordem dos middlewares importa."""
        
        # Rate limit antes de payload validation
        self.app.add_middleware(PayloadValidationMiddleware, max_payload_size=100)
        self.app.add_middleware(RateLimitMiddleware, default_rate_limit=1)
        
        client = TestClient(self.app)
        
        # Primeira requisição - deve passar pelo rate limit e falhar no payload
        large_payload = {"data": "x" * 200}  # Maior que o limite
        
        response = client.post(
            "/webhook/test",
            json=large_payload,
            headers={"Content-Type": "application/json"}
        )
        
        # Deve falhar no payload validation (413) não no rate limit (429)
        assert response.status_code == 413
        assert response.json()["code"] == "PAYLOAD_TOO_LARGE"
        
        # Segunda requisição - deve falhar no rate limit
        small_payload = {"data": "small"}
        
        response = client.post(
            "/webhook/test",
            json=small_payload,
            headers={"Content-Type": "application/json"}
        )
        
        # Deve falhar no rate limit
        assert response.status_code == 429
        assert response.json()["code"] == "RATE_LIMIT_EXCEEDED"


class TestMiddlewareErrorHandling:
    """Testes para tratamento de erros nos middlewares."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.post("/webhook/test")
        async def test_webhook():
            return {"success": True}
    
    @patch('app.api.middleware.validation_middleware.security_validator')
    def test_validation_middleware_exception_handling(self, mock_validator):
        """Testa tratamento de exceções no middleware de validação."""
        
        # Mock que gera exceção
        mock_validator.validate_dict.side_effect = Exception("Validation error")
        
        self.app.add_middleware(PayloadValidationMiddleware)
        client = TestClient(self.app)
        
        payload = {"message": "test"}
        
        response = client.post(
            "/webhook/test",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 500
        assert response.json()["code"] == "VALIDATION_ERROR"
    
    def test_rate_limit_middleware_invalid_ip(self):
        """Testa middleware de rate limit com IP inválido."""
        
        self.app.add_middleware(
            RateLimitMiddleware,
            enable_ip_based_limiting=True
        )
        client = TestClient(self.app)
        
        # Header com IP inválido
        response = client.post(
            "/webhook/test",
            headers={"X-Forwarded-For": "invalid-ip-format"}
        )
        
        # Deve funcionar normalmente (fallback para IP padrão)
        assert response.status_code == 200
    
    def test_middleware_with_malformed_request(self):
        """Testa middlewares com requisição malformada."""
        
        self.app.add_middleware(PayloadValidationMiddleware)
        client = TestClient(self.app)
        
        # Requisição sem Content-Type
        response = client.post(
            "/webhook/test",
            data="raw data without content type"
        )
        
        assert response.status_code == 415
        assert response.json()["code"] == "UNSUPPORTED_CONTENT_TYPE"