"""
Testes operacionais para confiabilidade do sistema.

Este módulo contém testes que verificam a confiabilidade operacional
do sistema, incluindo recuperação de falhas, degradação graceful,
e comportamento sob condições adversas.
"""

import pytest
import asyncio
import time
import psutil
from datetime import datetime, timedelta
from typing import Dict, Any, List
from unittest.mock import Mock, patch, AsyncMock
from uuid import uuid4

import redis.asyncio as redis
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.models.integrations import Integration, WebhookCall, WebhookToken
from app.services.metrics_collector import MetricsCollector, AlertLevel
from app.api.routes.health_monitoring import health_check
from app.core.database import get_async_session


class TestSystemReliability:
    """Testes de confiabilidade do sistema."""
    
    @pytest.fixture(autouse=True)
    async def setup_reliability_test(self):
        """Setup para testes de confiabilidade."""
        
        # Configurar banco de dados de teste
        self.test_engine = create_async_engine(
            "sqlite+aiosqlite:///./test_reliability.db",
            echo=False
        )
        
        self.TestSessionLocal = sessionmaker(
            self.test_engine,
            class_=AsyncSession,
            expire_on_commit=False
        )
        
        # Configurar Redis de teste
        self.redis_client = redis.Redis(
            host="localhost",
            port=6379,
            db=12,  # DB separado para testes de confiabilidade
            decode_responses=True
        )
        
        await self.redis_client.flushdb()
        
        # Override dependencies
        async def override_get_session():
            async with self.TestSessionLocal() as session:
                yield session
        
        app.dependency_overrides[get_async_session] = override_get_session
        
        # Criar cliente de teste
        self.client = TestClient(app)
        
        # Criar coletor de métricas
        self.metrics_collector = MetricsCollector(self.redis_client)
        
        # Criar dados de teste
        await self._create_test_data()
        
        yield
        
        # Cleanup
        await self.redis_client.flushdb()
        await self.redis_client.close()
        await self.test_engine.dispose()
        app.dependency_overrides.clear()
    
    async def _create_test_data(self):
        """Cria dados de teste para confiabilidade."""
        async with self.TestSessionLocal() as session:
            # Criar integração de teste
            self.test_integration = Integration(
                id=str(uuid4()),
                name="Reliability Test Integration",
                channel="whatsapp",
                agent_id=str(uuid4()),
                webhook_url="https://reliability-test.com/webhook",
                is_active=True,
                rate_limit_per_minute=60,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            session.add(self.test_integration)
            
            # Criar token de teste
            self.test_token = WebhookToken(
                integration_id=self.test_integration.id,
                token="whk_reliability_test_token_123",
                token_type="bearer",
                is_active=True,
                expires_at=datetime.utcnow() + timedelta(days=30),
                created_at=datetime.utcnow()
            )
            
            session.add(self.test_token)
            await session.commit()
            
            # Refresh para obter IDs
            await session.refresh(self.test_integration)
            await session.refresh(self.test_token)
    
    async def test_database_connection_recovery(self):
        """Testa recuperação de conexão com banco de dados."""
        
        # Simular perda de conexão com banco
        original_engine = self.test_engine
        
        # Criar engine que falha
        broken_engine = create_async_engine("sqlite+aiosqlite:///./nonexistent.db")
        
        async def broken_get_session():
            async with sessionmaker(broken_engine, class_=AsyncSession)() as session:
                yield session
        
        # Substituir dependency
        app.dependency_overrides[get_async_session] = broken_get_session
        
        try:
            # Tentar fazer health check - deve falhar
            response = self.client.get("/health/detailed")
            
            # Deve retornar status degradado ou não saudável
            assert response.status_code in [200, 503]
            
            if response.status_code == 200:
                health_data = response.json()
                assert health_data["status"] in ["degraded", "unhealthy"]
                assert health_data["components"]["database"]["status"] == "unhealthy"
            
        finally:
            # Restaurar conexão original
            async def restored_get_session():
                async with self.TestSessionLocal() as session:
                    yield session
            
            app.dependency_overrides[get_async_session] = restored_get_session
        
        # Verificar recuperação
        await asyncio.sleep(1)  # Aguardar um pouco
        
        response = self.client.get("/health/detailed")
        assert response.status_code == 200
        
        health_data = response.json()
        assert health_data["components"]["database"]["status"] == "healthy"
    
    async def test_redis_connection_recovery(self):
        """Testa recuperação de conexão com Redis."""
        
        # Simular falha do Redis
        original_redis = self.redis_client
        
        # Mock Redis que falha
        broken_redis = Mock()
        broken_redis.ping = AsyncMock(side_effect=redis.ConnectionError("Connection failed"))
        broken_redis.info = AsyncMock(side_effect=redis.ConnectionError("Connection failed"))
        
        # Substituir Redis no coletor de métricas
        self.metrics_collector.redis = broken_redis
        
        # Coletar métricas - deve detectar falha do Redis
        metrics = await self.metrics_collector.collect_metrics()
        
        # Verificar se métrica de conexão Redis indica falha
        redis_status_metrics = [m for m in metrics if m.name == "redis_connection_status"]
        assert len(redis_status_metrics) > 0
        assert redis_status_metrics[0].value == 0  # 0 = desconectado
        
        # Restaurar Redis original
        self.metrics_collector.redis = original_redis
        
        # Coletar métricas novamente - deve detectar recuperação
        await asyncio.sleep(1)
        metrics = await self.metrics_collector.collect_metrics()
        
        redis_status_metrics = [m for m in metrics if m.name == "redis_connection_status"]
        assert len(redis_status_metrics) > 0
        assert redis_status_metrics[0].value == 1  # 1 = conectado
    
    @patch('app.services.webhook_service.suna_client')
    async def test_suna_core_failure_handling(self, mock_suna_client):
        """Testa tratamento de falhas do Suna Core."""
        
        # Simular falha do Suna Core
        mock_suna_client.execute_agent = AsyncMock(
            side_effect=Exception("Suna Core unavailable")
        )
        
        payload = {
            "message": "Test message for Suna failure",
            "phone": "+5511999999999"
        }
        
        # Fazer requisição webhook
        response = self.client.post(
            f"/webhook/{self.test_integration.agent_id}/whatsapp",
            json=payload,
            headers={
                "Authorization": f"Bearer {self.test_token.token}",
                "Content-Type": "application/json"
            }
        )
        
        # Deve retornar erro, mas de forma controlada
        assert response.status_code == 500
        response_data = response.json()
        
        assert response_data["success"] is False
        assert response_data["code"] == "PROCESSING_ERROR"
        
        # Verificar que erro foi registrado no banco
        async with self.TestSessionLocal() as session:
            webhook_calls = await session.execute(
                select(WebhookCall).where(
                    WebhookCall.integration_id == self.test_integration.id
                )
            )
            calls = webhook_calls.scalars().all()
            
            assert len(calls) == 1
            call = calls[0]
            
            assert call.status_code == 500
            assert call.error_message is not None
            assert "Suna Core" in call.error_message or "unavailable" in call.error_message
    
    async def test_high_memory_usage_handling(self):
        """Testa comportamento sob alto uso de memória."""
        
        # Simular alto uso de memória
        with patch('psutil.virtual_memory') as mock_memory:
            # Simular 95% de uso de memória
            mock_memory.return_value = Mock(
                percent=95.0,
                used=8 * 1024 * 1024 * 1024,  # 8GB
                available=400 * 1024 * 1024   # 400MB
            )
            
            # Coletar métricas
            metrics = await self.metrics_collector.collect_metrics()
            
            # Verificar alertas
            alerts = await self.metrics_collector.check_alerts(metrics)
            
            # Deve gerar alerta de memória crítica
            memory_alerts = [a for a in alerts if "memory" in a.name.lower()]
            assert len(memory_alerts) > 0
            
            critical_memory_alerts = [
                a for a in memory_alerts 
                if a.level == AlertLevel.CRITICAL
            ]
            assert len(critical_memory_alerts) > 0
            
            # Verificar health check
            response = self.client.get("/health/detailed")
            health_data = response.json()
            
            # Sistema deve estar degradado devido ao alto uso de memória
            assert health_data["status"] in ["degraded", "unhealthy"]
    
    async def test_high_cpu_usage_handling(self):
        """Testa comportamento sob alto uso de CPU."""
        
        # Simular alto uso de CPU
        with patch('psutil.cpu_percent') as mock_cpu:
            mock_cpu.return_value = 95.0  # 95% de CPU
            
            # Coletar métricas
            metrics = await self.metrics_collector.collect_metrics()
            
            # Verificar alertas
            alerts = await self.metrics_collector.check_alerts(metrics)
            
            # Deve gerar alerta de CPU crítico
            cpu_alerts = [a for a in alerts if "cpu" in a.name.lower()]
            assert len(cpu_alerts) > 0
            
            critical_cpu_alerts = [
                a for a in cpu_alerts 
                if a.level == AlertLevel.CRITICAL
            ]
            assert len(critical_cpu_alerts) > 0
    
    async def test_disk_space_monitoring(self):
        """Testa monitoramento de espaço em disco."""
        
        # Simular pouco espaço em disco
        with patch('psutil.disk_usage') as mock_disk:
            mock_disk.return_value = Mock(
                percent=95.0,
                free=1 * 1024 * 1024 * 1024,  # 1GB livre
                total=20 * 1024 * 1024 * 1024  # 20GB total
            )
            
            # Coletar métricas
            metrics = await self.metrics_collector.collect_metrics()
            
            # Verificar métrica de disco
            disk_metrics = [m for m in metrics if "disk" in m.name]
            assert len(disk_metrics) > 0
            
            disk_percent_metrics = [m for m in disk_metrics if "percent" in m.name]
            assert len(disk_percent_metrics) > 0
            assert disk_percent_metrics[0].value == 95.0
    
    async def test_webhook_error_rate_monitoring(self):
        """Testa monitoramento de taxa de erro de webhooks."""
        
        # Criar webhook calls com alta taxa de erro
        async with self.TestSessionLocal() as session:
            current_time = datetime.utcnow()
            
            # Criar 10 calls: 7 com erro, 3 com sucesso
            for i in range(10):
                status_code = 500 if i < 7 else 200  # 70% de erro
                
                call = WebhookCall(
                    integration_id=self.test_integration.id,
                    status_code=status_code,
                    execution_time_ms=100,
                    payload={"error_test": i},
                    response={"success": status_code == 200} if status_code == 200 else None,
                    error_message="Test error" if status_code == 500 else None,
                    ip_address="192.168.1.100",
                    user_agent="ErrorTestAgent/1.0",
                    created_at=current_time - timedelta(minutes=1)  # Dentro da janela de 5 min
                )
                
                session.add(call)
            
            await session.commit()
        
        # Coletar métricas
        metrics = await self.metrics_collector.collect_metrics()
        
        # Verificar métrica de taxa de erro
        error_rate_metrics = [m for m in metrics if m.name == "webhook_error_rate"]
        assert len(error_rate_metrics) > 0
        
        error_rate = error_rate_metrics[0].value
        assert error_rate > 50  # Deve ser > 50%
        
        # Verificar alertas
        alerts = await self.metrics_collector.check_alerts(metrics)
        
        # Deve gerar alerta de alta taxa de erro
        error_alerts = [a for a in alerts if "error_rate" in a.name]
        assert len(error_alerts) > 0
        
        # Deve ser alerta crítico (> 20%)
        critical_error_alerts = [
            a for a in error_alerts 
            if a.level == AlertLevel.CRITICAL
        ]
        assert len(critical_error_alerts) > 0
    
    async def test_slow_response_time_monitoring(self):
        """Testa monitoramento de tempo de resposta lento."""
        
        # Criar webhook calls com tempo de resposta lento
        async with self.TestSessionLocal() as session:
            current_time = datetime.utcnow()
            
            # Criar calls com tempo de resposta de 6 segundos (crítico)
            for i in range(5):
                call = WebhookCall(
                    integration_id=self.test_integration.id,
                    status_code=200,
                    execution_time_ms=6000,  # 6 segundos
                    payload={"slow_test": i},
                    response={"success": True},
                    ip_address="192.168.1.100",
                    user_agent="SlowTestAgent/1.0",
                    created_at=current_time - timedelta(minutes=1)
                )
                
                session.add(call)
            
            await session.commit()
        
        # Coletar métricas
        metrics = await self.metrics_collector.collect_metrics()
        
        # Verificar métrica de tempo de resposta
        response_time_metrics = [m for m in metrics if m.name == "webhook_avg_response_time"]
        assert len(response_time_metrics) > 0
        
        avg_response_time = response_time_metrics[0].value
        assert avg_response_time > 5000  # Deve ser > 5 segundos
        
        # Verificar alertas
        alerts = await self.metrics_collector.check_alerts(metrics)
        
        # Deve gerar alerta de tempo de resposta crítico
        response_time_alerts = [a for a in alerts if "response_time" in a.name]
        assert len(response_time_alerts) > 0
        
        critical_response_alerts = [
            a for a in response_time_alerts 
            if a.level == AlertLevel.CRITICAL
        ]
        assert len(critical_response_alerts) > 0
    
    async def test_system_degradation_under_load(self):
        """Testa degradação do sistema sob carga."""
        
        # Simular condições de alta carga
        with patch('psutil.cpu_percent', return_value=85.0), \
             patch('psutil.virtual_memory', return_value=Mock(percent=85.0, used=7*1024*1024*1024, available=1*1024*1024*1024)):
            
            # Fazer múltiplas requisições simultâneas
            async def make_request(request_id: int):
                with patch('app.services.webhook_service.suna_client') as mock_suna:
                    # Simular latência alta do Suna Core sob carga
                    async def slow_suna_response(*args, **kwargs):
                        await asyncio.sleep(0.5)  # 500ms de latência
                        return {
                            "success": True,
                            "response": f"Load test response {request_id}"
                        }
                    
                    mock_suna.execute_agent = AsyncMock(side_effect=slow_suna_response)
                    
                    payload = {
                        "message": f"Load test {request_id}",
                        "phone": f"+551199999{request_id:04d}"
                    }
                    
                    try:
                        response = self.client.post(
                            f"/webhook/{self.test_integration.agent_id}/whatsapp",
                            json=payload,
                            headers={
                                "Authorization": f"Bearer {self.test_token.token}",
                                "Content-Type": "application/json"
                            }
                        )
                        
                        return {
                            "request_id": request_id,
                            "status_code": response.status_code,
                            "success": response.status_code == 200
                        }
                        
                    except Exception as e:
                        return {
                            "request_id": request_id,
                            "status_code": 500,
                            "success": False,
                            "error": str(e)
                        }
            
            # Executar 20 requisições concorrentes
            tasks = [make_request(i) for i in range(20)]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Analisar resultados
            successful_results = [r for r in results if isinstance(r, dict) and r.get("success")]
            failed_results = [r for r in results if isinstance(r, dict) and not r.get("success")]
            
            success_rate = len(successful_results) / len(results) * 100
            
            print(f"Load test results under system stress:")
            print(f"  Success rate: {success_rate:.1f}%")
            print(f"  Successful requests: {len(successful_results)}")
            print(f"  Failed requests: {len(failed_results)}")
            
            # Sob alta carga, ainda deve manter pelo menos 70% de sucesso
            assert success_rate >= 70, f"Success rate too low under load: {success_rate}%"
            
            # Coletar métricas após carga
            metrics = await self.metrics_collector.collect_metrics()
            alerts = await self.metrics_collector.check_alerts(metrics)
            
            # Deve gerar alertas de recursos
            resource_alerts = [
                a for a in alerts 
                if any(keyword in a.name.lower() for keyword in ["cpu", "memory"])
            ]
            assert len(resource_alerts) > 0
    
    async def test_alert_cooldown_mechanism(self):
        """Testa mecanismo de cooldown de alertas."""
        
        # Simular condição que gera alerta
        with patch('psutil.cpu_percent', return_value=95.0):
            
            # Primeira coleta - deve gerar alerta
            metrics1 = await self.metrics_collector.collect_metrics()
            alerts1 = await self.metrics_collector.check_alerts(metrics1)
            
            cpu_alerts1 = [a for a in alerts1 if "cpu" in a.name.lower()]
            assert len(cpu_alerts1) > 0
            
            # Segunda coleta imediata - não deve gerar alerta (cooldown)
            metrics2 = await self.metrics_collector.collect_metrics()
            alerts2 = await self.metrics_collector.check_alerts(metrics2)
            
            cpu_alerts2 = [a for a in alerts2 if "cpu" in a.name.lower()]
            assert len(cpu_alerts2) == 0  # Deve estar em cooldown
    
    async def test_metrics_persistence_reliability(self):
        """Testa confiabilidade da persistência de métricas."""
        
        # Coletar métricas
        metrics = await self.metrics_collector.collect_metrics()
        assert len(metrics) > 0
        
        # Verificar se métricas foram persistidas no Redis
        for metric in metrics[:5]:  # Verificar primeiras 5 métricas
            timeline_key = f"metrics:{metric.name}:timeline"
            
            # Verificar se existe no Redis
            exists = await self.redis_client.exists(timeline_key)
            assert exists == 1, f"Métrica {metric.name} não foi persistida"
            
            # Verificar dados
            timeline_data = await self.redis_client.zrange(timeline_key, 0, -1, withscores=True)
            assert len(timeline_data) > 0, f"Timeline da métrica {metric.name} está vazia"
    
    async def test_health_check_reliability(self):
        """Testa confiabilidade dos health checks."""
        
        # Fazer múltiplos health checks concorrentes
        async def health_check_request():
            response = self.client.get("/health/detailed")
            return {
                "status_code": response.status_code,
                "response_time": response.elapsed.total_seconds() if hasattr(response, 'elapsed') else 0,
                "success": response.status_code == 200
            }
        
        # Executar 10 health checks concorrentes
        tasks = [health_check_request() for _ in range(10)]
        results = await asyncio.gather(*tasks)
        
        # Todos devem ser bem-sucedidos
        successful_checks = [r for r in results if r["success"]]
        assert len(successful_checks) == 10, "Nem todos os health checks foram bem-sucedidos"
        
        # Verificar consistência das respostas
        status_codes = [r["status_code"] for r in results]
        assert all(code == 200 for code in status_codes), "Health checks retornaram códigos inconsistentes"
    
    async def test_graceful_shutdown_simulation(self):
        """Simula shutdown graceful do sistema."""
        
        # Iniciar coleta de métricas
        collection_task = asyncio.create_task(self.metrics_collector.start_collection())
        
        # Aguardar um pouco para coleta começar
        await asyncio.sleep(1)
        
        # Verificar que está coletando
        assert self.metrics_collector.is_running is True
        
        # Simular shutdown graceful
        self.metrics_collector.stop_collection()
        
        # Aguardar task terminar
        await asyncio.sleep(1)
        
        # Cancelar task se ainda estiver rodando
        if not collection_task.done():
            collection_task.cancel()
            try:
                await collection_task
            except asyncio.CancelledError:
                pass
        
        # Verificar que parou
        assert self.metrics_collector.is_running is False
    
    async def test_data_consistency_under_failure(self):
        """Testa consistência de dados sob falhas."""
        
        # Criar transação que pode falhar
        async with self.TestSessionLocal() as session:
            try:
                async with session.begin():
                    # Criar webhook call
                    call = WebhookCall(
                        integration_id=self.test_integration.id,
                        status_code=200,
                        execution_time_ms=100,
                        payload={"consistency_test": True},
                        response={"success": True},
                        ip_address="192.168.1.100",
                        user_agent="ConsistencyTestAgent/1.0",
                        created_at=datetime.utcnow()
                    )
                    
                    session.add(call)
                    
                    # Simular falha durante transação
                    if True:  # Sempre falhar para teste
                        raise Exception("Simulated failure during transaction")
                    
            except Exception:
                # Transação deve ser revertida automaticamente
                pass
        
        # Verificar que dados não foram persistidos (consistência mantida)
        async with self.TestSessionLocal() as session:
            calls = await session.execute(
                select(WebhookCall).where(
                    WebhookCall.integration_id == self.test_integration.id
                )
            )
            
            consistency_calls = [
                call for call in calls.scalars().all()
                if call.payload.get("consistency_test") is True
            ]
            
            assert len(consistency_calls) == 0, "Dados inconsistentes encontrados após falha"
    
    async def test_monitoring_system_self_monitoring(self):
        """Testa auto-monitoramento do sistema de monitoramento."""
        
        # Simular falha no coletor de métricas
        original_collect = self.metrics_collector.collect_metrics
        
        async def failing_collect_metrics():
            raise Exception("Metrics collection failed")
        
        self.metrics_collector.collect_metrics = failing_collect_metrics
        
        # Tentar coletar métricas
        try:
            metrics = await self.metrics_collector.collect_metrics()
            assert False, "Deveria ter falhado"
        except Exception:
            pass  # Falha esperada
        
        # Restaurar função original
        self.metrics_collector.collect_metrics = original_collect
        
        # Verificar que sistema se recupera
        metrics = await self.metrics_collector.collect_metrics()
        assert len(metrics) > 0, "Sistema de métricas não se recuperou"