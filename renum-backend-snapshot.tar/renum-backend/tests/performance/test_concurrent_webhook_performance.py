"""
Testes de performance para processamento concorrente de webhooks.

Este módulo testa a performance do sistema sob diferentes cargas,
incluindo alta concorrência, throughput, latência e uso de recursos.
"""

import pytest
import asyncio
import time
import statistics
import psutil
import threading
from datetime import datetime, timedelta
from typing import Dict, Any, List, Tuple
from unittest.mock import Mock, patch, AsyncMock
from uuid import uuid4
from concurrent.futures import ThreadPoolExecutor

import redis.asyncio as redis
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.models.integrations import Integration, WebhookCall, WebhookToken
from app.core.database import get_async_session


class TestConcurrentWebhookPerformance:
    """Testes de performance para webhooks concorrentes."""
    
    @pytest.fixture(autouse=True)
    async def setup_performance_test(self):
        """Setup para testes de performance."""
        
        # Configurar banco de dados de teste
        self.test_engine = create_async_engine(
            "sqlite+aiosqlite:///./test_performance.db",
            echo=False,
            pool_size=20,  # Pool maior para concorrência
            max_overflow=30
        )
        
        self.TestSessionLocal = sessionmaker(
            self.test_engine,
            class_=AsyncSession,
            expire_on_commit=False
        )
        
        # Configurar Redis de teste
        self.redis_client = redis.Redis(
            host="localhost",
            port=6379,
            db=13,  # DB separado para testes de performance
            decode_responses=True,
            max_connections=50  # Pool maior para concorrência
        )
        
        await self.redis_client.flushdb()
        
        # Override dependencies
        async def override_get_session():
            async with self.TestSessionLocal() as session:
                yield session
        
        app.dependency_overrides[get_async_session] = override_get_session
        
        # Criar cliente de teste
        self.client = TestClient(app)
        
        # Criar dados de teste
        await self._create_test_data()
        
        # Métricas de sistema
        self.initial_memory = psutil.virtual_memory().used
        self.initial_cpu = psutil.cpu_percent()
        
        yield
        
        # Cleanup
        await self.redis_client.flushdb()
        await self.redis_client.close()
        await self.test_engine.dispose()
        app.dependency_overrides.clear()
    
    async def _create_test_data(self):
        """Cria dados de teste otimizados para performance."""
        async with self.TestSessionLocal() as session:
            # Criar múltiplas integrações para distribuir carga
            self.test_integrations = []
            self.test_tokens = []
            
            for i in range(10):  # 10 integrações para distribuir carga
                integration = Integration(
                    id=str(uuid4()),
                    name=f"Performance Test Integration {i+1}",
                    channel="whatsapp",
                    agent_id=str(uuid4()),
                    webhook_url=f"https://perf-test-{i}.com/webhook",
                    is_active=True,
                    rate_limit_per_minute=1000,  # Limite alto para performance
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow()
                )
                
                session.add(integration)
                self.test_integrations.append(integration)
                
                # Criar token para cada integração
                token = WebhookToken(
                    integration_id=integration.id,
                    token=f"whk_perf_test_token_{i}_123456789",
                    token_type="bearer",
                    is_active=True,
                    expires_at=datetime.utcnow() + timedelta(days=30),
                    created_at=datetime.utcnow()
                )
                
                session.add(token)
                self.test_tokens.append(token)
            
            await session.commit()
            
            # Refresh para obter IDs
            for integration in self.test_integrations:
                await session.refresh(integration)
            
            for token in self.test_tokens:
                await session.refresh(token)
    
    @patch('app.services.webhook_service.suna_client')
    async def test_high_concurrency_webhook_processing(self, mock_suna_client):
        """Testa processamento de webhooks com alta concorrência."""
        
        # Mock do Suna Core com latência simulada
        async def mock_suna_response(*args, **kwargs):
            await asyncio.sleep(0.05)  # 50ms de latência simulada
            return {
                "success": True,
                "response": f"Response for {kwargs.get('payload', {}).get('request_id', 'unknown')}",
                "execution_time_ms": 50
            }
        
        mock_suna_client.execute_agent = AsyncMock(side_effect=mock_suna_response)
        
        async def make_webhook_request(request_id: int) -> Dict[str, Any]:
            """Faz uma requisição webhook individual."""
            integration_idx = request_id % len(self.test_integrations)
            integration = self.test_integrations[integration_idx]
            token = self.test_tokens[integration_idx]
            
            payload = {
                "message": f"High concurrency test {request_id}",
                "phone": f"+551199999{request_id:04d}",
                "request_id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }
            
            start_time = time.time()
            
            try:
                response = self.client.post(
                    f"/webhook/{integration.agent_id}/whatsapp",
                    json=payload,
                    headers={
                        "Authorization": f"Bearer {token.token}",
                        "Content-Type": "application/json",
                        "User-Agent": f"PerformanceTest/{request_id}"
                    }
                )
                
                end_time = time.time()
                response_time = (end_time - start_time) * 1000  # ms
                
                return {
                    "request_id": request_id,
                    "status_code": response.status_code,
                    "response_time": response_time,
                    "success": response.status_code == 200,
                    "integration_id": integration.id,
                    "payload_size": len(str(payload))
                }
                
            except Exception as e:
                end_time = time.time()
                response_time = (end_time - start_time) * 1000
                
                return {
                    "request_id": request_id,
                    "status_code": 500,
                    "response_time": response_time,
                    "success": False,
                    "error": str(e),
                    "integration_id": integration.id
                }
        
        # Teste com diferentes níveis de concorrência
        concurrency_levels = [10, 50, 100, 200]
        
        for concurrency in concurrency_levels:
            print(f"\n=== Testing concurrency level: {concurrency} ===")
            
            start_time = time.time()
            
            # Executar requisições concorrentes
            tasks = [make_webhook_request(i) for i in range(concurrency)]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            end_time = time.time()
            total_time = (end_time - start_time) * 1000  # ms
            
            # Analisar resultados
            successful_results = [r for r in results if isinstance(r, dict) and r.get("success")]
            failed_results = [r for r in results if isinstance(r, dict) and not r.get("success")]
            exceptions = [r for r in results if isinstance(r, Exception)]
            
            # Calcular métricas
            success_rate = len(successful_results) / concurrency * 100
            throughput = concurrency / (total_time / 1000)  # requests/second
            
            response_times = [r["response_time"] for r in successful_results]
            if response_times:
                avg_response_time = statistics.mean(response_times)
                median_response_time = statistics.median(response_times)
                p95_response_time = statistics.quantiles(response_times, n=20)[18]  # 95th percentile
                p99_response_time = statistics.quantiles(response_times, n=100)[98]  # 99th percentile
            else:
                avg_response_time = median_response_time = p95_response_time = p99_response_time = 0
            
            print(f"Results for {concurrency} concurrent requests:")
            print(f"  Total time: {total_time:.2f}ms")
            print(f"  Success rate: {success_rate:.1f}%")
            print(f"  Throughput: {throughput:.2f} req/sec")
            print(f"  Successful requests: {len(successful_results)}")
            print(f"  Failed requests: {len(failed_results)}")
            print(f"  Exceptions: {len(exceptions)}")
            print(f"  Average response time: {avg_response_time:.2f}ms")
            print(f"  Median response time: {median_response_time:.2f}ms")
            print(f"  95th percentile: {p95_response_time:.2f}ms")
            print(f"  99th percentile: {p99_response_time:.2f}ms")
            
            # Verificações de performance
            assert success_rate >= 95, f"Success rate too low: {success_rate}%"
            assert throughput >= 10, f"Throughput too low: {throughput} req/sec"
            assert avg_response_time <= 1000, f"Average response time too high: {avg_response_time}ms"
            assert p95_response_time <= 2000, f"95th percentile too high: {p95_response_time}ms"
            
            # Verificar que não há vazamentos de memória significativos
            current_memory = psutil.virtual_memory().used
            memory_increase = (current_memory - self.initial_memory) / 1024 / 1024  # MB
            
            print(f"  Memory increase: {memory_increase:.2f}MB")
            
            # Permitir algum aumento de memória, mas não excessivo
            assert memory_increase <= 100, f"Memory increase too high: {memory_increase}MB"
    
    @patch('app.services.webhook_service.suna_client')
    async def test_sustained_load_performance(self, mock_suna_client):
        """Testa performance sob carga sustentada."""
        
        # Mock do Suna Core
        mock_suna_client.execute_agent = AsyncMock(return_value={
            "success": True,
            "response": "Sustained load test response",
            "execution_time_ms": 25
        })
        
        # Configurações do teste
        duration_seconds = 30  # 30 segundos de teste
        requests_per_second = 20  # 20 req/sec
        total_requests = duration_seconds * requests_per_second
        
        print(f"\n=== Sustained Load Test ===")
        print(f"Duration: {duration_seconds} seconds")
        print(f"Target rate: {requests_per_second} req/sec")
        print(f"Total requests: {total_requests}")
        
        async def sustained_request_generator():
            """Gera requisições em taxa constante."""
            request_id = 0
            start_time = time.time()
            
            while time.time() - start_time < duration_seconds:
                # Calcular quando fazer próxima requisição
                elapsed = time.time() - start_time
                expected_requests = int(elapsed * requests_per_second)
                
                if request_id < expected_requests:
                    # Fazer requisição
                    integration_idx = request_id % len(self.test_integrations)
                    integration = self.test_integrations[integration_idx]
                    token = self.test_tokens[integration_idx]
                    
                    payload = {
                        "message": f"Sustained load test {request_id}",
                        "phone": f"+551199999{request_id:04d}",
                        "request_id": request_id
                    }
                    
                    try:
                        response = self.client.post(
                            f"/webhook/{integration.agent_id}/whatsapp",
                            json=payload,
                            headers={
                                "Authorization": f"Bearer {token.token}",
                                "Content-Type": "application/json"
                            }
                        )
                        
                        yield {
                            "request_id": request_id,
                            "timestamp": time.time(),
                            "status_code": response.status_code,
                            "success": response.status_code == 200
                        }
                        
                    except Exception as e:
                        yield {
                            "request_id": request_id,
                            "timestamp": time.time(),
                            "status_code": 500,
                            "success": False,
                            "error": str(e)
                        }
                    
                    request_id += 1
                
                # Pequena pausa para não sobrecarregar
                await asyncio.sleep(0.01)
        
        # Coletar resultados
        results = []
        start_time = time.time()
        
        async for result in sustained_request_generator():
            results.append(result)
        
        end_time = time.time()
        actual_duration = end_time - start_time
        
        # Analisar resultados
        successful_requests = [r for r in results if r["success"]]
        failed_requests = [r for r in results if not r["success"]]
        
        actual_rate = len(results) / actual_duration
        success_rate = len(successful_requests) / len(results) * 100 if results else 0
        
        print(f"Sustained load results:")
        print(f"  Actual duration: {actual_duration:.2f}s")
        print(f"  Total requests: {len(results)}")
        print(f"  Actual rate: {actual_rate:.2f} req/sec")
        print(f"  Success rate: {success_rate:.1f}%")
        print(f"  Successful requests: {len(successful_requests)}")
        print(f"  Failed requests: {len(failed_requests)}")
        
        # Verificações
        assert len(results) >= total_requests * 0.9, "Too few requests generated"
        assert success_rate >= 95, f"Success rate too low: {success_rate}%"
        assert actual_rate >= requests_per_second * 0.8, f"Actual rate too low: {actual_rate} req/sec"
    
    @patch('app.services.webhook_service.suna_client')
    async def test_burst_load_handling(self, mock_suna_client):
        """Testa tratamento de picos de carga (burst)."""
        
        mock_suna_client.execute_agent = AsyncMock(return_value={
            "success": True,
            "response": "Burst test response",
            "execution_time_ms": 30
        })
        
        async def make_burst_request(request_id: int):
            """Faz requisição durante burst."""
            integration_idx = request_id % len(self.test_integrations)
            integration = self.test_integrations[integration_idx]
            token = self.test_tokens[integration_idx]
            
            payload = {
                "message": f"Burst test {request_id}",
                "phone": f"+551199999{request_id:04d}",
                "burst_id": request_id
            }
            
            start_time = time.time()
            
            try:
                response = self.client.post(
                    f"/webhook/{integration.agent_id}/whatsapp",
                    json=payload,
                    headers={
                        "Authorization": f"Bearer {token.token}",
                        "Content-Type": "application/json"
                    }
                )
                
                end_time = time.time()
                
                return {
                    "request_id": request_id,
                    "response_time": (end_time - start_time) * 1000,
                    "status_code": response.status_code,
                    "success": response.status_code == 200
                }
                
            except Exception as e:
                end_time = time.time()
                
                return {
                    "request_id": request_id,
                    "response_time": (end_time - start_time) * 1000,
                    "status_code": 500,
                    "success": False,
                    "error": str(e)
                }
        
        # Teste de burst - 500 requisições simultâneas
        burst_size = 500
        print(f"\n=== Burst Load Test ({burst_size} simultaneous requests) ===")
        
        start_time = time.time()
        
        # Executar burst
        tasks = [make_burst_request(i) for i in range(burst_size)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        end_time = time.time()
        burst_duration = (end_time - start_time) * 1000  # ms
        
        # Analisar resultados
        successful_results = [r for r in results if isinstance(r, dict) and r.get("success")]
        failed_results = [r for r in results if isinstance(r, dict) and not r.get("success")]
        exceptions = [r for r in results if isinstance(r, Exception)]
        
        success_rate = len(successful_results) / burst_size * 100
        throughput = burst_size / (burst_duration / 1000)  # req/sec
        
        response_times = [r["response_time"] for r in successful_results]
        if response_times:
            avg_response_time = statistics.mean(response_times)
            max_response_time = max(response_times)
            min_response_time = min(response_times)
        else:
            avg_response_time = max_response_time = min_response_time = 0
        
        print(f"Burst test results:")
        print(f"  Burst duration: {burst_duration:.2f}ms")
        print(f"  Success rate: {success_rate:.1f}%")
        print(f"  Throughput: {throughput:.2f} req/sec")
        print(f"  Successful requests: {len(successful_results)}")
        print(f"  Failed requests: {len(failed_results)}")
        print(f"  Exceptions: {len(exceptions)}")
        print(f"  Average response time: {avg_response_time:.2f}ms")
        print(f"  Min response time: {min_response_time:.2f}ms")
        print(f"  Max response time: {max_response_time:.2f}ms")
        
        # Verificações para burst
        assert success_rate >= 80, f"Burst success rate too low: {success_rate}%"
        assert len(exceptions) == 0, f"Unexpected exceptions during burst: {len(exceptions)}"
        assert avg_response_time <= 5000, f"Average response time too high during burst: {avg_response_time}ms"
    
    async def test_memory_usage_under_load(self):
        """Testa uso de memória sob carga."""
        
        # Monitorar memória durante teste
        memory_samples = []
        
        def monitor_memory():
            """Monitor de memória em thread separada."""
            while getattr(monitor_memory, 'running', True):
                memory_info = psutil.virtual_memory()
                memory_samples.append({
                    "timestamp": time.time(),
                    "used_mb": memory_info.used / 1024 / 1024,
                    "percent": memory_info.percent
                })
                time.sleep(0.5)  # Sample a cada 500ms
        
        # Iniciar monitoramento
        monitor_memory.running = True
        monitor_thread = threading.Thread(target=monitor_memory)
        monitor_thread.start()
        
        try:
            # Executar carga de trabalho
            with patch('app.services.webhook_service.suna_client') as mock_suna:
                mock_suna.execute_agent = AsyncMock(return_value={
                    "success": True,
                    "response": "Memory test response"
                })
                
                # Fazer muitas requisições para testar uso de memória
                async def memory_test_request(request_id: int):
                    integration_idx = request_id % len(self.test_integrations)
                    integration = self.test_integrations[integration_idx]
                    token = self.test_tokens[integration_idx]
                    
                    # Payload com dados variados para testar uso de memória
                    payload = {
                        "message": f"Memory test {request_id} " + "x" * (request_id % 1000),
                        "phone": f"+551199999{request_id:04d}",
                        "data": {
                            "large_field": "y" * (request_id % 500),
                            "request_id": request_id,
                            "nested": {
                                "field1": "data1",
                                "field2": "data2",
                                "field3": list(range(request_id % 50))
                            }
                        }
                    }
                    
                    response = self.client.post(
                        f"/webhook/{integration.agent_id}/whatsapp",
                        json=payload,
                        headers={
                            "Authorization": f"Bearer {token.token}",
                            "Content-Type": "application/json"
                        }
                    )
                    
                    return response.status_code == 200
                
                # Executar em batches para monitorar progressão da memória
                batch_size = 50
                total_batches = 10
                
                for batch in range(total_batches):
                    print(f"Executing memory test batch {batch + 1}/{total_batches}")
                    
                    tasks = [
                        memory_test_request(batch * batch_size + i)
                        for i in range(batch_size)
                    ]
                    
                    results = await asyncio.gather(*tasks)
                    success_count = sum(1 for r in results if r)
                    
                    print(f"  Batch {batch + 1} success rate: {success_count}/{batch_size}")
                    
                    # Pequena pausa entre batches
                    await asyncio.sleep(1)
        
        finally:
            # Parar monitoramento
            monitor_memory.running = False
            monitor_thread.join()
        
        # Analisar uso de memória
        if memory_samples:
            initial_memory = memory_samples[0]["used_mb"]
            peak_memory = max(sample["used_mb"] for sample in memory_samples)
            final_memory = memory_samples[-1]["used_mb"]
            
            memory_increase = peak_memory - initial_memory
            memory_retained = final_memory - initial_memory
            
            print(f"\nMemory usage analysis:")
            print(f"  Initial memory: {initial_memory:.2f}MB")
            print(f"  Peak memory: {peak_memory:.2f}MB")
            print(f"  Final memory: {final_memory:.2f}MB")
            print(f"  Peak increase: {memory_increase:.2f}MB")
            print(f"  Retained increase: {memory_retained:.2f}MB")
            
            # Verificações de memória
            assert memory_increase <= 200, f"Memory increase too high: {memory_increase}MB"
            assert memory_retained <= 50, f"Too much memory retained: {memory_retained}MB"
            
            # Verificar que não há vazamento significativo
            memory_leak_threshold = 0.1  # 10% do pico
            if memory_retained > memory_increase * memory_leak_threshold:
                print(f"Warning: Possible memory leak detected")
    
    async def test_database_connection_pool_performance(self):
        """Testa performance do pool de conexões do banco."""
        
        async def db_intensive_request(request_id: int):
            """Requisição que usa intensivamente o banco."""
            async with self.TestSessionLocal() as session:
                # Simular operações de banco intensivas
                
                # 1. Consultar integração
                integration = self.test_integrations[request_id % len(self.test_integrations)]
                
                # 2. Criar webhook call
                webhook_call = WebhookCall(
                    integration_id=integration.id,
                    status_code=200,
                    execution_time_ms=100,
                    payload={"db_test": request_id},
                    response={"success": True},
                    ip_address=f"192.168.1.{100 + (request_id % 50)}",
                    user_agent="DBPerformanceTest/1.0",
                    created_at=datetime.utcnow()
                )
                
                session.add(webhook_call)
                
                # 3. Fazer algumas consultas
                from sqlalchemy import select, func
                
                # Contar calls para esta integração
                count_result = await session.execute(
                    select(func.count(WebhookCall.id)).where(
                        WebhookCall.integration_id == integration.id
                    )
                )
                
                call_count = count_result.scalar()
                
                await session.commit()
                
                return {
                    "request_id": request_id,
                    "integration_id": integration.id,
                    "call_count": call_count,
                    "success": True
                }
        
        # Teste com diferentes níveis de concorrência de banco
        concurrency_levels = [10, 25, 50]
        
        for concurrency in concurrency_levels:
            print(f"\n=== Database Pool Test - Concurrency: {concurrency} ===")
            
            start_time = time.time()
            
            tasks = [db_intensive_request(i) for i in range(concurrency)]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            end_time = time.time()
            duration = (end_time - start_time) * 1000  # ms
            
            successful_results = [r for r in results if isinstance(r, dict) and r.get("success")]
            exceptions = [r for r in results if isinstance(r, Exception)]
            
            success_rate = len(successful_results) / concurrency * 100
            throughput = concurrency / (duration / 1000)  # operations/sec
            
            print(f"Database pool results:")
            print(f"  Duration: {duration:.2f}ms")
            print(f"  Success rate: {success_rate:.1f}%")
            print(f"  Throughput: {throughput:.2f} ops/sec")
            print(f"  Successful operations: {len(successful_results)}")
            print(f"  Exceptions: {len(exceptions)}")
            
            # Verificações
            assert success_rate >= 95, f"DB success rate too low: {success_rate}%"
            assert len(exceptions) == 0, f"DB exceptions: {len(exceptions)}"
            assert throughput >= 5, f"DB throughput too low: {throughput} ops/sec"
    
    async def test_redis_connection_pool_performance(self):
        """Testa performance do pool de conexões Redis."""
        
        async def redis_intensive_operation(operation_id: int):
            """Operação que usa intensivamente o Redis."""
            try:
                # Simular operações Redis típicas do rate limiting
                
                # 1. Incrementar contador
                key = f"perf_test:{operation_id % 10}:{int(time.time())}"
                await self.redis_client.incr(key)
                await self.redis_client.expire(key, 60)
                
                # 2. Operações de set/get
                data_key = f"perf_data:{operation_id}"
                test_data = {
                    "operation_id": operation_id,
                    "timestamp": time.time(),
                    "data": f"test_data_{operation_id}"
                }
                
                await self.redis_client.setex(data_key, 30, json.dumps(test_data))
                retrieved_data = await self.redis_client.get(data_key)
                
                # 3. Operações de lista
                list_key = f"perf_list:{operation_id % 5}"
                await self.redis_client.lpush(list_key, f"item_{operation_id}")
                await self.redis_client.ltrim(list_key, 0, 99)  # Manter apenas 100 itens
                
                # 4. Operações de sorted set
                zset_key = f"perf_zset:{operation_id % 3}"
                await self.redis_client.zadd(zset_key, {f"member_{operation_id}": time.time()})
                
                return {
                    "operation_id": operation_id,
                    "success": True,
                    "retrieved_data": retrieved_data is not None
                }
                
            except Exception as e:
                return {
                    "operation_id": operation_id,
                    "success": False,
                    "error": str(e)
                }
        
        # Teste com diferentes níveis de concorrência Redis
        concurrency_levels = [20, 50, 100]
        
        for concurrency in concurrency_levels:
            print(f"\n=== Redis Pool Test - Concurrency: {concurrency} ===")
            
            start_time = time.time()
            
            tasks = [redis_intensive_operation(i) for i in range(concurrency)]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            end_time = time.time()
            duration = (end_time - start_time) * 1000  # ms
            
            successful_results = [r for r in results if isinstance(r, dict) and r.get("success")]
            failed_results = [r for r in results if isinstance(r, dict) and not r.get("success")]
            exceptions = [r for r in results if isinstance(r, Exception)]
            
            success_rate = len(successful_results) / concurrency * 100
            throughput = concurrency / (duration / 1000)  # operations/sec
            
            print(f"Redis pool results:")
            print(f"  Duration: {duration:.2f}ms")
            print(f"  Success rate: {success_rate:.1f}%")
            print(f"  Throughput: {throughput:.2f} ops/sec")
            print(f"  Successful operations: {len(successful_results)}")
            print(f"  Failed operations: {len(failed_results)}")
            print(f"  Exceptions: {len(exceptions)}")
            
            # Verificações
            assert success_rate >= 95, f"Redis success rate too low: {success_rate}%"
            assert len(exceptions) == 0, f"Redis exceptions: {len(exceptions)}"
            assert throughput >= 50, f"Redis throughput too low: {throughput} ops/sec"
    
    async def test_system_resource_limits(self):
        """Testa limites de recursos do sistema."""
        
        print(f"\n=== System Resource Limits Test ===")
        
        # Obter informações iniciais do sistema
        initial_cpu = psutil.cpu_percent(interval=1)
        initial_memory = psutil.virtual_memory()
        initial_connections = len(psutil.net_connections())
        
        print(f"Initial system state:")
        print(f"  CPU usage: {initial_cpu:.1f}%")
        print(f"  Memory usage: {initial_memory.percent:.1f}% ({initial_memory.used/1024/1024:.0f}MB)")
        print(f"  Network connections: {initial_connections}")
        
        # Executar carga progressiva
        with patch('app.services.webhook_service.suna_client') as mock_suna:
            mock_suna.execute_agent = AsyncMock(return_value={
                "success": True,
                "response": "Resource test response"
            })
            
            # Aumentar carga progressivamente
            for load_level in [50, 100, 200, 300]:
                print(f"\nTesting load level: {load_level} concurrent requests")
                
                async def resource_test_request(request_id: int):
                    integration_idx = request_id % len(self.test_integrations)
                    integration = self.test_integrations[integration_idx]
                    token = self.test_tokens[integration_idx]
                    
                    payload = {
                        "message": f"Resource test {request_id}",
                        "phone": f"+551199999{request_id:04d}",
                        "load_level": load_level
                    }
                    
                    response = self.client.post(
                        f"/webhook/{integration.agent_id}/whatsapp",
                        json=payload,
                        headers={
                            "Authorization": f"Bearer {token.token}",
                            "Content-Type": "application/json"
                        }
                    )
                    
                    return response.status_code == 200
                
                start_time = time.time()
                
                tasks = [resource_test_request(i) for i in range(load_level)]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                
                end_time = time.time()
                duration = end_time - start_time
                
                # Medir recursos após carga
                cpu_usage = psutil.cpu_percent(interval=0.1)
                memory_info = psutil.virtual_memory()
                connections = len(psutil.net_connections())
                
                successful_requests = sum(1 for r in results if r is True)
                success_rate = successful_requests / load_level * 100
                
                print(f"  Results:")
                print(f"    Duration: {duration:.2f}s")
                print(f"    Success rate: {success_rate:.1f}%")
                print(f"    CPU usage: {cpu_usage:.1f}%")
                print(f"    Memory usage: {memory_info.percent:.1f}% ({memory_info.used/1024/1024:.0f}MB)")
                print(f"    Network connections: {connections}")
                
                # Verificar limites de recursos
                assert cpu_usage <= 90, f"CPU usage too high: {cpu_usage}%"
                assert memory_info.percent <= 90, f"Memory usage too high: {memory_info.percent}%"
                assert connections <= initial_connections + 100, f"Too many connections: {connections}"
                
                # Se success rate cair muito, parar teste
                if success_rate < 80:
                    print(f"    Warning: Success rate dropped to {success_rate}%, stopping load test")
                    break
                
                # Pausa entre níveis de carga
                await asyncio.sleep(2)