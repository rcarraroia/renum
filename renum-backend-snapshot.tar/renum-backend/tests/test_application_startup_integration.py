"""
Testes de integração para validar o startup da aplicação.
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock
from contextlib import asynccontextmanager

from app.main import lifespan
from fastapi import FastAPI


class TestApplicationStartupIntegration:
    """Testes de integração para startup da aplicação"""

    @pytest.mark.asyncio
    async def test_application_lifespan_startup(self):
        """Testa se o lifespan da aplicação inicia sem erros"""
        
        # Mock das dependências externas
        with patch('app.main.get_db_instance') as mock_db, \
             patch('app.services.notification_service.NotificationRepository') as mock_repo_class, \
             patch('app.main.logger') as mock_logger:
            
            # Configura mocks
            mock_db_instance = Mock()
            mock_db_instance.client = AsyncMock()
            mock_db_instance.close = AsyncMock()
            mock_db.return_value = mock_db_instance
            
            mock_repo = Mock()
            mock_repo.create_tables = AsyncMock()
            mock_repo_class.return_value = mock_repo
            
            # Cria uma aplicação FastAPI para teste
            app = FastAPI()
            
            # Testa o lifespan
            async with lifespan(app):
                # Verifica se os logs de inicialização foram chamados
                mock_logger.info.assert_any_call("Starting Renum Backend application")
                mock_logger.info.assert_any_call("Notification service loaded: True")
                mock_logger.info.assert_any_call("WebSocket manager loaded: True")
                mock_logger.info.assert_any_call("Notification service initialized successfully")
            
            # Verifica se o shutdown foi chamado
            mock_logger.info.assert_any_call("Shutting down Renum Backend application")
            mock_logger.info.assert_any_call("Notification service shutdown completed")

    @pytest.mark.asyncio
    async def test_application_startup_with_notification_service_error(self):
        """Testa se a aplicação continua funcionando mesmo com erro no notification_service"""
        
        with patch('app.main.get_db_instance') as mock_db, \
             patch('app.services.notification_service.notification_service') as mock_notification_service, \
             patch('app.main.logger') as mock_logger:
            
            # Configura mocks
            mock_db_instance = Mock()
            mock_db_instance.client = AsyncMock()
            mock_db_instance.close = AsyncMock()
            mock_db.return_value = mock_db_instance
            
            # Simula erro na inicialização do notification_service
            mock_notification_service.initialize = AsyncMock(side_effect=Exception("Test error"))
            
            # Cria uma aplicação FastAPI para teste
            app = FastAPI()
            
            # O lifespan deve funcionar mesmo com erro no notification_service
            async with lifespan(app):
                # Verifica se o erro foi logado
                mock_logger.error.assert_any_call("Error initializing notification service: Test error")
                
                # Verifica se a aplicação continuou inicializando
                mock_logger.info.assert_any_call("Starting Renum Backend application")

    @pytest.mark.asyncio
    async def test_notification_websocket_integration(self):
        """Testa a integração entre notification_service e websocket_manager"""
        
        from app.services.notification_service import notification_service
        from app.services.websocket_manager import websocket_manager
        
        # Salva o estado original
        original_websocket_manager = notification_service.websocket_manager
        
        try:
            # Configura a integração
            notification_service.websocket_manager = websocket_manager
            
            # Verifica se a integração foi configurada
            assert notification_service.websocket_manager is websocket_manager
            
            # Mock de uma notificação para teste
            mock_notification = Mock()
            mock_notification.id = "test-notification"
            mock_notification.user_id = "test-user"
            mock_notification.dict.return_value = {
                "id": "test-notification",
                "message": "Test message"
            }
            
            # Mock do método send_to_user do websocket_manager
            with patch.object(websocket_manager, 'send_to_user', new_callable=AsyncMock) as mock_send:
                # Testa envio de notificação
                await notification_service._send_websocket_notification(mock_notification)
                
                # Verifica se o método foi chamado
                mock_send.assert_called_once()
                
                # Verifica os argumentos da chamada
                call_args = mock_send.call_args
                assert call_args[0][0] == "test-user"  # user_id
                
                # Verifica se a mensagem JSON contém os dados esperados
                import json
                message_data = json.loads(call_args[0][1])
                assert message_data["type"] == "notification"
                assert message_data["data"]["id"] == "test-notification"
                
        finally:
            # Restaura o estado original
            notification_service.websocket_manager = original_websocket_manager

    @pytest.mark.asyncio
    async def test_service_resilience_without_dependencies(self):
        """Testa se o serviço funciona sem dependências externas"""
        
        from app.services.notification_service import NotificationService
        
        # Cria uma nova instância para teste isolado
        test_service = NotificationService()
        
        # Mock do repositório
        with patch.object(test_service, '_get_repository') as mock_get_repo:
            mock_repo = Mock()
            mock_repo.create_tables = AsyncMock()
            mock_get_repo.return_value = mock_repo
            
            # Deve inicializar sem erro mesmo sem websocket_manager
            await test_service.initialize()
            
            # Deve fazer shutdown sem erro
            await test_service.shutdown()
            
            # Verifica se o repositório foi usado
            mock_get_repo.assert_called()
            mock_repo.create_tables.assert_called_once()


if __name__ == "__main__":
    pytest.main([__file__])