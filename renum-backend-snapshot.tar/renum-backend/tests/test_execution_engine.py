"""
Testes para o motor de execução de equipes de agentes.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID

from app.services.execution_engine import ExecutionEngine
from app.models.team_models import (
    TeamConfig,
    WorkflowType,
    ExecutionStatus,
    WorkflowDefinition,
    WorkflowAgent,
    AgentRole,
    InputSource
)


@pytest.mark.asyncio
async def test_create_execution_plan_sequential():
    """Testa a criação de um plano de execução sequencial."""
    # Arrange
    execution_repository = AsyncMock()
    suna_client = AsyncMock()
    context_manager = AsyncMock()
    message_bus = AsyncMock()
    api_key_manager = AsyncMock()
    
    engine = ExecutionEngine(
        execution_repository,
        suna_client,
        context_manager,
        message_bus,
        api_key_manager
    )
    
    team_config = TeamConfig(
        name="Test Team",
        workflow_definition=WorkflowDefinition(
            type=WorkflowType.SEQUENTIAL,
            agents=[
                WorkflowAgent(
                    agent_id="agent-1",
                    role=AgentRole.LEADER,
                    execution_order=1,
                    input=InputSource(source="initial_prompt")
                ),
                WorkflowAgent(
                    agent_id="agent-2",
                    role=AgentRole.MEMBER,
                    execution_order=2,
                    input=InputSource(
                        source="agent_result",
                        agent_id="agent-1"
                    )
                ),
                WorkflowAgent(
                    agent_id="agent-3",
                    role=AgentRole.MEMBER,
                    execution_order=3,
                    input=InputSource(
                        source="agent_result",
                        agent_id="agent-2"
                    )
                )
            ]
        )
    )
    
    execution_id = UUID("00000000-0000-0000-0000-000000000003")
    
    # Act
    plan = await engine.create_execution_plan(
        team_config,
        execution_id
    )
    
    # Assert
    assert plan is not None
    assert plan.execution_id == execution_id
    assert plan.strategy == WorkflowType.SEQUENTIAL
    assert len(plan.steps) == 3


@pytest.mark.asyncio
async def test_create_execution_plan_parallel():
    """Testa a criação de um plano de execução paralelo."""
    # Arrange
    execution_repository = AsyncMock()
    suna_client = AsyncMock()
    context_manager = AsyncMock()
    message_bus = AsyncMock()
    api_key_manager = AsyncMock()
    
    engine = ExecutionEngine(
        execution_repository,
        suna_client,
        context_manager,
        message_bus,
        api_key_manager
    )
    
    team_config = TeamConfig(
        name="Test Team",
        workflow_definition=WorkflowDefinition(
            type=WorkflowType.PARALLEL,
            agents=[
                WorkflowAgent(
                    agent_id="agent-1",
                    role=AgentRole.MEMBER,
                    input=InputSource(source="initial_prompt")
                ),
                WorkflowAgent(
                    agent_id="agent-2",
                    role=AgentRole.MEMBER,
                    input=InputSource(source="initial_prompt")
                ),
                WorkflowAgent(
                    agent_id="agent-3",
                    role=AgentRole.MEMBER,
                    input=InputSource(source="initial_prompt")
                )
            ]
        )
    )
    
    execution_id = UUID("00000000-0000-0000-0000-000000000003")
    
    # Act
    plan = await engine.create_execution_plan(
        team_config,
        execution_id
    )
    
    # Assert
    assert plan is not None
    assert plan.execution_id == execution_id
    assert plan.strategy == WorkflowType.PARALLEL
    assert len(plan.steps) == 3