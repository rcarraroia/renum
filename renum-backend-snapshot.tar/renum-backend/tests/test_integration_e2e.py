"""
Testes de integração end-to-end para o sistema de equipes de agentes.

Estes testes verificam o fluxo completo desde a criação de uma equipe
até a execução e monitoramento dos resultados.
"""

import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

from app.models.team_models import (
    TeamCreate,
    WorkflowDefinition,
    WorkflowType,
    WorkflowAgent,
    AgentRole,
    InputSource,
    ExecutionStatus
)
from app.services.team_orchestrator import TeamOrchestrator
from app.services.execution_engine import ExecutionEngine
from app.services.team_context_manager import TeamContextManager
from app.services.team_message_bus import TeamMessageBus
from app.services.suna_api_client import SunaApiClient
from app.services.api_key_manager import ApiKeyManager


@pytest.mark.asyncio
class TestTeamIntegrationE2E:
    """Testes de integração end-to-end para equipes de agentes."""
    
    async def test_complete_team_workflow_sequential(self):
        """Testa o fluxo completo de uma equipe com workflow sequencial."""
        # Arrange
        user_id = uuid4()
        team_id = uuid4()
        execution_id = uuid4()
        
        # Mock dos repositórios
        team_repository = AsyncMock()
        execution_repository = AsyncMock()
        
        # Mock do cliente Suna
        suna_client = AsyncMock()
        suna_client.execute_individual_agent.side_effect = [
            {"success": True, "output": {"result": "Agent 1 completed", "data": {"step1": "done"}}},
            {"success": True, "output": {"result": "Agent 2 completed", "data": {"step2": "done"}}},
            {"success": True, "output": {"result": "Agent 3 completed", "data": {"step3": "done"}}}
        ]
        
        # Mock dos serviços
        context_manager = AsyncMock()
        message_bus = AsyncMock()
        api_key_manager = AsyncMock()
        websocket_manager = AsyncMock()
        
        # Configuração da equipe
        team_config = TeamCreate(
            name="Test Sequential Team",
            description="Team for testing sequential workflow",
            agent_ids=["agent1", "agent2", "agent3"],
            workflow_definition=WorkflowDefinition(
                type=WorkflowType.SEQUENTIAL,
                agents=[
                    WorkflowAgent(
                        agent_id="agent1",
                        role=AgentRole.LEADER,
                        execution_order=1,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="agent2",
                        role=AgentRole.MEMBER,
                        execution_order=2,
                        input=InputSource(source="agent_result", agent_id="agent1")
                    ),
                    WorkflowAgent(
                        agent_id="agent3",
                        role=AgentRole.MEMBER,
                        execution_order=3,
                        input=InputSource(source="agent_result", agent_id="agent2")
                    )
                ]
            )
        )
        
        # Cria o orquestrador
        orchestrator = TeamOrchestrator(
            team_repository,
            execution_repository,
            ExecutionEngine(
                execution_repository,
                suna_client,
                context_manager,
                message_bus,
                api_key_manager,
                websocket_manager
            ),
            suna_client,
            context_manager,
            message_bus,
            api_key_manager
        )
        
        # Act - Executa a equipe
        result = await orchestrator.execute_team(
            team_id=team_id,
            initial_prompt="Analyze market trends and create a comprehensive report",
            user_id=user_id
        )
        
        # Assert
        assert result is not None
        
        # Verifica se todos os agentes foram executados na ordem correta
        assert suna_client.execute_individual_agent.call_count == 3
        
        # Verifica se o contexto foi gerenciado corretamente
        assert context_manager.create_context.called
        assert context_manager.update_context_object.call_count >= 3
        
        # Verifica se as mensagens foram enviadas
        assert message_bus.send_message.called or message_bus.broadcast_message.called
    
    async def test_complete_team_workflow_parallel(self):
        """Testa o fluxo completo de uma equipe com workflow paralelo."""
        # Arrange
        user_id = uuid4()
        team_id = uuid4()
        
        # Mock dos repositórios
        team_repository = AsyncMock()
        execution_repository = AsyncMock()
        
        # Mock do cliente Suna - todos os agentes executam simultaneamente
        suna_client = AsyncMock()
        suna_client.execute_individual_agent.side_effect = [
            {"success": True, "output": {"result": "Agent 1 completed", "analysis": "market_data"}},
            {"success": True, "output": {"result": "Agent 2 completed", "analysis": "competitor_data"}},
            {"success": True, "output": {"result": "Agent 3 completed", "analysis": "trend_data"}}
        ]
        
        # Mock dos serviços
        context_manager = AsyncMock()
        message_bus = AsyncMock()
        api_key_manager = AsyncMock()
        websocket_manager = AsyncMock()
        
        # Configuração da equipe paralela
        team_config = TeamCreate(
            name="Test Parallel Team",
            description="Team for testing parallel workflow",
            agent_ids=["analyst1", "analyst2", "analyst3"],
            workflow_definition=WorkflowDefinition(
                type=WorkflowType.PARALLEL,
                agents=[
                    WorkflowAgent(
                        agent_id="analyst1",
                        role=AgentRole.MEMBER,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="analyst2",
                        role=AgentRole.MEMBER,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="analyst3",
                        role=AgentRole.MEMBER,
                        input=InputSource(source="initial_prompt")
                    )
                ]
            )
        )
        
        # Cria o orquestrador
        orchestrator = TeamOrchestrator(
            team_repository,
            execution_repository,
            ExecutionEngine(
                execution_repository,
                suna_client,
                context_manager,
                message_bus,
                api_key_manager,
                websocket_manager
            ),
            suna_client,
            context_manager,
            message_bus,
            api_key_manager
        )
        
        # Act - Executa a equipe
        result = await orchestrator.execute_team(
            team_id=team_id,
            initial_prompt="Analyze different aspects of the market simultaneously",
            user_id=user_id
        )
        
        # Assert
        assert result is not None
        
        # Verifica se todos os agentes foram executados
        assert suna_client.execute_individual_agent.call_count == 3
        
        # Verifica se o contexto foi criado
        assert context_manager.create_context.called
    
    async def test_team_execution_with_failure_handling(self):
        """Testa o tratamento de falhas durante a execução da equipe."""
        # Arrange
        user_id = uuid4()
        team_id = uuid4()
        
        # Mock dos repositórios
        team_repository = AsyncMock()
        execution_repository = AsyncMock()
        
        # Mock do cliente Suna - simula falha no segundo agente
        suna_client = AsyncMock()
        suna_client.execute_individual_agent.side_effect = [
            {"success": True, "output": {"result": "Agent 1 completed"}},
            {"success": False, "error": "Agent 2 failed due to API limit"},
            {"success": True, "output": {"result": "Agent 3 completed"}}
        ]
        
        # Mock dos serviços
        context_manager = AsyncMock()
        message_bus = AsyncMock()
        api_key_manager = AsyncMock()
        websocket_manager = AsyncMock()
        
        # Configuração da equipe
        team_config = TeamCreate(
            name="Test Failure Handling Team",
            description="Team for testing failure scenarios",
            agent_ids=["agent1", "agent2", "agent3"],
            workflow_definition=WorkflowDefinition(
                type=WorkflowType.SEQUENTIAL,
                agents=[
                    WorkflowAgent(
                        agent_id="agent1",
                        role=AgentRole.MEMBER,
                        execution_order=1,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="agent2",
                        role=AgentRole.MEMBER,
                        execution_order=2,
                        input=InputSource(source="agent_result", agent_id="agent1")
                    ),
                    WorkflowAgent(
                        agent_id="agent3",
                        role=AgentRole.MEMBER,
                        execution_order=3,
                        input=InputSource(source="agent_result", agent_id="agent1")  # Pula agent2
                    )
                ]
            )
        )
        
        # Cria o orquestrador
        orchestrator = TeamOrchestrator(
            team_repository,
            execution_repository,
            ExecutionEngine(
                execution_repository,
                suna_client,
                context_manager,
                message_bus,
                api_key_manager,
                websocket_manager
            ),
            suna_client,
            context_manager,
            message_bus,
            api_key_manager
        )
        
        # Act - Executa a equipe
        result = await orchestrator.execute_team(
            team_id=team_id,
            initial_prompt="Test failure handling",
            user_id=user_id
        )
        
        # Assert
        # O resultado deve indicar que houve falhas, mas a execução continuou
        assert result is not None
        
        # Verifica se tentou executar todos os agentes
        assert suna_client.execute_individual_agent.call_count >= 2
        
        # Verifica se as mensagens de erro foram enviadas
        assert message_bus.send_message.called or message_bus.broadcast_message.called
    
    async def test_team_context_sharing(self):
        """Testa o compartilhamento de contexto entre agentes."""
        # Arrange
        user_id = uuid4()
        team_id = uuid4()
        execution_id = uuid4()
        
        # Mock dos repositórios
        team_repository = AsyncMock()
        execution_repository = AsyncMock()
        
        # Mock do cliente Suna
        suna_client = AsyncMock()
        suna_client.execute_individual_agent.side_effect = [
            {"success": True, "output": {"shared_data": "data_from_agent1", "result": "Agent 1 done"}},
            {"success": True, "output": {"shared_data": "data_from_agent2", "result": "Agent 2 done"}}
        ]
        
        # Mock dos serviços com comportamento específico para contexto
        context_manager = AsyncMock()
        context_manager.get_all_variables.return_value = {
            "shared_data": "data_from_agent1",
            "execution_id": str(execution_id)
        }
        
        message_bus = AsyncMock()
        api_key_manager = AsyncMock()
        websocket_manager = AsyncMock()
        
        # Configuração da equipe
        team_config = TeamCreate(
            name="Test Context Sharing Team",
            description="Team for testing context sharing",
            agent_ids=["agent1", "agent2"],
            workflow_definition=WorkflowDefinition(
                type=WorkflowType.SEQUENTIAL,
                agents=[
                    WorkflowAgent(
                        agent_id="agent1",
                        role=AgentRole.LEADER,
                        execution_order=1,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="agent2",
                        role=AgentRole.MEMBER,
                        execution_order=2,
                        input=InputSource(source="combined", sources=[
                            {"type": "initial_prompt"},
                            {"type": "agent_result", "agent_id": "agent1"}
                        ])
                    )
                ]
            )
        )
        
        # Cria o orquestrador
        orchestrator = TeamOrchestrator(
            team_repository,
            execution_repository,
            ExecutionEngine(
                execution_repository,
                suna_client,
                context_manager,
                message_bus,
                api_key_manager,
                websocket_manager
            ),
            suna_client,
            context_manager,
            message_bus,
            api_key_manager
        )
        
        # Act - Executa a equipe
        result = await orchestrator.execute_team(
            team_id=team_id,
            initial_prompt="Test context sharing between agents",
            user_id=user_id
        )
        
        # Assert
        assert result is not None
        
        # Verifica se o contexto foi criado e atualizado
        assert context_manager.create_context.called
        assert context_manager.update_context_object.call_count >= 2
        
        # Verifica se as variáveis compartilhadas foram acessadas
        assert context_manager.get_all_variables.called
    
    async def test_team_message_communication(self):
        """Testa a comunicação entre agentes via sistema de mensagens."""
        # Arrange
        user_id = uuid4()
        team_id = uuid4()
        
        # Mock dos repositórios
        team_repository = AsyncMock()
        execution_repository = AsyncMock()
        
        # Mock do cliente Suna
        suna_client = AsyncMock()
        suna_client.execute_individual_agent.return_value = {
            "success": True, 
            "output": {"result": "Agent completed"}
        }
        
        # Mock dos serviços com foco no sistema de mensagens
        context_manager = AsyncMock()
        message_bus = AsyncMock()
        api_key_manager = AsyncMock()
        websocket_manager = AsyncMock()
        
        # Configuração da equipe
        team_config = TeamCreate(
            name="Test Message Communication Team",
            description="Team for testing message communication",
            agent_ids=["coordinator", "worker1", "worker2"],
            workflow_definition=WorkflowDefinition(
                type=WorkflowType.PARALLEL,
                agents=[
                    WorkflowAgent(
                        agent_id="coordinator",
                        role=AgentRole.COORDINATOR,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="worker1",
                        role=AgentRole.MEMBER,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="worker2",
                        role=AgentRole.MEMBER,
                        input=InputSource(source="initial_prompt")
                    )
                ]
            )
        )
        
        # Cria o orquestrador
        orchestrator = TeamOrchestrator(
            team_repository,
            execution_repository,
            ExecutionEngine(
                execution_repository,
                suna_client,
                context_manager,
                message_bus,
                api_key_manager,
                websocket_manager
            ),
            suna_client,
            context_manager,
            message_bus,
            api_key_manager
        )
        
        # Act - Executa a equipe
        result = await orchestrator.execute_team(
            team_id=team_id,
            initial_prompt="Test message communication between agents",
            user_id=user_id
        )
        
        # Assert
        assert result is not None
        
        # Verifica se mensagens foram enviadas
        assert message_bus.send_message.called or message_bus.broadcast_message.called
        
        # Verifica se todos os agentes foram executados
        assert suna_client.execute_individual_agent.call_count == 3
    
    @pytest.mark.slow
    async def test_team_performance_with_multiple_executions(self):
        """Testa a performance do sistema com múltiplas execuções simultâneas."""
        # Arrange
        user_id = uuid4()
        num_teams = 3
        num_agents_per_team = 2
        
        # Mock dos repositórios
        team_repository = AsyncMock()
        execution_repository = AsyncMock()
        
        # Mock do cliente Suna
        suna_client = AsyncMock()
        suna_client.execute_individual_agent.return_value = {
            "success": True, 
            "output": {"result": "Agent completed"}
        }
        
        # Mock dos serviços
        context_manager = AsyncMock()
        message_bus = AsyncMock()
        api_key_manager = AsyncMock()
        websocket_manager = AsyncMock()
        
        # Cria múltiplas equipes
        teams = []
        for i in range(num_teams):
            team_config = TeamCreate(
                name=f"Performance Test Team {i+1}",
                description=f"Team {i+1} for performance testing",
                agent_ids=[f"agent{i}_{j}" for j in range(num_agents_per_team)],
                workflow_definition=WorkflowDefinition(
                    type=WorkflowType.PARALLEL,
                    agents=[
                        WorkflowAgent(
                            agent_id=f"agent{i}_{j}",
                            role=AgentRole.MEMBER,
                            input=InputSource(source="initial_prompt")
                        ) for j in range(num_agents_per_team)
                    ]
                )
            )
            teams.append(team_config)
        
        # Cria o orquestrador
        orchestrator = TeamOrchestrator(
            team_repository,
            execution_repository,
            ExecutionEngine(
                execution_repository,
                suna_client,
                context_manager,
                message_bus,
                api_key_manager,
                websocket_manager
            ),
            suna_client,
            context_manager,
            message_bus,
            api_key_manager
        )
        
        # Act - Executa todas as equipes simultaneamente
        tasks = []
        for i, team_config in enumerate(teams):
            task = orchestrator.execute_team(
                team_id=uuid4(),
                initial_prompt=f"Performance test task {i+1}",
                user_id=user_id
            )
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Assert
        # Verifica se todas as execuções foram bem-sucedidas
        successful_results = [r for r in results if not isinstance(r, Exception)]
        assert len(successful_results) == num_teams
        
        # Verifica se o número total de chamadas para agentes está correto
        expected_calls = num_teams * num_agents_per_team
        assert suna_client.execute_individual_agent.call_count == expected_calls