"""
Testes de integração end-to-end para o sistema de equipes de agentes.
Testa cenários completos de execução com todos os componentes integrados.
"""

import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4
from datetime import datetime

from app.services.team_orchestrator import TeamOrchestrator
from app.services.execution_engine import ExecutionEngine
from app.models.team_models import (
    TeamCreate,
    WorkflowDefinition,
    WorkflowType,
    WorkflowAgent,
    AgentRole,
    InputSource,
    TeamExecutionCreate,
    ExecutionStatus
)


class TestTeamIntegrationE2E:
    """Testes de integração end-to-end para equipes de agentes."""

    @pytest.mark.asyncio
    async def test_complete_team_workflow_sequential(self):
        """Testa o fluxo completo de uma equipe com workflow sequencial."""
        # Arrange
        user_id = uuid4()
        team_id = uuid4()
        execution_id = uuid4()

        # Mock dos repositórios
        execution_repository = AsyncMock()

        # Mock do cliente Suna
        suna_client = AsyncMock()
        suna_client.execute_individual_agent.side_effect = [
            {"success": True, "output": {"result": "Agent 1 completed", "data": {"step1": "done"}}},
            {"success": True, "output": {"result": "Agent 2 completed", "data": {"step2": "done"}}},
            {"success": True, "output": {"result": "Agent 3 completed", "data": {"step3": "done"}}}
        ]

        # Mock dos serviços
        context_manager = AsyncMock()
        message_bus = AsyncMock()
        api_key_manager = AsyncMock()
        websocket_manager = AsyncMock()
    
        # Configuração da equipe
        team_config = TeamCreate(
            name="Test Sequential Team",
            description="Team for testing sequential workflow",
            agent_ids=["agent1", "agent2", "agent3"],
            workflow_definition=WorkflowDefinition(
                type=WorkflowType.SEQUENTIAL,
                agents=[
                    WorkflowAgent(
                        agent_id="agent1",
                        role=AgentRole.LEADER,
                        execution_order=1,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="agent2",
                        role=AgentRole.MEMBER,
                        execution_order=2,
                        input=InputSource(source="agent_result", agent_id="agent1")
                    ),
                    WorkflowAgent(
                        agent_id="agent3",
                        role=AgentRole.MEMBER,
                        execution_order=3,
                        input=InputSource(source="agent_result", agent_id="agent2")
                    )
                ]
            )
        )

        # Cria o orquestrador
        orchestrator = TeamOrchestrator(
            ExecutionEngine(
                execution_repository,
                suna_client,
                context_manager,
                message_bus,
                api_key_manager,
                websocket_manager
            ),
            suna_client,
            context_manager,
            message_bus,
            api_key_manager
        )

        # Configuração da execução
        execution_config = TeamExecutionCreate(
            team_id=team_id,
            user_id=user_id,
            initial_prompt="Execute the sequential workflow",
            execution_config={
                "max_iterations": 3,
                "timeout": 300
            }
        )

        # Act
        result = await orchestrator.execute_team(execution_config, team_config.workflow_definition)

        # Assert
        assert result is not None
        assert result.status in [ExecutionStatus.COMPLETED, ExecutionStatus.RUNNING]
        
        # Verificar que os agentes foram executados na ordem correta
        assert suna_client.execute_individual_agent.call_count == 3
        
        # Verificar que o contexto foi atualizado
        assert context_manager.set_variable.called
        
        # Verificar que mensagens foram enviadas
        assert message_bus.send_message.called or message_bus.broadcast_message.called

    @pytest.mark.asyncio
    async def test_complete_team_workflow_parallel(self):
        """Testa o fluxo completo de uma equipe com workflow paralelo."""
        # Arrange
        user_id = uuid4()
        team_id = uuid4()

        # Mock dos repositórios
        execution_repository = AsyncMock()

        # Mock do cliente Suna - todos os agentes executam simultaneamente
        suna_client = AsyncMock()
        suna_client.execute_individual_agent.side_effect = [
            {"success": True, "output": {"result": "Agent 1 completed", "analysis": "market_data"}},
            {"success": True, "output": {"result": "Agent 2 completed", "analysis": "competitor_data"}},
            {"success": True, "output": {"result": "Agent 3 completed", "analysis": "trend_data"}}
        ]

        # Mock dos serviços
        context_manager = AsyncMock()
        message_bus = AsyncMock()
        api_key_manager = AsyncMock()
        websocket_manager = AsyncMock()

        # Configuração da equipe paralela
        team_config = TeamCreate(
            name="Test Parallel Team",
            description="Team for testing parallel workflow",
            agent_ids=["analyst1", "analyst2", "analyst3"],
            workflow_definition=WorkflowDefinition(
                type=WorkflowType.PARALLEL,
                agents=[
                    WorkflowAgent(
                        agent_id="analyst1",
                        role=AgentRole.MEMBER,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="analyst2",
                        role=AgentRole.MEMBER,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="analyst3",
                        role=AgentRole.MEMBER,
                        input=InputSource(source="initial_prompt")
                    )
                ]
            )
        )

        # Cria o orquestrador
        orchestrator = TeamOrchestrator(
            ExecutionEngine(
                execution_repository,
                suna_client,
                context_manager,
                message_bus,
                api_key_manager,
                websocket_manager
            ),
            suna_client,
            context_manager,
            message_bus,
            api_key_manager
        )

        # Configuração da execução
        execution_config = TeamExecutionCreate(
            team_id=team_id,
            user_id=user_id,
            initial_prompt="Analyze market data in parallel",
            execution_config={
                "max_parallel": 3,
                "timeout": 300
            }
        )

        # Act
        result = await orchestrator.execute_team(execution_config, team_config.workflow_definition)

        # Assert
        assert result is not None
        assert result.status in [ExecutionStatus.COMPLETED, ExecutionStatus.RUNNING]
        
        # Verificar que todos os agentes foram executados
        assert suna_client.execute_individual_agent.call_count == 3
        
        # Verificar que o contexto foi compartilhado
        assert context_manager.set_variable.called

    @pytest.mark.asyncio
    async def test_team_execution_with_failure_handling(self):
        """Testa o tratamento de falhas durante a execução da equipe."""
        # Arrange
        user_id = uuid4()
        team_id = uuid4()

        # Mock dos repositórios
        execution_repository = AsyncMock()

        # Mock do cliente Suna - simula falha no segundo agente
        suna_client = AsyncMock()
        suna_client.execute_individual_agent.side_effect = [
            {"success": True, "output": {"result": "Agent 1 completed"}},
            {"success": False, "error": "Agent 2 failed due to API limit"},
            {"success": True, "output": {"result": "Agent 3 completed"}}
        ]

        # Mock dos serviços
        context_manager = AsyncMock()
        message_bus = AsyncMock()
        api_key_manager = AsyncMock()
        websocket_manager = AsyncMock()

        # Configuração da equipe
        team_config = TeamCreate(
            name="Test Failure Handling Team",
            description="Team for testing failure scenarios",
            agent_ids=["agent1", "agent2", "agent3"],
            workflow_definition=WorkflowDefinition(
                type=WorkflowType.SEQUENTIAL,
                agents=[
                    WorkflowAgent(
                        agent_id="agent1",
                        role=AgentRole.MEMBER,
                        execution_order=1,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="agent2",
                        role=AgentRole.MEMBER,
                        execution_order=2,
                        input=InputSource(source="agent_result", agent_id="agent1")
                    ),
                    WorkflowAgent(
                        agent_id="agent3",
                        role=AgentRole.MEMBER,
                        execution_order=3,
                        input=InputSource(source="agent_result", agent_id="agent1")  # Pula agent2
                    )
                ]
            )
        )

        # Cria o orquestrador
        orchestrator = TeamOrchestrator(
            ExecutionEngine(
                execution_repository,
                suna_client,
                context_manager,
                message_bus,
                api_key_manager,
                websocket_manager
            ),
            suna_client,
            context_manager,
            message_bus,
            api_key_manager
        )

        # Configuração da execução
        execution_config = TeamExecutionCreate(
            team_id=team_id,
            user_id=user_id,
            initial_prompt="Test failure handling",
            execution_config={
                "continue_on_failure": True,
                "timeout": 300
            }
        )

        # Act
        result = await orchestrator.execute_team(execution_config, team_config.workflow_definition)

        # Assert
        assert result is not None
        # Pode ser COMPLETED (se continuou) ou FAILED (se parou)
        assert result.status in [ExecutionStatus.COMPLETED, ExecutionStatus.FAILED, ExecutionStatus.RUNNING]
        
        # Verificar que pelo menos o primeiro agente foi executado
        assert suna_client.execute_individual_agent.call_count >= 1

    @pytest.mark.asyncio
    async def test_team_context_sharing(self):
        """Testa o compartilhamento de contexto entre agentes."""
        # Arrange
        user_id = uuid4()
        team_id = uuid4()
        execution_id = uuid4()

        # Mock dos repositórios
        execution_repository = AsyncMock()

        # Mock do cliente Suna
        suna_client = AsyncMock()
        suna_client.execute_individual_agent.side_effect = [
            {"success": True, "output": {"shared_data": "data_from_agent1", "result": "Agent 1 done"}},
            {"success": True, "output": {"shared_data": "data_from_agent2", "result": "Agent 2 done"}}
        ]

        # Mock dos serviços com comportamento específico para contexto
        context_manager = AsyncMock()
        context_manager.get_all_variables.return_value = {
            "shared_data": "data_from_agent1",
            "execution_id": str(execution_id)
        }

        message_bus = AsyncMock()
        api_key_manager = AsyncMock()
        websocket_manager = AsyncMock()

        # Configuração da equipe
        team_config = TeamCreate(
            name="Test Context Sharing Team",
            description="Team for testing context sharing",
            agent_ids=["agent1", "agent2"],
            workflow_definition=WorkflowDefinition(
                type=WorkflowType.SEQUENTIAL,
                agents=[
                    WorkflowAgent(
                        agent_id="agent1",
                        role=AgentRole.LEADER,
                        execution_order=1,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="agent2",
                        role=AgentRole.MEMBER,
                        execution_order=2,
                        input=InputSource(source="combined", sources=[
                            {"type": "initial_prompt"},
                            {"type": "agent_result", "agent_id": "agent1"}
                        ])
                    )
                ]
            )
        )

        # Cria o orquestrador
        orchestrator = TeamOrchestrator(
            ExecutionEngine(
                execution_repository,
                suna_client,
                context_manager,
                message_bus,
                api_key_manager,
                websocket_manager
            ),
            suna_client,
            context_manager,
            message_bus,
            api_key_manager
        )

        # Configuração da execução
        execution_config = TeamExecutionCreate(
            team_id=team_id,
            user_id=user_id,
            initial_prompt="Test context sharing",
            execution_config={}
        )

        # Act
        result = await orchestrator.execute_team(execution_config, team_config.workflow_definition)

        # Assert
        assert result is not None
        
        # Verificar que o contexto foi acessado e atualizado
        assert context_manager.set_variable.called
        assert context_manager.get_all_variables.called or context_manager.get_variable.called

    @pytest.mark.asyncio
    async def test_team_message_communication(self):
        """Testa a comunicação entre agentes via sistema de mensagens."""
        # Arrange
        user_id = uuid4()
        team_id = uuid4()

        # Mock dos repositórios
        execution_repository = AsyncMock()

        # Mock do cliente Suna
        suna_client = AsyncMock()
        suna_client.execute_individual_agent.return_value = {
            "success": True,
            "output": {"result": "Agent completed"}
        }

        # Mock dos serviços com foco no sistema de mensagens
        context_manager = AsyncMock()
        message_bus = AsyncMock()
        api_key_manager = AsyncMock()
        websocket_manager = AsyncMock()

        # Configuração da equipe
        team_config = TeamCreate(
            name="Test Message Communication Team",
            description="Team for testing message communication",
            agent_ids=["coordinator", "worker1", "worker2"],
            workflow_definition=WorkflowDefinition(
                type=WorkflowType.PARALLEL,
                agents=[
                    WorkflowAgent(
                        agent_id="coordinator",
                        role=AgentRole.COORDINATOR,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="worker1",
                        role=AgentRole.MEMBER,
                        input=InputSource(source="initial_prompt")
                    ),
                    WorkflowAgent(
                        agent_id="worker2",
                        role=AgentRole.MEMBER,
                        input=InputSource(source="initial_prompt")
                    )
                ]
            )
        )

        # Cria o orquestrador
        orchestrator = TeamOrchestrator(
            ExecutionEngine(
                execution_repository,
                suna_client,
                context_manager,
                message_bus,
                api_key_manager,
                websocket_manager
            ),
            suna_client,
            context_manager,
            message_bus,
            api_key_manager
        )

        # Configuração da execução
        execution_config = TeamExecutionCreate(
            team_id=team_id,
            user_id=user_id,
            initial_prompt="Test message communication",
            execution_config={}
        )

        # Act
        result = await orchestrator.execute_team(execution_config, team_config.workflow_definition)

        # Assert
        assert result is not None
        
        # Verificar que mensagens foram enviadas
        assert message_bus.send_message.called or message_bus.broadcast_message.called

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_team_performance_with_multiple_executions(self):
        """Testa a performance do sistema com múltiplas execuções simultâneas."""
        # Arrange
        user_id = uuid4()
        num_teams = 3
        num_agents_per_team = 2

        # Mock dos repositórios
        execution_repository = AsyncMock()

        # Mock do cliente Suna
        suna_client = AsyncMock()
        suna_client.execute_individual_agent.return_value = {
            "success": True,
            "output": {"result": "Agent completed"}
        }

        # Mock dos serviços
        context_manager = AsyncMock()
        message_bus = AsyncMock()
        api_key_manager = AsyncMock()
        websocket_manager = AsyncMock()

        # Cria múltiplas equipes
        teams = []
        for i in range(num_teams):
            team_config = TeamCreate(
                name=f"Performance Test Team {i+1}",
                description=f"Team {i+1} for performance testing",
                agent_ids=[f"agent{i}_{j}" for j in range(num_agents_per_team)],
                workflow_definition=WorkflowDefinition(
                    type=WorkflowType.PARALLEL,
                    agents=[
                        WorkflowAgent(
                            agent_id=f"agent{i}_{j}",
                            role=AgentRole.MEMBER,
                            input=InputSource(source="initial_prompt")
                        ) for j in range(num_agents_per_team)
                    ]
                )
            )
            teams.append(team_config)

        # Cria o orquestrador
        orchestrator = TeamOrchestrator(
            ExecutionEngine(
                execution_repository,
                suna_client,
                context_manager,
                message_bus,
                api_key_manager,
                websocket_manager
            ),
            suna_client,
            context_manager,
            message_bus,
            api_key_manager
        )

        # Act - Executa múltiplas equipes simultaneamente
        tasks = []
        for i, team_config in enumerate(teams):
            execution_config = TeamExecutionCreate(
                team_id=uuid4(),
                user_id=user_id,
                initial_prompt=f"Performance test {i+1}",
                execution_config={}
            )
            
            task = orchestrator.execute_team(execution_config, team_config.workflow_definition)
            tasks.append(task)

        # Aguarda todas as execuções
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Assert
        assert len(results) == num_teams
        
        # Verificar que não houve exceções críticas
        exceptions = [r for r in results if isinstance(r, Exception)]
        assert len(exceptions) == 0, f"Exceções encontradas: {exceptions}"
        
        # Verificar que todas as execuções retornaram resultados
        successful_results = [r for r in results if not isinstance(r, Exception) and r is not None]
        assert len(successful_results) >= num_teams // 2, "Pelo menos metade das execuções deve ser bem-sucedida"

if __name__ == "__main__":
    pytest.main([__file__, "-v"])