"""
Testes unitários para os modelos de integração.

Este módulo contém testes para validação dos modelos de dados
de integrações de agentes e logs de webhook.
"""

import pytest
from datetime import datetime
from uuid import uuid4, UUID
from pydantic import ValidationError

from app.models.integrations import (
    AgentIntegration,
    WebhookCall,
    IntegrationStats,
    WebhookValidationResult,
    CreateIntegrationRequest,
    UpdateIntegrationRequest,
    IntegrationResponse,
    WebhookCallResponse,
    IntegrationStatus,
    IntegrationChannel
)


class TestAgentIntegration:
    """Testes para o modelo AgentIntegration."""
    
    def test_create_valid_integration(self):
        """Testa criação de integração válida."""
        integration = AgentIntegration(
            agent_id=uuid4(),
            client_id=uuid4(),
            channel=IntegrationChannel.WHATSAPP,
            webhook_token="whk_" + "a" * 32,
            status=IntegrationStatus.ACTIVE,
            rate_limit_per_minute=60,
            metadata={"phone": "+5511999999999"},
            created_by=uuid4()
        )
        
        assert integration.agent_id is not None
        assert integration.client_id is not None
        assert integration.channel == IntegrationChannel.WHATSAPP
        assert integration.webhook_token.startswith("whk_")
        assert integration.status == IntegrationStatus.ACTIVE
        assert integration.rate_limit_per_minute == 60
        assert integration.metadata["phone"] == "+5511999999999"
    
    def test_invalid_webhook_token_prefix(self):
        """Testa validação de token sem prefixo correto."""
        with pytest.raises(ValidationError) as exc_info:
            AgentIntegration(
                agent_id=uuid4(),
                client_id=uuid4(),
                channel=IntegrationChannel.WHATSAPP,
                webhook_token="invalid_token",
                rate_limit_per_minute=60
            )
        
        assert "Token deve começar com" in str(exc_info.value)
    
    def test_invalid_webhook_token_length(self):
        """Testa validação de token muito curto."""
        with pytest.raises(ValidationError) as exc_info:
            AgentIntegration(
                agent_id=uuid4(),
                client_id=uuid4(),
                channel=IntegrationChannel.WHATSAPP,
                webhook_token="whk_short",
                rate_limit_per_minute=60
            )
        
        assert "pelo menos 36 caracteres" in str(exc_info.value)
    
    def test_invalid_rate_limit_too_low(self):
        """Testa validação de rate limit muito baixo."""
        with pytest.raises(ValidationError) as exc_info:
            AgentIntegration(
                agent_id=uuid4(),
                client_id=uuid4(),
                channel=IntegrationChannel.WHATSAPP,
                webhook_token="whk_" + "a" * 32,
                rate_limit_per_minute=0
            )
        
        assert "pelo menos 1 chamada por minuto" in str(exc_info.value)
    
    def test_invalid_rate_limit_too_high(self):
        """Testa validação de rate limit muito alto."""
        with pytest.raises(ValidationError) as exc_info:
            AgentIntegration(
                agent_id=uuid4(),
                client_id=uuid4(),
                channel=IntegrationChannel.WHATSAPP,
                webhook_token="whk_" + "a" * 32,
                rate_limit_per_minute=1001
            )
        
        assert "não pode exceder 1000 chamadas" in str(exc_info.value)
    
    def test_default_values(self):
        """Testa valores padrão do modelo."""
        integration = AgentIntegration(
            agent_id=uuid4(),
            client_id=uuid4(),
            channel=IntegrationChannel.ZAPIER,
            webhook_token="whk_" + "b" * 32
        )
        
        assert integration.status == IntegrationStatus.ACTIVE
        assert integration.rate_limit_per_minute == 60
        assert integration.metadata == {}
        assert integration.created_by is None


class TestWebhookCall:
    """Testes para o modelo WebhookCall."""
    
    def test_create_valid_webhook_call(self):
        """Testa criação de log de webhook válido."""
        call = WebhookCall(
            integration_id=uuid4(),
            request_payload={"message": "Hello"},
            response_payload={"response": "Hi there"},
            status_code=200,
            execution_time_ms=150,
            ip_address="192.168.1.1",
            user_agent="Mozilla/5.0"
        )
        
        assert call.integration_id is not None
        assert call.request_payload["message"] == "Hello"
        assert call.response_payload["response"] == "Hi there"
        assert call.status_code == 200
        assert call.execution_time_ms == 150
        assert call.ip_address == "192.168.1.1"
        assert call.user_agent == "Mozilla/5.0"
        assert call.created_at is not None
    
    def test_invalid_status_code_too_low(self):
        """Testa validação de status code muito baixo."""
        with pytest.raises(ValidationError) as exc_info:
            WebhookCall(
                integration_id=uuid4(),
                status_code=99
            )
        
        assert "deve estar entre 100 e 599" in str(exc_info.value)
    
    def test_invalid_status_code_too_high(self):
        """Testa validação de status code muito alto."""
        with pytest.raises(ValidationError) as exc_info:
            WebhookCall(
                integration_id=uuid4(),
                status_code=600
            )
        
        assert "deve estar entre 100 e 599" in str(exc_info.value)
    
    def test_invalid_execution_time_negative(self):
        """Testa validação de tempo de execução negativo."""
        with pytest.raises(ValidationError) as exc_info:
            WebhookCall(
                integration_id=uuid4(),
                execution_time_ms=-1
            )
        
        assert "não pode ser negativo" in str(exc_info.value)
    
    def test_invalid_ip_address(self):
        """Testa validação de endereço IP inválido."""
        with pytest.raises(ValidationError) as exc_info:
            WebhookCall(
                integration_id=uuid4(),
                ip_address="invalid.ip.address"
            )
        
        assert "Endereço IP inválido" in str(exc_info.value)
    
    def test_valid_ipv6_address(self):
        """Testa validação de endereço IPv6 válido."""
        call = WebhookCall(
            integration_id=uuid4(),
            ip_address="2001:0db8:85a3:0000:0000:8a2e:0370:7334"
        )
        
        assert call.ip_address == "2001:0db8:85a3:0000:0000:8a2e:0370:7334"
    
    def test_optional_fields(self):
        """Testa campos opcionais do modelo."""
        call = WebhookCall(integration_id=uuid4())
        
        assert call.request_payload is None
        assert call.response_payload is None
        assert call.status_code is None
        assert call.execution_time_ms is None
        assert call.ip_address is None
        assert call.user_agent is None
        assert call.error_message is None


class TestIntegrationStats:
    """Testes para o modelo IntegrationStats."""
    
    def test_create_valid_stats(self):
        """Testa criação de estatísticas válidas."""
        stats = IntegrationStats(
            integration_id=uuid4(),
            total_calls=100,
            successful_calls=95,
            failed_calls=5,
            avg_execution_time_ms=250.5,
            last_call_at=datetime.now(),
            period_hours=24
        )
        
        assert stats.total_calls == 100
        assert stats.successful_calls == 95
        assert stats.failed_calls == 5
        assert stats.avg_execution_time_ms == 250.5
        assert stats.period_hours == 24
    
    def test_success_rate_calculation(self):
        """Testa cálculo da taxa de sucesso."""
        stats = IntegrationStats(
            integration_id=uuid4(),
            total_calls=100,
            successful_calls=80,
            failed_calls=20
        )
        
        assert stats.success_rate == 80.0
    
    def test_error_rate_calculation(self):
        """Testa cálculo da taxa de erro."""
        stats = IntegrationStats(
            integration_id=uuid4(),
            total_calls=100,
            successful_calls=80,
            failed_calls=20
        )
        
        assert stats.error_rate == 20.0
    
    def test_zero_calls_rates(self):
        """Testa cálculo de taxas com zero chamadas."""
        stats = IntegrationStats(
            integration_id=uuid4(),
            total_calls=0,
            successful_calls=0,
            failed_calls=0
        )
        
        assert stats.success_rate == 0.0
        assert stats.error_rate == 0.0
    
    def test_default_values(self):
        """Testa valores padrão das estatísticas."""
        stats = IntegrationStats(integration_id=uuid4())
        
        assert stats.total_calls == 0
        assert stats.successful_calls == 0
        assert stats.failed_calls == 0
        assert stats.avg_execution_time_ms is None
        assert stats.last_call_at is None
        assert stats.period_hours == 24


class TestWebhookValidationResult:
    """Testes para o modelo WebhookValidationResult."""
    
    def test_valid_result(self):
        """Testa resultado de validação válido."""
        result = WebhookValidationResult(
            integration_id=uuid4(),
            client_id=uuid4(),
            rate_limit_per_minute=60,
            is_valid=True
        )
        
        assert result.is_valid is True
        assert result.is_invalid is False
        assert result.integration_id is not None
        assert result.client_id is not None
        assert result.rate_limit_per_minute == 60
    
    def test_invalid_result(self):
        """Testa resultado de validação inválido."""
        result = WebhookValidationResult(
            integration_id=None,
            client_id=None,
            rate_limit_per_minute=None,
            is_valid=False
        )
        
        assert result.is_valid is False
        assert result.is_invalid is True
        assert result.integration_id is None
        assert result.client_id is None
        assert result.rate_limit_per_minute is None


class TestCreateIntegrationRequest:
    """Testes para o modelo CreateIntegrationRequest."""
    
    def test_create_valid_request(self):
        """Testa criação de requisição válida."""
        request = CreateIntegrationRequest(
            agent_id=uuid4(),
            channel=IntegrationChannel.N8N,
            rate_limit_per_minute=120,
            metadata={"webhook_url": "https://example.com/webhook"}
        )
        
        assert request.agent_id is not None
        assert request.channel == IntegrationChannel.N8N
        assert request.rate_limit_per_minute == 120
        assert request.metadata["webhook_url"] == "https://example.com/webhook"
    
    def test_default_values(self):
        """Testa valores padrão da requisição."""
        request = CreateIntegrationRequest(
            agent_id=uuid4(),
            channel=IntegrationChannel.TELEGRAM
        )
        
        assert request.rate_limit_per_minute == 60
        assert request.metadata == {}


class TestUpdateIntegrationRequest:
    """Testes para o modelo UpdateIntegrationRequest."""
    
    def test_update_valid_request(self):
        """Testa atualização válida."""
        request = UpdateIntegrationRequest(
            status=IntegrationStatus.INACTIVE,
            rate_limit_per_minute=30,
            metadata={"updated": True}
        )
        
        assert request.status == IntegrationStatus.INACTIVE
        assert request.rate_limit_per_minute == 30
        assert request.metadata["updated"] is True
    
    def test_partial_update(self):
        """Testa atualização parcial."""
        request = UpdateIntegrationRequest(
            status=IntegrationStatus.ACTIVE
        )
        
        assert request.status == IntegrationStatus.ACTIVE
        assert request.rate_limit_per_minute is None
        assert request.metadata is None
    
    def test_invalid_rate_limit_in_update(self):
        """Testa validação de rate limit inválido na atualização."""
        with pytest.raises(ValidationError) as exc_info:
            UpdateIntegrationRequest(
                rate_limit_per_minute=0
            )
        
        assert "pelo menos 1 chamada por minuto" in str(exc_info.value)


class TestIntegrationResponse:
    """Testes para o modelo IntegrationResponse."""
    
    def test_create_valid_response(self):
        """Testa criação de resposta válida."""
        stats = IntegrationStats(
            integration_id=uuid4(),
            total_calls=50,
            successful_calls=48,
            failed_calls=2
        )
        
        response = IntegrationResponse(
            agent_id=uuid4(),
            client_id=uuid4(),
            channel=IntegrationChannel.CUSTOM,
            webhook_token="whk_" + "c" * 32,
            webhook_url="https://api.renum.com/webhook/agent-123",
            status=IntegrationStatus.ACTIVE,
            rate_limit_per_minute=90,
            metadata={"custom_field": "value"},
            created_by=uuid4(),
            stats=stats
        )
        
        assert response.agent_id is not None
        assert response.webhook_url == "https://api.renum.com/webhook/agent-123"
        assert response.stats.total_calls == 50
        assert response.stats.success_rate == 96.0


class TestWebhookCallResponse:
    """Testes para o modelo WebhookCallResponse."""
    
    def test_create_valid_call_response(self):
        """Testa criação de resposta de chamada válida."""
        response = WebhookCallResponse(
            integration_id=uuid4(),
            status_code=200,
            execution_time_ms=125,
            created_at=datetime.now(),
            request_payload={"input": "test"},
            response_payload={"output": "result"},
            ip_address="10.0.0.1",
            user_agent="TestAgent/1.0"
        )
        
        assert response.integration_id is not None
        assert response.status_code == 200
        assert response.execution_time_ms == 125
        assert response.request_payload["input"] == "test"
        assert response.response_payload["output"] == "result"
        assert response.ip_address == "10.0.0.1"
        assert response.user_agent == "TestAgent/1.0"
    
    def test_minimal_call_response(self):
        """Testa resposta mínima de chamada."""
        response = WebhookCallResponse(
            integration_id=uuid4(),
            created_at=datetime.now()
        )
        
        assert response.integration_id is not None
        assert response.created_at is not None
        assert response.status_code is None
        assert response.execution_time_ms is None
        assert response.error_message is None