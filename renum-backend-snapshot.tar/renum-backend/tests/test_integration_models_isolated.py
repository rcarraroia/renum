"""
Testes isolados para os modelos de integração.
Este arquivo não depende do conftest.py para evitar problemas de importação.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest
from datetime import datetime
from uuid import uuid4
from pydantic import ValidationError

from app.models.integrations import (
    AgentIntegration,
    WebhookCall,
    IntegrationStats,
    IntegrationStatus,
    IntegrationChannel
)


def test_agent_integration_creation():
    """Testa criação básica de AgentIntegration."""
    integration = AgentIntegration(
        agent_id=uuid4(),
        client_id=uuid4(),
        channel=IntegrationChannel.WHATSAPP,
        webhook_token="whk_" + "a" * 32,
        status=IntegrationStatus.ACTIVE,
        rate_limit_per_minute=60
    )
    
    assert integration.agent_id is not None
    assert integration.client_id is not None
    assert integration.channel == IntegrationChannel.WHATSAPP
    assert integration.webhook_token.startswith("whk_")
    assert integration.status == IntegrationStatus.ACTIVE
    assert integration.rate_limit_per_minute == 60


def test_webhook_token_validation():
    """Testa validação do token de webhook."""
    # Token válido
    integration = AgentIntegration(
        agent_id=uuid4(),
        client_id=uuid4(),
        channel=IntegrationChannel.ZAPIER,
        webhook_token="whk_" + "b" * 32
    )
    assert integration.webhook_token.startswith("whk_")
    
    # Token inválido - sem prefixo
    with pytest.raises(ValidationError):
        AgentIntegration(
            agent_id=uuid4(),
            client_id=uuid4(),
            channel=IntegrationChannel.ZAPIER,
            webhook_token="invalid_token"
        )
    
    # Token inválido - muito curto
    with pytest.raises(ValidationError):
        AgentIntegration(
            agent_id=uuid4(),
            client_id=uuid4(),
            channel=IntegrationChannel.ZAPIER,
            webhook_token="whk_short"
        )


def test_rate_limit_validation():
    """Testa validação do rate limit."""
    # Rate limit válido
    integration = AgentIntegration(
        agent_id=uuid4(),
        client_id=uuid4(),
        channel=IntegrationChannel.N8N,
        webhook_token="whk_" + "c" * 32,
        rate_limit_per_minute=100
    )
    assert integration.rate_limit_per_minute == 100
    
    # Rate limit muito baixo
    with pytest.raises(ValidationError):
        AgentIntegration(
            agent_id=uuid4(),
            client_id=uuid4(),
            channel=IntegrationChannel.N8N,
            webhook_token="whk_" + "c" * 32,
            rate_limit_per_minute=0
        )
    
    # Rate limit muito alto
    with pytest.raises(ValidationError):
        AgentIntegration(
            agent_id=uuid4(),
            client_id=uuid4(),
            channel=IntegrationChannel.N8N,
            webhook_token="whk_" + "c" * 32,
            rate_limit_per_minute=1001
        )


def test_webhook_call_creation():
    """Testa criação de WebhookCall."""
    call = WebhookCall(
        integration_id=uuid4(),
        request_payload={"message": "Hello"},
        response_payload={"response": "Hi"},
        status_code=200,
        execution_time_ms=150,
        ip_address="192.168.1.1",
        user_agent="TestAgent/1.0"
    )
    
    assert call.integration_id is not None
    assert call.request_payload["message"] == "Hello"
    assert call.response_payload["response"] == "Hi"
    assert call.status_code == 200
    assert call.execution_time_ms == 150
    assert call.ip_address == "192.168.1.1"
    assert call.user_agent == "TestAgent/1.0"


def test_webhook_call_validations():
    """Testa validações do WebhookCall."""
    # Status code inválido
    with pytest.raises(ValidationError):
        WebhookCall(
            integration_id=uuid4(),
            status_code=99  # Muito baixo
        )
    
    with pytest.raises(ValidationError):
        WebhookCall(
            integration_id=uuid4(),
            status_code=600  # Muito alto
        )
    
    # Tempo de execução negativo
    with pytest.raises(ValidationError):
        WebhookCall(
            integration_id=uuid4(),
            execution_time_ms=-1
        )
    
    # IP inválido
    with pytest.raises(ValidationError):
        WebhookCall(
            integration_id=uuid4(),
            ip_address="invalid.ip"
        )


def test_integration_stats():
    """Testa IntegrationStats e seus cálculos."""
    stats = IntegrationStats(
        integration_id=uuid4(),
        total_calls=100,
        successful_calls=80,
        failed_calls=20
    )
    
    assert stats.total_calls == 100
    assert stats.successful_calls == 80
    assert stats.failed_calls == 20
    assert stats.success_rate == 80.0
    assert stats.error_rate == 20.0
    
    # Teste com zero chamadas
    empty_stats = IntegrationStats(
        integration_id=uuid4(),
        total_calls=0,
        successful_calls=0,
        failed_calls=0
    )
    
    assert empty_stats.success_rate == 0.0
    assert empty_stats.error_rate == 0.0


def test_integration_channels():
    """Testa os canais de integração disponíveis."""
    channels = [
        IntegrationChannel.WHATSAPP,
        IntegrationChannel.ZAPIER,
        IntegrationChannel.N8N,
        IntegrationChannel.TELEGRAM,
        IntegrationChannel.CUSTOM
    ]
    
    for i, channel in enumerate(channels):
        integration = AgentIntegration(
            agent_id=uuid4(),
            client_id=uuid4(),
            channel=channel,
            webhook_token="whk_" + "a" * 32 + str(i)  # Garantir 36+ caracteres
        )
        assert integration.channel == channel


def test_integration_status():
    """Testa os status de integração disponíveis."""
    statuses = [
        IntegrationStatus.ACTIVE,
        IntegrationStatus.INACTIVE
    ]
    
    for i, status in enumerate(statuses):
        integration = AgentIntegration(
            agent_id=uuid4(),
            client_id=uuid4(),
            channel=IntegrationChannel.CUSTOM,
            webhook_token="whk_" + "b" * 32 + str(i),  # Garantir 36+ caracteres
            status=status
        )
        assert integration.status == status


if __name__ == "__main__":
    # Executar testes básicos
    print("Executando testes dos modelos de integração...")
    
    try:
        test_agent_integration_creation()
        print("✓ Teste de criação de AgentIntegration passou")
        
        test_webhook_token_validation()
        print("✓ Teste de validação de token passou")
        
        test_rate_limit_validation()
        print("✓ Teste de validação de rate limit passou")
        
        test_webhook_call_creation()
        print("✓ Teste de criação de WebhookCall passou")
        
        test_webhook_call_validations()
        print("✓ Teste de validações de WebhookCall passou")
        
        test_integration_stats()
        print("✓ Teste de IntegrationStats passou")
        
        test_integration_channels()
        print("✓ Teste de canais de integração passou")
        
        test_integration_status()
        print("✓ Teste de status de integração passou")
        
        print("\n🎉 Todos os testes passaram com sucesso!")
        
    except Exception as e:
        print(f"\n❌ Erro nos testes: {e}")
        import traceback
        traceback.print_exc()