"""
Teste isolado para monitoramento e analytics de integrações.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import asyncio
from uuid import uuid4
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock
from enum import Enum


class IntegrationStatus(str, Enum):
    """Status de integração."""
    ACTIVE = "active"
    INACTIVE = "inactive"


class IntegrationChannel(str, Enum):
    """Canais de integração."""
    WHATSAPP = "whatsapp"
    ZAPIER = "zapier"
    N8N = "n8n"


class MockIntegrationResponse:
    """Mock de resposta de integração."""
    
    def __init__(self, id, agent_id, client_id, channel, status):
        self.id = id
        self.agent_id = agent_id
        self.client_id = client_id
        self.channel = channel
        self.status = status


class MockAnalyticsService:
    """Mock do serviço de analytics."""
    
    def __init__(self):
        self.integrations = {}
        self.webhook_calls = []
    
    def add_integration(self, integration_id, client_id, integration):
        """Adiciona integração ao mock."""
        key = f"{integration_id}_{client_id}"
        self.integrations[key] = integration
    
    def add_webhook_call(self, integration_id, status_code, execution_time_ms, created_at, error_message=None):
        """Adiciona chamada webhook ao mock."""
        call = {
            "id": str(uuid4()),
            "integration_id": str(integration_id),
            "status_code": status_code,
            "execution_time_ms": execution_time_ms,
            "ip_address": "192.168.1.1",
            "user_agent": "TestAgent/1.0",
            "error_message": error_message,
            "created_at": created_at.isoformat(),
            "has_request_payload": True,
            "has_response_payload": True
        }
        self.webhook_calls.append(call)
    
    async def get_integration(self, integration_id, client_id):
        """Mock de obtenção de integração."""
        key = f"{integration_id}_{client_id}"
        return self.integrations.get(key)
    
    async def get_webhook_calls(self, integration_id, client_id, limit=50, offset=0, 
                               status_code=None, start_date=None, end_date=None):
        """Mock de obtenção de chamadas webhook."""
        # Verificar se integração existe
        if not await self.get_integration(integration_id, client_id):
            return []
        
        # Filtrar chamadas
        filtered_calls = []
        for call in self.webhook_calls:
            if call["integration_id"] != str(integration_id):
                continue
            
            if status_code and call["status_code"] != status_code:
                continue
            
            call_date = datetime.fromisoformat(call["created_at"])
            
            if start_date and call_date < start_date:
                continue
            
            if end_date and call_date > end_date:
                continue
            
            filtered_calls.append(call)
        
        # Aplicar paginação
        return filtered_calls[offset:offset + limit]
    
    async def get_integration_analytics(self, integration_id, client_id, period_hours=24):
        """Mock de analytics de integração."""
        # Verificar se integração existe
        if not await self.get_integration(integration_id, client_id):
            return {}
        
        # Filtrar chamadas do período
        cutoff_time = datetime.now() - timedelta(hours=period_hours)
        period_calls = []
        
        for call in self.webhook_calls:
            if call["integration_id"] != str(integration_id):
                continue
            
            call_date = datetime.fromisoformat(call["created_at"])
            if call_date >= cutoff_time:
                period_calls.append(call)
        
        # Calcular estatísticas
        total_calls = len(period_calls)
        successful_calls = len([c for c in period_calls if 200 <= c["status_code"] < 300])
        failed_calls = total_calls - successful_calls
        
        success_rate = (successful_calls / max(total_calls, 1)) * 100
        error_rate = (failed_calls / max(total_calls, 1)) * 100
        
        execution_times = [c["execution_time_ms"] for c in period_calls if c["execution_time_ms"]]
        avg_execution_time = sum(execution_times) / len(execution_times) if execution_times else None
        
        last_call_at = max([c["created_at"] for c in period_calls]) if period_calls else None
        
        # Distribuição por status
        status_distribution = {}
        for call in period_calls:
            status = str(call["status_code"])
            status_distribution[status] = status_distribution.get(status, 0) + 1
        
        # Distribuição horária (simplificada)
        hourly_distribution = []
        for hour in range(min(24, period_hours)):
            hour_calls = len([c for c in period_calls if 
                            datetime.fromisoformat(c["created_at"]).hour == (datetime.now().hour - hour) % 24])
            hourly_distribution.append({
                "hour": f"{(datetime.now().hour - hour) % 24:02d}:00",
                "calls": hour_calls
            })
        
        # Tipos de erro
        error_types = {}
        for call in period_calls:
            if call["error_message"]:
                error_key = call["error_message"][:50] + "..." if len(call["error_message"]) > 50 else call["error_message"]
                error_types[error_key] = error_types.get(error_key, 0) + 1
        
        return {
            "integration_id": str(integration_id),
            "period_hours": period_hours,
            "total_calls": total_calls,
            "successful_calls": successful_calls,
            "failed_calls": failed_calls,
            "success_rate": success_rate,
            "error_rate": error_rate,
            "avg_execution_time_ms": avg_execution_time,
            "last_call_at": last_call_at,
            "status_distribution": status_distribution,
            "hourly_distribution": hourly_distribution,
            "error_types": error_types,
            "generated_at": datetime.now().isoformat()
        }
    
    async def list_integrations(self, client_id, limit=1000):
        """Mock de listagem de integrações."""
        client_integrations = []
        for key, integration in self.integrations.items():
            if key.endswith(f"_{client_id}"):
                client_integrations.append(integration)
        return client_integrations
    
    async def get_client_analytics_summary(self, client_id, period_hours=24):
        """Mock de resumo de analytics do cliente."""
        integrations = await self.list_integrations(client_id)
        
        if not integrations:
            return {
                "client_id": str(client_id),
                "period_hours": period_hours,
                "total_integrations": 0,
                "active_integrations": 0,
                "total_calls": 0,
                "successful_calls": 0,
                "failed_calls": 0,
                "success_rate": 0.0,
                "avg_execution_time_ms": None,
                "top_integrations": [],
                "channel_distribution": {},
                "generated_at": datetime.now().isoformat()
            }
        
        # Calcular estatísticas agregadas
        total_calls = 0
        successful_calls = 0
        failed_calls = 0
        execution_times = []
        channel_distribution = {}
        integration_stats = []
        
        for integration in integrations:
            # Contar por canal
            channel = integration.channel.value
            channel_distribution[channel] = channel_distribution.get(channel, 0) + 1
            
            # Obter analytics da integração
            analytics = await self.get_integration_analytics(
                integration.id, client_id, period_hours
            )
            
            if analytics:
                integration_total = analytics["total_calls"]
                integration_successful = analytics["successful_calls"]
                integration_failed = analytics["failed_calls"]
                integration_avg_time = analytics["avg_execution_time_ms"]
                
                total_calls += integration_total
                successful_calls += integration_successful
                failed_calls += integration_failed
                
                if integration_avg_time:
                    execution_times.append(integration_avg_time)
                
                integration_stats.append({
                    "integration_id": str(integration.id),
                    "agent_id": str(integration.agent_id),
                    "channel": channel,
                    "total_calls": integration_total,
                    "success_rate": analytics["success_rate"]
                })
        
        # Calcular médias
        success_rate = (successful_calls / max(total_calls, 1)) * 100
        avg_execution_time = sum(execution_times) / len(execution_times) if execution_times else None
        
        # Top integrações
        top_integrations = sorted(
            integration_stats,
            key=lambda x: x["total_calls"],
            reverse=True
        )[:5]
        
        return {
            "client_id": str(client_id),
            "period_hours": period_hours,
            "total_integrations": len(integrations),
            "active_integrations": len([i for i in integrations if i.status == IntegrationStatus.ACTIVE]),
            "total_calls": total_calls,
            "successful_calls": successful_calls,
            "failed_calls": failed_calls,
            "success_rate": success_rate,
            "avg_execution_time_ms": avg_execution_time,
            "top_integrations": top_integrations,
            "channel_distribution": channel_distribution,
            "generated_at": datetime.now().isoformat()
        }


async def test_webhook_calls_history():
    """Testa obtenção de histórico de chamadas webhook."""
    print("Testando histórico de chamadas webhook...")
    
    service = MockAnalyticsService()
    
    # Criar integração
    integration_id = uuid4()
    client_id = uuid4()
    
    integration = MockIntegrationResponse(
        id=integration_id,
        agent_id=uuid4(),
        client_id=client_id,
        channel=IntegrationChannel.WHATSAPP,
        status=IntegrationStatus.ACTIVE
    )
    
    service.add_integration(integration_id, client_id, integration)
    
    # Adicionar chamadas webhook
    now = datetime.now()
    
    # Chamadas bem-sucedidas
    service.add_webhook_call(integration_id, 200, 150, now - timedelta(minutes=10))
    service.add_webhook_call(integration_id, 200, 200, now - timedelta(minutes=20))
    
    # Chamadas com erro
    service.add_webhook_call(integration_id, 500, 300, now - timedelta(minutes=30), "Internal server error")
    service.add_webhook_call(integration_id, 429, 50, now - timedelta(minutes=40), "Rate limit exceeded")
    
    # Obter todas as chamadas
    all_calls = await service.get_webhook_calls(
        integration_id=integration_id,
        client_id=client_id,
        limit=10
    )
    
    assert len(all_calls) == 4
    assert all(call["integration_id"] == str(integration_id) for call in all_calls)
    
    # Filtrar por status code
    success_calls = await service.get_webhook_calls(
        integration_id=integration_id,
        client_id=client_id,
        status_code=200
    )
    
    assert len(success_calls) == 2
    assert all(call["status_code"] == 200 for call in success_calls)
    
    # Filtrar por data
    recent_calls = await service.get_webhook_calls(
        integration_id=integration_id,
        client_id=client_id,
        start_date=now - timedelta(minutes=25)
    )
    
    assert len(recent_calls) == 2  # Últimas 25 minutos
    
    print("✓ Histórico de chamadas webhook funcionou")


async def test_integration_analytics():
    """Testa analytics de integração."""
    print("Testando analytics de integração...")
    
    service = MockAnalyticsService()
    
    # Criar integração
    integration_id = uuid4()
    client_id = uuid4()
    
    integration = MockIntegrationResponse(
        id=integration_id,
        agent_id=uuid4(),
        client_id=client_id,
        channel=IntegrationChannel.ZAPIER,
        status=IntegrationStatus.ACTIVE
    )
    
    service.add_integration(integration_id, client_id, integration)
    
    # Adicionar chamadas variadas
    now = datetime.now()
    
    # 8 chamadas bem-sucedidas
    for i in range(8):
        service.add_webhook_call(
            integration_id, 
            200, 
            100 + i * 10, 
            now - timedelta(minutes=i * 5)
        )
    
    # 2 chamadas com erro
    service.add_webhook_call(integration_id, 500, 200, now - timedelta(minutes=45), "Database error")
    service.add_webhook_call(integration_id, 429, 50, now - timedelta(minutes=50), "Rate limit")
    
    # Obter analytics
    analytics = await service.get_integration_analytics(
        integration_id=integration_id,
        client_id=client_id,
        period_hours=1
    )
    
    # Verificar estatísticas básicas
    assert analytics["integration_id"] == str(integration_id)
    assert analytics["total_calls"] == 10
    assert analytics["successful_calls"] == 8
    assert analytics["failed_calls"] == 2
    assert analytics["success_rate"] == 80.0
    assert analytics["error_rate"] == 20.0
    assert analytics["avg_execution_time_ms"] is not None
    
    # Verificar distribuições
    assert "status_distribution" in analytics
    assert "200" in analytics["status_distribution"]
    assert analytics["status_distribution"]["200"] == 8
    
    assert "hourly_distribution" in analytics
    assert len(analytics["hourly_distribution"]) > 0
    
    assert "error_types" in analytics
    assert len(analytics["error_types"]) == 2
    
    print("✓ Analytics de integração funcionaram")


async def test_client_analytics_summary():
    """Testa resumo de analytics do cliente."""
    print("Testando resumo de analytics do cliente...")
    
    service = MockAnalyticsService()
    client_id = uuid4()
    
    # Criar múltiplas integrações
    integrations_data = [
        (IntegrationChannel.WHATSAPP, IntegrationStatus.ACTIVE),
        (IntegrationChannel.ZAPIER, IntegrationStatus.ACTIVE),
        (IntegrationChannel.N8N, IntegrationStatus.INACTIVE)
    ]
    
    integration_ids = []
    
    for channel, status in integrations_data:
        integration_id = uuid4()
        integration_ids.append(integration_id)
        
        integration = MockIntegrationResponse(
            id=integration_id,
            agent_id=uuid4(),
            client_id=client_id,
            channel=channel,
            status=status
        )
        
        service.add_integration(integration_id, client_id, integration)
        
        # Adicionar chamadas para integrações ativas
        if status == IntegrationStatus.ACTIVE:
            now = datetime.now()
            for i in range(5):
                service.add_webhook_call(
                    integration_id,
                    200 if i < 4 else 500,  # 4 sucessos, 1 erro
                    100 + i * 20,
                    now - timedelta(minutes=i * 10)
                )
    
    # Obter resumo
    summary = await service.get_client_analytics_summary(
        client_id=client_id,
        period_hours=24
    )
    
    # Verificar estatísticas agregadas
    assert summary["client_id"] == str(client_id)
    assert summary["total_integrations"] == 3
    assert summary["active_integrations"] == 2
    assert summary["total_calls"] == 10  # 5 chamadas x 2 integrações ativas
    assert summary["successful_calls"] == 8  # 4 sucessos x 2 integrações
    assert summary["failed_calls"] == 2  # 1 erro x 2 integrações
    assert summary["success_rate"] == 80.0
    
    # Verificar distribuição por canal
    assert "channel_distribution" in summary
    assert summary["channel_distribution"]["whatsapp"] == 1
    assert summary["channel_distribution"]["zapier"] == 1
    assert summary["channel_distribution"]["n8n"] == 1
    
    # Verificar top integrações
    assert "top_integrations" in summary
    # Pode ter menos integrações se algumas não tiveram chamadas
    assert len(summary["top_integrations"]) <= 3  # Máximo 3 integrações criadas
    
    print("✓ Resumo de analytics do cliente funcionou")


async def test_integration_health_check():
    """Testa verificação de saúde da integração."""
    print("Testando verificação de saúde da integração...")
    
    service = MockAnalyticsService()
    
    # Integração saudável
    healthy_id = uuid4()
    client_id = uuid4()
    
    healthy_integration = MockIntegrationResponse(
        id=healthy_id,
        agent_id=uuid4(),
        client_id=client_id,
        channel=IntegrationChannel.WHATSAPP,
        status=IntegrationStatus.ACTIVE
    )
    
    service.add_integration(healthy_id, client_id, healthy_integration)
    
    # Adicionar chamadas recentes bem-sucedidas
    now = datetime.now()
    for i in range(5):
        service.add_webhook_call(
            healthy_id,
            200,
            100 + i * 10,
            now - timedelta(minutes=i * 5)
        )
    
    # Simular verificação de saúde
    analytics = await service.get_integration_analytics(
        healthy_id, client_id, period_hours=1
    )
    
    health_status = "healthy"
    issues = []
    
    if healthy_integration.status != IntegrationStatus.ACTIVE:
        health_status = "inactive"
        issues.append("Integração está inativa")
    
    if analytics.get("error_rate", 0) > 50:
        health_status = "degraded"
        issues.append(f"Taxa de erro alta: {analytics['error_rate']:.1f}%")
    
    if analytics.get("total_calls", 0) == 0:
        health_status = "warning"
        issues.append("Nenhuma chamada recente")
    
    # Verificar saúde
    assert health_status == "healthy"
    assert len(issues) == 0
    assert analytics["success_rate"] == 100.0
    
    print("✓ Integração saudável identificada")
    
    # Integração com problemas
    problematic_id = uuid4()
    
    problematic_integration = MockIntegrationResponse(
        id=problematic_id,
        agent_id=uuid4(),
        client_id=client_id,
        channel=IntegrationChannel.ZAPIER,
        status=IntegrationStatus.ACTIVE
    )
    
    service.add_integration(problematic_id, client_id, problematic_integration)
    
    # Adicionar chamadas com muitos erros
    for i in range(10):
        status_code = 500 if i < 8 else 200  # 80% de erro
        service.add_webhook_call(
            problematic_id,
            status_code,
            200,
            now - timedelta(minutes=i * 2),
            "Server error" if status_code == 500 else None
        )
    
    # Verificar saúde problemática
    problematic_analytics = await service.get_integration_analytics(
        problematic_id, client_id, period_hours=1
    )
    
    problematic_health = "healthy"
    problematic_issues = []
    
    if problematic_analytics.get("error_rate", 0) > 50:
        problematic_health = "degraded"
        problematic_issues.append(f"Taxa de erro alta: {problematic_analytics['error_rate']:.1f}%")
    
    assert problematic_health == "degraded"
    assert len(problematic_issues) > 0
    assert "Taxa de erro alta" in problematic_issues[0]
    
    print("✓ Integração problemática identificada")


async def test_analytics_empty_data():
    """Testa analytics com dados vazios."""
    print("Testando analytics com dados vazios...")
    
    service = MockAnalyticsService()
    
    # Integração sem chamadas
    integration_id = uuid4()
    client_id = uuid4()
    
    integration = MockIntegrationResponse(
        id=integration_id,
        agent_id=uuid4(),
        client_id=client_id,
        channel=IntegrationChannel.N8N,
        status=IntegrationStatus.ACTIVE
    )
    
    service.add_integration(integration_id, client_id, integration)
    
    # Obter analytics sem dados
    analytics = await service.get_integration_analytics(
        integration_id=integration_id,
        client_id=client_id,
        period_hours=24
    )
    
    # Verificar valores padrão
    assert analytics["total_calls"] == 0
    assert analytics["successful_calls"] == 0
    assert analytics["failed_calls"] == 0
    assert analytics["success_rate"] == 0.0
    assert analytics["error_rate"] == 0.0
    assert analytics["avg_execution_time_ms"] is None
    assert analytics["last_call_at"] is None
    assert len(analytics["status_distribution"]) == 0
    assert len(analytics["error_types"]) == 0
    
    print("✓ Analytics com dados vazios funcionaram")


async def run_all_tests():
    """Executa todos os testes de monitoramento e analytics."""
    await test_webhook_calls_history()
    await test_integration_analytics()
    await test_client_analytics_summary()
    await test_integration_health_check()
    await test_analytics_empty_data()


if __name__ == "__main__":
    print("=" * 50)
    print("TESTE DE MONITORAMENTO E ANALYTICS")
    print("=" * 50)
    
    try:
        asyncio.run(run_all_tests())
        print("\n🎉 Todos os testes de monitoramento e analytics passaram!")
        print("✅ Sub-tarefa 4.3 - Monitoring and analytics implementados")
        print("💡 Sistema completo de monitoramento funcionando")
        
    except Exception as e:
        print(f"\n❌ Erro nos testes: {e}")
        import traceback
        traceback.print_exc()