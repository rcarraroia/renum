"""
Testes para validar a correção da inicialização do notification_service.
"""

import pytest
import asyncio
from unittest.mock import Mock, patch

from app.services.notification_service import notification_service, get_notification_service, NotificationService
from app.services.websocket_manager import websocket_manager


class TestNotificationServiceInitialization:
    """Testes de inicialização do serviço de notificações"""

    def test_notification_service_not_none(self):
        """Testa se o notification_service não é None após importação"""
        assert notification_service is not None
        assert isinstance(notification_service, NotificationService)

    def test_get_notification_service_returns_instance(self):
        """Testa se get_notification_service retorna a instância correta"""
        service = get_notification_service()
        assert service is not None
        assert isinstance(service, NotificationService)
        assert service is notification_service  # Deve ser a mesma instância

    def test_websocket_manager_assignment(self):
        """Testa se o websocket_manager pode ser atribuído corretamente"""
        # Salva o estado original
        original_websocket_manager = notification_service.websocket_manager
        
        try:
            # Testa atribuição
            notification_service.websocket_manager = websocket_manager
            assert notification_service.websocket_manager is not None
            assert notification_service.websocket_manager is websocket_manager
            
        finally:
            # Restaura o estado original
            notification_service.websocket_manager = original_websocket_manager

    @pytest.mark.asyncio
    async def test_service_initialization_without_websocket_manager(self):
        """Testa se o serviço pode ser inicializado sem websocket_manager"""
        # Cria uma nova instância para teste
        test_service = NotificationService()
        
        # Mock do repositório para evitar dependências externas
        with patch.object(test_service, '_get_repository') as mock_repo:
            mock_repository = Mock()
            mock_repository.create_tables = Mock(return_value=asyncio.Future())
            mock_repository.create_tables.return_value.set_result(None)
            mock_repo.return_value = mock_repository
            
            # Deve inicializar sem erro mesmo sem websocket_manager
            await test_service.initialize()
            
            # Verifica se o repositório foi inicializado
            mock_repo.assert_called_once()
            mock_repository.create_tables.assert_called_once()

    @pytest.mark.asyncio
    async def test_service_initialization_with_websocket_manager(self):
        """Testa se o serviço pode ser inicializado com websocket_manager"""
        # Cria uma nova instância para teste
        test_service = NotificationService(websocket_manager=websocket_manager)
        
        # Mock do repositório para evitar dependências externas
        with patch.object(test_service, '_get_repository') as mock_repo:
            mock_repository = Mock()
            mock_repository.create_tables = Mock(return_value=asyncio.Future())
            mock_repository.create_tables.return_value.set_result(None)
            mock_repo.return_value = mock_repository
            
            # Deve inicializar sem erro com websocket_manager
            await test_service.initialize()
            
            # Verifica se o websocket_manager foi configurado
            assert test_service.websocket_manager is websocket_manager
            
            # Verifica se o repositório foi inicializado
            mock_repo.assert_called_once()
            mock_repository.create_tables.assert_called_once()

    def test_service_constructor_logging(self):
        """Testa se o construtor registra logs adequadamente"""
        with patch('app.services.notification_service.logger') as mock_logger:
            # Cria nova instância
            test_service = NotificationService()
            
            # Verifica se o log foi registrado
            mock_logger.info.assert_called_with("NotificationService created with websocket_manager: False")
            
            # Testa com websocket_manager
            test_service_with_ws = NotificationService(websocket_manager=websocket_manager)
            mock_logger.info.assert_called_with("NotificationService created with websocket_manager: True")

    @pytest.mark.asyncio
    async def test_service_graceful_degradation(self):
        """Testa se o serviço funciona em modo degradado sem websocket_manager"""
        # Cria uma nova instância sem websocket_manager
        test_service = NotificationService()
        
        # Mock de uma notificação
        mock_notification = Mock()
        mock_notification.id = "test-id"
        mock_notification.user_id = "test-user"
        mock_notification.dict.return_value = {"id": "test-id", "message": "test"}
        
        # Deve funcionar sem erro mesmo sem websocket_manager
        await test_service._send_websocket_notification(mock_notification)
        
        # Deve funcionar sem erro para updates também
        await test_service._send_websocket_update("test-user", {"type": "test"})


if __name__ == "__main__":
    pytest.main([__file__])