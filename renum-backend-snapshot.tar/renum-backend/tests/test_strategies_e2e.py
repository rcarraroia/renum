"""
Testes end-to-end para as estratégias de execução de equipes.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID, uuid4

from app.services.execution_engine import ExecutionEngine
from app.models.team_models import (
    WorkflowDefinition,
    WorkflowType,
    WorkflowAgent,
    AgentRole,
    InputSource,
    AgentCondition,
    ExecutionStatus
)


@pytest.mark.asyncio
async def test_sequential_strategy_e2e():
    """Teste end-to-end da estratégia sequencial."""
    # Arrange
    execution_repository = AsyncMock()
    suna_client = AsyncMock()
    context_manager = AsyncMock()
    message_bus = AsyncMock()
    api_key_manager = AsyncMock()
    
    # Mock das respostas do Suna
    suna_client.execute_individual_agent.side_effect = [
        {"success": True, "output": {"result": "Agent 1 result"}},
        {"success": True, "output": {"result": "Agent 2 result"}},
        {"success": True, "output": {"result": "Agent 3 result"}}
    ]
    
    engine = ExecutionEngine(
        execution_repository,
        suna_client,
        context_manager,
        message_bus,
        api_key_manager
    )
    
    workflow = WorkflowDefinition(
        type=WorkflowType.SEQUENTIAL,
        agents=[
            WorkflowAgent(
                agent_id="agent1",
                role=AgentRole.LEADER,
                execution_order=1,
                input=InputSource(source="initial_prompt")
            ),
            WorkflowAgent(
                agent_id="agent2",
                role=AgentRole.MEMBER,
                execution_order=2,
                input=InputSource(source="agent_result", agent_id="agent1")
            ),
            WorkflowAgent(
                agent_id="agent3",
                role=AgentRole.MEMBER,
                execution_order=3,
                input=InputSource(source="agent_result", agent_id="agent2")
            )
        ]
    )
    
    execution_id = uuid4()
    
    # Act
    plan = await engine.create_execution_plan(
        workflow,
        ["agent1", "agent2", "agent3"],
        execution_id,
        {}
    )
    
    # Assert
    assert plan is not None
    assert plan.strategy == WorkflowType.SEQUENTIAL
    assert len(plan.steps) == 3


@pytest.mark.asyncio
async def test_parallel_strategy_e2e():
    """Teste end-to-end da estratégia paralela."""
    # Arrange
    execution_repository = AsyncMock()
    suna_client = AsyncMock()
    context_manager = AsyncMock()
    message_bus = AsyncMock()
    api_key_manager = AsyncMock()
    
    # Mock das respostas do Suna
    suna_client.execute_individual_agent.side_effect = [
        {"success": True, "output": {"result": "Agent 1 result"}},
        {"success": True, "output": {"result": "Agent 2 result"}},
        {"success": True, "output": {"result": "Agent 3 result"}}
    ]
    
    engine = ExecutionEngine(
        execution_repository,
        suna_client,
        context_manager,
        message_bus,
        api_key_manager
    )
    
    workflow = WorkflowDefinition(
        type=WorkflowType.PARALLEL,
        agents=[
            WorkflowAgent(
                agent_id="agent1",
                role=AgentRole.MEMBER,
                input=InputSource(source="initial_prompt")
            ),
            WorkflowAgent(
                agent_id="agent2",
                role=AgentRole.MEMBER,
                input=InputSource(source="initial_prompt")
            ),
            WorkflowAgent(
                agent_id="agent3",
                role=AgentRole.MEMBER,
                input=InputSource(source="initial_prompt")
            )
        ]
    )
    
    execution_id = uuid4()
    
    # Act
    plan = await engine.create_execution_plan(
        workflow,
        ["agent1", "agent2", "agent3"],
        execution_id,
        {}
    )
    
    # Assert
    assert plan is not None
    assert plan.strategy == WorkflowType.PARALLEL
    assert len(plan.steps) == 3
    
    # Em paralelo, nenhum step deve ter dependências
    for step in plan.steps:
        assert len(step.dependencies) == 0


@pytest.mark.asyncio
async def test_pipeline_strategy_e2e():
    """Teste end-to-end da estratégia pipeline."""
    # Arrange
    execution_repository = AsyncMock()
    suna_client = AsyncMock()
    context_manager = AsyncMock()
    message_bus = AsyncMock()
    api_key_manager = AsyncMock()
    
    engine = ExecutionEngine(
        execution_repository,
        suna_client,
        context_manager,
        message_bus,
        api_key_manager
    )
    
    workflow = WorkflowDefinition(
        type=WorkflowType.PIPELINE,
        agents=[
            WorkflowAgent(
                agent_id="agent1",
                role=AgentRole.MEMBER,
                execution_order=1,
                input=InputSource(source="initial_prompt")
            ),
            WorkflowAgent(
                agent_id="agent2",
                role=AgentRole.MEMBER,
                execution_order=2,
                input=InputSource(source="agent_result", agent_id="agent1")
            ),
            WorkflowAgent(
                agent_id="agent3",
                role=AgentRole.MEMBER,
                execution_order=3,
                input=InputSource(source="agent_result", agent_id="agent2")
            )
        ]
    )
    
    execution_id = uuid4()
    
    # Act
    plan = await engine.create_execution_plan(
        workflow,
        ["agent1", "agent2", "agent3"],
        execution_id,
        {}
    )
    
    # Assert
    assert plan is not None
    assert plan.strategy == WorkflowType.PIPELINE
    assert len(plan.steps) == 3