"""
Testes para o cliente Supabase centralizado.
"""

import os
import sys
import unittest
import logging
from unittest.mock import patch, MagicMock

# Adicionar o diretório pai ao path para importar módulos
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from app.core.supabase_client import SupabaseClient

# Configurar logging para os testes
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TestSupabaseClient(unittest.TestCase):
    """Testes para o cliente Supabase centralizado."""
    
    def setUp(self):
        """Configuração para os testes."""
        self.supabase = SupabaseClient.get_instance()
    
    def test_singleton_pattern(self):
        """Testa se o padrão Singleton está funcionando corretamente."""
        client1 = SupabaseClient.get_instance()
        client2 = SupabaseClient.get_instance()
        self.assertIs(client1, client2, "Singleton pattern não está funcionando")
    
    def test_client_initialization(self):
        """Testa se o cliente foi inicializado corretamente."""
        self.assertIsNotNone(self.supabase.client, "Cliente Supabase não foi inicializado")
        self.assertIsNotNone(self.supabase.admin_client, "Cliente Supabase Admin não foi inicializado")
    
    def test_table_access(self):
        """Testa o acesso às tabelas via API REST."""
        try:
            # Tentar acessar a tabela knowledge_bases
            result = self.supabase.from_("knowledge_bases", use_admin=True).select("*")
            logger.info(f"Acesso à tabela knowledge_bases: ✅ Sucesso")
            logger.info(f"  - Registros encontrados: {len(result.data) if result.data else 0}")
            self.assertIsNotNone(result)
        except Exception as e:
            logger.error(f"Erro ao acessar tabela knowledge_bases: {e}")
    
    def test_crud_operations(self):
        """Testa operações CRUD básicas."""
        # Testar método read
        try:
            result = self.supabase.from_("knowledge_bases", use_admin=True).select("*")
            logger.info(f"Leitura de knowledge_bases: ✅ Sucesso")
            logger.info(f"  - Registros encontrados: {len(result.data) if result.data else 0}")
            self.assertIsNotNone(result)
        except Exception as e:
            logger.error(f"Erro ao acessar tabela knowledge_bases: {str(e)}")
    
    def test_check_rag_tables(self):
        """Testa acesso às tabelas RAG."""
        rag_tables = [
            "knowledge_bases",
            "knowledge_collections",
            "documents",
            "document_chunks",
            "document_embeddings",
            "document_usage_stats",
            "retrieval_feedback",
            "processing_jobs"
        ]
        
        for table in rag_tables:
            try:
                result = self.supabase.from_(table, use_admin=True).select("*").limit(1)
                logger.info(f"Tabela {table}: ✅ Acessível")
            except Exception as e:
                logger.warning(f"Tabela {table}: ⚠️ Erro - {str(e)}")


if __name__ == '__main__':
    unittest.main()