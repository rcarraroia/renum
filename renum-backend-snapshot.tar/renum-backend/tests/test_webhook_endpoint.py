"""
Testes para o endpoint de webhook.

Este módulo testa o endpoint principal de webhook que recebe chamadas
de sistemas externos.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4
from fastapi.testclient import TestClient
from fastapi import FastAPI

# Importar o router de webhooks
from app.api.routes.webhooks import router as webhook_router


def create_test_app():
    """Cria uma aplicação FastAPI para testes."""
    app = FastAPI()
    app.include_router(webhook_router)
    return app


def test_webhook_endpoint_missing_token():
    """Testa webhook sem token de autorização."""
    app = create_test_app()
    client = TestClient(app)
    
    agent_id = str(uuid4())
    payload = {"message": "test"}
    
    response = client.post(f"/webhook/{agent_id}", json=payload)
    
    assert response.status_code == 401
    data = response.json()
    assert data["success"] is False
    assert "Token Bearer requerido" in data["error"]
    assert data["code"] == "MISSING_TOKEN"


def test_webhook_endpoint_invalid_token_format():
    """Testa webhook com formato de token inválido."""
    app = create_test_app()
    client = TestClient(app)
    
    agent_id = str(uuid4())
    payload = {"message": "test"}
    headers = {"Authorization": "InvalidFormat token123"}
    
    response = client.post(f"/webhook/{agent_id}", json=payload, headers=headers)
    
    assert response.status_code == 401
    data = response.json()
    assert data["success"] is False
    assert "Bearer" in data["error"]
    assert data["code"] == "INVALID_TOKEN_FORMAT"


def test_webhook_endpoint_success():
    """Testa webhook bem-sucedido."""
    app = create_test_app()
    client = TestClient(app)
    
    # Mock do serviço de webhook
    mock_service = MagicMock()
    mock_service.process_webhook_call = AsyncMock(return_value={
        "success": True,
        "data": {"response": "Hello from agent"},
        "execution_time_ms": 150
    })
    
    with patch('app.api.routes.webhooks.get_webhook_service', return_value=mock_service):
        agent_id = str(uuid4())
        payload = {"message": "test"}
        headers = {"Authorization": "Bearer whk_valid_token_here"}
        
        response = client.post(f"/webhook/{agent_id}", json=payload, headers=headers)
        
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert data["data"]["response"] == "Hello from agent"
        assert data["execution_time_ms"] == 150


def test_webhook_endpoint_invalid_token():
    """Testa webhook com token inválido."""
    app = create_test_app()
    client = TestClient(app)
    
    # Mock do serviço que levanta ValueError para token inválido
    mock_service = MagicMock()
    mock_service.process_webhook_call = AsyncMock(
        side_effect=ValueError("Token inválido ou agente não autorizado")
    )
    
    with patch('app.api.routes.webhooks.get_webhook_service', return_value=mock_service):
        agent_id = str(uuid4())
        payload = {"message": "test"}
        headers = {"Authorization": "Bearer whk_invalid_token"}
        
        response = client.post(f"/webhook/{agent_id}", json=payload, headers=headers)
        
        assert response.status_code == 403
        data = response.json()
        assert data["success"] is False
        assert "Token inválido" in data["error"]
        assert data["code"] == "INVALID_TOKEN"


def test_webhook_endpoint_rate_limit():
    """Testa webhook com rate limit excedido."""
    app = create_test_app()
    client = TestClient(app)
    
    # Mock do serviço que levanta PermissionError para rate limit
    mock_service = MagicMock()
    mock_service.process_webhook_call = AsyncMock(
        side_effect=PermissionError("Rate limit excedido")
    )
    
    with patch('app.api.routes.webhooks.get_webhook_service', return_value=mock_service):
        agent_id = str(uuid4())
        payload = {"message": "test"}
        headers = {"Authorization": "Bearer whk_valid_token"}
        
        response = client.post(f"/webhook/{agent_id}", json=payload, headers=headers)
        
        assert response.status_code == 429
        data = response.json()
        assert data["success"] is False
        assert "Rate limit excedido" in data["error"]
        assert data["code"] == "RATE_LIMIT_EXCEEDED"
        assert data["details"]["retry_after"] == 60


def test_webhook_endpoint_internal_error():
    """Testa webhook com erro interno."""
    app = create_test_app()
    client = TestClient(app)
    
    # Mock do serviço que levanta Exception genérica
    mock_service = MagicMock()
    mock_service.process_webhook_call = AsyncMock(
        side_effect=Exception("Database connection failed")
    )
    
    with patch('app.api.routes.webhooks.get_webhook_service', return_value=mock_service):
        agent_id = str(uuid4())
        payload = {"message": "test"}
        headers = {"Authorization": "Bearer whk_valid_token"}
        
        response = client.post(f"/webhook/{agent_id}", json=payload, headers=headers)
        
        assert response.status_code == 500
        data = response.json()
        assert data["success"] is False
        assert "Erro interno do servidor" in data["error"]
        assert data["code"] == "INTERNAL_ERROR"


def test_webhook_health_check():
    """Testa endpoint de health check."""
    app = create_test_app()
    client = TestClient(app)
    
    agent_id = str(uuid4())
    
    response = client.get(f"/webhook/{agent_id}/health")
    
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["agent_id"] == agent_id
    assert "timestamp" in data
    assert "funcionando" in data["message"]


def test_webhook_options():
    """Testa endpoint OPTIONS para CORS."""
    app = create_test_app()
    client = TestClient(app)
    
    agent_id = str(uuid4())
    
    response = client.options(f"/webhook/{agent_id}")
    
    assert response.status_code == 200
    data = response.json()
    assert "POST" in data["methods"]
    assert "OPTIONS" in data["methods"]
    
    # Verificar headers CORS
    headers = response.headers
    assert "Access-Control-Allow-Origin" in headers
    assert "Access-Control-Allow-Methods" in headers


def test_get_client_ip():
    """Testa extração de IP do cliente."""
    from app.api.routes.webhooks import get_client_ip
    
    # Mock de request com X-Forwarded-For
    mock_request = MagicMock()
    mock_request.headers.get.side_effect = lambda key: {
        "X-Forwarded-For": "192.168.1.1, 10.0.0.1",
        "X-Real-IP": None,
    }.get(key)
    mock_request.client.host = "127.0.0.1"
    
    ip = get_client_ip(mock_request)
    assert ip == "192.168.1.1"  # Primeiro IP da lista
    
    # Mock de request com X-Real-IP
    mock_request.headers.get.side_effect = lambda key: {
        "X-Forwarded-For": None,
        "X-Real-IP": "203.0.113.1",
    }.get(key)
    
    ip = get_client_ip(mock_request)
    assert ip == "203.0.113.1"
    
    # Mock de request sem headers de proxy
    mock_request.headers.get.return_value = None
    
    ip = get_client_ip(mock_request)
    assert ip == "127.0.0.1"  # IP direto


def test_create_error_response():
    """Testa criação de resposta de erro."""
    from app.api.routes.webhooks import create_error_response
    
    response = create_error_response(
        error_message="Test error",
        error_code="TEST_ERROR",
        status_code=400,
        details={"test": "data"}
    )
    
    assert response.status_code == 400
    # Note: Em um teste real, você verificaria o conteúdo da resposta


def test_webhook_payload_validation():
    """Testa validação de payload."""
    app = create_test_app()
    client = TestClient(app)
    
    # Mock do serviço
    mock_service = MagicMock()
    mock_service.process_webhook_call = AsyncMock(return_value={
        "success": True,
        "data": {"response": "OK"},
        "execution_time_ms": 100
    })
    
    with patch('app.api.routes.webhooks.get_webhook_service', return_value=mock_service):
        agent_id = str(uuid4())
        headers = {"Authorization": "Bearer whk_valid_token"}
        
        # Payload com campos opcionais
        payload = {
            "message": "Hello",
            "data": {"key": "value"},
            "user_id": "user123",
            "session_id": "session456",
            "custom_field": "custom_value"  # Campo extra permitido
        }
        
        response = client.post(f"/webhook/{agent_id}", json=payload, headers=headers)
        
        assert response.status_code == 200
        
        # Verificar se o serviço foi chamado com o payload correto
        mock_service.process_webhook_call.assert_called_once()
        call_args = mock_service.process_webhook_call.call_args
        assert call_args[1]["payload"]["message"] == "Hello"
        assert call_args[1]["payload"]["custom_field"] == "custom_value"


if __name__ == "__main__":
    print("Executando testes do endpoint de webhook...")
    
    try:
        # Executar testes síncronos
        test_webhook_endpoint_missing_token()
        print("✓ Teste de token ausente passou")
        
        test_webhook_endpoint_invalid_token_format()
        print("✓ Teste de formato de token inválido passou")
        
        test_webhook_health_check()
        print("✓ Teste de health check passou")
        
        test_webhook_options()
        print("✓ Teste de OPTIONS passou")
        
        test_get_client_ip()
        print("✓ Teste de extração de IP passou")
        
        print("\n🎉 Testes básicos do endpoint passaram!")
        print("💡 Execute com pytest para testes completos com mocks")
        
    except Exception as e:
        print(f"\n❌ Erro nos testes: {e}")
        import traceback
        traceback.print_exc()