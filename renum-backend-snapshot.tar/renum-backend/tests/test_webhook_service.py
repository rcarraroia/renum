"""
Testes unitários para o serviço de webhook.

Este módulo contém testes para validação dos serviços de webhook,
incluindo geração de tokens, rate limiting e auditoria.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4
from datetime import datetime

from app.services.webhook_service import (
    WebhookTokenService,
    WebhookRateLimitService,
    WebhookAuditService,
    WebhookExecutionService,
    WebhookService
)
from app.models.integrations import WebhookValidationResult, IntegrationStats


class TestWebhookTokenService:
    """Testes para o serviço de tokens de webhook."""
    
    def test_generate_webhook_token(self):
        """Testa geração de token de webhook."""
        token = WebhookTokenService.generate_webhook_token()
        
        assert token.startswith("whk_")
        assert len(token) >= 36  # whk_ + 32 caracteres
        
        # Gerar outro token e verificar que são diferentes
        token2 = WebhookTokenService.generate_webhook_token()
        assert token != token2
    
    def test_validate_token_format_valid(self):
        """Testa validação de formato de token válido."""
        valid_token = "whk_" + "a" * 32
        assert WebhookTokenService.validate_token_format(valid_token) is True
    
    def test_validate_token_format_invalid_prefix(self):
        """Testa validação de token com prefixo inválido."""
        invalid_token = "invalid_" + "a" * 32
        assert WebhookTokenService.validate_token_format(invalid_token) is False
    
    def test_validate_token_format_too_short(self):
        """Testa validação de token muito curto."""
        short_token = "whk_short"
        assert WebhookTokenService.validate_token_format(short_token) is False
    
    def test_validate_token_format_none(self):
        """Testa validação de token None."""
        assert WebhookTokenService.validate_token_format(None) is False
    
    def test_validate_token_format_empty(self):
        """Testa validação de token vazio."""
        assert WebhookTokenService.validate_token_format("") is False
    
    @pytest.mark.asyncio
    async def test_validate_webhook_token_success(self):
        """Testa validação bem-sucedida de token no banco."""
        # Mock do Supabase
        mock_supabase = MagicMock()
        mock_result = MagicMock()
        mock_result.data = [{
            'integration_id': str(uuid4()),
            'client_id': str(uuid4()),
            'rate_limit_per_minute': 60,
            'is_valid': True
        }]
        mock_supabase.rpc.return_value.execute.return_value = mock_result
        
        with patch('app.services.webhook_service.SupabaseClient.get_instance') as mock_client:
            mock_client.return_value.client = mock_supabase
            result = await WebhookTokenService.validate_webhook_token(
                "whk_valid_token", 
                uuid4()
            )
            
            assert result.is_valid is True
            assert result.integration_id is not None
            assert result.client_id is not None
            assert result.rate_limit_per_minute == 60
    
    @pytest.mark.asyncio
    async def test_validate_webhook_token_invalid(self):
        """Testa validação de token inválido."""
        # Mock do Supabase retornando token inválido
        mock_supabase = MagicMock()
        mock_result = MagicMock()
        mock_result.data = [{
            'integration_id': None,
            'client_id': None,
            'rate_limit_per_minute': None,
            'is_valid': False
        }]
        mock_supabase.rpc.return_value.execute.return_value = mock_result
        
        with patch('app.services.webhook_service.SupabaseClient.get_instance') as mock_client:
            mock_client.return_value.client = mock_supabase
            result = await WebhookTokenService.validate_webhook_token(
                "whk_invalid_token", 
                uuid4()
            )
            
            assert result.is_valid is False
            assert result.integration_id is None
            assert result.client_id is None
            assert result.rate_limit_per_minute is None


class TestWebhookRateLimitService:
    """Testes para o serviço de rate limiting."""
    
    @pytest.mark.asyncio
    async def test_check_rate_limit_no_redis(self):
        """Testa rate limiting sem Redis (modo desenvolvimento)."""
        service = WebhookRateLimitService(redis_client=None)
        
        result = await service.check_rate_limit(uuid4(), 60)
        assert result is True  # Deve permitir quando Redis não disponível
    
    @pytest.mark.asyncio
    async def test_check_rate_limit_within_limit(self):
        """Testa rate limiting dentro do limite."""
        # Mock do Redis
        mock_redis = AsyncMock()
        mock_redis.get.return_value = "5"  # 5 chamadas já feitas
        mock_redis.incr.return_value = 6
        
        service = WebhookRateLimitService(redis_client=mock_redis)
        
        result = await service.check_rate_limit(uuid4(), 60)
        assert result is True
        
        # Verificar se incrementou o contador
        mock_redis.incr.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_check_rate_limit_exceeded(self):
        """Testa rate limiting excedido."""
        # Mock do Redis
        mock_redis = AsyncMock()
        mock_redis.get.return_value = "60"  # Limite já atingido
        
        service = WebhookRateLimitService(redis_client=mock_redis)
        
        result = await service.check_rate_limit(uuid4(), 60)
        assert result is False
        
        # Não deve incrementar se já excedeu
        mock_redis.incr.assert_not_called()
    
    @pytest.mark.asyncio
    async def test_check_rate_limit_first_call(self):
        """Testa primeira chamada (define TTL)."""
        # Mock do Redis
        mock_redis = AsyncMock()
        mock_redis.get.return_value = None  # Primeira chamada
        mock_redis.incr.return_value = 1
        
        service = WebhookRateLimitService(redis_client=mock_redis)
        
        result = await service.check_rate_limit(uuid4(), 60)
        assert result is True
        
        # Deve definir TTL na primeira chamada
        mock_redis.expire.assert_called_once_with(mock_redis.incr.call_args[0][0], 60)
    
    @pytest.mark.asyncio
    async def test_get_rate_limit_info(self):
        """Testa obtenção de informações de rate limit."""
        # Mock do Redis
        mock_redis = AsyncMock()
        mock_redis.get.return_value = "10"
        mock_redis.ttl.return_value = 45
        
        service = WebhookRateLimitService(redis_client=mock_redis)
        
        info = await service.get_rate_limit_info(uuid4())
        
        assert info["current_count"] == 10
        assert info["ttl"] == 45
        assert info["redis_available"] is True


class TestWebhookAuditService:
    """Testes para o serviço de auditoria."""
    
    @pytest.mark.asyncio
    async def test_log_webhook_call_success(self):
        """Testa logging bem-sucedido de chamada webhook."""
        # Mock do Supabase
        mock_supabase = MagicMock()
        mock_result = MagicMock()
        mock_result.data = [{"id": str(uuid4())}]
        mock_supabase.table.return_value.insert.return_value.execute.return_value = mock_result
        
        with patch('app.services.webhook_service.SupabaseClient.get_instance') as mock_client:
            mock_client.return_value.client = mock_supabase
            result = await WebhookAuditService.log_webhook_call(
                integration_id=uuid4(),
                request_payload={"test": "data"},
                response_payload={"result": "success"},
                status_code=200,
                execution_time_ms=150,
                ip_address="192.168.1.1",
                user_agent="TestAgent/1.0"
            )
            
            assert result is True
            mock_supabase.table.assert_called_with('renum_webhook_calls')
    
    @pytest.mark.asyncio
    async def test_get_integration_stats_success(self):
        """Testa obtenção bem-sucedida de estatísticas."""
        # Mock do Supabase
        mock_supabase = MagicMock()
        mock_result = MagicMock()
        mock_result.data = [{
            'total_calls': 100,
            'successful_calls': 95,
            'failed_calls': 5,
            'avg_execution_time_ms': 250.5,
            'last_call_at': datetime.now().isoformat()
        }]
        mock_supabase.rpc.return_value.execute.return_value = mock_result
        
        with patch('app.services.webhook_service.SupabaseClient.get_instance') as mock_client:
            mock_client.return_value.client = mock_supabase
            stats = await WebhookAuditService.get_integration_stats(uuid4(), 24)
            
            assert stats is not None
            assert stats.total_calls == 100
            assert stats.successful_calls == 95
            assert stats.failed_calls == 5
            assert stats.success_rate == 95.0
            assert stats.error_rate == 5.0
    
    @pytest.mark.asyncio
    async def test_get_integration_stats_empty(self):
        """Testa obtenção de estatísticas vazias."""
        # Mock do Supabase retornando dados vazios
        mock_supabase = MagicMock()
        mock_result = MagicMock()
        mock_result.data = []
        mock_supabase.rpc.return_value.execute.return_value = mock_result
        
        with patch('app.services.webhook_service.SupabaseClient.get_instance') as mock_client:
            mock_client.return_value.client = mock_supabase
            stats = await WebhookAuditService.get_integration_stats(uuid4(), 24)
            
            assert stats is not None
            assert stats.total_calls == 0
            assert stats.successful_calls == 0
            assert stats.failed_calls == 0


class TestWebhookExecutionService:
    """Testes para o serviço de execução."""
    
    @pytest.mark.asyncio
    async def test_execute_agent_via_webhook_success(self):
        """Testa execução bem-sucedida de agente via webhook."""
        # Mock do SunaIntegrationService
        mock_suna_service = AsyncMock()
        mock_suna_service.execute_agent_with_context.return_value = {
            "result": "success",
            "output": "Agent executed successfully"
        }
        
        with patch('app.services.webhook_service.SunaIntegrationService.get_instance', return_value=mock_suna_service):
            service = WebhookExecutionService()
            
            result = await service.execute_agent_via_webhook(
                agent_id=uuid4(),
                client_id=uuid4(),
                payload={"input": "test"}
            )
            
            assert result["result"] == "success"
            assert result["output"] == "Agent executed successfully"
            mock_suna_service.execute_agent_with_context.assert_called_once()


class TestWebhookService:
    """Testes para o serviço principal de webhook."""
    
    @pytest.mark.asyncio
    async def test_process_webhook_call_success(self):
        """Testa processamento bem-sucedido de chamada webhook."""
        # Mock do Redis
        mock_redis = AsyncMock()
        
        # Criar serviço
        service = WebhookService(redis_client=mock_redis)
        
        # Mock dos sub-serviços
        with patch.object(service.token_service, 'validate_token_format', return_value=True), \
             patch.object(service.token_service, 'validate_webhook_token') as mock_validate, \
             patch.object(service.rate_limit_service, 'check_rate_limit', return_value=True), \
             patch.object(service.execution_service, 'execute_agent_via_webhook') as mock_execute, \
             patch.object(service.audit_service, 'log_webhook_call', return_value=True):
            
            # Configurar mocks
            mock_validate.return_value = WebhookValidationResult(
                integration_id=uuid4(),
                client_id=uuid4(),
                rate_limit_per_minute=60,
                is_valid=True
            )
            
            mock_execute.return_value = {"result": "success"}
            
            # Executar teste
            result = await service.process_webhook_call(
                agent_id=uuid4(),
                token="whk_valid_token",
                payload={"input": "test"},
                ip_address="192.168.1.1",
                user_agent="TestAgent/1.0"
            )
            
            assert result["success"] is True
            assert result["data"]["result"] == "success"
            assert "execution_time_ms" in result
    
    @pytest.mark.asyncio
    async def test_process_webhook_call_invalid_token_format(self):
        """Testa processamento com formato de token inválido."""
        service = WebhookService()
        
        with patch.object(service.token_service, 'validate_token_format', return_value=False):
            with pytest.raises(ValueError, match="Formato de token inválido"):
                await service.process_webhook_call(
                    agent_id=uuid4(),
                    token="invalid_token",
                    payload={"input": "test"}
                )
    
    @pytest.mark.asyncio
    async def test_process_webhook_call_invalid_token(self):
        """Testa processamento com token inválido."""
        service = WebhookService()
        
        with patch.object(service.token_service, 'validate_token_format', return_value=True), \
             patch.object(service.token_service, 'validate_webhook_token') as mock_validate:
            
            mock_validate.return_value = WebhookValidationResult(
                integration_id=None,
                client_id=None,
                rate_limit_per_minute=None,
                is_valid=False
            )
            
            with pytest.raises(ValueError, match="Token inválido ou agente não autorizado"):
                await service.process_webhook_call(
                    agent_id=uuid4(),
                    token="whk_invalid_token",
                    payload={"input": "test"}
                )
    
    @pytest.mark.asyncio
    async def test_process_webhook_call_rate_limit_exceeded(self):
        """Testa processamento com rate limit excedido."""
        service = WebhookService()
        
        with patch.object(service.token_service, 'validate_token_format', return_value=True), \
             patch.object(service.token_service, 'validate_webhook_token') as mock_validate, \
             patch.object(service.rate_limit_service, 'check_rate_limit', return_value=False):
            
            mock_validate.return_value = WebhookValidationResult(
                integration_id=uuid4(),
                client_id=uuid4(),
                rate_limit_per_minute=60,
                is_valid=True
            )
            
            with pytest.raises(PermissionError, match="Rate limit excedido"):
                await service.process_webhook_call(
                    agent_id=uuid4(),
                    token="whk_valid_token",
                    payload={"input": "test"}
                )


def test_get_webhook_service_singleton():
    """Testa que get_webhook_service retorna singleton."""
    from app.services.webhook_service import get_webhook_service
    
    service1 = get_webhook_service()
    service2 = get_webhook_service()
    
    assert service1 is service2


if __name__ == "__main__":
    # Executar testes básicos
    print("Executando testes do serviço de webhook...")
    
    try:
        # Testes síncronos
        test_token_service = TestWebhookTokenService()
        test_token_service.test_generate_webhook_token()
        print("✓ Teste de geração de token passou")
        
        test_token_service.test_validate_token_format_valid()
        print("✓ Teste de validação de formato passou")
        
        test_get_webhook_service_singleton()
        print("✓ Teste de singleton passou")
        
        print("\n🎉 Testes síncronos passaram com sucesso!")
        print("💡 Execute com pytest para testes assíncronos completos")
        
    except Exception as e:
        print(f"\n❌ Erro nos testes: {e}")
        import traceback
        traceback.print_exc()