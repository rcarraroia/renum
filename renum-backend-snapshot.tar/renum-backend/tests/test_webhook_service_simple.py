"""
Testes simples para o serviço de webhook.
Este arquivo testa apenas as funcionalidades básicas sem dependências externas.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from uuid import uuid4


def test_webhook_token_generation():
    """Testa geração básica de tokens."""
    from app.services.webhook_service import WebhookTokenService
    
    # Gerar token
    token = WebhookTokenService.generate_webhook_token()
    
    # Verificar formato
    assert token.startswith("whk_")
    assert len(token) >= 36
    
    # Gerar outro token e verificar que são diferentes
    token2 = WebhookTokenService.generate_webhook_token()
    assert token != token2
    
    print(f"✓ Token gerado: {token[:12]}...")


def test_token_format_validation():
    """Testa validação de formato de token."""
    from app.services.webhook_service import WebhookTokenService
    
    # Token válido
    valid_token = "whk_" + "a" * 32
    assert WebhookTokenService.validate_token_format(valid_token) is True
    
    # Token inválido - prefixo errado
    invalid_token = "invalid_" + "a" * 32
    assert WebhookTokenService.validate_token_format(invalid_token) is False
    
    # Token inválido - muito curto
    short_token = "whk_short"
    assert WebhookTokenService.validate_token_format(short_token) is False
    
    # Token None
    assert WebhookTokenService.validate_token_format(None) is False
    
    # Token vazio
    assert WebhookTokenService.validate_token_format("") is False
    
    print("✓ Validação de formato funcionando")


def test_rate_limit_service_no_redis():
    """Testa rate limiting sem Redis."""
    from app.services.webhook_service import WebhookRateLimitService
    import asyncio
    
    async def run_test():
        service = WebhookRateLimitService(redis_client=None)
        
        # Deve permitir quando Redis não disponível
        result = await service.check_rate_limit(uuid4(), 60)
        assert result is True
        
        # Obter info deve retornar dados padrão
        info = await service.get_rate_limit_info(uuid4())
        assert info["current_count"] == 0
        assert info["redis_available"] is False
    
    asyncio.run(run_test())
    print("✓ Rate limiting sem Redis funcionando")


def test_webhook_service_singleton():
    """Testa que get_webhook_service retorna singleton."""
    from app.services.webhook_service import get_webhook_service
    
    service1 = get_webhook_service()
    service2 = get_webhook_service()
    
    assert service1 is service2
    print("✓ Singleton funcionando")


def test_integration_stats_calculations():
    """Testa cálculos de estatísticas."""
    from app.models.integrations import IntegrationStats
    
    # Estatísticas com dados
    stats = IntegrationStats(
        integration_id=uuid4(),
        total_calls=100,
        successful_calls=80,
        failed_calls=20
    )
    
    assert stats.success_rate == 80.0
    assert stats.error_rate == 20.0
    
    # Estatísticas vazias
    empty_stats = IntegrationStats(
        integration_id=uuid4(),
        total_calls=0,
        successful_calls=0,
        failed_calls=0
    )
    
    assert empty_stats.success_rate == 0.0
    assert empty_stats.error_rate == 0.0
    
    print("✓ Cálculos de estatísticas funcionando")


if __name__ == "__main__":
    print("Executando testes simples do serviço de webhook...")
    
    try:
        test_webhook_token_generation()
        test_token_format_validation()
        test_rate_limit_service_no_redis()
        test_webhook_service_singleton()
        test_integration_stats_calculations()
        
        print("\n🎉 Todos os testes simples passaram com sucesso!")
        print("💡 Serviços de webhook implementados e funcionando")
        
    except Exception as e:
        print(f"\n❌ Erro nos testes: {e}")
        import traceback
        traceback.print_exc()