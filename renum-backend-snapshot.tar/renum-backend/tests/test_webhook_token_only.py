"""
Teste isolado apenas para geração de tokens de webhook.
"""

import secrets


class WebhookTokenService:
    """Serviço simplificado para geração de tokens."""
    
    TOKEN_PREFIX = "whk_"
    TOKEN_LENGTH = 32
    
    @classmethod
    def generate_webhook_token(cls) -> str:
        """Gera um token único para webhook."""
        random_part = secrets.token_urlsafe(cls.TOKEN_LENGTH)
        token = f"{cls.TOKEN_PREFIX}{random_part}"
        return token
    
    @classmethod
    def validate_token_format(cls, token: str) -> bool:
        """Valida o formato do token."""
        if not token or not isinstance(token, str):
            return False
            
        if not token.startswith(cls.TOKEN_PREFIX):
            return False
            
        if len(token) < len(cls.TOKEN_PREFIX) + cls.TOKEN_LENGTH:
            return False
            
        return True


def test_token_generation():
    """Testa geração de tokens."""
    print("Testando geração de tokens...")
    
    # Gerar token
    token = WebhookTokenService.generate_webhook_token()
    print(f"Token gerado: {token}")
    
    # Verificar formato
    assert token.startswith("whk_")
    assert len(token) >= 36
    print("✓ Formato correto")
    
    # Gerar outro token e verificar que são diferentes
    token2 = WebhookTokenService.generate_webhook_token()
    assert token != token2
    print("✓ Tokens únicos")
    
    # Testar validação de formato
    assert WebhookTokenService.validate_token_format(token) is True
    print("✓ Validação de formato OK")
    
    # Testar formatos inválidos
    assert WebhookTokenService.validate_token_format("invalid") is False
    assert WebhookTokenService.validate_token_format(None) is False
    assert WebhookTokenService.validate_token_format("") is False
    print("✓ Validação de formatos inválidos OK")


if __name__ == "__main__":
    print("=" * 50)
    print("TESTE DE GERAÇÃO DE TOKENS DE WEBHOOK")
    print("=" * 50)
    
    try:
        test_token_generation()
        print("\n🎉 Teste de tokens passou com sucesso!")
        print("✅ Sub-tarefa 2.1 - Token generation implementada")
        
    except Exception as e:
        print(f"\n❌ Erro no teste: {e}")
        import traceback
        traceback.print_exc()